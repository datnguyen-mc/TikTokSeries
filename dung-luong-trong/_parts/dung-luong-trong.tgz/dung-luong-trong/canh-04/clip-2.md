A 15-second live-action film sequence of 3 shots, 16:9 widescreen, 24 fps, with hard cuts only at 5s, 9s; one place and one moment, sound and action continuous across the cuts.

[STYLE]
Photorealistic live-action near-future science-fiction drama set in Hanoi in 2041, where the city looks almost like today — narrow alleys, tangled power cables, peeling yellow collective housing blocks, street food stalls — with quiet touches of the future: slim translucent phones, small violet holograms, silent electric scooters; natural skin texture, subtle 35mm film grain, shallow depth of field, intimate handheld camera.

[LIGHTING]
Motivated, grounded light: warm sodium-orange street light and bare tungsten bulbs in the alleys and rooms, soft grey daylight through barred windows, a cool violet glow from NeuroRent devices and holograms; memory flashbacks are graded cold cyan-blue with flickering, slightly unstable light and a faint digital glitch; shadows stay soft, never murky.

[LOCATION]
The small shared courtyard of the old collective housing block at dusk: potted bonsai and chili plants, a low plastic table with plastic stools, a water tap, warm tungsten light spilling from open doorways, the blue evening sky between the buildings.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards.
- @BaTu = Bà Tư, 68, the gentle landlady of the old collective housing block; small and slightly stooped, a deeply lined kind face, cloudy warm eyes, silver hair in a low bun, a worn thin translucent patch with a faint violet light on the back of her neck; loose brown cotton blouse with cloth buttons, black silky trousers, plastic sandals.
- @Khai = Khải, 27, a broke delivery rider in Hanoi in 2041; lean wiry build, sun-browned skin, slightly long messy black hair falling over his forehead, a thin face with tired but warm dark eyes and a quick apologetic grin; faded orange delivery jacket with a plain patch without letters over a grey T-shirt, dark jeans, worn black sneakers.
Nobody else appears in the shot.

[SHOT LIST — 3 shots, hard cuts only at the marked seconds]
- Shot 1, 0–5s: 85mm close-up of the old woman speaking softly, locked off.
- Shot 2, 5–9s: 50mm over-the-shoulder shot from behind the old woman onto the young man listening, handheld.
- Shot 3, 9–15s: 40mm medium two-shot of them at the low plastic table, slow push-in.
- Continuity: continues the same moment, place and lighting as the previous shot; Shot 1 keeps the previous framing axis, no jump.
- Every cut keeps the same lighting, wardrobe, props and screen direction; whoever is speaking has the face clearly on screen in that shot.
- Eyelines: the camera stays on one side of the line between the characters (180-degree rule) so their eyes meet across the cuts.

[TIMELINE — second by second]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one clear action per second; clothing stays fully worn.
- 0–1s (Shot 1): @BaTu is already speaking slowly, waving a hand at the idea of pain.
- 1–2s (Shot 1): @BaTu keeps talking, her eyes drifting toward a doorway.
- 2–3s (Shot 1): @BaTu goes on softly, smoothing her blouse over her knees.
- 3–4s (Shot 1): @BaTu keeps speaking, her voice dropping a little.
- 4–5s (Shot 1): @BaTu finishes and closes her mouth, lips pressed together.
- 5–6s (CUT to Shot 2): @Khai leans forward and asks in an interested voice.
- 6–7s (Shot 2): @Khai keeps talking, resting his forearms on his knees.
- 7–8s (Shot 2): @Khai finishes and closes his mouth.
- 8–9s (Shot 2): @BaTu brightens and answers, counting on her fingers.
- 9–10s (CUT to Shot 3): @BaTu keeps talking, miming sleep with her palms against one cheek.
- 10–11s (Shot 3): @BaTu goes on, laughing softly.
- 11–12s (Shot 3): @BaTu keeps speaking, patting the plastic table proudly.
- 12–13s (Shot 3): @BaTu finishes and closes her mouth with a satisfied smile.
- 13–14s (Shot 3): @Khai nods slowly, thinking, mouth closed.
- 14–15s (Shot 3): @Khai looks down at his own palms while @BaTu sips from a small cup of tea. The sequence settles on this as its final frame.

[AUDIO]
- Dialogue in Vietnamese with exact lip-sync, three spoken turns in this order, each said exactly once (no subtitles):
- Turn 1, 0.4–5.7s, spoken on camera by @BaTu (old woman of 68, soft creaky gentle voice, a little breathless, speaking at a natural, even conversational pace, matter-of-fact, a little sad): "Đau gì mà đau. Hồi ông nhà bà mất đi, bà lấy tiền đâu ra mà sống hả con."
- Turn 2, 6.2–8.7s, spoken on camera by @Khai (man of 27, warm slightly husky baritone, an easygoing Hanoi street voice that turns tight and quiet when scared, speaking at a natural, even conversational pace, interested): "Thế mỗi đêm bà được bao nhiêu tiền hả bà?"
- Turn 3, 9.2–14.2s, spoken on camera by @BaTu (old woman of 68, soft creaky gentle voice, a little breathless, speaking at a natural, even conversational pace, brightening, almost proud): "Đủ tiền chợ, tiền điện. Ngủ một giấc, sáng ra là có tiền rồi, sướng lắm con ạ."
- Throughout, each speaker's face and lips stay clearly visible while speaking; only the person whose turn it is moves the lips while the other listens with the mouth closed; after the last word both close their mouths and say nothing more — no repeated words, no echo. No narrator and no other voices.
- Voices: every character speaks standard Hà Nội Northern Vietnamese (never Southern or Central accents), says each word once and clearly, and sounds clearly different from the other speaker in pitch, age and texture.
- All speech is over by 14.2s. From then until 15.0s nobody says a single word: the last beat plays as a silent reaction over ambience and sound effects, and no line or part of a line is ever said again to fill the time.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: crickets, the television through an open door, a neighbour frying garlic, the tap dripping. Ambience continues to 15.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, cuts at any moment other than the planned shot changes, jump cuts, a change of location, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, rushed delivery, slow drawn-out delivery or long pauses inside a sentence, an off-screen narrator or voice-over, Southern or Central Vietnamese accents.
