A 15-second live-action film sequence of 3 shots, 16:9 widescreen, 24 fps, with hard cuts only at 5s, 10s; one place and one moment, sound and action continuous across the cuts.

[STYLE]
Photorealistic live-action near-future science-fiction drama set in Hanoi in 2041, where the city looks almost like today — narrow alleys, tangled power cables, peeling yellow collective housing blocks, street food stalls — with quiet touches of the future: slim translucent phones, small violet holograms, silent electric scooters; natural skin texture, subtle 35mm film grain, shallow depth of field, intimate handheld camera.

[LIGHTING]
Motivated, grounded light: warm sodium-orange street light and bare tungsten bulbs in the alleys and rooms, soft grey daylight through barred windows, a cool violet glow from NeuroRent devices and holograms; memory flashbacks are graded cold cyan-blue with flickering, slightly unstable light and a faint digital glitch; shadows stay soft, never murky.

[LOCATION]
An abandoned old collective housing block in Hanoi, daytime: a dark stairwell with broken railings and damp stained walls, sealed doors along the corridor, and inside one empty apartment a torn yellow curtain on the window, a crooked lotus painting on the wall, a heavy dark wooden table with a sharp corner, grey daylight through dusty glass.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards.
- @Vy = Vy, 30, a former NeuroRent systems engineer in hiding; slim, pale skin, a chin-length black bob, dark circles under sharp guarded eyes, a small scar through her left eyebrow; oversized charcoal-grey hoodie, black cargo trousers, black boots, a battered laptop bag across her chest.
- @Khai = Khải, 27, a broke delivery rider in Hanoi in 2041; lean wiry build, sun-browned skin, slightly long messy black hair falling over his forehead, a thin face with tired but warm dark eyes and a quick apologetic grin; faded orange delivery jacket with a plain patch without letters over a grey T-shirt, dark jeans, worn black sneakers.
Nobody else appears in the shot.

[SHOT LIST — 3 shots, hard cuts only at the marked seconds]
- Shot 1, 0–5s: 85mm close-up of the woman speaking gently, locked off.
- Shot 2, 5–10s: 40mm medium shot of the young man scrambling to his knees, handheld.
- Shot 3, 10–15s: 50mm over-the-shoulder shot from behind the young man onto the woman, slow push-in.
- Continuity: continues the same moment, place and lighting as the previous shot; Shot 1 keeps the previous framing axis, no jump.
- Every cut keeps the same lighting, wardrobe, props and screen direction; whoever is speaking has the face clearly on screen in that shot.
- Eyelines: the camera stays on one side of the line between the characters (180-degree rule) so their eyes meet across the cuts.

[TIMELINE — second by second]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one clear action per second; clothing stays fully worn.
- 0–1s (Shot 1): @Vy is already speaking slowly and gently, her eyes lowered.
- 1–2s (Shot 1): @Vy keeps talking, pressing her palm flat on the laptop lid.
- 2–3s (Shot 1): @Vy goes on, rubbing her thumb in a slow circle as if wearing something away.
- 3–4s (Shot 1): @Vy keeps speaking softly.
- 4–5s (Shot 1): @Vy finishes and closes her mouth.
- 5–6s (CUT to Shot 2): @Khai rises to his knees and answers fast, upset.
- 6–7s (Shot 2): @Khai keeps talking quickly, his hands in fists.
- 7–8s (Shot 2): @Khai goes on, pointing out of the window toward the city.
- 8–9s (Shot 2): @Khai finishes and closes his mouth, breathing hard.
- 9–10s (Shot 2): @Vy answers at an even pace, quiet and sorry.
- 10–11s (CUT to Shot 3): @Vy keeps talking, looking away.
- 11–12s (Shot 3): @Vy goes on, hugging her knees.
- 12–13s (Shot 3): @Vy finishes and closes her mouth.
- 13–14s (Shot 3): @Khai sinks back down onto the floor, silent.
- 14–15s (Shot 3): The two sit without speaking as the torn curtain moves in the draught. The sequence settles on this as its final frame.

[AUDIO]
- Dialogue in Vietnamese with exact lip-sync, three spoken turns in this order, each said exactly once (no subtitles):
- Turn 1, 0.4–5.7s, spoken on camera by @Vy (woman of 30, low clipped quiet alto, guarded and precise, speaking slowly and softly, unhurried, with a short natural pause between phrases, gentle but blunt): "Bà cụ nào dán chip lâu năm, ký ức của chính bà sẽ bị đè lên, mòn dần đi."
- Turn 2, 6.2–9.4s, spoken on camera by @Khai (man of 27, warm slightly husky baritone, an easygoing Hanoi street voice that turns tight and quiet when scared, speaking quickly in short lively phrases, every word still clear, connecting the dots, upset): "Thảo nào bà Tư cứ quên trước quên sau. Bà ấy dán mười năm rồi!"
- Turn 3, 9.9–13.4s, spoken on camera by @Vy (woman of 30, low clipped quiet alto, guarded and precise, speaking at a natural, even conversational pace, quiet, sorry): "Mười năm. Chắc bà ấy chẳng còn nhớ nhiều thứ của mình nữa đâu."
- Pacing: @Vy speaks slowly and calmly, then @Khai answers quickly, then @Vy answers at an even everyday pace; the change of speed is clearly audible.
- Throughout, each speaker's face and lips stay clearly visible while speaking; only the person whose turn it is moves the lips while the other listens with the mouth closed; after the last word both close their mouths and say nothing more — no repeated words, no echo. No narrator and no other voices.
- Voices: every character speaks standard Hà Nội Northern Vietnamese (never Southern or Central accents), says each word once and clearly, and sounds clearly different from the other speaker in pitch, age and texture.
- All speech is over by 13.4s. From then until 15.0s nobody says a single word: the last beat plays as a silent reaction over ambience and sound effects, and no line or part of a line is ever said again to fill the time.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: the laptop fan, wind through the broken pane, distant children's voices from the street below. Ambience continues to 15.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, cuts at any moment other than the planned shot changes, jump cuts, a change of location, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, mumbled or swallowed words, an off-screen narrator or voice-over, Southern or Central Vietnamese accents.
