# Găng Tơ Tái Xuất — Cốt Truyện, Nhân Vật & Phim Tham Khảo

**Thể loại:** phim hành động xã hội đen, kịch bản gốc · **Thời lượng:** 27 phút (27 cảnh × 6 clip × 10 giây = 162 clip) · **Khung hình:** 16:9 · **Bối cảnh:** Hải Phòng hôm nay, cảng hư cấu "Vạn Hải"

## Phim tham khảo (chỉ lấy tinh thần thể loại, không chép cốt truyện)

| Phim | Lấy gì |
|---|---|
| *Anh Hùng Bản Sắc* (A Better Tomorrow, Ngô Vũ Sâm, 1986) | Giang hồ ra tù muốn làm lại cuộc đời; người em là cảnh sát không tha thứ; tình anh em và chữ "nghĩa". |
| *John Wick* (2014) / *Nobody* (2021) | Người đã rửa tay gác kiếm bị kéo trở lại; cả giới giang hồ chùn lại khi nghe tên "Phong Sói". |
| *Hai Phượng* (2019) | Nhịp hành động kiểu Việt; cha mẹ lao vào thế giới ngầm để cứu con. |
| *Drive* (2011) / *Baby Driver* (2017) | Nhân vật chính là **tay lái tẩu thoát**: hành động nằm ở rượt đuổi, drift, luồn lách. |

**Vì sao chọn "tay lái" chứ không phải "tay đấm":** Google Flow (Omni) chặn hoặc treo 360s mọi clip có người đánh nhau. Vì vậy toàn bộ hành động được dựng bằng rượt đuổi xe máy, ô tô, ca nô; nhảy phà; container chặn lối; đám cháy; đối đầu bằng ánh mắt; đàn em tự lùi lại; và bắt giữ khi đối tượng tự nguyện giơ tay. Không có cảnh đấm đá. Súng chỉ xuất hiện trong lời dẫn ("hắn không có súng"), không bao giờ có trên hình.

## Nhân vật (7 ảnh tham chiếu)

| Tag | Nhân vật | Vai trò |
|---|---|---|
| `@Phong` | **Phong Sói**, 45 | Tay lái tẩu thoát huyền thoại của cảng Vạn Hải; ngồi tù 12 năm vì nhận tội thay đàn em. Áo da đen, sẹo vắt qua lông mày trái. |
| `@Khang` | **Khang Hổ**, 42 | Đàn em cũ được Phong che chở, nay là ông trùm hãng vận tải; chính hắn đã báo cảnh sát đêm ấy. Vest linen kem, đồng hồ vàng. |
| `@Huy` | **Huy**, 31 | Em trai Phong, thượng úy cảnh sát hình sự mặc thường phục; ban đầu không tha thứ cho anh. |
| `@MeTu` | **Bà Tư**, 68 | Mẹ Phong, bán bánh đa cua ở ngõ chợ ven sông hơn 30 năm. |
| `@An` | **An**, 18 | Con gái Phong, lớn lên chỉ biết bố qua tấm ảnh cũ; bướng bỉnh và gan dạ, tự mở khoá thoát thân. |
| `@Tuan` | **Tuấn Còi**, 44 | Bạn chí cốt, thợ sửa xe gầm cầu, từng lái cẩu; giữ con xe đen của Phong suốt 12 năm. |
| `@OngBay` | **Ông Bảy Cảng**, 72 | Ông trùm già có "luật", bị Khang giam lỏng; giao cuốn sổ đen cho Phong đêm ấy. |

Đạo cụ chính: con xe sedan đen đời 90 đèn tròn, cuốn **sổ đen bìa da** bọc vải dầu (ghi tên những kẻ nhận tiền), chiếc bật lửa vàng của Khang, bó thư Phong viết suốt 12 năm mà chưa gửi.

## Cấu trúc 3 hồi

### Hồi 1 — Sói Về Cảng (Cảnh 01–09 · 00:00–09:00)
Mở đầu là đêm mưa 12 năm trước ở bãi container: Phong cho Khang ôm túi tiền chạy thoát, còn mình nhận hết tội. Hiện tại, Phong ra tù và Tuấn Còi lái con xe cũ đến đón. Bà Tư làm bát bánh đa cua cho con; An hỏi sao 12 năm bố không gửi lấy một lá thư. Huy cảnh cáo anh trai; Khang Hổ nghe tin "Sói về". Ông Bảy tiết lộ chính Khang đã bán đứng Phong. Phong tìm thấy cuốn sổ đen giấu sau táp-lô con xe. Khang đến quán đe doạ ("quán lợp bạt, dễ bắt lửa lắm"), và nửa đêm hôm ấy quán bốc cháy.

### Hồi 2 — Lửa Và Đường Chạy (Cảnh 10–18 · 09:00–18:00)
Phong cưỡi xe máy rượt đuổi qua phố cổ rồi phóng lên phà đúng lúc phà rời bến. Trên boong phà, Huy đọc sổ và thấy tên sếp mình, nên hai anh em bắt tay: "em lo pháp luật, anh lo đường chạy". Ba người lên kế hoạch ở gara. Phong và An ngồi trên kè biển, móc ngoéo hứa sẽ chở con ra Hà Nội nhập học. Tối đó, Khang dụ An lên chiếc xe thùng đen rồi gọi Phong: mang sổ đến bãi container lúc nửa đêm. An bị nhốt trong phòng tôn nhưng giấu được chiếc kẹp tóc. Ông Bảy gọi anh em bến cảng, và Phong Sói tái xuất.

### Hồi 3 — Đêm Cảng Cuối Cùng (Cảnh 19–27 · 18:00–27:00)
Bãi container đêm mưa, đối xứng với đêm 12 năm trước. Cuốn sổ Phong đưa ra hoá ra toàn trang trắng, vì sổ thật đã nằm trong tay đặc nhiệm. An tự mở khoá thoát ra. Tuấn lái cẩu hạ container chặn lối, hàng chục đèn pin của anh em bến cảng bật sáng, và đàn em Khang tự rút lui. Rượt đuổi trong mê cung container: An chỉ đường cho bố. Khang trốn bằng ca nô, Phong bám theo bằng xuồng dân chài đến tận rạng sáng và ép ca nô mắc cạn trên bãi bồi. Huy còng tay Khang. Một tháng sau, quán bánh đa mở lại. Cảnh cuối: con xe đen chở An ra Hà Nội, rồi một cuộc gọi lạ báo trang cuối cuốn sổ còn một cái tên, mở đường cho phần 2.

## Quy tắc sản xuất
- Nguồn duy nhất là `PHAN_CANH_OMNI.json`. Sau khi sửa: `python3 flowkit/scripts/build_omni_horror_prompts.py gang-to-tai-xuat` (thêm `--check` để chỉ kiểm tra), rồi đồng bộ DB cho UI.
- Clip VO chỉ có giọng người dẫn chuyện (nam ~45, giọng Hà Nội, trầm khàn, kể nhanh). Clip thoại chỉ có giọng người nói, nhép môi.
- Mỗi nhân vật chính được người dẫn chuyện giới thiệu đúng một lần, ở clip xuất hiện đầu tiên.
- Không chữ trên hình, không logo, không đồng hồ số; tối đa 2 người trong khung.
- Nối khung cuối clip trước chỉ khi cùng bối cảnh và không có nhân vật mới.
- Nhạc nền không đưa vào prompt. Hãy thêm nhạc hành động khi dựng hậu kỳ.
