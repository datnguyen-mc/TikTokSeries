# KỊCH BẢN CHI TIẾT 27 PHÚT: GĂNG TƠ TÁI XUẤT

- **Giọng Người Dẫn Chuyện (cố định cả 162 clip):** Vietnamese man about 45, strictly standard Hà Nội Northern accent (giọng chuẩn Hà Nội Bắc Bộ, never Southern accent) with clear six tones, deep gravelly baritone with crisp consonants, fast gripping crime-film storytelling in one continuous breath, every word spoken once and clearly, no stutter, no repeated words. Mỗi clip VO dùng **nguyên văn cùng một câu mô tả giọng** để Omni giữ một giọng duy nhất; đọc nhanh liên thanh như oan-thai-doi-me, ~4.0 âm tiết/giây, liền một hơi, không ngắt giữa câu.

## Cảnh 01: Đêm Mưa Cảng Vạn Hải, Mười Hai Năm Trước (23:00 Đêm mưa, mười hai năm trước (00:00–01:00))
- **Bối cảnh:** Bãi container cảng Vạn Hải, Hải Phòng, đêm mưa lớn.

- **[Clip 01.1](canh-01/clip-1.md)** (`VO` | `24 âm tiết`): "Mười hai năm trước, ở cảng Vạn Hải đất Hải Phòng, có một tay lái mà cả giới giang hồ đều phải kiêng nể."
- **[Clip 01.2](canh-01/clip-2.md)** (`VO` | `18 âm tiết`): "Hắn là Phong, giang hồ gọi là Phong Sói, chưa từng có chiếc xe nào đuổi kịp hắn."
- **[Clip 01.3](canh-01/clip-3.md)** (`VO` | `22 âm tiết`): "Ngồi ghế phụ là Khang, thằng đàn em hắn thương như ruột thịt, đang ôm chặt chiếc túi đen của ông trùm."
- **[Clip 01.4](canh-01/clip-4.md)** (`LIPSYNC:@Khang` | `16 âm tiết`): "Anh Phong ơi, cảnh sát chặn kín hai đầu cảng rồi, mình hết đường thật rồi!"
- **[Clip 01.5](canh-01/clip-5.md)** (`LIPSYNC:@Phong` | `17 âm tiết`): "Mày ôm túi xuống xe ngay, chạy vào lối container bên trái, tuyệt đối đừng ngoái lại."
- **[Clip 01.6](canh-01/clip-6.md)** (`VO` | `19 âm tiết`): "Đêm ấy Phong nhận hết tội về mình, ngồi tù mười hai năm, không khai ra nửa cái tên."

## Cảnh 02: Ngày Ra Tù (07:00 Sáng sớm đầu đông, hiện tại (01:00–02:00))
- **Bối cảnh:** Cổng trại giam ngoại ô Hải Phòng, con đường đất hai hàng bạch đàn.

- **[Clip 02.1](canh-02/clip-1.md)** (`VO` | `21 âm tiết`): "Mười hai năm sau, vào một buổi sáng đầu đông, cánh cổng sắt nặng nề ấy cuối cùng cũng mở ra."
- **[Clip 02.2](canh-02/clip-2.md)** (`VO` | `22 âm tiết`): "Không hoa, không người đón, hắn chỉ mang theo chiếc túi vải cũ và chiếc đồng hồ đã chết kim từ lâu."
- **[Clip 02.3](canh-02/clip-3.md)** (`VO` | `21 âm tiết`): "Hắn đứng lặng giữa con đường vắng, nhắm mắt hít thật sâu cái mùi gió mặn quen thuộc của đất Cảng."
- **[Clip 02.4](canh-02/clip-4.md)** (`VO` | `24 âm tiết`): "Rồi tiếng máy gầm vang, Tuấn Còi, thợ sửa xe gầm cầu, người bạn chí cốt duy nhất, lái con xe cũ đến đón."
- **[Clip 02.5](canh-02/clip-5.md)** (`LIPSYNC:@Tuan` | `16 âm tiết`): "Mười hai năm tao giữ con xe này bóng hơn mặt tao, lên xe đi Sói!"
- **[Clip 02.6](canh-02/clip-6.md)** (`LIPSYNC:@Phong` | `16 âm tiết`): "Đưa tao về quán mẹ, rồi tao trả mày đủ mười hai năm tiền rửa xe."

## Cảnh 03: Bát Bánh Đa Cua Của Mẹ (08:00 Sáng, quán bánh đa ven sông (02:00–03:00))
- **Bối cảnh:** Quán bánh đa cua nhỏ của bà Tư trong ngõ chợ ven sông gần cảng.

- **[Clip 03.1](canh-03/clip-1.md)** (`VO` | `24 âm tiết`): "Bà Tư, mẹ hắn, đã bán bánh đa cua ở bến sông này hơn ba mươi năm, sáng nào cũng ngóng ra đầu ngõ."
- **[Clip 03.2](canh-03/clip-2.md)** (`VO` | `23 âm tiết`): "Còn An, con gái hắn, năm nay mười tám tuổi, chỉ biết mặt bố qua một tấm ảnh cũ bà kẹp trong ví."
- **[Clip 03.3](canh-03/clip-3.md)** (`VO` | `22 âm tiết`): "Chiếc muôi trên tay bà khựng lại giữa chừng, đứa con trai bà chờ mười hai năm đang đứng ngay trước quán."
- **[Clip 03.4](canh-03/clip-4.md)** (`LIPSYNC:@MeTu` | `17 âm tiết`): "Về rồi thì ngồi xuống đây, mẹ nấu cho con bát bánh đa cua như ngày xưa."
- **[Clip 03.5](canh-03/clip-5.md)** (`LIPSYNC:@An` | `17 âm tiết`): "Chú là bố cháu thật à? Sao mười hai năm chú không gửi lấy một lá thư?"
- **[Clip 03.6](canh-03/clip-6.md)** (`LIPSYNC:@Phong` | `21 âm tiết`): "Bố viết đủ mười hai năm, nhưng không dám gửi, vì sợ con xấu hổ có một người bố đi tù."

## Cảnh 04: Người Em Cảnh Sát (10:00 Trưa âm u, bờ kè sau chợ (03:00–04:00))
- **Bối cảnh:** Bờ kè đá ven sông sau chợ, thuyền gỗ neo, cần cẩu bên kia sông.

- **[Clip 04.1](canh-04/clip-1.md)** (`VO` | `24 âm tiết`): "Huy, em trai hắn, giờ là thượng úy cảnh sát hình sự, người duy nhất trong nhà chưa bao giờ tha thứ cho hắn."
- **[Clip 04.2](canh-04/clip-2.md)** (`LIPSYNC:@Huy` | `17 âm tiết`): "Anh về thì sống cho tử tế, đừng kéo mẹ với con bé vào chuyện cũ nữa."
- **[Clip 04.3](canh-04/clip-3.md)** (`LIPSYNC:@Phong` | `16 âm tiết`): "Anh về để làm lại từ đầu, chứ không phải để làm lại những chuyện cũ."
- **[Clip 04.4](canh-04/clip-4.md)** (`LIPSYNC:@Huy` | `17 âm tiết`): "Cảng này giờ là đất của Khang Hổ, cái thằng mà anh đã ngồi tù thay đấy."
- **[Clip 04.5](canh-04/clip-5.md)** (`VO` | `22 âm tiết`): "Cái tên ấy làm quai hàm Phong siết lại, mười hai năm trời, Khang chưa từng vào thăm hắn lấy một lần."
- **[Clip 04.6](canh-04/clip-6.md)** (`LIPSYNC:@Huy` | `16 âm tiết`): "Em đang điều tra nó đấy, anh mà dính vào, em còng tay anh trước tiên."

## Cảnh 05: Đế Chế Khang Hổ (11:00 Trưa, văn phòng kính tầng thượng (04:00–05:00))
- **Bối cảnh:** Văn phòng kính tầng thượng hãng vận tải Vạn Hải nhìn xuống bãi container.

- **[Clip 05.1](canh-05/clip-1.md)** (`VO` | `20 âm tiết`): "Mười hai năm, chiếc túi đen đêm ấy đã giúp Khang dựng nên cả một đế chế trên bến cảng."
- **[Clip 05.2](canh-05/clip-2.md)** (`VO` | `25 âm tiết`): "Giờ người ta gọi gã là Khang Hổ, ông chủ hãng vận tải lớn nhất Vạn Hải, sạch sẽ từ cổ áo đến đôi giày."
- **[Clip 05.3](canh-05/clip-3.md)** (`VO` | `23 âm tiết`): "Tay đàn em cúi xuống báo tin, Phong Sói đã ra tù sáng nay và đang ngồi ở quán bánh đa của mẹ."
- **[Clip 05.4](canh-05/clip-4.md)** (`LIPSYNC:@Khang` | `21 âm tiết`): "Mười hai năm trong đó, con sói nào cũng thành chó nhà, cứ để nó ăn bát bánh đa cho yên."
- **[Clip 05.5](canh-05/clip-5.md)** (`VO` | `24 âm tiết`): "Nhưng có một thứ Khang tìm mãi không thấy, cuốn sổ đen ông trùm cũ ghi tên tất cả những kẻ từng nhận tiền."
- **[Clip 05.6](canh-05/clip-6.md)** (`LIPSYNC:@Khang` | `19 âm tiết`): "Cho người bám nó ngày đêm, cuốn sổ ấy mà lộ ra thì cả cái cảng này sụp đổ."

## Cảnh 06: Ông Trùm Bị Giam Lỏng (15:00 Chiều, biệt thự cũ trên mỏm đá (05:00–06:00))
- **Bối cảnh:** Biệt thự Pháp cũ tường vàng bong tróc trên mỏm đá nhìn ra biển.

- **[Clip 06.1](canh-06/clip-1.md)** (`VO` | `23 âm tiết`): "Phong tìm đến căn biệt thự cũ trên mỏm đá, nơi ông trùm năm xưa đang sống chẳng khác gì một tù nhân."
- **[Clip 06.2](canh-06/clip-2.md)** (`VO` | `21 âm tiết`): "Ông Bảy Cảng, người từng nắm cả bến cảng trong lòng bàn tay, giờ bị chính Khang giam lỏng ở đây."
- **[Clip 06.3](canh-06/clip-3.md)** (`LIPSYNC:@OngBay` | `16 âm tiết`): "Thằng Sói, mày gầy đi nhiều, nhưng ánh mắt vẫn y như mười hai năm trước."
- **[Clip 06.4](canh-06/clip-4.md)** (`LIPSYNC:@Phong` | `17 âm tiết`): "Ông Bảy, đêm ấy cảnh sát biết trước đường con xe chạy, là ai đã báo tin?"
- **[Clip 06.5](canh-06/clip-5.md)** (`LIPSYNC:@OngBay` | `17 âm tiết`): "Là thằng Khang, nó gọi cảnh sát bán đứng mày, để ngồi vào chiếc ghế của tao."
- **[Clip 06.6](canh-06/clip-6.md)** (`LIPSYNC:@OngBay` | `19 âm tiết`): "Cuốn sổ đen tao giao mày đêm ấy, nếu còn giữ, nó sẽ trả lại cho mày tất cả."

## Cảnh 07: Bí Mật Trong Con Xe Cũ (20:00 Tối, gara gầm cầu (06:00–07:00))
- **Bối cảnh:** Gara sửa xe dưới gầm cầu bê tông.

- **[Clip 07.1](canh-07/clip-1.md)** (`VO` | `19 âm tiết`): "Tối hôm đó ở gara gầm cầu, Phong bảo Tuấn tháo tung bảng táp-lô của con xe cũ."
- **[Clip 07.2](canh-07/clip-2.md)** (`VO` | `22 âm tiết`): "Sau tấm nhựa phủ bụi mười hai năm, một gói vải dầu nằm im lìm, bọc kín cuốn sổ bìa da đen."
- **[Clip 07.3](canh-07/clip-3.md)** (`LIPSYNC:@Tuan` | `18 âm tiết`): "Mười hai năm tao chở cả quả bom đi rửa xe mỗi tuần mà không hề hay biết."
- **[Clip 07.4](canh-07/clip-4.md)** (`LIPSYNC:@Phong` | `17 âm tiết`): "Đây không phải bom, đây là cái giá để mẹ tao với con bé được sống yên."
- **[Clip 07.5](canh-07/clip-5.md)** (`VO` | `21 âm tiết`): "Ngoài kia, một chiếc xe đen tắt đèn đã nằm im ở chân dốc cầu từ lúc nào không ai hay."
- **[Clip 07.6](canh-07/clip-6.md)** (`VO` | `18 âm tiết`): "Phong không quay đầu, chỉ liếc qua gương chiếu hậu, và hắn biết cuộc săn đã bắt đầu."

## Cảnh 08: Lời Mời Của Khang Hổ (07:30 Sáng hôm sau, quán bánh đa (07:00–08:00))
- **Bối cảnh:** Quán bánh đa cua nhỏ của bà Tư trong ngõ chợ ven sông gần cảng.

- **[Clip 08.1](canh-08/clip-1.md)** (`VO` | `19 âm tiết`): "Sáng hôm sau, Khang Hổ đích thân ghé quán, hai tay đàn em đứng chắn kín lối ra vào."
- **[Clip 08.2](canh-08/clip-2.md)** (`VO` | `22 âm tiết`): "Bà Tư bưng bát bánh đa ra, đôi tay già run đến mức nước dùng sóng sánh tràn cả ra mép bát."
- **[Clip 08.3](canh-08/clip-3.md)** (`LIPSYNC:@Khang` | `18 âm tiết`): "Bánh đa cua bà Tư vẫn ngon nhất cảng, tiếc là quán lợp bạt, dễ bắt lửa lắm."
- **[Clip 08.4](canh-08/clip-4.md)** (`VO` | `19 âm tiết`): "Phong bước vào, kéo ghế ngồi đối diện, hai người đàn ông nhìn nhau qua làn khói nước dùng."
- **[Clip 08.5](canh-08/clip-5.md)** (`LIPSYNC:@Khang` | `16 âm tiết`): "Anh Phong, đưa em cuốn sổ, em trả anh cả một đời giàu sang yên ổn."
- **[Clip 08.6](canh-08/clip-6.md)** (`LIPSYNC:@Phong` | `17 âm tiết`): "Mày lấy của tao mười hai năm rồi, Khang, đừng hòng lấy thêm một ngày nào nữa."

## Cảnh 09: Đêm Lửa Ngõ Chợ (00:30 Nửa đêm, ngõ chợ (08:00–09:00))
- **Bối cảnh:** Ngõ chợ ven sông lúc nửa đêm, nhà ống hai tầng phía sau quán bánh đa.

- **[Clip 09.1](canh-09/clip-1.md)** (`VO` | `21 âm tiết`): "Nửa đêm hôm ấy, mùi xăng lẩn khuất trong ngõ chợ, rồi một đốm lửa nhỏ bùng lên trên mái bạt."
- **[Clip 09.2](canh-09/clip-2.md)** (`VO` | `20 âm tiết`): "Phong choàng tỉnh vì khói, hắn lao xuống cầu thang, gọi tên mẹ và con trong ánh lửa đỏ rực."
- **[Clip 09.3](canh-09/clip-3.md)** (`VO` | `21 âm tiết`): "An dìu bà nội ra lối cửa sau, khăn ướt che kín mặt, sau lưng là tiếng kính vỡ lách tách."
- **[Clip 09.4](canh-09/clip-4.md)** (`VO` | `21 âm tiết`): "Phong ôm bình cứu hỏa xông ra, dập từng mảng lửa trước khi nó kịp liếm sang dãy nhà bên cạnh."
- **[Clip 09.5](canh-09/clip-5.md)** (`LIPSYNC:@Huy` | `16 âm tiết`): "Anh thấy chưa, anh mới về được hai ngày, nhà mình đã thành ra thế này!"
- **[Clip 09.6](canh-09/clip-6.md)** (`LIPSYNC:@Phong` | `20 âm tiết`): "Đám lửa này là lời nhắn của Khang, và lần này anh sẽ trả lời nó theo cách của anh."

## Cảnh 10: Rượt Đuổi Phố Cổ (09:00 Sáng, phố cổ Hải Phòng (09:00–10:00))
- **Bối cảnh:** Phố cổ Hải Phòng với dãy nhà Pháp vàng, ngõ hẹp và bến phà ven sông.

- **[Clip 10.1](canh-10/clip-1.md)** (`VO` | `19 âm tiết`): "Sáng hôm sau, Phong giấu cuốn sổ trong áo khoác, phóng chiếc xe máy cũ của Tuấn ra phố."
- **[Clip 10.2](canh-10/clip-2.md)** (`VO` | `19 âm tiết`): "Ba chiếc xe máy đen lập tức rồ ga bám theo, những gương mặt quen của băng Khang Hổ."
- **[Clip 10.3](canh-10/clip-3.md)** (`VO` | `21 âm tiết`): "Phong ngoặt gấp vào con ngõ chỉ vừa một vai người, lách qua dãy chậu cây không sượt một chiếc lá."
- **[Clip 10.4](canh-10/clip-4.md)** (`VO` | `19 âm tiết`): "Đám đàn em lao theo, trượt bánh vào chồng thúng tre, rau củ lăn tung tóe khắp mặt ngõ."
- **[Clip 10.5](canh-10/clip-5.md)** (`VO` | `19 âm tiết`): "Hắn phóng thẳng lên chiếc phà vừa rời bến, bánh sau chạm boong đúng lúc cầu phà kéo lên."
- **[Clip 10.6](canh-10/clip-6.md)** (`VO` | `21 âm tiết`): "Trên bờ, ba chiếc xe đen phanh kít, chỉ còn biết đứng nhìn con sói già lướt đi giữa dòng sông."

## Cảnh 11: Hai Anh Em Trên Boong Phà (09:30 Sáng, phà qua sông (10:00–11:00))
- **Bối cảnh:** Boong phà cũ chở xe qua sông rộng nước nâu, buổi sáng âm u.

- **[Clip 11.1](canh-11/clip-1.md)** (`VO` | `20 âm tiết`): "Trên boong phà, Huy đã đứng chờ sẵn từ lúc nào, cậu bám theo anh trai suốt từ sáng sớm."
- **[Clip 11.2](canh-11/clip-2.md)** (`LIPSYNC:@Huy` | `17 âm tiết`): "Anh định một mình chơi với cả băng Khang Hổ à? Đưa cuốn sổ đây cho em."
- **[Clip 11.3](canh-11/clip-3.md)** (`LIPSYNC:@Phong` | `19 âm tiết`): "Em mở trang cuối ra mà đọc, rồi hãy nói với anh em còn tin được ai trong đồn."
- **[Clip 11.4](canh-11/clip-4.md)** (`VO` | `21 âm tiết`): "Huy lật đến trang cuối, mặt cậu tái đi, cái tên quen thuộc nhất lại nằm ngay ở dòng đầu tiên."
- **[Clip 11.5](canh-11/clip-5.md)** (`LIPSYNC:@Huy` | `16 âm tiết`): "Là sếp trực tiếp của em, hèn gì mấy lần đột kích đều về tay trắng."
- **[Clip 11.6](canh-11/clip-6.md)** (`LIPSYNC:@Phong` | `16 âm tiết`): "Vậy thì làm theo cách của anh, em lo pháp luật, còn anh lo đường chạy."

## Cảnh 12: Kế Hoạch Gầm Cầu (21:00 Tối, gara gầm cầu (11:00–12:00))
- **Bối cảnh:** Gara sửa xe dưới gầm cầu bê tông, buổi tối.

- **[Clip 12.1](canh-12/clip-1.md)** (`VO` | `21 âm tiết`): "Đêm đó gara gầm cầu sáng đèn, những chiếc cờ lê trên nắp capô đã thành tấm bản đồ bến cảng."
- **[Clip 12.2](canh-12/clip-2.md)** (`LIPSYNC:@Huy` | `18 âm tiết`): "Đêm mai tàu của Khang nhổ neo, em đã gọi được đội đặc nhiệm từ Hà Nội xuống."
- **[Clip 12.3](canh-12/clip-3.md)** (`LIPSYNC:@Phong` | `17 âm tiết`): "Anh sẽ làm mồi, kéo hết lũ đàn em ra khỏi bãi, em chỉ việc mở container."
- **[Clip 12.4](canh-12/clip-4.md)** (`LIPSYNC:@Tuan` | `17 âm tiết`): "Lần này tao lái cẩu cho mày, cái bãi container đó tao thuộc như lòng bàn tay."
- **[Clip 12.5](canh-12/clip-5.md)** (`VO` | `19 âm tiết`): "Phong nhìn hai người, lần đầu tiên sau mười hai năm, hắn thấy mình không còn đơn độc nữa."
- **[Clip 12.6](canh-12/clip-6.md)** (`LIPSYNC:@Huy` | `17 âm tiết`): "Anh hứa với em một điều thôi, xong việc này, anh phải sống cho mẹ được vui."

## Cảnh 13: Bố Và Con Gái (17:30 Chiều tà, kè biển (12:00–13:00))
- **Bối cảnh:** Kè biển bê tông dài ven thành phố cảng lúc hoàng hôn.

- **[Clip 13.1](canh-13/clip-1.md)** (`VO` | `21 âm tiết`): "Chiều hôm ấy, Phong đón An tan trường, hai bố con ngồi trên kè biển trước giờ cô đi học thêm."
- **[Clip 13.2](canh-13/clip-2.md)** (`VO` | `21 âm tiết`): "An mở một lá thư trong bó thư cũ, bố viết nó vào đúng ngày sinh nhật năm cô lên bảy."
- **[Clip 13.3](canh-13/clip-3.md)** (`LIPSYNC:@An` | `17 âm tiết`): "Bố ơi, sao bố lại nhận tội thay người ta? Bố không thương con với bà à?"
- **[Clip 13.4](canh-13/clip-4.md)** (`LIPSYNC:@Phong` | `18 âm tiết`): "Vì bố tưởng mình đang cứu một đứa em, nhưng hóa ra bố đã rước sói vào nhà."
- **[Clip 13.5](canh-13/clip-5.md)** (`LIPSYNC:@An` | `19 âm tiết`): "Thi xong đại học, bố chở con ra Hà Nội bằng con xe đen ấy nhé, bố hứa đi!"
- **[Clip 13.6](canh-13/clip-6.md)** (`VO` | `21 âm tiết`): "Hắn ngoắc tay hứa, không biết rằng chỉ vài giờ nữa thôi, lời hứa ấy suýt thành lời hứa cuối cùng."

## Cảnh 14: Chiếc Xe Thùng Đen (19:00 Tối, cổng lò luyện thi (13:00–14:00))
- **Bối cảnh:** Cổng một lò luyện thi trên phố, đầu buổi tối.

- **[Clip 14.1](canh-14/clip-1.md)** (`VO` | `20 âm tiết`): "Tối hôm ấy, trước cổng lò luyện thi, một chiếc xe thùng đen đã đỗ sẵn dưới gốc cây bàng."
- **[Clip 14.2](canh-14/clip-2.md)** (`VO` | `21 âm tiết`): "An bước ra cổng, vừa nhắn tin cho bố thì cửa xe trượt mở, một gã áo đen khẽ cúi chào."
- **[Clip 14.3](canh-14/clip-3.md)** (`LIPSYNC:@An` | `16 âm tiết`): "Các anh là ai? Tránh ra, bố tôi đang đến đón tôi ngay bây giờ đấy!"
- **[Clip 14.4](canh-14/clip-4.md)** (`LIPSYNC:@Khang` | `18 âm tiết`): "Cháu An, chú là bạn cũ của bố cháu, lên xe đi, chú đưa cháu đi gặp bố."
- **[Clip 14.5](canh-14/clip-5.md)** (`VO` | `22 âm tiết`): "An nhìn quanh, ba gã áo đen đã đứng kín sau lưng, cô siết chặt quai ba lô rồi bước lên xe."
- **[Clip 14.6](canh-14/clip-6.md)** (`VO` | `25 âm tiết`): "Cửa xe đóng lại, chiếc xe thùng lặng lẽ khuất vào bóng tối, chỉ còn chiếc điện thoại sáng màn hình nằm dưới lòng đường."

## Cảnh 15: Cuộc Gọi Từ Kẻ Phản Bội (21:00 Đêm, trước lò luyện thi & văn phòng Khang (14:00–15:00))
- **Bối cảnh:** Phố trước cổng lò luyện thi lúc đêm muộn; văn phòng kính tầng thượng của Khang ban đêm.

- **[Clip 15.1](canh-15/clip-1.md)** (`VO` | `21 âm tiết`): "Phong đợi mãi trước cổng lò luyện thi, rồi hắn nhặt lên chiếc điện thoại vỡ màn hình của con gái."
- **[Clip 15.2](canh-15/clip-2.md)** (`VO` | `23 âm tiết`): "Đúng lúc đó, chính chiếc điện thoại ấy rung lên, và giọng nói đầu dây bên kia hắn nhớ suốt mười hai năm."
- **[Clip 15.3](canh-15/clip-3.md)** (`LIPSYNC:@Khang` | `18 âm tiết`): "Anh Phong, con bé đang ngồi uống trà với em, mang cuốn sổ đến bãi container một mình."
- **[Clip 15.4](canh-15/clip-4.md)** (`LIPSYNC:@Phong` | `20 âm tiết`): "Mày động vào một sợi tóc của con tao, cả cái cảng này sẽ không còn chỗ cho mày trốn."
- **[Clip 15.5](canh-15/clip-5.md)** (`LIPSYNC:@Khang` | `17 âm tiết`): "Nửa đêm nay, bãi container cũ, đúng chỗ anh bị bắt năm xưa, em sẽ chờ anh."
- **[Clip 15.6](canh-15/clip-6.md)** (`VO` | `22 âm tiết`): "Hắn cúp máy, siết chặt chiếc điện thoại, lần đầu tiên sau mười hai năm, đôi mắt con sói già đỏ lên."

## Cảnh 16: An Trong Căn Phòng Tôn (22:00 Đêm, phòng điều hành bằng container (15:00–16:00))
- **Bối cảnh:** Phòng điều hành làm từ container ở góc khuất bãi cảng, ban đêm.

- **[Clip 16.1](canh-16/clip-1.md)** (`VO` | `21 âm tiết`): "Ở một góc khuất của bãi container, An bị giữ trong căn phòng tôn, chỉ có chiếc đèn tuýp chập chờn."
- **[Clip 16.2](canh-16/clip-2.md)** (`VO` | `21 âm tiết`): "Cô bé không khóc, chỉ lặng lẽ nhìn qua khe cửa, đếm từng bước chân của bọn canh gác bên ngoài."
- **[Clip 16.3](canh-16/clip-3.md)** (`LIPSYNC:@Khang` | `17 âm tiết`): "Bố cháu là người giỏi nhất chú từng biết, chỉ tiếc là ông ấy quá tin người."
- **[Clip 16.4](canh-16/clip-4.md)** (`LIPSYNC:@An` | `18 âm tiết`): "Bố tôi sẽ đến, chú cứ chờ mà xem, lần này người phải chạy trốn là chú đấy."
- **[Clip 16.5](canh-16/clip-5.md)** (`VO` | `21 âm tiết`): "Khang bật cười bỏ đi, gã không để ý An đã kịp giấu chiếc kẹp tóc đen vào lòng bàn tay."
- **[Clip 16.6](canh-16/clip-6.md)** (`VO` | `19 âm tiết`): "Cô bé nhớ lời bố dặn chiều nay, gặp nguy thì đừng hoảng, hãy bình tĩnh tìm đường thoát."

## Cảnh 17: Anh Em Bến Cảng (22:30 Đêm, sân thượng đồn, biệt thự Ông Bảy, xóm thợ cảng (16:00–17:00))
- **Bối cảnh:** Sân thượng đồn cảnh sát, trong con xe đen, hiên biệt thự Ông Bảy và xóm nhà tôn ven cảng — ban đêm.

- **[Clip 17.1](canh-17/clip-1.md)** (`LIPSYNC:@Huy` | `19 âm tiết`): "Cuốn sổ thật em đã giao cho đặc nhiệm, anh cầm chân thằng Khang đến lúc bọn em tới."
- **[Clip 17.2](canh-17/clip-2.md)** (`VO` | `20 âm tiết`): "Phong không chờ ai cả, hắn quay xe thẳng lên mỏm đá, nơi ông trùm già vẫn đang thức đợi."
- **[Clip 17.3](canh-17/clip-3.md)** (`VO` | `20 âm tiết`): "Ông Bảy chống gậy đứng dậy, lần đầu sau nhiều năm, ông nhấc chiếc điện thoại bàn đã phủ bụi."
- **[Clip 17.4](canh-17/clip-4.md)** (`LIPSYNC:@OngBay` | `19 âm tiết`): "Anh em bến cảng đâu, thằng Sói về rồi, đêm nay ai còn nhớ ơn nó thì ra bãi."
- **[Clip 17.5](canh-17/clip-5.md)** (`LIPSYNC:@OngBay` | `16 âm tiết`): "Mày đi đi, đêm nay cả bến cảng này sẽ đứng sau lưng mày, Sói ạ."
- **[Clip 17.6](canh-17/clip-6.md)** (`VO` | `25 âm tiết`): "Trong những dãy nhà tôn ven cảng, từng ngọn đèn pin lần lượt bật sáng, những người thợ bốc vác già lặng lẽ bước ra."

## Cảnh 18: Sói Tái Xuất (23:00 Đêm, nhà bà Tư & gara gầm cầu (17:00–18:00))
- **Bối cảnh:** Gian nhà ống ám khói sau quán bánh đa, rồi gara gầm cầu, ban đêm.

- **[Clip 18.1](canh-18/clip-1.md)** (`VO` | `20 âm tiết`): "Trước khi đi, Phong ghé về nhà, mẹ hắn đã thắp sẵn ba nén nhang trên bàn thờ ám khói."
- **[Clip 18.2](canh-18/clip-2.md)** (`LIPSYNC:@MeTu` | `18 âm tiết`): "Con đi đưa cái An về, mẹ nấu sẵn nồi bánh đa, chờ hai bố con về ăn."
- **[Clip 18.3](canh-18/clip-3.md)** (`LIPSYNC:@Phong` | `18 âm tiết`): "Mẹ ơi, con nợ mẹ mười hai năm, đêm nay con xin trả trước một phần, mẹ nhé."
- **[Clip 18.4](canh-18/clip-4.md)** (`VO` | `25 âm tiết`): "Ở gara, Phong bọc cuốn sổ vào tấm vải dầu cũ, rồi đeo đôi găng tay lái đã nằm trong hộc xe mười hai năm."
- **[Clip 18.5](canh-18/clip-5.md)** (`LIPSYNC:@Tuan` | `17 âm tiết`): "Xăng đầy bình, lốp mới thay, con xe này chỉ chờ đúng đêm nay thôi, Sói ạ!"
- **[Clip 18.6](canh-18/clip-6.md)** (`VO` | `16 âm tiết`): "Tiếng máy gầm lên dưới gầm cầu, và Phong Sói chính thức tái xuất giang hồ."

## Cảnh 19: Bãi Container Nửa Đêm (00:00 Nửa đêm, bãi container (18:00–19:00))
- **Bối cảnh:** Bãi container cảng Vạn Hải lúc nửa đêm, mưa lớn, y như đêm định mệnh mười hai năm trước.

- **[Clip 19.1](canh-19/clip-1.md)** (`VO` | `18 âm tiết`): "Nửa đêm, mưa lại trút xuống bãi container, y hệt cái đêm định mệnh mười hai năm trước."
- **[Clip 19.2](canh-19/clip-2.md)** (`VO` | `20 âm tiết`): "Con xe đen chậm rãi lăn bánh giữa hai dãy container, đèn pha rọi thẳng vào hàng xe của Khang."
- **[Clip 19.3](canh-19/clip-3.md)** (`VO` | `22 âm tiết`): "Khang đứng chờ dưới ánh đèn cẩu, ung dung che ô, còn An vẫn bị nhốt đâu đó giữa mê cung container."
- **[Clip 19.4](canh-19/clip-4.md)** (`LIPSYNC:@Phong` | `17 âm tiết`): "Thả con bé ra, sổ ở đây, chuyện của người lớn thì mày với tao giải quyết."
- **[Clip 19.5](canh-19/clip-5.md)** (`LIPSYNC:@Khang` | `17 âm tiết`): "Anh vẫn thế, anh Phong, vẫn tin rằng cứ nhận hết về mình là xong mọi chuyện."
- **[Clip 19.6](canh-19/clip-6.md)** (`VO` | `21 âm tiết`): "Phong đặt cuốn sổ lên nắp capô, hai người đàn ông bước chậm về phía nhau giữa màn mưa trắng xóa."

## Cảnh 20: Cuốn Sổ Trắng (00:10 Nửa đêm, bãi container & phòng tôn (19:00–20:00))
- **Bối cảnh:** Lối container trước mũi xe Phong; căn phòng tôn nơi An bị giữ; lối hẹp giữa các dãy container.

- **[Clip 20.1](canh-20/clip-1.md)** (`VO` | `19 âm tiết`): "Khang cầm cuốn sổ lên, lật vội từng trang dưới ánh đèn pha, rồi bàn tay gã khựng lại."
- **[Clip 20.2](canh-20/clip-2.md)** (`VO` | `18 âm tiết`): "Từng trang giấy đều trắng tinh, cuốn sổ thật đã nằm trong tay đội đặc nhiệm từ chiều."
- **[Clip 20.3](canh-20/clip-3.md)** (`LIPSYNC:@Khang` | `19 âm tiết`): "Anh dám lừa em à, anh Phong? Anh quên con gái anh đang ở trong tay ai rồi sao?"
- **[Clip 20.4](canh-20/clip-4.md)** (`LIPSYNC:@Phong` | `18 âm tiết`): "Mười hai năm trước tao dạy mày chạy, đêm nay tao dạy mày cách đứng lại chịu tội."
- **[Clip 20.5](canh-20/clip-5.md)** (`VO` | `21 âm tiết`): "Cùng lúc ấy, trong căn phòng tôn, chiếc kẹp tóc của An xoay thêm một vòng, và ổ khóa bật mở."
- **[Clip 20.6](canh-20/clip-6.md)** (`VO` | `21 âm tiết`): "Cô bé lách ra ngoài, men theo bóng tối giữa những dãy container, chạy về phía ánh đèn pha của bố."

## Cảnh 21: Đèn Cẩu Bật Sáng (00:15 Nửa đêm, bãi container (20:00–21:00))
- **Bối cảnh:** Bãi container dưới cần cẩu giàn vàng; buồng lái cần cẩu của Tuấn trên cao.

- **[Clip 21.1](canh-21/clip-1.md)** (`LIPSYNC:@Khang` | `16 âm tiết`): "Lục tung cả cái bãi này lên, tìm con bé về đây cho tao, nhanh lên!"
- **[Clip 21.2](canh-21/clip-2.md)** (`VO` | `19 âm tiết`): "Đúng lúc ấy, trên buồng lái cần cẩu cao ba mươi mét, Tuấn Còi kéo mạnh cần điều khiển."
- **[Clip 21.3](canh-21/clip-3.md)** (`VO` | `23 âm tiết`): "Một chiếc container khổng lồ từ từ hạ xuống chặn ngang lối ra, đám đàn em khựng lại, lùi dần về phía sau."
- **[Clip 21.4](canh-21/clip-4.md)** (`VO` | `20 âm tiết`): "Rồi hàng chục ngọn đèn pin bật sáng trên nóc container, anh em bến cảng của Ông Bảy đã đến."
- **[Clip 21.5](canh-21/clip-5.md)** (`VO` | `21 âm tiết`): "Đám đàn em nhìn nhau, rồi từng đứa một lặng lẽ lùi vào bóng tối, bỏ mặc Khang đứng một mình."
- **[Clip 21.6](canh-21/clip-6.md)** (`VO` | `22 âm tiết`): "An chạy ra từ giữa hai dãy container, lao vào vòng tay bố, Phong mở cửa đưa con bé lên ghế phụ."

## Cảnh 22: Rượt Đuổi Mê Cung Container (00:20 Nửa đêm, mê cung container (21:00–22:00))
- **Bối cảnh:** Mê cung container trong mưa và bên trong con xe đen của Phong.

- **[Clip 22.1](canh-22/clip-1.md)** (`VO` | `22 âm tiết`): "Hai chiếc xe đen của đám đàn em trung thành cuối cùng rồ máy, đèn pha quét loang loáng giữa màn mưa."
- **[Clip 22.2](canh-22/clip-2.md)** (`LIPSYNC:@Phong` | `18 âm tiết`): "Thắt dây an toàn vào con, bố cho con xem vì sao người ta gọi bố là Sói."
- **[Clip 22.3](canh-22/clip-3.md)** (`VO` | `20 âm tiết`): "Con xe đen lướt vào mê cung container, drift qua từng khúc cua hẹp chỉ cách vách thép vài phân."
- **[Clip 22.4](canh-22/clip-4.md)** (`LIPSYNC:@An` | `16 âm tiết`): "Bố ơi, bên trái có khe hở vừa đúng một thân xe, bố lách vào đi!"
- **[Clip 22.5](canh-22/clip-5.md)** (`VO` | `20 âm tiết`): "Hai chiếc xe đuổi theo không kịp phanh, trượt dài trên mặt đường ướt rồi lao vào đống pallet gỗ."
- **[Clip 22.6](canh-22/clip-6.md)** (`VO` | `21 âm tiết`): "Trong gương chiếu hậu chỉ còn khói và mưa, nhưng phía cầu tàu, một chiếc ca nô trắng vừa nổ máy."

## Cảnh 23: Ca Nô Trốn Chạy (00:40 Đêm, cầu tàu & mặt sông (22:00–23:00))
- **Bối cảnh:** Cầu tàu gỗ và bê tông ở rìa cảng trong mưa; mặt sông đen kịt.

- **[Clip 23.1](canh-23/clip-1.md)** (`VO` | `21 âm tiết`): "Khang bỏ lại tất cả, nhảy xuống chiếc ca nô trắng, rồ máy lao ra cửa sông trong màn mưa đêm."
- **[Clip 23.2](canh-23/clip-2.md)** (`LIPSYNC:@Phong` | `17 âm tiết`): "Con ở lại đây chờ chú Tuấn, bố phải đi đòi lại món nợ mười hai năm."
- **[Clip 23.3](canh-23/clip-3.md)** (`LIPSYNC:@An` | `17 âm tiết`): "Bố phải về đấy, bố còn nợ con một chuyến ra Hà Nội bằng con xe đen."
- **[Clip 23.4](canh-23/clip-4.md)** (`VO` | `21 âm tiết`): "Phong nhảy xuống chiếc xuồng máy của dân chài neo bên cầu tàu, giật dây khởi động một lần là nổ."
- **[Clip 23.5](canh-23/clip-5.md)** (`VO` | `20 âm tiết`): "Hai con thuyền xé màn mưa trên mặt sông đen kịt, đèn cảng hai bên bờ lùi lại vun vút."
- **[Clip 23.6](canh-23/clip-6.md)** (`VO` | `22 âm tiết`): "Hắn không có súng, không có đàn em, chỉ có đôi tay lái mà cả đất Cảng này từng phải kiêng nể."

## Cảnh 24: Bình Minh Trên Bãi Bồi (05:30 Rạng sáng, cửa sông (23:00–24:00))
- **Bối cảnh:** Cửa sông lúc rạng sáng, nước ròng để lộ bãi bùn mênh mông và rừng đước.

- **[Clip 24.1](canh-24/clip-1.md)** (`VO` | `22 âm tiết`): "Cuộc rượt đuổi kéo dài đến tận rạng sáng, khi nước ròng để lộ những bãi bùn mênh mông ở cửa sông."
- **[Clip 24.2](canh-24/clip-2.md)** (`VO` | `19 âm tiết`): "Khang ngoái lại nhìn chiếc xuồng nhỏ vẫn bám sau lưng, gã bẻ lái gấp về phía rừng đước."
- **[Clip 24.3](canh-24/clip-3.md)** (`VO` | `23 âm tiết`): "Phong lớn lên ở bến sông này, hắn thuộc từng luồng lạch, và hắn cố tình ép ca nô về phía bãi cạn."
- **[Clip 24.4](canh-24/clip-4.md)** (`VO` | `21 âm tiết`): "Chiếc ca nô trắng trườn lên bãi bùn, mũi cắm sâu xuống, động cơ rú lên một hồi rồi tắt lịm."
- **[Clip 24.5](canh-24/clip-5.md)** (`VO` | `22 âm tiết`): "Khang lội bùn đến đầu gối, bộ vest kem lấm lem, ngẩng lên thì bốn phía đã có ca nô cảnh sát."
- **[Clip 24.6](canh-24/clip-6.md)** (`LIPSYNC:@Huy` | `17 âm tiết`): "Khang, đội đặc nhiệm đây, giơ hai tay lên, cuộc chạy trốn của anh kết thúc rồi."

## Cảnh 25: Còng Tay Bên Bãi Bồi (06:00 Sáng, bãi bồi cửa sông (24:00–25:00))
- **Bối cảnh:** Bãi bùn cửa sông lúc mặt trời mọc, ca nô trắng mắc cạn, ca nô cảnh sát ghé sát.

- **[Clip 25.1](canh-25/clip-1.md)** (`VO` | `19 âm tiết`): "Ông trùm cảng Vạn Hải giơ hai tay lên trời, đứng giữa bãi bùn như một kẻ trắng tay."
- **[Clip 25.2](canh-25/clip-2.md)** (`VO` | `19 âm tiết`): "Huy bước xuống bùn, chiếc còng số tám khép lại trên cổ tay đeo đồng hồ vàng của gã."
- **[Clip 25.3](canh-25/clip-3.md)** (`LIPSYNC:@Khang` | `16 âm tiết`): "Anh tưởng anh thắng à, anh Phong? Anh vẫn chỉ là một thằng tù mà thôi."
- **[Clip 25.4](canh-25/clip-4.md)** (`LIPSYNC:@Phong` | `19 âm tiết`): "Tao không cần thắng, tao chỉ lấy lại cái tên mà mày đã bán đi mười hai năm trước."
- **[Clip 25.5](canh-25/clip-5.md)** (`VO` | `23 âm tiết`): "Sáng hôm ấy, theo cuốn sổ đen, mười bảy cái tên trong thành phố bị gọi lên, có cả sếp cũ của Huy."
- **[Clip 25.6](canh-25/clip-6.md)** (`LIPSYNC:@Huy` | `18 âm tiết`): "Anh à, lần này anh không có tội gì để nhận cả, về nhà thôi, mẹ đang chờ."

## Cảnh 26: Bát Bánh Đa Đoàn Viên (08:00 Một tháng sau, quán bánh đa mới (25:00–26:00))
- **Bối cảnh:** Quán bánh đa cua của bà Tư dựng lại trong ngõ chợ ven sông, một tháng sau.

- **[Clip 26.1](canh-26/clip-1.md)** (`VO` | `21 âm tiết`): "Một tháng sau, quán bánh đa của bà Tư mở cửa lại, mái bạt mới tinh, nồi nước dùng đỏ au."
- **[Clip 26.2](canh-26/clip-2.md)** (`VO` | `21 âm tiết`): "Bà Tư múc bát đầu tiên, An bưng ra bàn, hai bà cháu cười như chưa từng có đêm lửa nào."
- **[Clip 26.3](canh-26/clip-3.md)** (`VO` | `21 âm tiết`): "Phong và Huy ngồi chung một bàn, hai anh em lần đầu cùng ăn sáng với nhau sau mười hai năm."
- **[Clip 26.4](canh-26/clip-4.md)** (`LIPSYNC:@Huy` | `18 âm tiết`): "Anh này, sếp mới của em hỏi anh có muốn về dạy lái xe cho đội không đấy."
- **[Clip 26.5](canh-26/clip-5.md)** (`LIPSYNC:@Phong` | `21 âm tiết`): "Anh chỉ nhận dạy đúng một học trò thôi, con bé nhà mình, nó đang chờ anh chở ra Hà Nội."
- **[Clip 26.6](canh-26/clip-6.md)** (`VO` | `22 âm tiết`): "Ở bàn bên, Ông Bảy và Tuấn Còi nâng chén trà, bến cảng Vạn Hải lần đầu tiên thật sự bình yên."

## Cảnh 27: Con Đường Ra Hà Nội (07:00 Sáng hôm sau, quốc lộ (26:00–27:00))
- **Bối cảnh:** Quốc lộ thẳng tắp giữa đồng lúa xanh hướng về Hà Nội, và bên trong con xe đen.

- **[Clip 27.1](canh-27/clip-1.md)** (`VO` | `21 âm tiết`): "Sáng hôm sau, con xe đen lăn bánh trên quốc lộ, chở cô tân sinh viên ra Hà Nội nhập học."
- **[Clip 27.2](canh-27/clip-2.md)** (`LIPSYNC:@An` | `17 âm tiết`): "Bố ơi, bố đi chậm thôi, con muốn chuyến đi này kéo dài thêm một chút nữa."
- **[Clip 27.3](canh-27/clip-3.md)** (`VO` | `21 âm tiết`): "Phong bật cười, lần đầu tiên sau mười hai năm, con sói già lái xe mà không phải chạy trốn ai."
- **[Clip 27.4](canh-27/clip-4.md)** (`VO` | `20 âm tiết`): "Nhưng rồi chiếc điện thoại cũ trong túi áo da rung lên, một số máy lạ không hiển thị tên."
- **[Clip 27.5](canh-27/clip-5.md)** (`VO` | `23 âm tiết`): "Giọng bên kia chỉ nói một câu, trang cuối cuốn sổ đen còn một cái tên mà đội đặc nhiệm chưa đọc tới."
- **[Clip 27.6](canh-27/clip-6.md)** (`VO` | `18 âm tiết`): "Găng tơ đã tái xuất, nhưng cuộc chơi thật sự, có lẽ bây giờ mới chỉ bắt đầu."
