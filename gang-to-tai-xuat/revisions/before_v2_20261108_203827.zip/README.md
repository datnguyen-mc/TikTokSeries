# Găng Tơ Tái Xuất (27 Cảnh × 6 Clips × 10s = 27 Phút)

- **Giọng Người Dẫn Chuyện (cố định cả 162 clip):** Vietnamese man about 45, strictly standard Hà Nội Northern accent (giọng chuẩn Hà Nội Bắc Bộ, never Southern accent) with clear six tones, deep gravelly baritone with crisp consonants, fast gripping crime-film storytelling in one continuous breath, every word spoken once and clearly, no stutter, no repeated words. Mỗi clip VO dùng **nguyên văn cùng một câu mô tả giọng** để Omni giữ một giọng duy nhất; đọc nhanh liên thanh như oan-thai-doi-me, ~4.0 âm tiết/giây, liền một hơi, không ngắt giữa câu.
- **Thoại nhân vật (Lip-Sync):** clip thoại chỉ mô tả giọng của người nói, không có người dẫn chuyện; mặt và môi người nói luôn thấy rõ.
- **Mật độ:** 162 clips × 10s — 98 clip VO + 64 clip thoại; lời nói nằm trong khung riêng bắt đầu từ 0.4s (xem cột *Khung thoại*).
- **Cách tạo trên Flow (runner tự chọn):** 39 clip nối khung cuối (Frames — cùng bối cảnh, không có nhân vật mới), 99 clip ảnh nhân vật (Ingredients), 24 clip chỉ text. Tắt nối khung: `FLOWKIT_CHAIN_LAST_FRAME=0`.
- **Hậu kỳ runner:** clip VO được tăng tốc giọng thêm 1.18x khi tải về (`FLOWKIT_VOICE_TEMPO` mặc định 1.18, đặt 1.0 để tắt), giữ nguyên khung hình 10s; clip lip-sync không bao giờ bị tăng tốc để khớp khẩu hình.
- **Màu phim & ánh sáng:** Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.
- **Nguồn dữ liệu:** `PHAN_CANH_OMNI.json` → `python3 flowkit/scripts/build_omni_horror_prompts.py gang-to-tai-xuat` sinh lại toàn bộ clip, README, kịch bản.

## Danh Sách 27 Cảnh (162 Clips × 10s)

| Cảnh | Tiêu Đề | Thời Gian | Đường Dẫn |
|---|---|---|---|
| **Cảnh 01** | Đêm Mưa Cảng Vạn Hải, Mười Hai Năm Trước | 23:00 Đêm mưa, mười hai năm trước (00:00–01:00) | [`canh-01/`](canh-01/README.md) |
| **Cảnh 02** | Ngày Ra Tù | 07:00 Sáng sớm đầu đông, hiện tại (01:00–02:00) | [`canh-02/`](canh-02/README.md) |
| **Cảnh 03** | Bát Bánh Đa Cua Của Mẹ | 08:00 Sáng, quán bánh đa ven sông (02:00–03:00) | [`canh-03/`](canh-03/README.md) |
| **Cảnh 04** | Người Em Cảnh Sát | 10:00 Trưa âm u, bờ kè sau chợ (03:00–04:00) | [`canh-04/`](canh-04/README.md) |
| **Cảnh 05** | Đế Chế Khang Hổ | 11:00 Trưa, văn phòng kính tầng thượng (04:00–05:00) | [`canh-05/`](canh-05/README.md) |
| **Cảnh 06** | Ông Trùm Bị Giam Lỏng | 15:00 Chiều, biệt thự cũ trên mỏm đá (05:00–06:00) | [`canh-06/`](canh-06/README.md) |
| **Cảnh 07** | Bí Mật Trong Con Xe Cũ | 20:00 Tối, gara gầm cầu (06:00–07:00) | [`canh-07/`](canh-07/README.md) |
| **Cảnh 08** | Lời Mời Của Khang Hổ | 07:30 Sáng hôm sau, quán bánh đa (07:00–08:00) | [`canh-08/`](canh-08/README.md) |
| **Cảnh 09** | Đêm Lửa Ngõ Chợ | 00:30 Nửa đêm, ngõ chợ (08:00–09:00) | [`canh-09/`](canh-09/README.md) |
| **Cảnh 10** | Rượt Đuổi Phố Cổ | 09:00 Sáng, phố cổ Hải Phòng (09:00–10:00) | [`canh-10/`](canh-10/README.md) |
| **Cảnh 11** | Hai Anh Em Trên Boong Phà | 09:30 Sáng, phà qua sông (10:00–11:00) | [`canh-11/`](canh-11/README.md) |
| **Cảnh 12** | Kế Hoạch Gầm Cầu | 21:00 Tối, gara gầm cầu (11:00–12:00) | [`canh-12/`](canh-12/README.md) |
| **Cảnh 13** | Bố Và Con Gái | 17:30 Chiều tà, kè biển (12:00–13:00) | [`canh-13/`](canh-13/README.md) |
| **Cảnh 14** | Chiếc Xe Thùng Đen | 19:00 Tối, cổng lò luyện thi (13:00–14:00) | [`canh-14/`](canh-14/README.md) |
| **Cảnh 15** | Cuộc Gọi Từ Kẻ Phản Bội | 21:00 Đêm, trước lò luyện thi & văn phòng Khang (14:00–15:00) | [`canh-15/`](canh-15/README.md) |
| **Cảnh 16** | An Trong Căn Phòng Tôn | 22:00 Đêm, phòng điều hành bằng container (15:00–16:00) | [`canh-16/`](canh-16/README.md) |
| **Cảnh 17** | Anh Em Bến Cảng | 22:30 Đêm, sân thượng đồn, biệt thự Ông Bảy, xóm thợ cảng (16:00–17:00) | [`canh-17/`](canh-17/README.md) |
| **Cảnh 18** | Sói Tái Xuất | 23:00 Đêm, nhà bà Tư & gara gầm cầu (17:00–18:00) | [`canh-18/`](canh-18/README.md) |
| **Cảnh 19** | Bãi Container Nửa Đêm | 00:00 Nửa đêm, bãi container (18:00–19:00) | [`canh-19/`](canh-19/README.md) |
| **Cảnh 20** | Cuốn Sổ Trắng | 00:10 Nửa đêm, bãi container & phòng tôn (19:00–20:00) | [`canh-20/`](canh-20/README.md) |
| **Cảnh 21** | Đèn Cẩu Bật Sáng | 00:15 Nửa đêm, bãi container (20:00–21:00) | [`canh-21/`](canh-21/README.md) |
| **Cảnh 22** | Rượt Đuổi Mê Cung Container | 00:20 Nửa đêm, mê cung container (21:00–22:00) | [`canh-22/`](canh-22/README.md) |
| **Cảnh 23** | Ca Nô Trốn Chạy | 00:40 Đêm, cầu tàu & mặt sông (22:00–23:00) | [`canh-23/`](canh-23/README.md) |
| **Cảnh 24** | Bình Minh Trên Bãi Bồi | 05:30 Rạng sáng, cửa sông (23:00–24:00) | [`canh-24/`](canh-24/README.md) |
| **Cảnh 25** | Còng Tay Bên Bãi Bồi | 06:00 Sáng, bãi bồi cửa sông (24:00–25:00) | [`canh-25/`](canh-25/README.md) |
| **Cảnh 26** | Bát Bánh Đa Đoàn Viên | 08:00 Một tháng sau, quán bánh đa mới (25:00–26:00) | [`canh-26/`](canh-26/README.md) |
| **Cảnh 27** | Con Đường Ra Hà Nội | 07:00 Sáng hôm sau, quốc lộ (26:00–27:00) | [`canh-27/`](canh-27/README.md) |
