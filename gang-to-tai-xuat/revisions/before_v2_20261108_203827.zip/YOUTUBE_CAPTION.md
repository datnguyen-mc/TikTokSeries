# 🎬 YOUTUBE CAPTION & METADATA — "GĂNG TƠ TÁI XUẤT" (FULL 27 CẢNH)

## 1. TIÊU ĐỀ YOUTUBE ĐỀ XUẤT (CHỌN 1 TRONG 3)

1. **GĂNG TƠ TÁI XUẤT (Full) | Ngồi Tù 12 Năm Thay Đàn Em, Ngày Ra Tù Mới Biết Bị Bán Đứng | Phim Hành Động Việt Nam**
2. **Găng Tơ Tái Xuất — Phong Sói Trở Lại Cảng Hải Phòng | Rượt Đuổi Nghẹt Thở Trong Mê Cung Container**
3. **[PHIM HÀNH ĐỘNG] Găng Tơ Tái Xuất | Tay Lái Huyền Thoại, Cuốn Sổ Đen & Đêm Mưa Định Mệnh Ở Bến Cảng**

---

## 2. MÔ TẢ VIDEO YOUTUBE (COPY & PASTE)

```text
🚗 GĂNG TƠ TÁI XUẤT (Full 27 Phút) — Phim Hành Động Xã Hội Đen Đất Cảng
🎙️ Giọng kể chuẩn miền Bắc, trầm khàn, dồn dập
🎧 Nên đeo tai nghe để nghe rõ tiếng máy gầm, tiếng mưa trên mái container và những cú drift trong đêm...

📖 TÓM TẮT:
Mười hai năm trước, Phong Sói là tay lái chưa ai đuổi kịp ở cảng Vạn Hải.
Đêm bị cảnh sát vây, anh cho đàn em Khang ôm túi chạy thoát rồi một mình nhận hết tội.
Ngày ra tù, Phong mới biết chính Khang đã báo tin bán đứng mình để ngồi vào ghế ông trùm.
Quán bánh đa cua của mẹ bốc cháy, con gái An bị đưa đi trên chiếc xe thùng đen —
và Khang chỉ muốn một thứ: cuốn sổ đen ghi tên mọi kẻ từng nhận tiền trên bến cảng.
Cùng em trai cảnh sát, người bạn thợ máy và anh em bến cảng năm xưa,
Phong Sói tái xuất: không bằng nắm đấm, mà bằng đôi tay lái mà cả đất Cảng từng kiêng nể.

⏱️ MỤC LỤC:
00:00 Đêm mưa cảng Vạn Hải, mười hai năm trước
01:00 Ngày ra tù
02:00 Bát bánh đa cua của mẹ
03:00 Người em cảnh sát
04:00 Đế chế Khang Hổ
05:00 Ông trùm bị giam lỏng
06:00 Bí mật trong con xe cũ
07:00 Lời mời của Khang Hổ
08:00 Đêm lửa ngõ chợ
09:00 Rượt đuổi phố cổ
10:00 Hai anh em trên boong phà
11:00 Kế hoạch gầm cầu
12:00 Bố và con gái
13:00 Chiếc xe thùng đen
14:00 Cuộc gọi từ kẻ phản bội
15:00 An trong căn phòng tôn
16:00 Anh em bến cảng
17:00 Sói tái xuất
18:00 Bãi container nửa đêm
19:00 Cuốn sổ trắng
20:00 Đèn cẩu bật sáng
21:00 Rượt đuổi mê cung container
22:00 Ca nô trốn chạy
23:00 Bình minh trên bãi bồi
24:00 Còng tay bên bãi bồi
25:00 Bát bánh đa đoàn viên
26:00 Con đường ra Hà Nội

⚠️ Phim hư cấu, kịch bản gốc. Mọi nhân vật, địa danh (cảng Vạn Hải) và tình tiết đều do tác giả sáng tác; mọi sự trùng hợp là ngẫu nhiên.

#gangtotaixuat #phimhanhdong #phimxahoiden #giangho #haiphong #phimvietnam #ruotduoi
```

---

## 3. TAGS

găng tơ tái xuất, phim hành động, phim xã hội đen, giang hồ đất cảng, hải phòng, phim hành động việt nam, rượt đuổi, tay lái, ra tù, tình anh em, cha con, bến cảng, phim ngắn việt nam, giọng kể miền bắc
