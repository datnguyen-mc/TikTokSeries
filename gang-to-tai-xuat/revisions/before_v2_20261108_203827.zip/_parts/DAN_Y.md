# Găng Tơ Tái Xuất — dàn ý clip (nguồn cho người viết JSON)

27 cảnh × 6 clip × 10s = 27 phút. Hải Phòng hiện tại, cảng hư cấu "Vạn Hải". Mỗi clip: `[chars] | speaker | lời thoại nháp | hình ảnh`.
`cont` = clip nối tiếp liền mạch clip trước (chỉ hợp lệ khi chars ⊆ chars clip trước, không rỗng, cùng setting). Còn lại là `cut`.

## Đạo cụ khoá — dùng NGUYÊN VĂN chuỗi tiếng Anh này mỗi khi nhắc tới
- CAR = "the restored glossy black 1990s sedan with round headlights"
- BIKE = "Tuấn's old dark-green motorbike with a round headlamp" (trong beat không ghi tên, ghi "the old dark-green motorbike with a round headlamp")
- LEDGER = "the black leather ledger wrapped in oilcloth" (khi đã mở bọc: "the black leather ledger")
- SUV = "black SUVs with tinted windows" (số ít: "a black SUV with tinted windows")
- VAN = "a black van with tinted windows"
- LIGHTER = "a gold lighter"
- LETTERS = "a bundle of old sealed envelopes tied with brown string"
- SPEEDBOAT = "a white speedboat"; SKIFF = "a small wooden fishing skiff with an outboard motor"
- CRANE = "a towering yellow gantry crane"
- HENCHMEN (extras) = "henchmen in black shirts" — không bao giờ chạm vào ai, chỉ đứng chắn, đi theo, lùi lại.

## HỒI 1 — SÓI VỀ CẢNG (Cảnh 01–09)

### C01 — Đêm Mưa Cảng Vạn Hải, Mười Hai Năm Trước | "23:00 Đêm mưa, mười hai năm trước (00:00–01:00)"
Location: Bãi container cảng Vạn Hải, Hải Phòng, đêm mưa lớn. Axis: xe chạy từ trái sang phải màn hình dọc các lối container. Props: CAR, túi vải đen.
Setting: A vast container port yard at night in heavy rain: towering stacks of rust-red, blue and green shipping containers forming narrow lanes, yellow gantry cranes lit by sodium floodlights, deep puddles reflecting distant red and blue police lights.
1. [] | NAR | Mười hai năm trước, ở cảng Vạn Hải đất Hải Phòng, có một tay lái mà cả giới giang hồ đều phải kiêng nể. | aerial mưa đêm, cẩu, đèn pha CAR lao giữa container, đèn cảnh sát xa.
2. [@Phong] | NAR | Hắn là Phong, giang hồ gọi là Phong Sói, chưa từng có chiếc xe nào đuổi kịp hắn. | trong CAR: gạt mưa, tay Phong vững trên vô lăng, drift qua khúc cua.
3. [@Phong,@Khang] | NAR | Ngồi ghế phụ là Khang, thằng đàn em hắn thương như ruột thịt, đang ôm chặt chiếc túi đen của ông trùm. | two-shot qua kính chắn gió, Khang ôm túi vải đen, ngoái nhìn sau.
4. [@Phong,@Khang] cont | @Khang | Anh Phong ơi, cảnh sát chặn kín hai đầu cảng rồi, mình hết đường thật rồi! | Khang ngoái qua kính sau, ánh đèn đỏ xanh quét qua mặt.
5. [@Phong,@Khang] cont | @Phong | Mày ôm túi xuống xe, chạy lối container bên trái, tuyệt đối đừng ngoái lại. | xe chậm lại trong khe tối, Khang mở cửa, lách ra mưa, biến mất giữa container.
6. [@Phong] cut | NAR | Đêm ấy Phong nhận hết tội về mình, ngồi tù mười hai năm, không khai ra nửa cái tên. | CAR dừng giữa vòng đèn xanh đỏ, Phong bước ra mưa, giơ hai bàn tay mở trống trước ngực, bình thản.

### C02 — Ngày Ra Tù | "07:00 Sáng sớm đầu đông, hiện tại (01:00–02:00)"
Location: Cổng trại giam ngoại ô, đường đất hai hàng bạch đàn. Axis: cổng ở cuối hình, đường chạy về phía máy quay. Props: túi vải cũ, đồng hồ thép đứng kim, CAR.
Setting: Early winter morning mist outside a remote detention center: a long high grey concrete wall, a heavy dark-green steel gate, an empty muddy road lined with tall eucalyptus trees, pale low sun.
1. [] | NAR | Mười hai năm sau, vào một buổi sáng đầu đông, cánh cổng sắt nặng nề ấy cuối cùng cũng mở ra. | cổng xanh rêu từ từ mở, sương.
2. [@Phong] | NAR | Không hoa, không người đón, hắn chỉ mang theo chiếc túi vải cũ và chiếc đồng hồ đã chết kim từ lâu. | Phong bước ra, nhìn mặt đồng hồ đứng kim.
3. [@Phong] cont | NAR | Hắn đứng lặng giữa con đường vắng, nhắm mắt hít thật sâu cái mùi gió mặn quen thuộc của đất Cảng. | nhắm mắt, ngực phồng lên, gió lay áo.
4. [@Tuan] cut | NAR | Rồi tiếng máy gầm vang, Tuấn Còi, thợ sửa xe gầm cầu, người bạn chí cốt duy nhất, lái con xe cũ đến đón. | CAR gầm đến, trượt ngang dừng lại, Tuấn cười toe sau vô lăng.
5. [@Tuan,@Phong] cut | @Tuan | Mười hai năm tao giữ con xe này bóng hơn mặt tao, lên xe đi Sói! | Tuấn đứng cạnh nắp capô vỗ nhẹ, Phong đối diện.
6. [@Phong,@Tuan] cont | @Phong | Đưa tao về quán mẹ, rồi tao trả mày đủ mười hai năm tiền rửa xe. | Phong nhếch môi cười, mở cửa ghế phụ.

### C03 — Bát Bánh Đa Cua Của Mẹ | "08:00 Sáng, quán bánh đa ven sông (02:00–03:00)"
Location: Quán bánh đa cua nhỏ của bà Tư trong ngõ chợ ven sông gần cảng. Axis: máy quay trong quán nhìn ra ngõ, nồi nước dùng bên trái. Props: nồi nhôm nước dùng cua, muôi, bát, LETTERS.
Setting: Morning at a small open-front crab-noodle stall in a riverside market lane of Hải Phòng: a steaming aluminum pot of orange-red crab broth, low red plastic stools, small green plastic tables, a canvas awning, the river and distant cranes beyond.
1. [@MeTu] | NAR | Bà Tư, mẹ hắn, đã bán bánh đa cua ở bến sông này hơn ba mươi năm, sáng nào cũng ngóng ra đầu ngõ. | nồi bốc khói; bà Tư múc nước dùng, ngóng ra ngõ.
2. [@An] cut | NAR | Còn An, con gái hắn, năm nay mười tám tuổi, chỉ biết mặt bố qua một tấm ảnh cũ bà kẹp trong ví. | An bưng bát ra bàn, buộc lại tóc đuôi ngựa.
3. [@MeTu,@Phong] cut | NAR | Chiếc muôi trên tay bà khựng lại giữa chừng, đứa con trai bà chờ mười hai năm đang đứng ngay trước quán. | Phong xuất hiện dưới mái bạt; muôi khựng giữa không trung.
4. [@MeTu,@Phong] cont | @MeTu | Về rồi thì ngồi xuống đây, mẹ nấu cho con bát bánh đa cua như ngày xưa. | bà đặt muôi xuống, mắt đỏ hoe, kéo ghế nhựa.
5. [@An,@Phong] cut | @An | Chú là bố cháu thật à? Sao mười hai năm chú không gửi lấy một lá thư? | An đứng đối diện Phong, ôm khay, cằm hất lên.
6. [@Phong,@An] cont | @Phong | Bố viết đủ mười hai năm, nhưng không dám gửi, vì sợ con xấu hổ có một người bố đi tù. | Phong đặt LETTERS lên bàn, đẩy nhẹ về phía An.

### C04 — Người Em Cảnh Sát | "10:00 Trưa âm u, bờ kè sau chợ (03:00–04:00)"
Location: Bờ kè đá ven sông sau chợ, thuyền gỗ neo, cẩu bên kia sông. Axis: sông bên phải màn hình, Huy bên trái, Phong bên phải. Props: xe máy của Huy, cọc neo gỉ.
Setting: Overcast late morning on a stone riverside embankment behind the market: a low stone wall, moored wooden fishing boats, rusty bollards, container cranes across the wide brown river.
1. [@Huy] | NAR | Huy, em trai hắn, giờ là thượng úy cảnh sát hình sự, người duy nhất trong nhà chưa bao giờ tha thứ cho hắn. | Huy dựng xe máy, sải bước dọc bờ kè.
2. [@Huy,@Phong] cut | @Huy | Anh về thì sống cho tử tế, đừng kéo mẹ với con bé vào chuyện cũ nữa. | đứng đối mặt cạnh cọc neo.
3. [@Phong,@Huy] cont | @Phong | Anh về để làm lại từ đầu, chứ không phải để làm lại những chuyện cũ. |
4. [@Huy,@Phong] cont | @Huy | Cảng này giờ là đất của Khang Hổ, cái thằng mà anh đã ngồi tù thay đấy. | Huy hất cằm về phía cẩu bên kia sông.
5. [@Phong] cut | NAR | Cái tên ấy làm quai hàm Phong siết lại, mười hai năm trời, Khang chưa từng vào thăm hắn lấy một lần. | cận mặt, quai hàm, vết sẹo lông mày.
6. [@Huy] cut | @Huy | Em đang điều tra nó, anh mà dính vào, em còng tay anh trước tiên. | Huy bước đi, ngoảnh lại qua vai.

### C05 — Đế Chế Khang Hổ | "11:00 Trưa, văn phòng kính tầng thượng (04:00–05:00)"
Location: Văn phòng kính tầng thượng hãng vận tải Vạn Hải nhìn xuống bãi container. Axis: cửa kính phía sau bàn, Khang quay lưng ra cảng. Props: bàn gỗ, mô hình tàu hàng trong tủ kính, két sắt âm tường.
Setting: A top-floor glass office of a shipping company overlooking the container port: floor-to-ceiling windows, gantry cranes and stacked containers below, a dark polished wood desk, black leather chairs, a model cargo ship in a glass case, a steel wall safe.
1. [] | NAR | Mười hai năm, chiếc túi đen đêm ấy đã giúp Khang dựng nên cả một đế chế trên bến cảng. | aerial áp sát tòa nhà kính trên bãi cảng.
2. [@Khang] | NAR | Giờ người ta gọi gã là Khang Hổ, ông chủ hãng vận tải lớn nhất Vạn Hải, sạch sẽ từ cổ áo đến đôi giày. | Khang chỉnh măng sét bên cửa kính.
3. [@Khang] cont + extras "a henchman in a black shirt with a shaved head" | NAR | Tay đàn em cúi xuống báo tin, Phong Sói đã ra tù sáng nay và đang ngồi ở quán bánh đa của mẹ. | đàn em bước vào cúi đầu.
4. [@Khang] cont | @Khang | Mười hai năm trong đó, con sói nào cũng thành chó nhà, cứ để nó ăn bát bánh đa cho yên. | cười khẩy, xoay ghế.
5. [@Khang] cut | NAR | Nhưng có một thứ Khang tìm mãi không thấy, cuốn sổ đen ông trùm cũ ghi tên tất cả những kẻ từng nhận tiền. | Khang mở két sắt, ngăn nhung trống.
6. [@Khang] cont | @Khang | Cho người bám nó ngày đêm, cuốn sổ ấy mà lộ ra thì cả cái cảng này sụp đổ. | đóng két, nhìn xuống cảng.

### C06 — Ông Trùm Bị Giam Lỏng | "15:00 Chiều, biệt thự cũ trên mỏm đá (05:00–06:00)"
Location: Biệt thự Pháp cũ tường vàng bong tróc trên mỏm đá nhìn ra biển. Axis: hiên nhà, biển phía sau bên trái. Props: ghế mây, gậy gỗ chạm, chuỗi hạt.
Setting: Afternoon at an old French colonial seaside villa with peeling mustard-yellow walls on a rocky headland: a shaded veranda with rattan chairs, a frangipani tree, wrought-iron railings, a grey sea below.
1. [] + extras "a bored guard in a black shirt leaning on the iron gate" | NAR | Phong tìm đến căn biệt thự cũ trên mỏm đá, nơi ông trùm năm xưa đang sống chẳng khác gì một tù nhân. |
2. [@OngBay] | NAR | Ông Bảy Cảng, người từng nắm cả bến cảng trong lòng bàn tay, giờ bị chính Khang giam lỏng ở đây. | ông ngồi ghế mây, lần chuỗi hạt.
3. [@OngBay,@Phong] cut | @OngBay | Thằng Sói, mày gầy đi nhiều, nhưng ánh mắt vẫn y như mười hai năm trước. | Phong bước lên hiên.
4. [@Phong,@OngBay] cont | @Phong | Ông Bảy, đêm ấy cảnh sát biết trước đường con xe chạy, là ai đã báo tin? |
5. [@OngBay,@Phong] cont | @OngBay | Là thằng Khang, nó gọi cảnh sát bán đứng mày, để ngồi vào chiếc ghế của tao. | gõ gậy xuống sàn.
6. [@OngBay,@Phong] cont | @OngBay | Cuốn sổ đen tao giao mày đêm ấy, nếu còn giữ, nó sẽ trả lại cho mày tất cả. | Phong khựng lại, mắt liếc về phía xa (nhớ ra con xe).

### C07 — Bí Mật Trong Con Xe Cũ | "20:00 Tối, gara gầm cầu (06:00–07:00)"
Location: Gara sửa xe dưới gầm cầu bê tông. Axis: CAR giữa gara, cửa gara bên phải mở ra dốc cầu. Props: CAR, tua vít, đèn lồng sắt, LEDGER.
Setting: Night inside a cluttered repair garage under a concrete highway bridge: hanging tools, stacked tires, an oil-stained concrete floor, a single caged work lamp, rain dripping from the bridge edge outside, the restored glossy black 1990s sedan with round headlights parked in the middle.
1. [@Tuan,@Phong] | NAR | Tối hôm đó ở gara gầm cầu, Phong bảo Tuấn tháo tung bảng táp-lô của con xe cũ. | Tuấn tháo tấm nhựa táp-lô, Phong soi đèn pin.
2. [@Phong] cont | NAR | Sau tấm nhựa phủ bụi mười hai năm, một gói vải dầu nằm im lìm, bọc kín cuốn sổ bìa da đen. | tay Phong lấy LEDGER ra, mở lớp vải dầu.
3. [@Tuan,@Phong] cut | @Tuan | Mười hai năm tao chở cả quả bom đi rửa xe mỗi tuần mà không hề hay biết. | Tuấn gãi đầu, cười méo.
4. [@Phong,@Tuan] cont | @Phong | Đây không phải bom, đây là cái giá để mẹ tao với con bé được sống yên. | Phong nhét sổ vào trong áo da.
5. [] cut, setting riêng "Night at the foot of the bridge ramp outside the garage in light rain, a parked black SUV with tinted windows, its lights off" + extras "two shadowy figures inside the SUV, faces unseen" | NAR | Ngoài kia, một chiếc xe đen tắt đèn đã nằm im ở chân dốc cầu từ lúc nào không ai hay. |
6. [@Phong] cut | NAR | Phong không quay đầu, chỉ liếc qua gương chiếu hậu, và hắn biết cuộc săn đã bắt đầu. | đôi mắt Phong trong gương chiếu hậu của CAR.

### C08 — Lời Mời Của Khang Hổ | "07:30 Sáng hôm sau, quán bánh đa (07:00–08:00)"
Location/Setting: như C03 (quán bánh đa). Axis: Khang ngồi bên trái bàn, Phong bên phải.
1. [@Khang] + extras "two henchmen in black shirts standing at the stall entrance" | NAR | Sáng hôm sau, Khang Hổ đích thân ghé quán, hai tay đàn em đứng chắn kín lối ra vào. | Khang ngồi ghế nhựa đỏ, vest kem.
2. [@MeTu] cut | NAR | Bà Tư bưng bát bánh đa ra, đôi tay già run đến mức nước dùng sóng sánh tràn cả ra mép bát. |
3. [@Khang] cut | @Khang | Bánh đa cua bà Tư vẫn ngon nhất cảng, tiếc là quán lợp bạt, dễ bắt lửa lắm. | Khang ngước nhìn mái bạt.
4. [@Phong,@Khang] cut | NAR | Phong bước vào, kéo ghế ngồi đối diện, hai người đàn ông nhìn nhau qua làn khói nước dùng. |
5. [@Khang,@Phong] cont | @Khang | Anh Phong, đưa em cuốn sổ, em trả anh cả một đời giàu sang yên ổn. |
6. [@Phong,@Khang] cont | @Phong | Mày lấy của tao mười hai năm rồi, Khang, đừng hòng lấy thêm một ngày nào nữa. | Khang đứng dậy, để LIGHTER lại trên bàn.

### C09 — Đêm Lửa Ngõ Chợ | "00:30 Nửa đêm, ngõ chợ (08:00–09:00)"
Location: Ngõ chợ ven sông nửa đêm, nhà ống hai tầng sau quán. Props: mái bạt, bình cứu hỏa đỏ, khăn ướt.
Setting: Midnight in the narrow riverside market lane: shuttered stalls, the crab-noodle stall's canvas awning, a two-storey tube house behind it, sodium streetlight, orange firelight and drifting smoke.
1. [] | NAR | Nửa đêm hôm ấy, mùi xăng lẩn khuất trong ngõ chợ, rồi một đốm lửa nhỏ bùng lên trên mái bạt. | ngõ vắng, lửa cam leo lên mái bạt (không thấy người phóng hỏa).
2. [@Phong] cut, setting riêng "Inside the narrow staircase of the tube house at midnight, drifting smoke and an orange glow from below" | NAR | Phong choàng tỉnh vì khói, hắn lao xuống cầu thang, gọi tên mẹ và con trong ánh lửa đỏ rực. |
3. [@MeTu,@An] cut, setting riêng "A dark back alley behind the tube house at midnight, smoke drifting out of an open back door" | NAR | An dìu bà nội ra lối cửa sau, khăn ướt che kín mặt, sau lưng là tiếng kính vỡ lách tách. |
4. [@Phong] cut | NAR | Phong ôm bình cứu hỏa xông ra, dập từng mảng lửa trước khi nó kịp liếm sang dãy nhà bên cạnh. | bọt trắng phủ lên lửa.
5. [@Huy,@Phong] cut | @Huy | Anh thấy chưa, anh mới về được hai ngày, nhà mình đã thành ra thế này! | mái bạt cháy đen, khói, ánh đèn xe cứu hỏa nhấp nháy xa.
6. [@Phong,@Huy] cont | @Phong | Đám lửa này là lời nhắn của Khang, và lần này anh sẽ trả lời nó theo cách của anh. | Phong nhặt LIGHTER từ gầm bàn cháy xém.

## HỒI 2 — LỬA VÀ ĐƯỜNG CHẠY (Cảnh 10–18)

### C10 — Rượt Đuổi Phố Cổ | "09:00 Sáng, phố cổ Hải Phòng (09:00–10:00)"
Location: Phố cổ nhà Pháp vàng, ngõ hẹp, bến phà. Props: BIKE, LEDGER trong áo, thúng tre.
Setting: Morning in the old quarter of Hải Phòng: narrow streets of mustard-yellow French-era shophouses with green shutters, tangled overhead wires, street vendors' bamboo baskets, potted plants lining a tight alley.
1. [@Phong] | NAR | Sáng hôm sau, Phong giấu cuốn sổ trong áo khoác, phóng chiếc xe máy cũ của Tuấn ra phố. | Phong cưỡi BIKE ra phố.
2. [@Phong] cut + extras "three riders in black helmets on black motorbikes following at a distance" | NAR | Ba chiếc xe máy đen lập tức rồ ga bám theo, những gương mặt quen của băng Khang Hổ. |
3. [@Phong] cut | NAR | Phong ngoặt gấp vào con ngõ chỉ vừa một vai người, lách qua dãy chậu cây không sượt một chiếc lá. |
4. [] + extras "three riders in black helmets on black motorbikes" | NAR | Đám đàn em lao theo, trượt bánh vào chồng thúng tre, rau củ lăn tung tóe khắp mặt ngõ. | xe trượt vào chồng thúng rỗng, không ai bị thương, hài hước.
5. [@Phong] cut, setting riêng "A riverside ferry landing in the morning, an old car ferry pulling away from the concrete ramp, brown water churning" | NAR | Hắn phóng thẳng lên chiếc phà vừa rời bến, bánh sau chạm boong đúng lúc cầu phà kéo lên. |
6. [@Phong] cont (cùng setting riêng) | NAR | Trên bờ, ba chiếc xe đen phanh kít, chỉ còn biết đứng nhìn con sói già lướt đi giữa dòng sông. | Phong trên boong, bờ xa có 3 xe máy đen dừng.

### C11 — Hai Anh Em Trên Boong Phà | "09:30 Sáng, phà qua sông (10:00–11:00)"
Setting: Overcast morning on the open deck of an old river car ferry crossing a wide brown river: rusty white railings, a few parked motorbikes, coils of rope, distant container cranes and low green banks. Props: LEDGER, BIKE.
1. [@Huy] | NAR | Trên boong phà, Huy đã đứng chờ sẵn từ lúc nào, cậu bám theo anh trai suốt từ sáng sớm. |
2. [@Huy,@Phong] cut | @Huy | Anh định một mình chơi với cả băng Khang Hổ à? Đưa cuốn sổ đây cho em. |
3. [@Phong,@Huy] cont | @Phong | Em mở trang cuối ra mà đọc, rồi hãy nói với anh em còn tin được ai trong đồn. | Phong đưa LEDGER.
4. [@Huy] cut | NAR | Huy lật đến trang cuối, mặt cậu tái đi, cái tên quen thuộc nhất lại nằm ngay ở dòng đầu tiên. | trang giấy chỉ là các dòng mực mờ, không đọc được.
5. [@Huy,@Phong] cut | @Huy | Là sếp trực tiếp của em, hèn gì mấy lần đột kích đều về tay trắng. |
6. [@Phong,@Huy] cont | @Phong | Vậy thì làm theo cách của anh, em lo pháp luật, còn anh lo đường chạy. | hai anh em cùng nhìn ra sông.

### C12 — Kế Hoạch Gầm Cầu | "21:00 Tối, gara gầm cầu (11:00–12:00)"
Location/Setting: như C07 (gara). Props: cờ lê, xe đồ chơi trên nắp capô làm bản đồ cảng.
1. [] | NAR | Đêm đó gara gầm cầu sáng đèn, những chiếc cờ lê trên nắp capô đã thành tấm bản đồ bến cảng. | cờ lê, ốc vít, xe đồ chơi xếp thành bãi container trên nắp CAR.
2. [@Huy,@Phong] cut | @Huy | Đêm mai tàu của Khang nhổ neo, em đã gọi được đội đặc nhiệm từ Hà Nội xuống. |
3. [@Phong,@Huy] cont | @Phong | Anh sẽ làm mồi, kéo hết lũ đàn em ra khỏi bãi, em chỉ việc mở container. | Phong đẩy xe đồ chơi trên nắp capô.
4. [@Tuan,@Phong] cut | @Tuan | Lần này tao lái cẩu cho mày, cái bãi container đó tao thuộc như lòng bàn tay. | (Tuấn từng là thợ lái cẩu)
5. [@Phong] cut | NAR | Phong nhìn hai người, lần đầu tiên sau mười hai năm, hắn thấy mình không còn đơn độc nữa. |
6. [@Huy,@Phong] cut | @Huy | Anh hứa với em một điều thôi, xong việc này, anh phải sống cho mẹ được vui. |

### C13 — Bố Và Con Gái | "17:30 Chiều tà, kè biển (12:00–13:00)"
Setting: Golden sunset on a long concrete sea wall at the edge of the port city: calm silver sea, fishing boats on the horizon, cranes silhouetted far away. Props: LETTERS, ba lô đen.
1. [@Phong,@An] | NAR | Chiều hôm ấy, Phong đón An tan trường, hai bố con ngồi trên kè biển trước giờ cô đi học thêm. |
2. [@An] cut | NAR | An mở một lá thư trong bó thư cũ, bố viết nó vào đúng ngày sinh nhật năm cô lên bảy. | giấy viết tay mờ, không đọc được.
3. [@An,@Phong] cut | @An | Bố ơi, sao bố lại nhận tội thay người ta? Bố không thương con với bà à? |
4. [@Phong,@An] cont | @Phong | Vì bố tưởng mình đang cứu một đứa em, nhưng hóa ra bố đã rước sói vào nhà. |
5. [@An,@Phong] cont | @An | Thi xong đại học, bố chở con ra Hà Nội bằng con xe đen ấy nhé, bố hứa đi! | An chìa ngón út.
6. [@Phong,@An] cut (wide từ xa, hai bóng người trên kè) | NAR | Hắn ngoắc tay hứa, không biết rằng chỉ vài giờ nữa thôi, lời hứa ấy suýt thành lời hứa cuối cùng. |

### C14 — Chiếc Xe Thùng Đen | "19:00 Tối, cổng lò luyện thi (13:00–14:00)"
Setting: Early evening outside a tutoring center on a city street: a row of parked motorbikes, warm shop lights, a streetlamp, an Indian almond tree, a quiet dark side street. Props: VAN, điện thoại An.
1. [] | NAR | Tối hôm ấy, trước cổng lò luyện thi, một chiếc xe thùng đen đã đỗ sẵn dưới gốc cây bàng. | VAN dưới gốc bàng.
2. [@An] cut + extras "a henchman in a black shirt standing beside the black van" | NAR | An bước ra cổng, vừa nhắn tin cho bố thì cửa xe trượt mở, một gã áo đen khẽ cúi chào. |
3. [@An] cont (cùng extras) | @An | Các anh là ai? Tránh ra, bố tôi đang đến đón tôi ngay bây giờ đấy! | An lùi một bước, siết quai ba lô.
4. [@Khang] cut, setting riêng "Inside the dim back seat of a black van at night, tinted windows, streetlight sliding across" | @Khang | Cháu An, chú là bạn cũ của bố cháu, lên xe đi, chú đưa cháu đi gặp bố. | Khang cười nhạt, giơ tay mời.
5. [@An] cut + extras "three henchmen in black shirts standing in a loose half-circle a few steps away" | NAR | An nhìn quanh, ba gã áo đen đã đứng kín sau lưng, cô siết chặt quai ba lô rồi bước lên xe. | không ai chạm vào cô.
6. [] | NAR | Cửa xe đóng lại, chiếc xe thùng lặng lẽ khuất vào bóng tối, chỉ còn chiếc điện thoại sáng màn hình nằm dưới lòng đường. | điện thoại phát sáng trên mặt đường ướt (màn hình trống, không chữ).

### C15 — Cuộc Gọi Từ Kẻ Phản Bội | "21:00 Đêm (14:00–15:00)"
Setting chính: như C14 (phố trước lò luyện thi) nhưng muộn hơn, vắng. Clip 3 và 5 dùng setting riêng văn phòng kính của Khang ban đêm.
1. [@Phong] | NAR | Phong đợi mãi trước cổng lò luyện thi, rồi hắn nhặt lên chiếc điện thoại vỡ màn hình của con gái. | CAR đỗ bên lề, Phong cúi nhặt điện thoại.
2. [@Phong] cont | NAR | Đúng lúc đó, chính chiếc điện thoại ấy rung lên, và giọng nói đầu dây bên kia hắn nhớ suốt mười hai năm. | điện thoại rung trong tay, Phong áp lên tai.
3. [@Khang] cut, setting riêng "The top-floor glass office at night, city and harbor lights beyond the windows, a single desk lamp" | @Khang | Anh Phong, con bé đang ngồi uống trà với em, mang cuốn sổ đến bãi container một mình. |
4. [@Phong] cut | @Phong | Mày động vào một sợi tóc của con tao, cả cái cảng này sẽ không còn chỗ cho mày trốn. | cận mặt, nói vào điện thoại.
5. [@Khang] cut (setting văn phòng) | @Khang | Nửa đêm nay, bãi container cũ, đúng chỗ anh bị bắt năm xưa, em sẽ chờ anh. |
6. [@Phong] cut | NAR | Hắn cúp máy, siết chặt chiếc điện thoại, lần đầu tiên sau mười hai năm, đôi mắt con sói già đỏ lên. |

### C16 — An Trong Căn Phòng Tôn | "22:00 Đêm, phòng điều hành bằng container (15:00–16:00)"
Setting: A converted shipping-container site office at night: a metal desk, a flickering fluorescent tube, a small barred window, a kettle and tea cups, a narrow steel door with a simple lock. Props: kẹp tóc đen, ấm trà.
1. [] | NAR | Ở một góc khuất của bãi container, An bị giữ trong căn phòng tôn, chỉ có chiếc đèn tuýp chập chờn. |
2. [@An] | NAR | Cô bé không khóc, chỉ lặng lẽ nhìn qua khe cửa, đếm từng bước chân của bọn canh gác bên ngoài. |
3. [@Khang,@An] cut | @Khang | Bố cháu là người giỏi nhất chú từng biết, chỉ tiếc là ông ấy quá tin người. | Khang rót trà, đẩy cốc về phía An.
4. [@An,@Khang] cont | @An | Bố tôi sẽ đến, chú cứ chờ mà xem, lần này người phải chạy trốn là chú đấy. | An không nhận cốc trà.
5. [@An] cut | NAR | Khang bật cười bỏ đi, gã không để ý An đã kịp giấu chiếc kẹp tóc đen vào lòng bàn tay. |
6. [@An] cont | NAR | Cô bé nhớ lời bố dặn chiều nay, gặp nguy thì đừng hoảng, hãy bình tĩnh tìm đường thoát. | An quỳ bên cửa, khều kẹp tóc vào ổ khóa.

### C17 — Anh Em Bến Cảng | "22:30 Đêm (16:00–17:00)" — mỗi clip có setting riêng
1. [@Huy] setting "A police station rooftop at night, city lights and harbor cranes in the distance, light drizzle" | @Huy | Cuốn sổ thật em đã giao cho đặc nhiệm, anh cầm chân thằng Khang đến lúc bọn em tới. | nói điện thoại.
2. [@Phong] cut setting "Inside the restored glossy black 1990s sedan at night, rain on the windshield, city lights streaking past" | NAR | Phong không chờ ai cả, hắn quay xe thẳng lên mỏm đá, nơi ông trùm già vẫn đang thức đợi. |
3. [@OngBay] cut setting "The villa veranda at night, a single oil lamp, black sea and distant harbor lights below" | NAR | Ông Bảy chống gậy đứng dậy, lần đầu sau nhiều năm, ông nhấc chiếc điện thoại bàn đã phủ bụi. |
4. [@OngBay] cont | @OngBay | Anh em bến cảng đâu, thằng Sói về rồi, đêm nay ai còn nhớ ơn nó thì ra bãi. | nói vào ống nghe điện thoại bàn cũ.
5. [@Phong,@OngBay] cut (cùng setting hiên đêm) | @OngBay | Mày đi đi, đêm nay cả bến cảng này sẽ đứng sau lưng mày, Sói ạ. | đặt tay lên vai Phong.
6. [] setting "A dockworkers' quarter of tin-roofed houses beside the port at night" + extras "many old dock workers in faded work clothes stepping out of their doors holding flashlights" | NAR | Trong những dãy nhà tôn ven cảng, từng ngọn đèn pin lần lượt bật sáng, những người thợ bốc vác già lặng lẽ bước ra. |

### C18 — Sói Tái Xuất | "23:00 Đêm (17:00–18:00)"
Setting chính: "Night inside the smoke-stained front room of the tube house behind the stall: a small family altar with incense, a single warm lamp, scorched walls". Clip 4–6 setting garage như C07.
1. [@MeTu] | NAR | Trước khi đi, Phong ghé về nhà, mẹ hắn đã thắp sẵn ba nén nhang trên bàn thờ ám khói. |
2. [@MeTu,@Phong] cut | @MeTu | Con đi đưa cái An về, mẹ nấu sẵn nồi bánh đa, chờ hai bố con về ăn. |
3. [@Phong,@MeTu] cont | @Phong | Mẹ ơi, con nợ mẹ mười hai năm, đêm nay con xin trả trước một phần, mẹ nhé. | Phong cúi đầu chào mẹ.
4. [@Phong] cut (gara) | NAR | Ở gara, Phong bọc cuốn sổ vào tấm vải dầu cũ, rồi đeo đôi găng tay lái đã nằm trong hộc xe mười hai năm. | (không lộ đây là sổ giả)
5. [@Tuan,@Phong] cut | @Tuan | Xăng đầy bình, lốp mới thay, con xe này chỉ chờ đúng đêm nay thôi, Sói ạ! |
6. [@Phong] cut, setting riêng "Rainy night at the garage entrance under the bridge, wet asphalt shining" | NAR | Tiếng máy gầm lên dưới gầm cầu, và Phong Sói chính thức tái xuất giang hồ. | đèn pha CAR bật, xe lăn ra mưa — khoảnh khắc hoành tráng.

## HỒI 3 — ĐÊM CẢNG CUỐI CÙNG (Cảnh 19–27)

### C19 — Bãi Container Nửa Đêm | "00:00 Nửa đêm, bãi container (18:00–19:00)"
Setting: như C01 (bãi container đêm mưa), không có đèn cảnh sát: "A vast container port yard at midnight in heavy rain: towering stacks of rust-red, blue and green shipping containers forming narrow lanes, a towering yellow gantry crane lit by sodium floodlights, deep puddles on the asphalt."
1. [] | NAR | Nửa đêm, mưa lại trút xuống bãi container, y hệt cái đêm định mệnh mười hai năm trước. | aerial, CAR tiến vào.
2. [@Phong] cut | NAR | Con xe đen chậm rãi lăn bánh giữa hai dãy container, đèn pha rọi thẳng vào hàng xe của Khang. | trong xe, qua kính chắn gió thấy SUV.
3. [@Khang] cut | NAR | Khang đứng chờ dưới ánh đèn cẩu, ung dung che ô, còn An vẫn bị nhốt đâu đó giữa mê cung container. | Khang cầm ô đen, SUV phía sau.
4. [@Phong] cut | @Phong | Thả con bé ra, sổ ở đây, chuyện của người lớn thì mày với tao giải quyết. | Phong bước ra khỏi xe, giơ LEDGER.
5. [@Khang] cut | @Khang | Anh vẫn thế, anh Phong, vẫn tin rằng cứ nhận hết về mình là xong mọi chuyện. |
6. [@Phong,@Khang] cut (wide, hai người cách xa) | NAR | Phong đặt cuốn sổ lên nắp capô, hai người đàn ông bước chậm về phía nhau giữa màn mưa trắng xóa. |

### C20 — Cuốn Sổ Trắng | "00:10 (19:00–20:00)" — setting như C19; clip 5–6 setting phòng tôn / lối container
1. [@Khang] | NAR | Khang cầm cuốn sổ lên, lật vội từng trang dưới ánh đèn pha, rồi bàn tay gã khựng lại. |
2. [@Khang] cont | NAR | Từng trang giấy đều trắng tinh, cuốn sổ thật đã nằm trong tay đội đặc nhiệm từ chiều. | trang trắng bay phần phật trong mưa.
3. [@Khang,@Phong] cut | @Khang | Anh dám lừa em à, anh Phong? Anh quên con gái anh đang ở trong tay ai rồi sao? |
4. [@Phong,@Khang] cont | @Phong | Mười hai năm trước tao dạy mày chạy, đêm nay tao dạy mày cách đứng lại chịu tội. |
5. [@An] cut, setting như C16 | NAR | Cùng lúc ấy, trong căn phòng tôn, chiếc kẹp tóc của An xoay thêm một vòng, và ổ khóa bật mở. |
6. [@An] cut, setting "A narrow lane between towering container stacks at midnight in heavy rain, distant headlights glowing at the far end" | NAR | Cô bé lách ra ngoài, men theo bóng tối giữa những dãy container, chạy về phía ánh đèn pha của bố. |

### C21 — Đèn Cẩu Bật Sáng | "00:15 (20:00–21:00)" — setting như C19
1. [@Khang] cut + extras "a line of henchmen in black shirts standing far behind him" | @Khang | Lục tung cả cái bãi này lên, tìm con bé về đây cho tao, nhanh lên! | Khang chỉ tay vào bóng tối.
2. [@Tuan] cut, setting "Inside the glass cab of a towering yellow gantry crane high above the rainy container yard at night, glowing control levers" | NAR | Đúng lúc ấy, trên buồng lái cần cẩu cao ba mươi mét, Tuấn Còi kéo mạnh cần điều khiển. |
3. [] + extras "henchmen in black shirts far below, stepping back" | NAR | Một chiếc container khổng lồ từ từ hạ xuống chặn ngang lối ra, đám đàn em khựng lại, lùi dần về phía sau. |
4. [] + extras "dozens of old dock workers in faded work clothes standing on top of the container stacks holding flashlights" | NAR | Rồi hàng chục ngọn đèn pin bật sáng trên nóc container, anh em bến cảng của Ông Bảy đã đến. |
5. [@Khang] cut + extras "henchmen in black shirts backing away into the dark" | NAR | Đám đàn em nhìn nhau, rồi từng đứa một lặng lẽ lùi vào bóng tối, bỏ mặc Khang đứng một mình. |
6. [@An,@Phong] cut | NAR | An chạy ra từ giữa hai dãy container, lao vào vòng tay bố, Phong mở cửa đưa con bé lên ghế phụ. |

### C22 — Rượt Đuổi Mê Cung Container | "00:20 (21:00–22:00)" — setting như C19
1. [] | NAR | Hai chiếc xe đen của đám đàn em trung thành cuối cùng rồ máy, đèn pha quét loang loáng giữa màn mưa. | hai SUV.
2. [@Phong,@An] cut, setting riêng "Inside the restored glossy black 1990s sedan at night in heavy rain, wipers sweeping, container lanes rushing past" | @Phong | Thắt dây an toàn vào con, bố cho con xem vì sao người ta gọi bố là Sói. |
3. [] | NAR | Con xe đen lướt vào mê cung container, drift qua từng khúc cua hẹp chỉ cách vách thép vài phân. |
4. [@An,@Phong] cut (setting trong xe) | @An | Bố ơi, bên trái có khe hở vừa đúng một thân xe, bố lách vào đi! | An chỉ tay, mắt sáng.
5. [] | NAR | Hai chiếc xe đuổi theo không kịp phanh, trượt dài trên mặt đường ướt rồi lao vào đống pallet gỗ. | không thấy người, xe trượt vào đống pallet rỗng.
6. [@Phong,@An] cut (setting trong xe) | NAR | Trong gương chiếu hậu chỉ còn khói và mưa, nhưng phía cầu tàu, một chiếc ca nô trắng vừa nổ máy. |

### C23 — Ca Nô Trốn Chạy | "00:40 Cầu tàu (22:00–23:00)"
Setting: A wooden and concrete pier at the edge of the port at night in rain: moored tugboats, coils of rope, black water, harbor lights reflecting on the surface. Props: SPEEDBOAT, SKIFF.
1. [@Khang] | NAR | Khang bỏ lại tất cả, nhảy xuống chiếc ca nô trắng, rồ máy lao ra cửa sông trong màn mưa đêm. |
2. [@Phong,@An] cut | @Phong | Con ở lại đây chờ chú Tuấn, bố phải đi đòi lại món nợ mười hai năm. |
3. [@An,@Phong] cont | @An | Bố phải về đấy, bố còn nợ con một chuyến ra Hà Nội bằng con xe đen. |
4. [@Phong] cut | NAR | Phong nhảy xuống chiếc xuồng máy của dân chài neo bên cầu tàu, giật dây khởi động một lần là nổ. |
5. [] setting riêng "A wide black river at night in rain, port lights streaking along both banks" | NAR | Hai con thuyền xé màn mưa trên mặt sông đen kịt, đèn cảng hai bên bờ lùi lại vun vút. | SPEEDBOAT phía trước, SKIFF bám sau, không thấy mặt người.
6. [@Phong] cut (setting sông đêm) | NAR | Hắn không có súng, không có đàn em, chỉ có đôi tay lái mà cả đất Cảng này từng phải kiêng nể. | Phong đứng lái SKIFF, nước bắn.

### C24 — Bình Minh Trên Bãi Bồi | "05:30 Rạng sáng, cửa sông (23:00–24:00)"
Setting: Dawn at a wide river mouth near the sea: pale pink and steel-grey sky, low tide exposing vast glistening mudflats and mangrove edges, rows of bamboo fishing stakes in the water, distant cranes.
1. [] | NAR | Cuộc rượt đuổi kéo dài đến tận rạng sáng, khi nước ròng để lộ những bãi bùn mênh mông ở cửa sông. |
2. [@Khang] | NAR | Khang ngoái lại nhìn chiếc xuồng nhỏ vẫn bám sau lưng, gã bẻ lái gấp về phía rừng đước. | Khang lái SPEEDBOAT.
3. [@Phong] cut | NAR | Phong lớn lên ở bến sông này, hắn thuộc từng luồng lạch, và hắn cố tình ép ca nô về phía bãi cạn. |
4. [] | NAR | Chiếc ca nô trắng trườn lên bãi bùn, mũi cắm sâu xuống, động cơ rú lên một hồi rồi tắt lịm. |
5. [@Khang] cut + extras "two grey police patrol boats approaching across the water in the distance" | NAR | Khang lội bùn đến đầu gối, bộ vest kem lấm lem, ngẩng lên thì bốn phía đã có ca nô cảnh sát. |
6. [@Huy] cut + extras "police officers in dark uniforms on the deck behind him" | @Huy | Khang, đội đặc nhiệm đây, giơ hai tay lên, cuộc chạy trốn của anh kết thúc rồi. | Huy đứng mũi ca nô cảnh sát.

### C25 — Còng Tay Bên Bãi Bồi | "06:00 Sáng (24:00–25:00)" — setting như C24
1. [@Khang] cut | NAR | Ông trùm cảng Vạn Hải giơ hai tay lên trời, đứng giữa bãi bùn như một kẻ trắng tay. |
2. [@Huy,@Khang] cut | NAR | Huy bước xuống bùn, chiếc còng số tám khép lại trên cổ tay đeo đồng hồ vàng của gã. | Khang tự đưa hai cổ tay ra, bắt giữ hợp tác.
3. [@Khang,@Phong] cut | @Khang | Anh tưởng anh thắng à, anh Phong? Anh vẫn chỉ là một thằng tù mà thôi. |
4. [@Phong,@Khang] cont | @Phong | Tao không cần thắng, tao chỉ lấy lại cái tên mà mày đã bán đi mười hai năm trước. |
5. [@Huy] cut | NAR | Sáng hôm ấy, theo cuốn sổ đen, mười bảy cái tên trong thành phố bị gọi lên, có cả sếp cũ của Huy. |
6. [@Huy,@Phong] cut | @Huy | Anh à, lần này anh không có tội gì để nhận cả, về nhà thôi, mẹ đang chờ. | Huy đặt tay lên vai anh.

### C26 — Bát Bánh Đa Đoàn Viên | "08:00 Một tháng sau, quán bánh đa mới (25:00–26:00)"
Setting: Bright morning a month later at the rebuilt crab-noodle stall in the riverside market lane: a brand-new striped canvas awning, a steaming pot of orange-red crab broth, red plastic stools, green tables, sunlight on the river and cranes beyond.
1. [] | NAR | Một tháng sau, quán bánh đa của bà Tư mở cửa lại, mái bạt mới tinh, nồi nước dùng đỏ au. |
2. [@MeTu,@An] cut | NAR | Bà Tư múc bát đầu tiên, An bưng ra bàn, hai bà cháu cười như chưa từng có đêm lửa nào. |
3. [@Phong,@Huy] cut | NAR | Phong và Huy ngồi chung một bàn, hai anh em lần đầu cùng ăn sáng với nhau sau mười hai năm. |
4. [@Huy,@Phong] cont | @Huy | Anh này, sếp mới của em hỏi anh có muốn về dạy lái xe cho đội không đấy. |
5. [@Phong,@Huy] cont | @Phong | Anh chỉ nhận dạy đúng một học trò thôi, con bé nhà mình, nó đang chờ anh chở ra Hà Nội. |
6. [@OngBay,@Tuan] cut | NAR | Ở bàn bên, Ông Bảy và Tuấn Còi nâng chén trà, bến cảng Vạn Hải lần đầu tiên thật sự bình yên. |

### C27 — Con Đường Ra Hà Nội | "07:00 Sáng hôm sau, quốc lộ (26:00–27:00)"
Setting: Bright morning on a long straight highway through green rice fields toward the capital, scattered villages and power lines, a wide pale-blue sky.
1. [] | NAR | Sáng hôm sau, con xe đen lăn bánh trên quốc lộ, chở cô tân sinh viên ra Hà Nội nhập học. | aerial CAR trên đường thẳng giữa đồng lúa.
2. [@Phong,@An] cut, setting riêng "Inside the restored glossy black 1990s sedan on a sunny morning highway, rice fields sliding past the windows" | @An | Bố ơi, bố đi chậm thôi, con muốn chuyến đi này kéo dài thêm một chút nữa. |
3. [@Phong,@An] cont | NAR | Phong bật cười, lần đầu tiên sau mười hai năm, con sói già lái xe mà không phải chạy trốn ai. |
4. [@Phong] cut (trong xe) | NAR | Nhưng rồi chiếc điện thoại cũ trong túi áo da rung lên, một số máy lạ không hiển thị tên. | màn hình sáng trống, không chữ.
5. [@Phong] cont | NAR | Giọng bên kia chỉ nói một câu, trang cuối cuốn sổ đen còn một cái tên mà đội đặc nhiệm chưa đọc tới. | Phong nghe, ánh mắt lạnh lại qua gương.
6. [] | NAR | Găng tơ đã tái xuất, nhưng cuộc chơi thật sự, có lẽ bây giờ mới chỉ bắt đầu. | aerial CAR chạy xa về phía chân trời thành phố, nắng lóa.
