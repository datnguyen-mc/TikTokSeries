# Cảnh 01: Đêm Mưa Cảng Vạn Hải, Mười Hai Năm Trước (6 Clips × 10s = 60s)

- **Thời gian:** 23:00 Đêm mưa, mười hai năm trước (00:00–01:00)
- **Bối cảnh:** Bãi container cảng Vạn Hải, Hải Phòng, đêm mưa lớn.
- **Trục không gian cố định:** Xe chạy từ trái sang phải màn hình dọc các lối container; ghế lái bên trái, ghế phụ bên phải.
- **Đạo cụ chính:** Chiếc sedan đen thập niên 90 đèn tròn, túi vải đen của ông trùm, đèn cảnh sát xanh đỏ ở xa.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **24** | `0.4–6.4s` | "Mười hai năm trước, ở cảng Vạn Hải đất Hải Phòng, có một tay lái mà cả giới giang hồ đều phải kiêng nể." | 24mm aerial slow descending glide through the rain | Text-to-video |
| [**Clip 2**](clip-2.md) | `@Phong` | `VO` | **18** | `0.4–4.9s` | "Hắn là Phong, giang hồ gọi là Phong Sói, chưa từng có chiếc xe nào đuổi kịp hắn." | 35mm medium shot through the windshield, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Phong`, `@Khang` | `VO` | **22** | `0.4–5.9s` | "Ngồi ghế phụ là Khang, thằng đàn em hắn thương như ruột thịt, đang ôm chặt chiếc túi đen của ông trùm." | 50mm close-up two-shot from the dashboard, gentle handheld sway | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@Phong`, `@Khang` | `LIPSYNC:@Khang` | **16** | `0.4–4.4s` | "Anh Phong ơi, cảnh sát chặn kín hai đầu cảng rồi, mình hết đường thật rồi!" | 35mm medium two-shot from the back seat, slow drift left | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | `@Phong`, `@Khang` | `LIPSYNC:@Phong` | **17** | `0.4–4.8s` | "Mày ôm túi xuống xe ngay, chạy vào lối container bên trái, tuyệt đối đừng ngoái lại." | 50mm close-up on the driver, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 6**](clip-6.md) | `@Phong` | `VO` | **19** | `0.4–5.2s` | "Đêm ấy Phong nhận hết tội về mình, ngồi tù mười hai năm, không khai ra nửa cái tên." | 28mm wide low-angle shot, slow crane up | Ingredients: ảnh nhân vật |
