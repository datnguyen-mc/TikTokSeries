# Cảnh 02: Ngày Ra Tù (6 Clips × 10s = 60s)

- **Thời gian:** 07:00 Sáng sớm đầu đông, hiện tại (01:00–02:00)
- **Bối cảnh:** Cổng trại giam ngoại ô Hải Phòng, con đường đất hai hàng bạch đàn.
- **Trục không gian cố định:** Cổng sắt ở cuối hình, con đường chạy thẳng về phía máy quay; xe đến từ bên phải màn hình.
- **Đạo cụ chính:** Túi vải cũ, đồng hồ thép đứng kim, chiếc sedan đen thập niên 90 đèn tròn.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **21** | `0.4–5.7s` | "Mười hai năm sau, vào một buổi sáng đầu đông, cánh cổng sắt nặng nề ấy cuối cùng cũng mở ra." | 35mm wide locked-off shot down the road toward the gate | Text-to-video |
| [**Clip 2**](clip-2.md) | `@Phong` | `VO` | **22** | `0.4–5.9s` | "Không hoa, không người đón, hắn chỉ mang theo chiếc túi vải cũ và chiếc đồng hồ đã chết kim từ lâu." | 50mm medium tracking shot moving backward | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Phong` | `VO` | **21** | `0.4–5.7s` | "Hắn đứng lặng giữa con đường vắng, nhắm mắt hít thật sâu cái mùi gió mặn quen thuộc của đất Cảng." | 85mm close-up, slow orbit around the face | Frames: nối khung cuối clip trước |
| [**Clip 4**](clip-4.md) | `@Tuan` | `VO` | **24** | `0.4–6.4s` | "Rồi tiếng máy gầm vang, Tuấn Còi, thợ sửa xe gầm cầu, người bạn chí cốt duy nhất, lái con xe cũ đến đón." | 24mm wide low-angle shot from road level, slow pan | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | `@Tuan`, `@Phong` | `LIPSYNC:@Tuan` | **16** | `3.0–7.0s` | "Mười hai năm tao giữ con xe này bóng hơn mặt tao, lên xe đi Sói!" | 35mm medium two-shot beside the car hood, slow dolly in | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Phong`, `@Tuan` | `LIPSYNC:@Phong` | **16** | `0.4–4.6s` | "Đưa tao về quán mẹ, rồi tao trả mày đủ mười hai năm tiền rửa xe." | 85mm close-up from over the bonnet, slow dolly-in | Frames: nối khung cuối clip trước |
