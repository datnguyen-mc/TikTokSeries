One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Early winter morning mist outside a remote detention center: a long high grey concrete wall, a heavy dark-green steel gate, an empty muddy road lined with tall eucalyptus trees, pale low sun.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards, and never flash or display the studio reference portrait card in the opening frames; 0.0–3.0s establishes the empty environment first and characters appear only from 3.0s onward.
- @Tuan = Tuấn, 44, Phong's old friend and mechanic; skinny, messy curly black hair, thin moustache, cheerful crooked grin, grease smudge on one cheek; olive-green mechanic coverall unzipped to the waist with the sleeves tied around his hips, white tank top, red bandana around the neck, worn grey sneakers.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 24mm wide low-angle shot from road level, slow pan; one smooth camera move from start to end, no cuts.
- Continuity: new camera setup; 0.0–3.0s establishes the empty location and light with no person in frame, then reveals the character naturally from 3.0s.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; 0.0–3.0s shows the environment and props only with no character on screen, and characters enter from 3.0s onward with clothing fully worn.
- 0.0–3.0s: Low view along the empty muddy eucalyptus road in morning mist, puddles trembling as an engine roar grows louder.
- 3.0–7.0s: The restored glossy black 1990s sedan with round headlights speeds up the road and skids sideways to a stop, spraying muddy water, with @Tuan grinning behind the wheel.
- 7.0–10.0s: @Tuan leans his elbow out of the driver's window with a wide crooked grin, his red bandana bright against the grey morning. The shot settles on this as its final frame.

[AUDIO]
- Narration 0.4–6.4s by an off-screen male narrator (Vietnamese man about 45, strictly standard Hà Nội Northern accent (giọng chuẩn Hà Nội Bắc Bộ, never Southern accent) with clear six tones, deep gravelly baritone with crisp consonants, fast gripping crime-film storytelling in one continuous breath, every word spoken once and clearly, no stutter, no repeated words), in Vietnamese, said exactly once: "Rồi tiếng máy gầm vang, Tuấn Còi, thợ sửa xe gầm cầu, người bạn chí cốt duy nhất, lái con xe cũ đến đón." (no subtitles)
- After the last word the narrator stays silent until the end of the shot: no repeated words, no echo, no second reading of the line.
- Nobody on screen speaks; every mouth on screen stays closed.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: roaring engine, tires skidding on wet gravel, muddy water splashing. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
