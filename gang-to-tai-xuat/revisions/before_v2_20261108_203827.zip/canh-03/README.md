# Cảnh 03: Bát Bánh Đa Cua Của Mẹ (6 Clips × 10s = 60s)

- **Thời gian:** 08:00 Sáng, quán bánh đa ven sông (02:00–03:00)
- **Bối cảnh:** Quán bánh đa cua nhỏ của bà Tư trong ngõ chợ ven sông gần cảng.
- **Trục không gian cố định:** Máy quay trong quán nhìn ra ngõ; nồi nước dùng bên trái màn hình, lối vào dưới mái bạt bên phải.
- **Đạo cụ chính:** Nồi nhôm nước dùng cua, muôi, bát bánh đa, khay, bó phong bì cũ buộc dây nâu.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@MeTu` | `VO` | **24** | `0.4–6.4s` | "Bà Tư, mẹ hắn, đã bán bánh đa cua ở bến sông này hơn ba mươi năm, sáng nào cũng ngóng ra đầu ngõ." | 35mm medium shot from inside the stall, slow lateral slide | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@An` | `VO` | **23** | `0.4–6.2s` | "Còn An, con gái hắn, năm nay mười tám tuổi, chỉ biết mặt bố qua một tấm ảnh cũ bà kẹp trong ví." | 50mm close-up tracking alongside, gentle handheld | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@MeTu`, `@Phong` | `VO` | **22** | `0.4–5.9s` | "Chiếc muôi trên tay bà khựng lại giữa chừng, đứa con trai bà chờ mười hai năm đang đứng ngay trước quán." | 28mm wide shot from behind the broth pot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@MeTu`, `@Phong` | `LIPSYNC:@MeTu` | **17** | `0.4–4.9s` | "Về rồi thì ngồi xuống đây, mẹ nấu cho con bát bánh đa cua như ngày xưa." | 85mm close-up, slow dolly-in on her face | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | `@An`, `@Phong` | `LIPSYNC:@An` | **17** | `3.0–7.3s` | "Chú là bố cháu thật à? Sao mười hai năm chú không gửi lấy một lá thư?" | 50mm over-the-shoulder two-shot, slow dolly | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Phong`, `@An` | `LIPSYNC:@Phong` | **21** | `0.4–5.8s` | "Bố viết đủ mười hai năm, nhưng không dám gửi, vì sợ con xấu hổ có một người bố đi tù." | 85mm close-up on the table, slow tilt up to his face | Frames: nối khung cuối clip trước |
