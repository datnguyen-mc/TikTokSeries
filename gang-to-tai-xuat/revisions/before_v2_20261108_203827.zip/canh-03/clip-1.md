One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Morning at a small open-front crab-noodle stall in a riverside market lane of Hải Phòng: a steaming aluminum pot of orange-red crab broth, low red plastic stools, small green plastic tables, a canvas awning, the river and distant cranes beyond.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards, and never flash or display the studio reference portrait card in the opening frames; 0.0–3.0s establishes the empty environment first and characters appear only from 3.0s onward.
- @MeTu = Bà Tư, 68, Phong and Huy's mother who runs a crab-noodle stall; short and plump, short wavy grey hair, round kind face with deep laugh lines; faded maroon floral blouse, black trousers, blue-and-white checkered cloth apron, plastic sandals.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 35mm medium shot from inside the stall, slow lateral slide; one smooth camera move from start to end, no cuts.
- Continuity: new camera setup; 0.0–3.0s establishes the empty location and light with no person in frame, then reveals the character naturally from 3.0s.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; 0.0–3.0s shows the environment and props only with no character on screen, and characters enter from 3.0s onward with clothing fully worn.
- 0.0–3.0s: Steam rises from a large aluminum pot of orange-red crab broth under the canvas awning, red plastic stools and green tables waiting in the morning light.
- 3.0–7.0s: @MeTu ladles steaming broth into a bowl of noodles, her checkered apron knotted at the waist.
- 7.0–10.0s: @MeTu pauses with the ladle in her hand and looks out toward the entrance of the market lane, her eyes searching. The shot settles on this as its final frame.

[AUDIO]
- Narration 0.4–6.4s by an off-screen male narrator (Vietnamese man about 45, strictly standard Hà Nội Northern accent (giọng chuẩn Hà Nội Bắc Bộ, never Southern accent) with clear six tones, deep gravelly baritone with crisp consonants, fast gripping crime-film storytelling in one continuous breath, every word spoken once and clearly, no stutter, no repeated words), in Vietnamese, said exactly once: "Bà Tư, mẹ hắn, đã bán bánh đa cua ở bến sông này hơn ba mươi năm, sáng nào cũng ngóng ra đầu ngõ." (no subtitles)
- After the last word the narrator stays silent until the end of the shot: no repeated words, no echo, no second reading of the line.
- Nobody on screen speaks; every mouth on screen stays closed.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: bubbling broth, market chatter, a boat engine on the river. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
