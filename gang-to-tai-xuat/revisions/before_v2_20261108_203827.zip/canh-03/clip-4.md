One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Morning at a small open-front crab-noodle stall in a riverside market lane of Hải Phòng: a steaming aluminum pot of orange-red crab broth, low red plastic stools, small green plastic tables, a canvas awning, the river and distant cranes beyond.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards.
- @MeTu = Bà Tư, 68, Phong and Huy's mother who runs a crab-noodle stall; short and plump, short wavy grey hair, round kind face with deep laugh lines; faded maroon floral blouse, black trousers, blue-and-white checkered cloth apron, plastic sandals.
- @Phong = Phong, 45, former getaway driver just out of prison; tall and lean, short black hair greying at the temples, a thin pale scar through his left eyebrow, short dark stubble, weathered tan skin; worn black leather jacket over a charcoal crew-neck T-shirt, dark jeans, black boots, old steel wristwatch.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 85mm close-up, slow dolly-in on her face; one smooth camera move from start to end, no cuts.
- Continuity: continues the same moment, place and lighting as the previous shot; same framing axis, no jump.
- Eyelines: the camera stays on one side of the line between the characters (180-degree rule) so their eyes meet across the frame.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; clothing stays fully worn from the first frame.
- 0.0–3.0s: @MeTu sets the ladle down on the pot rim, her lips trembling and her eyes reddening.
- 3.0–7.0s: @MeTu speaks softly to @Phong while pulling a red plastic stool out from under the table with a shaking hand.
- 7.0–10.0s: @MeTu presses her apron to the corner of her eye as @Phong stands still before her, head lowered. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 0.4–4.9s, spoken on camera by @MeTu (old woman of 68, strictly standard Hà Nội Northern accent (never Southern accent), warm husky voice trembling with emotion, speaking at a brisk pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Về rồi thì ngồi xuống đây, mẹ nấu cho con bát bánh đa cua như ngày xưa." (no subtitles)
- @MeTu's face and lips stay clearly visible while speaking; after the last word @MeTu closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: broth simmering, distant market chatter. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
