# Cảnh 04: Người Em Cảnh Sát (6 Clips × 10s = 60s)

- **Thời gian:** 10:00 Trưa âm u, bờ kè sau chợ (03:00–04:00)
- **Bối cảnh:** Bờ kè đá ven sông sau chợ, thuyền gỗ neo, cần cẩu bên kia sông.
- **Trục không gian cố định:** Sông bên phải màn hình; Huy đứng bên trái, Phong bên phải, cần cẩu ở hậu cảnh.
- **Đạo cụ chính:** Xe máy của Huy, mũ bảo hiểm, cọc neo sắt gỉ, dây neo thuyền.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Huy` | `VO` | **24** | `0.4–6.4s` | "Huy, em trai hắn, giờ là thượng úy cảnh sát hình sự, người duy nhất trong nhà chưa bao giờ tha thứ cho hắn." | 35mm wide tracking shot along the embankment | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@Huy`, `@Phong` | `LIPSYNC:@Huy` | **17** | `3.0–7.3s` | "Anh về thì sống cho tử tế, đừng kéo mẹ với con bé vào chuyện cũ nữa." | 50mm medium two-shot in profile, slow dolly in | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Phong`, `@Huy` | `LIPSYNC:@Phong` | **16** | `0.4–4.6s` | "Anh về để làm lại từ đầu, chứ không phải để làm lại những chuyện cũ." | 85mm close-up on the older brother, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 4**](clip-4.md) | `@Huy`, `@Phong` | `LIPSYNC:@Huy` | **17** | `0.4–4.7s` | "Cảng này giờ là đất của Khang Hổ, cái thằng mà anh đã ngồi tù thay đấy." | 35mm over-the-shoulder shot from behind the older brother, slow pan | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | `@Phong` | `VO` | **22** | `0.4–5.9s` | "Cái tên ấy làm quai hàm Phong siết lại, mười hai năm trời, Khang chưa từng vào thăm hắn lấy một lần." | 100mm extreme close-up, slow rack focus | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Huy` | `LIPSYNC:@Huy` | **16** | `3.0–7.0s` | "Em đang điều tra nó đấy, anh mà dính vào, em còng tay anh trước tiên." | 50mm medium shot, slow tracking backward | Ingredients: ảnh nhân vật |
