# Cảnh 05: Đế Chế Khang Hổ (6 Clips × 10s = 60s)

- **Thời gian:** 11:00 Trưa, văn phòng kính tầng thượng (04:00–05:00)
- **Bối cảnh:** Văn phòng kính tầng thượng hãng vận tải Vạn Hải nhìn xuống bãi container.
- **Trục không gian cố định:** Cửa kính sát trần phía sau bàn làm việc; Khang quay lưng ra cảng, cửa ra vào bên phải màn hình.
- **Đạo cụ chính:** Bàn gỗ sẫm bóng, ghế da đen, mô hình tàu hàng trong tủ kính, két sắt âm tường, đồng hồ vàng.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **20** | `0.4–5.4s` | "Mười hai năm, chiếc túi đen đêm ấy đã giúp Khang dựng nên cả một đế chế trên bến cảng." | 24mm aerial slow glide toward the glass tower | Text-to-video |
| [**Clip 2**](clip-2.md) | `@Khang` | `VO` | **25** | `0.4–6.7s` | "Giờ người ta gọi gã là Khang Hổ, ông chủ hãng vận tải lớn nhất Vạn Hải, sạch sẽ từ cổ áo đến đôi giày." | 50mm medium shot, slow dolly along the window | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Khang` | `VO` | **23** | `0.4–6.2s` | "Tay đàn em cúi xuống báo tin, Phong Sói đã ra tù sáng nay và đang ngồi ở quán bánh đa của mẹ." | 35mm wide shot from the doorway, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 4**](clip-4.md) | `@Khang` | `LIPSYNC:@Khang` | **21** | `0.4–5.7s` | "Mười hai năm trong đó, con sói nào cũng thành chó nhà, cứ để nó ăn bát bánh đa cho yên." | 85mm close-up, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | `@Khang` | `VO` | **24** | `0.4–6.4s` | "Nhưng có một thứ Khang tìm mãi không thấy, cuốn sổ đen ông trùm cũ ghi tên tất cả những kẻ từng nhận tiền." | 35mm medium shot, slow lateral slide | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Khang` | `LIPSYNC:@Khang` | **19** | `0.4–5.2s` | "Cho người bám nó ngày đêm, cuốn sổ ấy mà lộ ra thì cả cái cảng này sụp đổ." | 85mm close-up, slow dolly-in | Frames: nối khung cuối clip trước |
