One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
A top-floor glass office of a shipping company overlooking the container port: floor-to-ceiling windows, gantry cranes and stacked containers below, a dark polished wood desk, black leather chairs, a model cargo ship in a glass case, a steel wall safe.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards.
- @Khang = Khang, 42, the polished port boss; medium build, slicked-back black hair, clean-shaven, cold narrow eyes, faint smirk; cream linen suit over a black open-collar shirt, thin gold chain, gold wristwatch, polished brown loafers.
- Extra: a henchman in a black shirt with a shaved head standing silently in the background
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 85mm close-up, slow dolly-in; one smooth camera move from start to end, no cuts.
- Continuity: continues the same moment, place and lighting as the previous shot; same framing axis, no jump.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; clothing stays fully worn from the first frame.
- 0.0–3.0s: @Khang turns from the window and lowers himself into his black leather chair, crossing one leg over the other.
- 3.0–7.0s: @Khang speaks with a lazy smirk, swiveling the chair slightly from side to side.
- 7.0–10.0s: @Khang flicks a speck of dust from the knee of his cream trousers, the smirk still on his lips. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 0.4–5.7s, spoken on camera by @Khang (man of 42, strictly standard Hà Nội Northern accent (never Southern accent), smooth silky baritone, mocking and cold, speaking at a brisk, fast-clipped pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Mười hai năm trong đó, con sói nào cũng thành chó nhà, cứ để nó ăn bát bánh đa cho yên." (no subtitles)
- @Khang's face and lips stay clearly visible while speaking; after the last word @Khang closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: a leather chair creaking, air conditioning hum. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
