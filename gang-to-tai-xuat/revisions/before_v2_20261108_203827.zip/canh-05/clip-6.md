One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
A top-floor glass office of a shipping company overlooking the container port: floor-to-ceiling windows, gantry cranes and stacked containers below, a dark polished wood desk, black leather chairs, a model cargo ship in a glass case, a steel wall safe.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards.
- @Khang = Khang, 42, the polished port boss; medium build, slicked-back black hair, clean-shaven, cold narrow eyes, faint smirk; cream linen suit over a black open-collar shirt, thin gold chain, gold wristwatch, polished brown loafers.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 85mm close-up, slow dolly-in; one smooth camera move from start to end, no cuts.
- Continuity: continues the same moment, place and lighting as the previous shot; same framing axis, no jump.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; clothing stays fully worn from the first frame.
- 0.0–3.0s: @Khang shuts the safe door with a heavy clunk and spins the dial.
- 3.0–7.0s: @Khang speaks coldly over his shoulder toward the doorway, his eyes hard and unblinking.
- 7.0–10.0s: @Khang turns back to the window and gazes down at the cranes, adjusting his gold wristwatch. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 0.4–5.2s, spoken on camera by @Khang (man of 42, strictly standard Hà Nội Northern accent (never Southern accent), smooth silky baritone, mocking and cold, speaking at a brisk, fast-clipped pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Cho người bám nó ngày đêm, cuốn sổ ấy mà lộ ra thì cả cái cảng này sụp đổ." (no subtitles)
- @Khang's face and lips stay clearly visible while speaking; after the last word @Khang closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: a steel door clunking shut, the dial spinning, a distant crane horn. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
