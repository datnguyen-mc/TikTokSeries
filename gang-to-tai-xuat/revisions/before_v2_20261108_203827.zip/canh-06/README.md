# Cảnh 06: Ông Trùm Bị Giam Lỏng (6 Clips × 10s = 60s)

- **Thời gian:** 15:00 Chiều, biệt thự cũ trên mỏm đá (05:00–06:00)
- **Bối cảnh:** Biệt thự Pháp cũ tường vàng bong tróc trên mỏm đá nhìn ra biển.
- **Trục không gian cố định:** Hiên nhà nhìn ra biển; biển phía sau bên trái màn hình, Ông Bảy ngồi bên trái, Phong bên phải.
- **Đạo cụ chính:** Ghế mây, gậy gỗ chạm sẫm màu, chuỗi hạt gỗ, cổng sắt uốn, cây hoa đại.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **23** | `0.4–6.2s` | "Phong tìm đến căn biệt thự cũ trên mỏm đá, nơi ông trùm năm xưa đang sống chẳng khác gì một tù nhân." | 24mm wide establishing shot, slow crane down | Text-to-video |
| [**Clip 2**](clip-2.md) | `@OngBay` | `VO` | **21** | `0.4–5.7s` | "Ông Bảy Cảng, người từng nắm cả bến cảng trong lòng bàn tay, giờ bị chính Khang giam lỏng ở đây." | 50mm medium shot, slow dolly along the veranda | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@OngBay`, `@Phong` | `LIPSYNC:@OngBay` | **16** | `3.0–7.3s` | "Thằng Sói, mày gầy đi nhiều, nhưng ánh mắt vẫn y như mười hai năm trước." | 35mm wide two-shot from the railing, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@Phong`, `@OngBay` | `LIPSYNC:@Phong` | **17** | `0.4–4.8s` | "Ông Bảy, đêm ấy cảnh sát biết trước đường con xe chạy, là ai đã báo tin?" | 85mm close-up from behind the rattan chair, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | `@OngBay`, `@Phong` | `LIPSYNC:@OngBay` | **17** | `0.4–4.9s` | "Là thằng Khang, nó gọi cảnh sát bán đứng mày, để ngồi vào chiếc ghế của tao." | 50mm medium two-shot in profile, static | Frames: nối khung cuối clip trước |
| [**Clip 6**](clip-6.md) | `@OngBay`, `@Phong` | `LIPSYNC:@OngBay` | **19** | `0.4–5.4s` | "Cuốn sổ đen tao giao mày đêm ấy, nếu còn giữ, nó sẽ trả lại cho mày tất cả." | 85mm close-up, slow rack focus | Frames: nối khung cuối clip trước |
