One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Afternoon at an old French colonial seaside villa with peeling mustard-yellow walls on a rocky headland: a shaded veranda with rattan chairs, a frangipani tree, wrought-iron railings, a grey sea below.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards.
- @Phong = Phong, 45, former getaway driver just out of prison; tall and lean, short black hair greying at the temples, a thin pale scar through his left eyebrow, short dark stubble, weathered tan skin; worn black leather jacket over a charcoal crew-neck T-shirt, dark jeans, black boots, old steel wristwatch.
- @OngBay = Ông Bảy, 72, the retired old port boss; broad but frail, white crew-cut hair, short white goatee, deep-set heavy-lidded eyes; dark-brown silk shirt, beige trousers, wooden prayer beads on his wrist, carved dark wooden cane.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 85mm close-up from behind the rattan chair, slow dolly-in; one smooth camera move from start to end, no cuts.
- Continuity: continues the same moment, place and lighting as the previous shot; same framing axis, no jump.
- Eyelines: the camera stays on one side of the line between the characters (180-degree rule) so their eyes meet across the frame.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; clothing stays fully worn from the first frame.
- 0.0–3.0s: @Phong lowers himself onto the rattan chair opposite @OngBay and leans forward with his elbows on his knees.
- 3.0–7.0s: @Phong asks quietly, his eyes locked on @OngBay's face.
- 7.0–10.0s: @Phong waits without blinking, his clasped hands tightening. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 0.4–4.8s, spoken on camera by @Phong (man of 45, strictly standard Hà Nội Northern accent (never Southern accent), low gravelly baritone, calm and controlled, speaking at a brisk, steady, fast-clipped pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Ông Bảy, đêm ấy cảnh sát biết trước đường con xe chạy, là ai đã báo tin?" (no subtitles)
- @Phong's face and lips stay clearly visible while speaking; after the last word @Phong closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: sea wind, a gull, a chair creaking. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
