# Cảnh 07: Bí Mật Trong Con Xe Cũ (6 Clips × 10s = 60s)

- **Thời gian:** 20:00 Tối, gara gầm cầu (06:00–07:00)
- **Bối cảnh:** Gara sửa xe dưới gầm cầu bê tông.
- **Trục không gian cố định:** Chiếc sedan đen đỗ giữa gara, đầu xe hướng trái màn hình; cửa gara bên phải mở ra dốc cầu.
- **Đạo cụ chính:** Chiếc sedan đen thập niên 90 đèn tròn, tua vít, tấm nhựa táp-lô, đèn pin, đèn lồng sắt, cuốn sổ bìa da đen bọc vải dầu.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Tuan`, `@Phong` | `VO` | **19** | `0.4–5.2s` | "Tối hôm đó ở gara gầm cầu, Phong bảo Tuấn tháo tung bảng táp-lô của con xe cũ." | 28mm wide shot from the garage entrance, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@Phong` | `VO` | **22** | `0.4–5.9s` | "Sau tấm nhựa phủ bụi mười hai năm, một gói vải dầu nằm im lìm, bọc kín cuốn sổ bìa da đen." | 100mm extreme close-up on the hands, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 3**](clip-3.md) | `@Tuan`, `@Phong` | `LIPSYNC:@Tuan` | **18** | `3.0–7.5s` | "Mười hai năm tao chở cả quả bom đi rửa xe mỗi tuần mà không hề hay biết." | 50mm medium two-shot beside the car, slow dolly | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@Phong`, `@Tuan` | `LIPSYNC:@Phong` | **17** | `0.4–4.8s` | "Đây không phải bom, đây là cái giá để mẹ tao với con bé được sống yên." | 85mm close-up, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | — | `VO` | **21** | `0.4–5.7s` | "Ngoài kia, một chiếc xe đen tắt đèn đã nằm im ở chân dốc cầu từ lúc nào không ai hay." | 35mm wide static shot from behind a concrete pillar | Text-to-video |
| [**Clip 6**](clip-6.md) | `@Phong` | `VO` | **18** | `0.4–4.9s` | "Phong không quay đầu, chỉ liếc qua gương chiếu hậu, và hắn biết cuộc săn đã bắt đầu." | 100mm extreme close-up on the rear-view mirror, slow rack focus | Ingredients: ảnh nhân vật |
