One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Night inside a cluttered repair garage under a concrete highway bridge: hanging tools, stacked tires, an oil-stained concrete floor, a single caged work lamp, rain dripping from the bridge edge outside, the restored glossy black 1990s sedan with round headlights parked in the middle.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards.
- @Phong = Phong, 45, former getaway driver just out of prison; tall and lean, short black hair greying at the temples, a thin pale scar through his left eyebrow, short dark stubble, weathered tan skin; worn black leather jacket over a charcoal crew-neck T-shirt, dark jeans, black boots, old steel wristwatch.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 100mm extreme close-up on the hands, slow dolly-in; one smooth camera move from start to end, no cuts.
- Continuity: continues the same moment, place and lighting as the previous shot; same framing axis, no jump.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; clothing stays fully worn from the first frame.
- 0.0–3.0s: @Phong reaches into the dusty cavity behind the dashboard and draws out a package wrapped in old oilcloth.
- 3.0–7.0s: @Phong unfolds the stiff oilcloth on the car seat, revealing the black leather ledger inside.
- 7.0–10.0s: @Phong rests his palm flat on the black leather ledger, dust drifting through the flashlight beam. The shot settles on this as its final frame.

[AUDIO]
- Narration 0.4–5.9s by an off-screen male narrator (Vietnamese man about 45, strictly standard Hà Nội Northern accent (giọng chuẩn Hà Nội Bắc Bộ, never Southern accent) with clear six tones, deep gravelly baritone with crisp consonants, fast gripping crime-film storytelling in one continuous breath, every word spoken once and clearly, no stutter, no repeated words), in Vietnamese, said exactly once: "Sau tấm nhựa phủ bụi mười hai năm, một gói vải dầu nằm im lìm, bọc kín cuốn sổ bìa da đen." (no subtitles)
- After the last word the narrator stays silent until the end of the shot: no repeated words, no echo, no second reading of the line.
- Nobody on screen speaks; every mouth on screen stays closed.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: oilcloth crinkling, rain dripping, a faint electric hum from the lamp. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
