# Cảnh 08: Lời Mời Của Khang Hổ (6 Clips × 10s = 60s)

- **Thời gian:** 07:30 Sáng hôm sau, quán bánh đa (07:00–08:00)
- **Bối cảnh:** Quán bánh đa cua nhỏ của bà Tư trong ngõ chợ ven sông gần cảng.
- **Trục không gian cố định:** Khang ngồi bên trái chiếc bàn giữa quán, Phong bên phải; nồi nước dùng ở hậu cảnh bên trái, lối vào bên phải.
- **Đạo cụ chính:** Bát bánh đa cua, đũa, ghế nhựa đỏ, bàn nhựa xanh, chiếc bật lửa vàng.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Khang` | `VO` | **19** | `0.4–5.2s` | "Sáng hôm sau, Khang Hổ đích thân ghé quán, hai tay đàn em đứng chắn kín lối ra vào." | 28mm wide shot from inside the stall, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@MeTu` | `VO` | **22** | `0.4–5.9s` | "Bà Tư bưng bát bánh đa ra, đôi tay già run đến mức nước dùng sóng sánh tràn cả ra mép bát." | 100mm extreme close-up on the bowl, slow tilt up | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Khang` | `LIPSYNC:@Khang` | **18** | `3.0–7.5s` | "Bánh đa cua bà Tư vẫn ngon nhất cảng, tiếc là quán lợp bạt, dễ bắt lửa lắm." | 50mm medium shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@Phong`, `@Khang` | `VO` | **19** | `0.4–5.2s` | "Phong bước vào, kéo ghế ngồi đối diện, hai người đàn ông nhìn nhau qua làn khói nước dùng." | 35mm wide two-shot in profile across the table, static | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | `@Khang`, `@Phong` | `LIPSYNC:@Khang` | **16** | `0.4–4.4s` | "Anh Phong, đưa em cuốn sổ, em trả anh cả một đời giàu sang yên ổn." | 85mm close-up across the steam, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 6**](clip-6.md) | `@Phong`, `@Khang` | `LIPSYNC:@Phong` | **17** | `0.4–4.8s` | "Mày lấy của tao mười hai năm rồi, Khang, đừng hòng lấy thêm một ngày nào nữa." | 50mm medium two-shot, slow lateral slide | Frames: nối khung cuối clip trước |
