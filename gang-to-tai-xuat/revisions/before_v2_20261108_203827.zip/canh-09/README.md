# Cảnh 09: Đêm Lửa Ngõ Chợ (6 Clips × 10s = 60s)

- **Thời gian:** 00:30 Nửa đêm, ngõ chợ (08:00–09:00)
- **Bối cảnh:** Ngõ chợ ven sông lúc nửa đêm, nhà ống hai tầng phía sau quán bánh đa.
- **Trục không gian cố định:** Ngõ chạy sâu vào hình; quán và mái bạt bên trái màn hình, nhà ống phía sau quán, cuối ngõ là đường lớn.
- **Đạo cụ chính:** Mái bạt quán, bình cứu hỏa đỏ, khăn ướt, bàn nhựa cháy xém, chiếc bật lửa vàng.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **21** | `0.4–5.7s` | "Nửa đêm hôm ấy, mùi xăng lẩn khuất trong ngõ chợ, rồi một đốm lửa nhỏ bùng lên trên mái bạt." | 35mm wide slow dolly-in down the lane | Text-to-video |
| [**Clip 2**](clip-2.md) | `@Phong` | `VO` | **20** | `0.4–5.4s` | "Phong choàng tỉnh vì khói, hắn lao xuống cầu thang, gọi tên mẹ và con trong ánh lửa đỏ rực." | 35mm medium handheld shot from the bottom of the stairs | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@MeTu`, `@An` | `VO` | **21** | `0.4–5.7s` | "An dìu bà nội ra lối cửa sau, khăn ướt che kín mặt, sau lưng là tiếng kính vỡ lách tách." | 50mm close-up tracking backward | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@Phong` | `VO` | **21** | `0.4–5.7s` | "Phong ôm bình cứu hỏa xông ra, dập từng mảng lửa trước khi nó kịp liếm sang dãy nhà bên cạnh." | 28mm wide low-angle shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | `@Huy`, `@Phong` | `LIPSYNC:@Huy` | **16** | `3.0–7.0s` | "Anh thấy chưa, anh mới về được hai ngày, nhà mình đã thành ra thế này!" | 50mm medium two-shot, slow dolly in | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Phong`, `@Huy` | `LIPSYNC:@Phong` | **20** | `0.4–5.6s` | "Đám lửa này là lời nhắn của Khang, và lần này anh sẽ trả lời nó theo cách của anh." | 85mm close-up, slow dolly-in | Frames: nối khung cuối clip trước |
