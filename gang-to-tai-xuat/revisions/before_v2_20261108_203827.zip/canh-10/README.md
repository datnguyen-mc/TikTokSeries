# Cảnh 10: Rượt Đuổi Phố Cổ (6 Clips × 10s = 60s)

- **Thời gian:** 09:00 Sáng, phố cổ Hải Phòng (09:00–10:00)
- **Bối cảnh:** Phố cổ Hải Phòng với dãy nhà Pháp vàng, ngõ hẹp và bến phà ven sông.
- **Trục không gian cố định:** Xe chạy từ trái sang phải màn hình; nhóm xe máy đen luôn ở phía sau Phong.
- **Đạo cụ chính:** Chiếc xe máy cũ xanh rêu đèn tròn của Tuấn, cuốn sổ đen giấu trong áo khoác, chồng thúng tre, ba xe máy đen.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Phong` | `VO` | **19** | `0.4–5.2s` | "Sáng hôm sau, Phong giấu cuốn sổ trong áo khoác, phóng chiếc xe máy cũ của Tuấn ra phố." | 35mm wide street-level tracking shot alongside the motorbike | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@Phong` | `VO` | **19** | `0.4–5.2s` | "Ba chiếc xe máy đen lập tức rồ ga bám theo, những gương mặt quen của băng Khang Hổ." | 85mm telephoto medium shot from the front, slow follow | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Phong` | `VO` | **21** | `0.4–5.7s` | "Phong ngoặt gấp vào con ngõ chỉ vừa một vai người, lách qua dãy chậu cây không sượt một chiếc lá." | 24mm low-angle close-up on the front wheel, fast glide through the alley | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | — | `VO` | **19** | `0.4–5.2s` | "Đám đàn em lao theo, trượt bánh vào chồng thúng tre, rau củ lăn tung tóe khắp mặt ngõ." | 28mm wide locked-off shot facing the alley mouth | Text-to-video |
| [**Clip 5**](clip-5.md) | `@Phong` | `VO` | **19** | `0.4–5.2s` | "Hắn phóng thẳng lên chiếc phà vừa rời bến, bánh sau chạm boong đúng lúc cầu phà kéo lên." | 50mm medium side tracking shot along the concrete ramp | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Phong` | `VO` | **21** | `0.4–5.7s` | "Trên bờ, ba chiếc xe đen phanh kít, chỉ còn biết đứng nhìn con sói già lướt đi giữa dòng sông." | 35mm wide shot from the ferry deck looking back at the shore, slow pull-back | Frames: nối khung cuối clip trước |
