One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Morning in the old quarter of Hải Phòng: narrow streets of mustard-yellow French-era shophouses with green shutters, tangled overhead wires, street vendors' bamboo baskets, potted plants lining a tight alley.

[CHARACTERS]
- Extra: three riders in black helmets on black motorbikes
No named characters appear in this shot; the extras above are the only people in it.

[SHOT]
- Framing & motion: 28mm wide locked-off shot facing the alley mouth; one smooth camera move from start to end, no cuts.
- Continuity: new camera setup; establish the place and light cleanly from the first frame.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; clothing stays fully worn from the first frame.
- 0.0–3.0s: The alley mouth with a tall stack of bamboo baskets full of cabbages, carrots and pumpkins left beside the wall, no vendor in sight.
- 3.0–7.0s: Three riders in black helmets on black motorbikes swerve into the alley too fast, their rear wheels skidding sideways on the damp stones into the stack of baskets.
- 7.0–10.0s: The riders stop their motorbikes in a tangle, unhurt, as cabbages and carrots roll across the alley floor around their boots. The shot settles on this as its final frame.

[AUDIO]
- Narration 0.4–5.2s by an off-screen male narrator (Vietnamese man about 45, strictly standard Hà Nội Northern accent (giọng chuẩn Hà Nội Bắc Bộ, never Southern accent) with clear six tones, deep gravelly baritone with crisp consonants, fast gripping crime-film storytelling in one continuous breath, every word spoken once and clearly, no stutter, no repeated words), in Vietnamese, said exactly once: "Đám đàn em lao theo, trượt bánh vào chồng thúng tre, rau củ lăn tung tóe khắp mặt ngõ." (no subtitles)
- After the last word the narrator stays silent until the end of the shot: no repeated words, no echo, no second reading of the line.
- Nobody on screen speaks; every mouth on screen stays closed.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: tires skidding on stone, wicker baskets toppling, vegetables thudding and rolling. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
