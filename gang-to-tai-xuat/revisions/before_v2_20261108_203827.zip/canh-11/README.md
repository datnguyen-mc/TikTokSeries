# Cảnh 11: Hai Anh Em Trên Boong Phà (6 Clips × 10s = 60s)

- **Thời gian:** 09:30 Sáng, phà qua sông (10:00–11:00)
- **Bối cảnh:** Boong phà cũ chở xe qua sông rộng nước nâu, buổi sáng âm u.
- **Trục không gian cố định:** Lan can phà bên phải màn hình, sông phía sau; Huy bên trái, Phong bên phải.
- **Đạo cụ chính:** Cuốn sổ bìa da đen bọc vải dầu, chiếc xe máy cũ xanh rêu, cuộn dây thừng, lan can sắt gỉ.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Huy` | `VO` | **20** | `0.4–5.4s` | "Trên boong phà, Huy đã đứng chờ sẵn từ lúc nào, cậu bám theo anh trai suốt từ sáng sớm." | 50mm medium shot, slow dolly along the railing | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@Huy`, `@Phong` | `LIPSYNC:@Huy` | **17** | `3.0–7.3s` | "Anh định một mình chơi với cả băng Khang Hổ à? Đưa cuốn sổ đây cho em." | 40mm over-the-shoulder two-shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Phong`, `@Huy` | `LIPSYNC:@Phong` | **19** | `0.4–5.3s` | "Em mở trang cuối ra mà đọc, rồi hãy nói với anh em còn tin được ai trong đồn." | 50mm medium close-up on Phong, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 4**](clip-4.md) | `@Huy` | `VO` | **21** | `0.4–5.7s` | "Huy lật đến trang cuối, mặt cậu tái đi, cái tên quen thuộc nhất lại nằm ngay ở dòng đầu tiên." | 100mm macro extreme close-up on the ledger page, slow tilt up to the face | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | `@Huy`, `@Phong` | `LIPSYNC:@Huy` | **16** | `3.0–7.0s` | "Là sếp trực tiếp của em, hèn gì mấy lần đột kích đều về tay trắng." | 35mm wide two-shot from the far railing, static | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Phong`, `@Huy` | `LIPSYNC:@Phong` | **16** | `0.4–4.6s` | "Vậy thì làm theo cách của anh, em lo pháp luật, còn anh lo đường chạy." | 50mm medium two-shot from behind the railing, slow arc | Frames: nối khung cuối clip trước |
