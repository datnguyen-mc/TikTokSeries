# Cảnh 12: Kế Hoạch Gầm Cầu (6 Clips × 10s = 60s)

- **Thời gian:** 21:00 Tối, gara gầm cầu (11:00–12:00)
- **Bối cảnh:** Gara sửa xe dưới gầm cầu bê tông, buổi tối.
- **Trục không gian cố định:** Con xe đen giữa gara; Huy và Phong đứng bên trái nắp capô, Tuấn bên phải, cửa gara mở ra dốc cầu bên phải.
- **Đạo cụ chính:** Con xe đen, cờ lê, ốc vít, xe đồ chơi xếp thành bản đồ cảng trên nắp capô, đèn lồng sắt.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **21** | `0.4–5.7s` | "Đêm đó gara gầm cầu sáng đèn, những chiếc cờ lê trên nắp capô đã thành tấm bản đồ bến cảng." | 50mm overhead top-down close-up drifting slowly across the hood | Text-to-video |
| [**Clip 2**](clip-2.md) | `@Huy`, `@Phong` | `LIPSYNC:@Huy` | **18** | `3.0–7.5s` | "Đêm mai tàu của Khang nhổ neo, em đã gọi được đội đặc nhiệm từ Hà Nội xuống." | 35mm medium two-shot across the hood, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Phong`, `@Huy` | `LIPSYNC:@Phong` | **17** | `0.4–4.8s` | "Anh sẽ làm mồi, kéo hết lũ đàn em ra khỏi bãi, em chỉ việc mở container." | 85mm close-up on Phong's hands and face, slow tilt up | Frames: nối khung cuối clip trước |
| [**Clip 4**](clip-4.md) | `@Tuan`, `@Phong` | `LIPSYNC:@Tuan` | **17** | `3.0–7.3s` | "Lần này tao lái cẩu cho mày, cái bãi container đó tao thuộc như lòng bàn tay." | 28mm wide shot from the garage doorway, static | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | `@Phong` | `VO` | **19** | `0.4–5.2s` | "Phong nhìn hai người, lần đầu tiên sau mười hai năm, hắn thấy mình không còn đơn độc nữa." | 85mm close-up, slow dolly-in on the face | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Huy`, `@Phong` | `LIPSYNC:@Huy` | **17** | `3.0–7.3s` | "Anh hứa với em một điều thôi, xong việc này, anh phải sống cho mẹ được vui." | 50mm medium two-shot beside the sedan's open door, gentle handheld | Ingredients: ảnh nhân vật |
