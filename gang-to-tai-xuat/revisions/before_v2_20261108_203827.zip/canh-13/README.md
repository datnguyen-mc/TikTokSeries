# Cảnh 13: Bố Và Con Gái (6 Clips × 10s = 60s)

- **Thời gian:** 17:30 Chiều tà, kè biển (12:00–13:00)
- **Bối cảnh:** Kè biển bê tông dài ven thành phố cảng lúc hoàng hôn.
- **Trục không gian cố định:** Biển phía trước, máy quay sau lưng hai bố con; An bên trái, Phong bên phải.
- **Đạo cụ chính:** Bó thư cũ buộc dây nâu, ba lô đen nhỏ của An.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Phong`, `@An` | `VO` | **21** | `0.4–5.7s` | "Chiều hôm ấy, Phong đón An tan trường, hai bố con ngồi trên kè biển trước giờ cô đi học thêm." | 35mm wide shot from behind, slow crane down | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@An` | `VO` | **21** | `0.4–5.7s` | "An mở một lá thư trong bó thư cũ, bố viết nó vào đúng ngày sinh nhật năm cô lên bảy." | 85mm close-up, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@An`, `@Phong` | `LIPSYNC:@An` | **17** | `3.0–7.3s` | "Bố ơi, sao bố lại nhận tội thay người ta? Bố không thương con với bà à?" | 50mm medium two-shot in profile, static | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@Phong`, `@An` | `LIPSYNC:@Phong` | **18** | `0.4–5.1s` | "Vì bố tưởng mình đang cứu một đứa em, nhưng hóa ra bố đã rước sói vào nhà." | 85mm over-the-shoulder close-up on Phong from behind An, static | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | `@An`, `@Phong` | `LIPSYNC:@An` | **19** | `0.4–5.2s` | "Thi xong đại học, bố chở con ra Hà Nội bằng con xe đen ấy nhé, bố hứa đi!" | 35mm medium shot, slow arc around the pair | Frames: nối khung cuối clip trước |
| [**Clip 6**](clip-6.md) | `@Phong`, `@An` | `VO` | **21** | `0.4–5.7s` | "Hắn ngoắc tay hứa, không biết rằng chỉ vài giờ nữa thôi, lời hứa ấy suýt thành lời hứa cuối cùng." | 24mm aerial wide shot pulling back from the sea wall | Ingredients: ảnh nhân vật |
