One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Golden sunset on a long concrete sea wall at the edge of the port city: calm silver sea, fishing boats on the horizon, cranes silhouetted far away.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards, and never flash or display the studio reference portrait card in the opening frames; 0.0–3.0s establishes the empty environment first and characters appear only from 3.0s onward.
- @An = An, 18, Phong's daughter; slim, long straight black hair in a high ponytail, bright stubborn eyes, no makeup; mustard-yellow hoodie, light-blue jeans, white sneakers, small black backpack.
- @Phong = Phong, 45, former getaway driver just out of prison; tall and lean, short black hair greying at the temples, a thin pale scar through his left eyebrow, short dark stubble, weathered tan skin; worn black leather jacket over a charcoal crew-neck T-shirt, dark jeans, black boots, old steel wristwatch.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 50mm medium two-shot in profile, static; one smooth camera move from start to end, no cuts.
- Continuity: new camera setup; 0.0–3.0s establishes the empty location and light with no person in frame, then reveals the character naturally from 3.0s.
- Eyelines: the camera stays on one side of the line between the characters (180-degree rule) so their eyes meet across the frame.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; 0.0–3.0s shows the environment and props only with no character on screen, and characters enter from 3.0s onward with clothing fully worn.
- 0.0–3.0s: Profile view along the sea wall at sunset, the open letter lying on the concrete, small waves catching the golden light below.
- 3.0–7.0s: @An turns toward @Phong beside her, holding the letter against her knee, and asks him with wet eyes.
- 7.0–10.0s: @An keeps looking at @Phong, her breath catching as she waits. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 3.0–7.3s, spoken on camera by @An (young woman of 18, strictly standard Hà Nội Northern accent (never Southern accent), clear bright soprano, stubborn and emotional, speaking at a brisk, urgent, fast-clipped pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Bố ơi, sao bố lại nhận tội thay người ta? Bố không thương con với bà à?" (no subtitles)
- From 3.0s onward, @An's face and lips stay clearly visible while speaking; after the last word @An closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: waves, distant gulls, wind. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
