One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Golden sunset on a long concrete sea wall at the edge of the port city: calm silver sea, fishing boats on the horizon, cranes silhouetted far away.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards.
- @Phong = Phong, 45, former getaway driver just out of prison; tall and lean, short black hair greying at the temples, a thin pale scar through his left eyebrow, short dark stubble, weathered tan skin; worn black leather jacket over a charcoal crew-neck T-shirt, dark jeans, black boots, old steel wristwatch.
- @An = An, 18, Phong's daughter; slim, long straight black hair in a high ponytail, bright stubborn eyes, no makeup; mustard-yellow hoodie, light-blue jeans, white sneakers, small black backpack.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 85mm over-the-shoulder close-up on Phong from behind An, static; one smooth camera move from start to end, no cuts.
- Continuity: continues the same moment, place and lighting as the previous shot; same framing axis, no jump.
- Eyelines: the camera stays on one side of the line between the characters (180-degree rule) so their eyes meet across the frame.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; clothing stays fully worn from the first frame.
- 0.0–3.0s: @Phong looks down at his scarred hands resting on his knees, then turns his face toward @An.
- 3.0–7.0s: @Phong speaks steadily to @An, the low sun lighting the thin scar through his eyebrow.
- 7.0–10.0s: @Phong closes his mouth and swallows, his eyes glistening in the golden light. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 0.4–5.1s, spoken on camera by @Phong (man of 45, strictly standard Hà Nội Northern accent (never Southern accent), low gravelly baritone, calm and controlled, speaking at a brisk, steady, fast-clipped pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Vì bố tưởng mình đang cứu một đứa em, nhưng hóa ra bố đã rước sói vào nhà." (no subtitles)
- @Phong's face and lips stay clearly visible while speaking; after the last word @Phong closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: waves, wind, a distant boat horn. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
