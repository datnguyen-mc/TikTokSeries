# Cảnh 14: Chiếc Xe Thùng Đen (6 Clips × 10s = 60s)

- **Thời gian:** 19:00 Tối, cổng lò luyện thi (13:00–14:00)
- **Bối cảnh:** Cổng một lò luyện thi trên phố, đầu buổi tối.
- **Trục không gian cố định:** Cổng lò luyện thi bên trái màn hình, xe thùng đen đỗ dưới gốc bàng bên phải.
- **Đạo cụ chính:** Chiếc xe thùng đen kính tối, điện thoại của An, ba lô đen nhỏ.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **20** | `0.4–5.4s` | "Tối hôm ấy, trước cổng lò luyện thi, một chiếc xe thùng đen đã đỗ sẵn dưới gốc cây bàng." | 35mm wide shot, slow dolly along the pavement | Text-to-video |
| [**Clip 2**](clip-2.md) | `@An` | `VO` | **21** | `0.4–5.7s` | "An bước ra cổng, vừa nhắn tin cho bố thì cửa xe trượt mở, một gã áo đen khẽ cúi chào." | 50mm medium shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@An` | `LIPSYNC:@An` | **16** | `0.4–4.4s` | "Các anh là ai? Tránh ra, bố tôi đang đến đón tôi ngay bây giờ đấy!" | 85mm close-up on her face, handheld | Frames: nối khung cuối clip trước |
| [**Clip 4**](clip-4.md) | `@Khang` | `LIPSYNC:@Khang` | **18** | `3.0–7.5s` | "Cháu An, chú là bạn cũ của bố cháu, lên xe đi, chú đưa cháu đi gặp bố." | 40mm medium shot from the open side door, static | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | `@An` | `VO` | **22** | `0.4–5.9s` | "An nhìn quanh, ba gã áo đen đã đứng kín sau lưng, cô siết chặt quai ba lô rồi bước lên xe." | 24mm wide high-angle shot, slow crane down | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | — | `VO` | **25** | `0.4–6.7s` | "Cửa xe đóng lại, chiếc xe thùng lặng lẽ khuất vào bóng tối, chỉ còn chiếc điện thoại sáng màn hình nằm dưới lòng đường." | 50mm ground-level close-up, rack focus from the street to the phone | Text-to-video |
