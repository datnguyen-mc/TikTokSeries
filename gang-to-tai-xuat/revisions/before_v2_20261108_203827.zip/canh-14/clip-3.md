One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Early evening outside a tutoring center on a city street: a row of parked motorbikes, warm shop lights, a streetlamp, an Indian almond tree, a quiet dark side street.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards.
- @An = An, 18, Phong's daughter; slim, long straight black hair in a high ponytail, bright stubborn eyes, no makeup; mustard-yellow hoodie, light-blue jeans, white sneakers, small black backpack.
- Extra: a henchman in a black shirt standing beside the black van, keeping his distance
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 85mm close-up on her face, handheld; one smooth camera move from start to end, no cuts.
- Continuity: continues the same moment, place and lighting as the previous shot; same framing axis, no jump.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; clothing stays fully worn from the first frame.
- 0.0–3.0s: @An takes one step back from the open van door, both hands tightening on her backpack straps.
- 3.0–7.0s: @An speaks sharply toward the henchman in a black shirt, who stands still beside the van with his hands folded in front of him.
- 7.0–10.0s: @An's eyes dart along the dark street, her chest rising fast. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 0.4–4.4s, spoken on camera by @An (young woman of 18, strictly standard Hà Nội Northern accent (never Southern accent), clear bright soprano, stubborn and emotional, speaking at a brisk, urgent, fast-clipped pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Các anh là ai? Tránh ra, bố tôi đang đến đón tôi ngay bây giờ đấy!" (no subtitles)
- @An's face and lips stay clearly visible while speaking; after the last word @An closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: traffic, cicadas, an idling engine. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
