# Cảnh 15: Cuộc Gọi Từ Kẻ Phản Bội (6 Clips × 10s = 60s)

- **Thời gian:** 21:00 Đêm, trước lò luyện thi & văn phòng Khang (14:00–15:00)
- **Bối cảnh:** Phố trước cổng lò luyện thi lúc đêm muộn; văn phòng kính tầng thượng của Khang ban đêm.
- **Trục không gian cố định:** Phong đứng cạnh con xe đen đỗ bên lề, cổng lò luyện thi phía sau bên trái; Khang đứng bên cửa kính nhìn ra cảng.
- **Đạo cụ chính:** Con xe đen, điện thoại vỡ màn hình của An, điện thoại và chén trà của Khang.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Phong` | `VO` | **21** | `0.4–5.7s` | "Phong đợi mãi trước cổng lò luyện thi, rồi hắn nhặt lên chiếc điện thoại vỡ màn hình của con gái." | 35mm wide shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@Phong` | `VO` | **23** | `0.4–6.2s` | "Đúng lúc đó, chính chiếc điện thoại ấy rung lên, và giọng nói đầu dây bên kia hắn nhớ suốt mười hai năm." | 85mm close-up on the phone and face, slow tilt up | Frames: nối khung cuối clip trước |
| [**Clip 3**](clip-3.md) | `@Khang` | `LIPSYNC:@Khang` | **18** | `3.0–7.5s` | "Anh Phong, con bé đang ngồi uống trà với em, mang cuốn sổ đến bãi container một mình." | 50mm medium shot from behind the desk, slow arc | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@Phong` | `LIPSYNC:@Phong` | **20** | `3.0–8.2s` | "Mày động vào một sợi tóc của con tao, cả cái cảng này sẽ không còn chỗ cho mày trốn." | 100mm extreme close-up on the face, static | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | `@Khang` | `LIPSYNC:@Khang` | **17** | `3.0–7.3s` | "Nửa đêm nay, bãi container cũ, đúng chỗ anh bị bắt năm xưa, em sẽ chờ anh." | 35mm wide shot from across the office, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Phong` | `VO` | **22** | `0.4–5.9s` | "Hắn cúp máy, siết chặt chiếc điện thoại, lần đầu tiên sau mười hai năm, đôi mắt con sói già đỏ lên." | 50mm medium shot, slow dolly around him | Ingredients: ảnh nhân vật |
