One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
The top-floor glass office at night, city and harbor lights beyond the windows, a single desk lamp.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards, and never flash or display the studio reference portrait card in the opening frames; 0.0–3.0s establishes the empty environment first and characters appear only from 3.0s onward.
- @Khang = Khang, 42, the polished port boss; medium build, slicked-back black hair, clean-shaven, cold narrow eyes, faint smirk; cream linen suit over a black open-collar shirt, thin gold chain, gold wristwatch, polished brown loafers.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 50mm medium shot from behind the desk, slow arc; one smooth camera move from start to end, no cuts.
- Continuity: new camera setup; 0.0–3.0s establishes the empty location and light with no person in frame, then reveals the character naturally from 3.0s.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; 0.0–3.0s shows the environment and props only with no character on screen, and characters enter from 3.0s onward with clothing fully worn.
- 0.0–3.0s: The top-floor glass office at night, a single desk lamp glowing on the dark polished desk, harbor lights glittering beyond the tall windows.
- 3.0–7.0s: @Khang stands at the window with a phone to his ear, holding a small cup of tea in his other hand as he speaks.
- 7.0–10.0s: @Khang sips the tea slowly, watching the harbor lights with a faint smirk. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 3.0–7.5s, spoken on camera by @Khang (man of 42, strictly standard Hà Nội Northern accent (never Southern accent), smooth silky baritone, mocking and cold, speaking at a brisk, fast-clipped pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Anh Phong, con bé đang ngồi uống trà với em, mang cuốn sổ đến bãi container một mình." (no subtitles)
- From 3.0s onward, @Khang's face and lips stay clearly visible while speaking; after the last word @Khang closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: air-conditioning hum, a teacup clinking on a saucer. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
