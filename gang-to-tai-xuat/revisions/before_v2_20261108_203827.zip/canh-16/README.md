# Cảnh 16: An Trong Căn Phòng Tôn (6 Clips × 10s = 60s)

- **Thời gian:** 22:00 Đêm, phòng điều hành bằng container (15:00–16:00)
- **Bối cảnh:** Phòng điều hành làm từ container ở góc khuất bãi cảng, ban đêm.
- **Trục không gian cố định:** Cửa thép bên phải màn hình, bàn sắt bên trái, cửa sổ chấn song ở giữa.
- **Đạo cụ chính:** Đèn tuýp chập chờn, ấm trà, chén trà, chiếc kẹp tóc đen, ổ khóa cửa thép.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **21** | `0.4–5.7s` | "Ở một góc khuất của bãi container, An bị giữ trong căn phòng tôn, chỉ có chiếc đèn tuýp chập chờn." | 24mm wide shot, slow pan across the room | Text-to-video |
| [**Clip 2**](clip-2.md) | `@An` | `VO` | **21** | `0.4–5.7s` | "Cô bé không khóc, chỉ lặng lẽ nhìn qua khe cửa, đếm từng bước chân của bọn canh gác bên ngoài." | 85mm close-up, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Khang`, `@An` | `LIPSYNC:@Khang` | **17** | `3.0–7.3s` | "Bố cháu là người giỏi nhất chú từng biết, chỉ tiếc là ông ấy quá tin người." | 40mm medium two-shot across the desk, static | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@An`, `@Khang` | `LIPSYNC:@An` | **18** | `0.4–4.9s` | "Bố tôi sẽ đến, chú cứ chờ mà xem, lần này người phải chạy trốn là chú đấy." | 85mm over-the-shoulder close-up on An from behind Khang, static | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | `@An` | `VO` | **21** | `0.4–5.7s` | "Khang bật cười bỏ đi, gã không để ý An đã kịp giấu chiếc kẹp tóc đen vào lòng bàn tay." | 100mm extreme close-up on her hand, slow tilt up | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@An` | `VO` | **19** | `0.4–5.2s` | "Cô bé nhớ lời bố dặn chiều nay, gặp nguy thì đừng hoảng, hãy bình tĩnh tìm đường thoát." | 50mm medium shot, slow dolly toward the door | Frames: nối khung cuối clip trước |
