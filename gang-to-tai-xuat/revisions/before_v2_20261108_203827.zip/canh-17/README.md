# Cảnh 17: Anh Em Bến Cảng (6 Clips × 10s = 60s)

- **Thời gian:** 22:30 Đêm, sân thượng đồn, biệt thự Ông Bảy, xóm thợ cảng (16:00–17:00)
- **Bối cảnh:** Sân thượng đồn cảnh sát, trong con xe đen, hiên biệt thự Ông Bảy và xóm nhà tôn ven cảng — ban đêm.
- **Trục không gian cố định:** Mỗi bối cảnh một trục: Huy nhìn ra cảng bên phải; xe chạy trái sang phải; ở hiên biệt thự biển phía sau bên trái.
- **Đạo cụ chính:** Điện thoại của Huy, con xe đen, đèn dầu, điện thoại bàn quay số cũ, gậy gỗ chạm, đèn pin.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Huy` | `LIPSYNC:@Huy` | **19** | `3.0–7.8s` | "Cuốn sổ thật em đã giao cho đặc nhiệm, anh cầm chân thằng Khang đến lúc bọn em tới." | 50mm medium shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@Phong` | `VO` | **20** | `0.4–5.4s` | "Phong không chờ ai cả, hắn quay xe thẳng lên mỏm đá, nơi ông trùm già vẫn đang thức đợi." | 35mm close-up through the windshield, slow drift | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@OngBay` | `VO` | **20** | `0.4–5.4s` | "Ông Bảy chống gậy đứng dậy, lần đầu sau nhiều năm, ông nhấc chiếc điện thoại bàn đã phủ bụi." | 28mm wide shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@OngBay` | `LIPSYNC:@OngBay` | **19** | `0.4–5.4s` | "Anh em bến cảng đâu, thằng Sói về rồi, đêm nay ai còn nhớ ơn nó thì ra bãi." | 85mm close-up, static | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | `@Phong`, `@OngBay` | `LIPSYNC:@OngBay` | **16** | `3.0–7.3s` | "Mày đi đi, đêm nay cả bến cảng này sẽ đứng sau lưng mày, Sói ạ." | 50mm medium two-shot, slow arc | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | — | `VO` | **25** | `0.4–6.7s` | "Trong những dãy nhà tôn ven cảng, từng ngọn đèn pin lần lượt bật sáng, những người thợ bốc vác già lặng lẽ bước ra." | 24mm aerial wide shot, slow crane down over the rooftops | Text-to-video |
