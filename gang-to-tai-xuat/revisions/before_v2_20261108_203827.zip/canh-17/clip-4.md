One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
The villa veranda at night, a single oil lamp, black sea and distant harbor lights below.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards.
- @OngBay = Ông Bảy, 72, the retired old port boss; broad but frail, white crew-cut hair, short white goatee, deep-set heavy-lidded eyes; dark-brown silk shirt, beige trousers, wooden prayer beads on his wrist, carved dark wooden cane.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 85mm close-up, static; one smooth camera move from start to end, no cuts.
- Continuity: continues the same moment, place and lighting as the previous shot; same framing axis, no jump.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; clothing stays fully worn from the first frame.
- 0.0–3.0s: @OngBay holds the heavy receiver to his ear, his finger turning the rotary dial.
- 3.0–7.0s: @OngBay speaks slowly into the receiver, his heavy-lidded eyes hardening in the oil-lamp glow.
- 7.0–10.0s: @OngBay sets the receiver back down and keeps one hand resting on it. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 0.4–5.4s, spoken on camera by @OngBay (man of 72, strictly standard Hà Nội Northern accent (never Southern accent), deep raspy bass, slow authority but fluent, speaking at a brisk, clipped pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Anh em bến cảng đâu, thằng Sói về rồi, đêm nay ai còn nhớ ơn nó thì ra bãi." (no subtitles)
- @OngBay's face and lips stay clearly visible while speaking; after the last word @OngBay closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: a rotary dial clicking, waves below, wind. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
