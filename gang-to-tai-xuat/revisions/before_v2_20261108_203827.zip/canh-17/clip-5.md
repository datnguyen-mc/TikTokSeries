One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
The villa veranda at night, a single oil lamp, black sea and distant harbor lights below.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards, and never flash or display the studio reference portrait card in the opening frames; 0.0–3.0s establishes the empty environment first and characters appear only from 3.0s onward.
- @Phong = Phong, 45, former getaway driver just out of prison; tall and lean, short black hair greying at the temples, a thin pale scar through his left eyebrow, short dark stubble, weathered tan skin; worn black leather jacket over a charcoal crew-neck T-shirt, dark jeans, black boots, old steel wristwatch.
- @OngBay = Ông Bảy, 72, the retired old port boss; broad but frail, white crew-cut hair, short white goatee, deep-set heavy-lidded eyes; dark-brown silk shirt, beige trousers, wooden prayer beads on his wrist, carved dark wooden cane.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 50mm medium two-shot, slow arc; one smooth camera move from start to end, no cuts.
- Continuity: new camera setup; 0.0–3.0s establishes the empty location and light with no person in frame, then reveals the character naturally from 3.0s.
- Eyelines: the camera stays on one side of the line between the characters (180-degree rule) so their eyes meet across the frame.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; 0.0–3.0s shows the environment and props only with no character on screen, and characters enter from 3.0s onward with clothing fully worn.
- 0.0–3.0s: The veranda steps in the oil-lamp glow, rain dripping from the frangipani leaves, the black sea beyond.
- 3.0–7.0s: @Phong climbs the steps onto the veranda as @OngBay turns to face him and rests one hand on his shoulder, speaking.
- 7.0–10.0s: @Phong gives one deep nod to @OngBay, rain glistening on his black leather jacket. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 3.0–7.3s, spoken on camera by @OngBay (man of 72, strictly standard Hà Nội Northern accent (never Southern accent), deep raspy bass, slow authority but fluent, speaking at a brisk, clipped pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Mày đi đi, đêm nay cả bến cảng này sẽ đứng sau lưng mày, Sói ạ." (no subtitles)
- From 3.0s onward, @OngBay's face and lips stay clearly visible while speaking; after the last word @OngBay closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: rain dripping, waves, wind. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
