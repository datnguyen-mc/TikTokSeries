# Cảnh 18: Sói Tái Xuất (6 Clips × 10s = 60s)

- **Thời gian:** 23:00 Đêm, nhà bà Tư & gara gầm cầu (17:00–18:00)
- **Bối cảnh:** Gian nhà ống ám khói sau quán bánh đa, rồi gara gầm cầu, ban đêm.
- **Trục không gian cố định:** Bàn thờ ở giữa tường sau; bà Tư bên trái, Phong bên phải. Ở gara: con xe đen giữa khung, cửa gara bên phải.
- **Đạo cụ chính:** Bàn thờ nhỏ, ba nén nhang, đèn vàng, cuốn sổ bọc vải dầu, đôi găng tay lái da cũ, con xe đen, chìa khóa xe.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@MeTu` | `VO` | **20** | `0.4–5.4s` | "Trước khi đi, Phong ghé về nhà, mẹ hắn đã thắp sẵn ba nén nhang trên bàn thờ ám khói." | 50mm medium shot, slow dolly toward the altar | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@MeTu`, `@Phong` | `LIPSYNC:@MeTu` | **18** | `3.0–7.8s` | "Con đi đưa cái An về, mẹ nấu sẵn nồi bánh đa, chờ hai bố con về ăn." | 35mm wide two-shot from the doorway, static | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Phong`, `@MeTu` | `LIPSYNC:@Phong` | **18** | `0.4–5.1s` | "Mẹ ơi, con nợ mẹ mười hai năm, đêm nay con xin trả trước một phần, mẹ nhé." | 85mm close-up over her shoulder, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 4**](clip-4.md) | `@Phong` | `VO` | **25** | `0.4–6.7s` | "Ở gara, Phong bọc cuốn sổ vào tấm vải dầu cũ, rồi đeo đôi găng tay lái đã nằm trong hộc xe mười hai năm." | 100mm extreme close-up on the hands, slow tilt up | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | `@Tuan`, `@Phong` | `LIPSYNC:@Tuan` | **17** | `3.0–7.3s` | "Xăng đầy bình, lốp mới thay, con xe này chỉ chờ đúng đêm nay thôi, Sói ạ!" | 35mm medium two-shot beside the car, slow dolly | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Phong` | `VO` | **16** | `0.4–4.4s` | "Tiếng máy gầm lên dưới gầm cầu, và Phong Sói chính thức tái xuất giang hồ." | 24mm low-angle wide shot from bumper height, static then slow creep forward | Ingredients: ảnh nhân vật |
