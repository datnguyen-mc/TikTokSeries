# Cảnh 19: Bãi Container Nửa Đêm (6 Clips × 10s = 60s)

- **Thời gian:** 00:00 Nửa đêm, bãi container (18:00–19:00)
- **Bối cảnh:** Bãi container cảng Vạn Hải lúc nửa đêm, mưa lớn, y như đêm định mệnh mười hai năm trước.
- **Trục không gian cố định:** Xe của Phong tiến vào từ bên trái màn hình; Khang và hàng SUV đen đứng bên phải dưới đèn cần cẩu.
- **Đạo cụ chính:** Xe sedan đen thập niên 90 đèn tròn, cuốn sổ bọc vải dầu, ô đen của Khang, hàng SUV đen kính tối.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **18** | `0.4–4.9s` | "Nửa đêm, mưa lại trút xuống bãi container, y hệt cái đêm định mệnh mười hai năm trước." | 24mm aerial slow descending glide through the rain | Text-to-video |
| [**Clip 2**](clip-2.md) | `@Phong` | `VO` | **20** | `0.4–5.4s` | "Con xe đen chậm rãi lăn bánh giữa hai dãy container, đèn pha rọi thẳng vào hàng xe của Khang." | 35mm medium shot through the windshield, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Khang` | `VO` | **22** | `0.4–5.9s` | "Khang đứng chờ dưới ánh đèn cẩu, ung dung che ô, còn An vẫn bị nhốt đâu đó giữa mê cung container." | 50mm wide low-angle locked-off shot | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@Phong` | `LIPSYNC:@Phong` | **17** | `3.0–7.4s` | "Thả con bé ra, sổ ở đây, chuyện của người lớn thì mày với tao giải quyết." | 50mm medium shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | `@Khang` | `LIPSYNC:@Khang` | **17** | `3.0–7.3s` | "Anh vẫn thế, anh Phong, vẫn tin rằng cứ nhận hết về mình là xong mọi chuyện." | 85mm close-up, locked-off | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Phong`, `@Khang` | `VO` | **21** | `0.4–5.7s` | "Phong đặt cuốn sổ lên nắp capô, hai người đàn ông bước chậm về phía nhau giữa màn mưa trắng xóa." | 24mm wide high-angle crane shot rising slowly | Ingredients: ảnh nhân vật |
