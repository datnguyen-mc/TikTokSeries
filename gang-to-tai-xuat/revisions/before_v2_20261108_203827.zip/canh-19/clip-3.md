One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
A vast container port yard at midnight in heavy rain: towering stacks of rust-red, blue and green shipping containers forming narrow lanes, a towering yellow gantry crane lit by sodium floodlights, deep puddles on the asphalt.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards, and never flash or display the studio reference portrait card in the opening frames; 0.0–3.0s establishes the empty environment first and characters appear only from 3.0s onward.
- @Khang = Khang, 42, the polished port boss; medium build, slicked-back black hair, clean-shaven, cold narrow eyes, faint smirk; cream linen suit over a black open-collar shirt, thin gold chain, gold wristwatch, polished brown loafers.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 50mm wide low-angle locked-off shot; one smooth camera move from start to end, no cuts.
- Continuity: new camera setup; 0.0–3.0s establishes the empty location and light with no person in frame, then reveals the character naturally from 3.0s.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; 0.0–3.0s shows the environment and props only with no character on screen, and characters enter from 3.0s onward with clothing fully worn.
- 0.0–3.0s: A pool of sodium floodlight under the towering yellow gantry crane, rain falling in bright sheets, black SUVs with tinted windows parked in a row behind.
- 3.0–7.0s: @Khang stands in the light under a black umbrella, his cream linen suit spotless, one hand in his pocket, gaze fixed on the approaching headlights.
- 7.0–10.0s: @Khang tilts the umbrella slightly back and smiles thinly, his gold wristwatch glinting as rain streams off the umbrella's edge. The shot settles on this as its final frame.

[AUDIO]
- Narration 0.4–5.9s by an off-screen male narrator (Vietnamese man about 45, strictly standard Hà Nội Northern accent (giọng chuẩn Hà Nội Bắc Bộ, never Southern accent) with clear six tones, deep gravelly baritone with crisp consonants, fast gripping crime-film storytelling in one continuous breath, every word spoken once and clearly, no stutter, no repeated words), in Vietnamese, said exactly once: "Khang đứng chờ dưới ánh đèn cẩu, ung dung che ô, còn An vẫn bị nhốt đâu đó giữa mê cung container." (no subtitles)
- After the last word the narrator stays silent until the end of the shot: no repeated words, no echo, no second reading of the line.
- Nobody on screen speaks; every mouth on screen stays closed.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: rain pattering on an umbrella, idling SUV engines, the buzz of floodlights. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
