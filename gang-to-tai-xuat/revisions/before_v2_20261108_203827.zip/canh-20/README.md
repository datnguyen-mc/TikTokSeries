# Cảnh 20: Cuốn Sổ Trắng (6 Clips × 10s = 60s)

- **Thời gian:** 00:10 Nửa đêm, bãi container & phòng tôn (19:00–20:00)
- **Bối cảnh:** Lối container trước mũi xe Phong; căn phòng tôn nơi An bị giữ; lối hẹp giữa các dãy container.
- **Trục không gian cố định:** Phong bên trái, Khang bên phải giữa hai luồng đèn pha; trong phòng tôn, cửa thép bên phải màn hình.
- **Đạo cụ chính:** Cuốn sổ trắng, tấm vải dầu, kẹp tóc đen, cửa thép phòng tôn, xe sedan đen.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Khang` | `VO` | **19** | `0.4–5.2s` | "Khang cầm cuốn sổ lên, lật vội từng trang dưới ánh đèn pha, rồi bàn tay gã khựng lại." | 50mm medium shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@Khang` | `VO` | **18** | `0.4–4.9s` | "Từng trang giấy đều trắng tinh, cuốn sổ thật đã nằm trong tay đội đặc nhiệm từ chiều." | 100mm extreme close-up on the pages, slow tilt up to the face | Frames: nối khung cuối clip trước |
| [**Clip 3**](clip-3.md) | `@Khang`, `@Phong` | `LIPSYNC:@Khang` | **19** | `3.0–7.8s` | "Anh dám lừa em à, anh Phong? Anh quên con gái anh đang ở trong tay ai rồi sao?" | 35mm medium two-shot, slow lateral track | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@Phong`, `@Khang` | `LIPSYNC:@Phong` | **18** | `0.4–5.1s` | "Mười hai năm trước tao dạy mày chạy, đêm nay tao dạy mày cách đứng lại chịu tội." | 85mm close-up over Khang's shoulder on Phong | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | `@An` | `VO` | **21** | `0.4–5.7s` | "Cùng lúc ấy, trong căn phòng tôn, chiếc kẹp tóc của An xoay thêm một vòng, và ổ khóa bật mở." | 100mm extreme close-up on the lock, slow rack focus to the face | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@An` | `VO` | **21** | `0.4–5.7s` | "Cô bé lách ra ngoài, men theo bóng tối giữa những dãy container, chạy về phía ánh đèn pha của bố." | 28mm wide low tracking shot | Ingredients: ảnh nhân vật |
