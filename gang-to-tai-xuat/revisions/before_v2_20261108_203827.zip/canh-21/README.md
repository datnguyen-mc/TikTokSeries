# Cảnh 21: Đèn Cẩu Bật Sáng (6 Clips × 10s = 60s)

- **Thời gian:** 00:15 Nửa đêm, bãi container (20:00–21:00)
- **Bối cảnh:** Bãi container dưới cần cẩu giàn vàng; buồng lái cần cẩu của Tuấn trên cao.
- **Trục không gian cố định:** Cần cẩu và lối ra ở cuối hình; Khang đứng giữa vùng đèn; xe của Phong bên trái màn hình.
- **Đạo cụ chính:** Cần cẩu giàn vàng, container đỏ gỉ chặn lối, đèn pin của anh em bến cảng, xe sedan đen, cuốn sổ trắng.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Khang` | `LIPSYNC:@Khang` | **16** | `3.0–7.0s` | "Lục tung cả cái bãi này lên, tìm con bé về đây cho tao, nhanh lên!" | 35mm medium shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@Tuan` | `VO` | **19** | `0.4–5.2s` | "Đúng lúc ấy, trên buồng lái cần cẩu cao ba mươi mét, Tuấn Còi kéo mạnh cần điều khiển." | 24mm wide shot inside the cab, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | — | `VO` | **23** | `0.4–6.2s` | "Một chiếc container khổng lồ từ từ hạ xuống chặn ngang lối ra, đám đàn em khựng lại, lùi dần về phía sau." | aerial top-down shot slowly descending | Text-to-video |
| [**Clip 4**](clip-4.md) | — | `VO` | **20** | `0.4–5.4s` | "Rồi hàng chục ngọn đèn pin bật sáng trên nóc container, anh em bến cảng của Ông Bảy đã đến." | 24mm wide low-angle slow pan along the container tops | Text-to-video |
| [**Clip 5**](clip-5.md) | `@Khang` | `VO` | **21** | `0.4–5.7s` | "Đám đàn em nhìn nhau, rồi từng đứa một lặng lẽ lùi vào bóng tối, bỏ mặc Khang đứng một mình." | 50mm medium shot, slow arc | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@An`, `@Phong` | `VO` | **22** | `0.4–5.9s` | "An chạy ra từ giữa hai dãy container, lao vào vòng tay bố, Phong mở cửa đưa con bé lên ghế phụ." | 28mm wide tracking shot | Ingredients: ảnh nhân vật |
