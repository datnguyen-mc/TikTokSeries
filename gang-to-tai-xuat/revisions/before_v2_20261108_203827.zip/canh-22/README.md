# Cảnh 22: Rượt Đuổi Mê Cung Container (6 Clips × 10s = 60s)

- **Thời gian:** 00:20 Nửa đêm, mê cung container (21:00–22:00)
- **Bối cảnh:** Mê cung container trong mưa và bên trong con xe đen của Phong.
- **Trục không gian cố định:** Xe của Phong chạy từ trái sang phải màn hình; hai SUV đen bám phía sau; trong xe Phong cầm lái bên trái, An ghế phụ bên phải.
- **Đạo cụ chính:** Xe sedan đen, hai SUV đen kính tối, đống pallet gỗ rỗng, gương chiếu hậu, ca nô trắng phía cầu tàu.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **22** | `0.4–5.9s` | "Hai chiếc xe đen của đám đàn em trung thành cuối cùng rồ máy, đèn pha quét loang loáng giữa màn mưa." | 24mm wide low-angle shot | Text-to-video |
| [**Clip 2**](clip-2.md) | `@Phong`, `@An` | `LIPSYNC:@Phong` | **18** | `3.0–7.7s` | "Thắt dây an toàn vào con, bố cho con xem vì sao người ta gọi bố là Sói." | 35mm medium two-shot through the windshield, locked to the car | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | — | `VO` | **20** | `0.4–5.4s` | "Con xe đen lướt vào mê cung container, drift qua từng khúc cua hẹp chỉ cách vách thép vài phân." | 24mm aerial shot following overhead | Text-to-video |
| [**Clip 4**](clip-4.md) | `@An`, `@Phong` | `LIPSYNC:@An` | **16** | `3.0–7.0s` | "Bố ơi, bên trái có khe hở vừa đúng một thân xe, bố lách vào đi!" | 50mm close-up on An, handheld | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | — | `VO` | **20** | `0.4–5.4s` | "Hai chiếc xe đuổi theo không kịp phanh, trượt dài trên mặt đường ướt rồi lao vào đống pallet gỗ." | 24mm wide locked-off framing of the gap | Text-to-video |
| [**Clip 6**](clip-6.md) | `@Phong`, `@An` | `VO` | **21** | `0.4–5.7s` | "Trong gương chiếu hậu chỉ còn khói và mưa, nhưng phía cầu tàu, một chiếc ca nô trắng vừa nổ máy." | 85mm close-up on the rear-view mirror, rack focus to the windshield | Ingredients: ảnh nhân vật |
