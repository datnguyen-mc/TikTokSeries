# Cảnh 23: Ca Nô Trốn Chạy (6 Clips × 10s = 60s)

- **Thời gian:** 00:40 Đêm, cầu tàu & mặt sông (22:00–23:00)
- **Bối cảnh:** Cầu tàu gỗ và bê tông ở rìa cảng trong mưa; mặt sông đen kịt.
- **Trục không gian cố định:** Cầu tàu chạy dọc bên trái màn hình, mặt sông mở ra bên phải; trên sông, ca nô dẫn trước, xuồng bám sau.
- **Đạo cụ chính:** Ca nô trắng, xuồng máy gỗ của dân chài, cuộn dây thừng, xe sedan đen đỗ đầu cầu tàu.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Khang` | `VO` | **21** | `0.4–5.7s` | "Khang bỏ lại tất cả, nhảy xuống chiếc ca nô trắng, rồ máy lao ra cửa sông trong màn mưa đêm." | 35mm wide tracking shot along the pier | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@Phong`, `@An` | `LIPSYNC:@Phong` | **17** | `3.0–7.4s` | "Con ở lại đây chờ chú Tuấn, bố phải đi đòi lại món nợ mười hai năm." | 50mm medium two-shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@An`, `@Phong` | `LIPSYNC:@An` | **17** | `0.4–4.7s` | "Bố phải về đấy, bố còn nợ con một chuyến ra Hà Nội bằng con xe đen." | 85mm close-up over Phong's shoulder on An | Frames: nối khung cuối clip trước |
| [**Clip 4**](clip-4.md) | `@Phong` | `VO` | **21** | `0.4–5.7s` | "Phong nhảy xuống chiếc xuồng máy của dân chài neo bên cầu tàu, giật dây khởi động một lần là nổ." | 35mm wide high-angle shot from the pier | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | — | `VO` | **20** | `0.4–5.4s` | "Hai con thuyền xé màn mưa trên mặt sông đen kịt, đèn cảng hai bên bờ lùi lại vun vút." | 24mm aerial tracking shot low over the water | Text-to-video |
| [**Clip 6**](clip-6.md) | `@Phong` | `VO` | **22** | `0.4–5.9s` | "Hắn không có súng, không có đàn em, chỉ có đôi tay lái mà cả đất Cảng này từng phải kiêng nể." | 50mm medium shot from the bow, handheld | Ingredients: ảnh nhân vật |
