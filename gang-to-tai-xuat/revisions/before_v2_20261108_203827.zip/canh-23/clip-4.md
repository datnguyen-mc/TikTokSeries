One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
A wooden and concrete pier at the edge of the port at night in rain: moored tugboats, coils of rope, black water, harbor lights reflecting on the surface.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards, and never flash or display the studio reference portrait card in the opening frames; 0.0–3.0s establishes the empty environment first and characters appear only from 3.0s onward.
- @Phong = Phong, 45, former getaway driver just out of prison; tall and lean, short black hair greying at the temples, a thin pale scar through his left eyebrow, short dark stubble, weathered tan skin; worn black leather jacket over a charcoal crew-neck T-shirt, dark jeans, black boots, old steel wristwatch.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 35mm wide high-angle shot from the pier; one smooth camera move from start to end, no cuts.
- Continuity: new camera setup; 0.0–3.0s establishes the empty location and light with no person in frame, then reveals the character naturally from 3.0s.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; 0.0–3.0s shows the environment and props only with no character on screen, and characters enter from 3.0s onward with clothing fully worn.
- 0.0–3.0s: A small wooden fishing skiff with an outboard motor bobbing against the pier pilings in the rain, its mooring rope slack.
- 3.0–7.0s: @Phong drops down from the pier into the small wooden fishing skiff with an outboard motor and slips the rope off the post in one motion.
- 7.0–10.0s: @Phong yanks the starter cord once, the outboard motor coughs to life and the skiff swings out into the black river. The shot settles on this as its final frame.

[AUDIO]
- Narration 0.4–5.7s by an off-screen male narrator (Vietnamese man about 45, strictly standard Hà Nội Northern accent (giọng chuẩn Hà Nội Bắc Bộ, never Southern accent) with clear six tones, deep gravelly baritone with crisp consonants, fast gripping crime-film storytelling in one continuous breath, every word spoken once and clearly, no stutter, no repeated words), in Vietnamese, said exactly once: "Phong nhảy xuống chiếc xuồng máy của dân chài neo bên cầu tàu, giật dây khởi động một lần là nổ." (no subtitles)
- After the last word the narrator stays silent until the end of the shot: no repeated words, no echo, no second reading of the line.
- Nobody on screen speaks; every mouth on screen stays closed.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: a small boat rocking, a starter cord pulled, an outboard motor sputtering to life. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
