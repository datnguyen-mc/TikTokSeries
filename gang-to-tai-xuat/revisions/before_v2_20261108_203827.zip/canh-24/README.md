# Cảnh 24: Bình Minh Trên Bãi Bồi (6 Clips × 10s = 60s)

- **Thời gian:** 05:30 Rạng sáng, cửa sông (23:00–24:00)
- **Bối cảnh:** Cửa sông lúc rạng sáng, nước ròng để lộ bãi bùn mênh mông và rừng đước.
- **Trục không gian cố định:** Ca nô chạy từ trái sang phải về phía rừng đước, xuồng của Phong bám sau; ca nô cảnh sát tiến vào từ hai phía.
- **Đạo cụ chính:** Ca nô trắng, xuồng máy gỗ, cọc tre đánh cá, ca nô cảnh sát xám.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **22** | `0.4–5.9s` | "Cuộc rượt đuổi kéo dài đến tận rạng sáng, khi nước ròng để lộ những bãi bùn mênh mông ở cửa sông." | 24mm aerial slow glide | Text-to-video |
| [**Clip 2**](clip-2.md) | `@Khang` | `VO` | **19** | `0.4–5.2s` | "Khang ngoái lại nhìn chiếc xuồng nhỏ vẫn bám sau lưng, gã bẻ lái gấp về phía rừng đước." | 50mm medium shot from the speedboat's bow | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Phong` | `VO` | **23** | `0.4–6.2s` | "Phong lớn lên ở bến sông này, hắn thuộc từng luồng lạch, và hắn cố tình ép ca nô về phía bãi cạn." | 85mm close-up, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | — | `VO` | **21** | `0.4–5.7s` | "Chiếc ca nô trắng trườn lên bãi bùn, mũi cắm sâu xuống, động cơ rú lên một hồi rồi tắt lịm." | 24mm wide locked-off shot | Text-to-video |
| [**Clip 5**](clip-5.md) | `@Khang` | `VO` | **22** | `0.4–5.9s` | "Khang lội bùn đến đầu gối, bộ vest kem lấm lem, ngẩng lên thì bốn phía đã có ca nô cảnh sát." | 50mm medium shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Huy` | `LIPSYNC:@Huy` | **17** | `3.0–7.3s` | "Khang, đội đặc nhiệm đây, giơ hai tay lên, cuộc chạy trốn của anh kết thúc rồi." | 85mm close-up from the water, slow dolly-in | Ingredients: ảnh nhân vật |
