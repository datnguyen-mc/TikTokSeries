One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Dawn at a wide river mouth near the sea: pale pink and steel-grey sky, low tide exposing vast glistening mudflats and mangrove edges, rows of bamboo fishing stakes in the water, distant cranes.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards, and never flash or display the studio reference portrait card in the opening frames; 0.0–3.0s establishes the empty environment first and characters appear only from 3.0s onward.
- @Huy = Huy, 31, Phong's younger brother, plain-clothes police detective; athletic build, neat short black hair, clean-shaven sharp jaw, alert eyes; light-blue collared shirt with rolled sleeves, dark navy trousers, black belt, brown leather shoes.
- Extra: police officers in dark uniforms on the deck behind him
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 85mm close-up from the water, slow dolly-in; one smooth camera move from start to end, no cuts.
- Continuity: new camera setup; 0.0–3.0s establishes the empty location and light with no person in frame, then reveals the character naturally from 3.0s.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; 0.0–3.0s shows the environment and props only with no character on screen, and characters enter from 3.0s onward with clothing fully worn.
- 0.0–3.0s: The grey bow of a police patrol boat cutting through the calm dawn water, mist and mangroves behind.
- 3.0–7.0s: @Huy stands at the bow with the police officers in dark uniforms on the deck behind him, calling out across the water.
- 7.0–10.0s: @Huy holds his position at the bow, jaw set, one hand raised in a firm stop signal toward the mudflat. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 3.0–7.3s, spoken on camera by @Huy (man of 31, strictly standard Hà Nội Northern accent (never Southern accent), firm clear tenor, tense and direct, speaking at a brisk, urgent, fast-clipped pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Khang, đội đặc nhiệm đây, giơ hai tay lên, cuộc chạy trốn của anh kết thúc rồi." (no subtitles)
- From 3.0s onward, @Huy's face and lips stay clearly visible while speaking; after the last word @Huy closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: a patrol boat engine idling, water lapping, morning wind. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
