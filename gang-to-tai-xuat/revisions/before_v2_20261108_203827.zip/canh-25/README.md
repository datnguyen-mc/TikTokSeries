# Cảnh 25: Còng Tay Bên Bãi Bồi (6 Clips × 10s = 60s)

- **Thời gian:** 06:00 Sáng, bãi bồi cửa sông (24:00–25:00)
- **Bối cảnh:** Bãi bùn cửa sông lúc mặt trời mọc, ca nô trắng mắc cạn, ca nô cảnh sát ghé sát.
- **Trục không gian cố định:** Ca nô mắc cạn bên trái, ca nô cảnh sát bên phải, mặt trời mọc phía sau lưng Phong.
- **Đạo cụ chính:** Còng số tám, đồng hồ vàng của Khang, cuốn sổ đen thật, ca nô cảnh sát xám, xuồng gỗ của Phong.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | `@Khang` | `VO` | **19** | `0.4–5.2s` | "Ông trùm cảng Vạn Hải giơ hai tay lên trời, đứng giữa bãi bùn như một kẻ trắng tay." | 24mm wide high-angle shot, slow descent | Ingredients: ảnh nhân vật |
| [**Clip 2**](clip-2.md) | `@Huy`, `@Khang` | `VO` | **19** | `0.4–5.2s` | "Huy bước xuống bùn, chiếc còng số tám khép lại trên cổ tay đeo đồng hồ vàng của gã." | 50mm medium two-shot, slow lateral track | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Khang`, `@Phong` | `LIPSYNC:@Khang` | **16** | `3.0–7.0s` | "Anh tưởng anh thắng à, anh Phong? Anh vẫn chỉ là một thằng tù mà thôi." | 85mm close-up, locked-off | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@Phong`, `@Khang` | `LIPSYNC:@Phong` | **19** | `0.4–5.3s` | "Tao không cần thắng, tao chỉ lấy lại cái tên mà mày đã bán đi mười hai năm trước." | 50mm over-the-shoulder shot on Phong, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | `@Huy` | `VO` | **23** | `0.4–6.2s` | "Sáng hôm ấy, theo cuốn sổ đen, mười bảy cái tên trong thành phố bị gọi lên, có cả sếp cũ của Huy." | 50mm medium shot, slow dolly-in | Ingredients: ảnh nhân vật |
| [**Clip 6**](clip-6.md) | `@Huy`, `@Phong` | `LIPSYNC:@Huy` | **18** | `3.0–7.5s` | "Anh à, lần này anh không có tội gì để nhận cả, về nhà thôi, mẹ đang chờ." | 85mm close-up two-shot, slow arc | Ingredients: ảnh nhân vật |
