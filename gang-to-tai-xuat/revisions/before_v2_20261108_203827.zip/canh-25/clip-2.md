One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Dawn at a wide river mouth near the sea: pale pink and steel-grey sky, low tide exposing vast glistening mudflats and mangrove edges, rows of bamboo fishing stakes in the water, distant cranes.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards, and never flash or display the studio reference portrait card in the opening frames; 0.0–3.0s establishes the empty environment first and characters appear only from 3.0s onward.
- @Huy = Huy, 31, Phong's younger brother, plain-clothes police detective; athletic build, neat short black hair, clean-shaven sharp jaw, alert eyes; light-blue collared shirt with rolled sleeves, dark navy trousers, black belt, brown leather shoes.
- @Khang = Khang, 42, the polished port boss; medium build, slicked-back black hair, clean-shaven, cold narrow eyes, faint smirk; cream linen suit over a black open-collar shirt, thin gold chain, gold wristwatch, polished brown loafers.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 50mm medium two-shot, slow lateral track; one smooth camera move from start to end, no cuts.
- Continuity: new camera setup; 0.0–3.0s establishes the empty location and light with no person in frame, then reveals the character naturally from 3.0s.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; 0.0–3.0s shows the environment and props only with no character on screen, and characters enter from 3.0s onward with clothing fully worn.
- 0.0–3.0s: Shallow water at the edge of the mudflat, a grey police patrol boat nosed into the mud, morning mist hanging low.
- 3.0–7.0s: @Huy steps down into the mud and walks to @Khang, who lowers his hands and holds out both wrists on his own.
- 7.0–10.0s: @Huy closes a pair of steel handcuffs around @Khang's offered wrists with a click, the gold wristwatch glinting beside the cuff. The shot settles on this as its final frame.

[AUDIO]
- Narration 0.4–5.2s by an off-screen male narrator (Vietnamese man about 45, strictly standard Hà Nội Northern accent (giọng chuẩn Hà Nội Bắc Bộ, never Southern accent) with clear six tones, deep gravelly baritone with crisp consonants, fast gripping crime-film storytelling in one continuous breath, every word spoken once and clearly, no stutter, no repeated words), in Vietnamese, said exactly once: "Huy bước xuống bùn, chiếc còng số tám khép lại trên cổ tay đeo đồng hồ vàng của gã." (no subtitles)
- After the last word the narrator stays silent until the end of the shot: no repeated words, no echo, no second reading of the line.
- Nobody on screen speaks; every mouth on screen stays closed.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: boots squelching in mud, a metallic handcuff click, soft wind. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
