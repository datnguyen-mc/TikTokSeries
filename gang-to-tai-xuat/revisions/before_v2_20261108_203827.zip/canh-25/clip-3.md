One continuous 10-second live-action shot, 16:9 widescreen, 24 fps.

[STYLE]
Photorealistic live-action Vietnamese crime thriller drama film set in the port city of Hải Phòng today; gritty neo-noir grade with deep teal shadows, sodium-orange highlights, wet asphalt reflections, rust-red containers and steel-grey sea, natural skin texture, subtle 35mm film grain, soft anamorphic lens flares.

[LIGHTING]
Low-key neo-noir lighting: sodium-orange streetlights and cold cyan harbor floodlights, red and blue light glints on wet surfaces at night; daytime is overcast and hazy steel-grey, with warm practical lamps indoors and golden low sun at dusk and dawn.

[LOCATION]
Dawn at a wide river mouth near the sea: pale pink and steel-grey sky, low tide exposing vast glistening mudflats and mangrove edges, rows of bamboo fishing stakes in the water, distant cranes.

[CHARACTERS]
Keep every face, hairstyle and outfit exactly consistent. Attached reference images show faces and clothes only — never copy their backgrounds, furniture or signboards, and never flash or display the studio reference portrait card in the opening frames; 0.0–3.0s establishes the empty environment first and characters appear only from 3.0s onward.
- @Khang = Khang, 42, the polished port boss; medium build, slicked-back black hair, clean-shaven, cold narrow eyes, faint smirk; cream linen suit over a black open-collar shirt, thin gold chain, gold wristwatch, polished brown loafers.
- @Phong = Phong, 45, former getaway driver just out of prison; tall and lean, short black hair greying at the temples, a thin pale scar through his left eyebrow, short dark stubble, weathered tan skin; worn black leather jacket over a charcoal crew-neck T-shirt, dark jeans, black boots, old steel wristwatch.
Nobody else appears in the shot.

[SHOT]
- Framing & motion: 85mm close-up, locked-off; one smooth camera move from start to end, no cuts.
- Continuity: new camera setup; 0.0–3.0s establishes the empty location and light with no person in frame, then reveals the character naturally from 3.0s.
- Eyelines: the camera stays on one side of the line between the characters (180-degree rule) so their eyes meet across the frame.

[TIMELINE]
Emotion shows through physical cues (breathing, eyes, jaw, hands, posture); one main action per beat; 0.0–3.0s shows the environment and props only with no character on screen, and characters enter from 3.0s onward with clothing fully worn.
- 0.0–3.0s: The small wooden bow of the fishing skiff resting at the edge of the mudflat in the dawn light, ripples spreading.
- 3.0–7.0s: @Khang, hands cuffed in front of him, turns his head toward @Phong, who has stepped onto the mud, and sneers as he speaks.
- 7.0–10.0s: @Phong stands a few paces away in the mud without a word, as @Khang's sneer slowly stiffens on his face. The shot settles on this as its final frame.

[AUDIO]
- Dialogue 3.0–7.0s, spoken on camera by @Khang (man of 42, strictly standard Hà Nội Northern accent (never Southern accent), smooth silky baritone, mocking and cold, speaking at a brisk, fast-clipped pace, every word spoken once clearly without stutter), in Vietnamese with exact lip-sync, said exactly once: "Anh tưởng anh thắng à, anh Phong? Anh vẫn chỉ là một thằng tù mà thôi." (no subtitles)
- From 3.0s onward, @Khang's face and lips stay clearly visible while speaking; after the last word @Khang closes the mouth and says nothing more — no repeated words, no echo. No narrator and no other voices.
- Speak only the Vietnamese words inside the double quotes, once, with natural Northern Vietnamese tones; never read these directions, names or tags aloud.
- SFX: mud squelching, gentle waves, seabirds. Ambience continues to 10.0s. No music.

[AVOID]
On-screen text of any kind (subtitles, captions, titles, credits, watermarks, logos, TV graphics, digital clock readouts), readable writing on signs, labels, name tags, paper or phone screens, blurry faces, distorted hands, background music, letterbox bars, jump cuts or scene changes, extra people, extra or fused fingers, face or costume changes, slurred speech, repeated, stuttered or echoed words, the line spoken twice, slow drawn-out narration or long pauses inside a sentence, Southern or Central Vietnamese accents.
