# Cảnh 26: Bát Bánh Đa Đoàn Viên (6 Clips × 10s = 60s)

- **Thời gian:** 08:00 Một tháng sau, quán bánh đa mới (25:00–26:00)
- **Bối cảnh:** Quán bánh đa cua của bà Tư dựng lại trong ngõ chợ ven sông, một tháng sau.
- **Trục không gian cố định:** Máy quay trong quán nhìn ra ngõ, nồi nước dùng bên trái như cảnh 03; bàn của hai anh em ở giữa, bàn Ông Bảy và Tuấn bên phải.
- **Đạo cụ chính:** Mái bạt sọc mới, nồi nước dùng cua đỏ au, bát bánh đa, rổ rau thơm, ấm trà và chén trà.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **21** | `0.4–5.7s` | "Một tháng sau, quán bánh đa của bà Tư mở cửa lại, mái bạt mới tinh, nồi nước dùng đỏ au." | 24mm wide crane-down shot | Text-to-video |
| [**Clip 2**](clip-2.md) | `@MeTu`, `@An` | `VO` | **21** | `0.4–5.7s` | "Bà Tư múc bát đầu tiên, An bưng ra bàn, hai bà cháu cười như chưa từng có đêm lửa nào." | 50mm medium shot, slow lateral dolly | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Phong`, `@Huy` | `VO` | **21** | `0.4–5.7s` | "Phong và Huy ngồi chung một bàn, hai anh em lần đầu cùng ăn sáng với nhau sau mười hai năm." | 35mm wide shot, locked-off | Ingredients: ảnh nhân vật |
| [**Clip 4**](clip-4.md) | `@Huy`, `@Phong` | `LIPSYNC:@Huy` | **18** | `0.4–4.9s` | "Anh này, sếp mới của em hỏi anh có muốn về dạy lái xe cho đội không đấy." | 85mm close-up over Phong's shoulder on Huy | Frames: nối khung cuối clip trước |
| [**Clip 5**](clip-5.md) | `@Phong`, `@Huy` | `LIPSYNC:@Phong` | **21** | `0.4–5.8s` | "Anh chỉ nhận dạy đúng một học trò thôi, con bé nhà mình, nó đang chờ anh chở ra Hà Nội." | 50mm medium two-shot, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 6**](clip-6.md) | `@OngBay`, `@Tuan` | `VO` | **22** | `0.4–5.9s` | "Ở bàn bên, Ông Bảy và Tuấn Còi nâng chén trà, bến cảng Vạn Hải lần đầu tiên thật sự bình yên." | 24mm wide shot, slow pull-back | Ingredients: ảnh nhân vật |
