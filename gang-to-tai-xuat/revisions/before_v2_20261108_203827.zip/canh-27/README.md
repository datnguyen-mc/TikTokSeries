# Cảnh 27: Con Đường Ra Hà Nội (6 Clips × 10s = 60s)

- **Thời gian:** 07:00 Sáng hôm sau, quốc lộ (26:00–27:00)
- **Bối cảnh:** Quốc lộ thẳng tắp giữa đồng lúa xanh hướng về Hà Nội, và bên trong con xe đen.
- **Trục không gian cố định:** Xe chạy thẳng về phía chân trời; trong xe Phong cầm lái bên trái, An ngồi ghế phụ bên phải.
- **Đạo cụ chính:** Xe sedan đen, ba lô đen và vali của An, điện thoại cũ của Phong.

| Clip | Nhân Vật | Giọng | Âm tiết | Khung thoại | Lời Dẫn / Thoại | Camera | Cách tạo trên Flow |
|---|---|---|---|---|---|---|---|
| [**Clip 1**](clip-1.md) | — | `VO` | **21** | `0.4–5.7s` | "Sáng hôm sau, con xe đen lăn bánh trên quốc lộ, chở cô tân sinh viên ra Hà Nội nhập học." | 24mm aerial tracking shot | Text-to-video |
| [**Clip 2**](clip-2.md) | `@Phong`, `@An` | `LIPSYNC:@An` | **17** | `3.0–7.3s` | "Bố ơi, bố đi chậm thôi, con muốn chuyến đi này kéo dài thêm một chút nữa." | 35mm medium two-shot from the dashboard | Ingredients: ảnh nhân vật |
| [**Clip 3**](clip-3.md) | `@Phong`, `@An` | `VO` | **21** | `0.4–5.7s` | "Phong bật cười, lần đầu tiên sau mười hai năm, con sói già lái xe mà không phải chạy trốn ai." | 85mm close-up on Phong, slow dolly-in | Frames: nối khung cuối clip trước |
| [**Clip 4**](clip-4.md) | `@Phong` | `VO` | **20** | `0.4–5.4s` | "Nhưng rồi chiếc điện thoại cũ trong túi áo da rung lên, một số máy lạ không hiển thị tên." | 100mm extreme close-up on the jacket pocket, slow tilt up | Ingredients: ảnh nhân vật |
| [**Clip 5**](clip-5.md) | `@Phong` | `VO` | **23** | `0.4–6.2s` | "Giọng bên kia chỉ nói một câu, trang cuối cuốn sổ đen còn một cái tên mà đội đặc nhiệm chưa đọc tới." | 50mm medium shot framed through the rear-view mirror | Frames: nối khung cuối clip trước |
| [**Clip 6**](clip-6.md) | — | `VO` | **18** | `0.4–4.9s` | "Găng tơ đã tái xuất, nhưng cuộc chơi thật sự, có lẽ bây giờ mới chỉ bắt đầu." | 24mm aerial rising crane shot, slow ascent | Text-to-video |
