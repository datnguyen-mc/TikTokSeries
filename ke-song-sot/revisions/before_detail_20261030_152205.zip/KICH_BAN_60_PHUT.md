# Kẻ Sống Sót: Bóng Ma
## Kịch bản bản 3 — cuộc trao đổi bị phản bội

**60 đơn vị sản xuất × 6 clip × 10 giây = 60 phút hình nguồn.** Mỗi clip một cú máy, nhịp diễn thay đổi theo hành động; không giữ hình để đủ phút. Thời lượng bản dựng phụ thuộc phần trim và mix âm thanh thực tế.

Nguồn duy nhất: `PHAN_CANH_V3.json`. Hành động/camera viết tiếng Anh cho prompt, ý đồ cảnh và thoại giữ tiếng Việt. Tái sinh bằng `python3 build_full_60_scenes.py`; kiểm tra bằng `python3 build_full_60_scenes.py --check`.

Sơn có bảy ngày trước chuyến tàu chuyển Hạ đi. Anh hợp tác với Mây, giao bằng chứng cho điều tra và chấp nhận trả giá. Kiên muốn Sơn im lặng, Bà Hai muốn lấy lại quyền kiểm soát. Cuộc trao đổi ở cảng bị phản bội; Dũng dùng chất Tê hư cấu giữ Sơn sống, cả hai phe đều nhận biết thuốc. Hạ để lại dấu và mở đường, Mây dẫn việc cứu người. Sơn cứu cả Kiên khỏi ngã rồi tự nhận còng.

| Cảnh | Phút phim | Tên | Biến chuyển mới |
|---|---|---|---|
| 01 | 00:00–01:00 | Ngày Thứ Nhất | Sơn tới Hòn Sóng và tự đặt hạn chờ. |
| 02 | 01:00–02:00 | Quá Khứ: Hợp Đồng Cuối | Bà Hai giao việc cuối và Dũng lộ sự ghen tức. |
| 03 | 02:00–03:00 | Khách Không Nhìn Biển | Mây chú ý cách Sơn chọn chỗ và quan sát đường. |
| 04 | 03:00–04:00 | Quá Khứ: Ba Lần Ghé Tiệm | Tình cảm nảy từ hành vi cụ thể qua ba lần gặp. |
| 05 | 04:00–05:00 | Sổ Đen Và Hạn Chót | Giới thiệu bằng chứng bị lấy và lịch giao hàng trong bảy ngày. |
| 06 | 05:00–06:00 | Quá Khứ: Lời Mời Về Biển | Hạ đặt giới hạn rồi tặng đồng hồ như một lời hẹn. |
| 07 | 06:00–07:00 | Mây Gõ Cửa | Mây tìm thấy giấy giả và chọn theo dõi người truy tìm Sơn. |
| 08 | 07:00–08:00 | Quá Khứ: Đêm Bị Gài | Sơn bị gài với bằng chứng giả và đồng hồ hỏng khi thoát. |
| 09 | 08:00–09:00 | Hai Người Lạ | Bảy và Thành tạo mạng quan sát, kẻ truy tìm để lại dấu. |
| 10 | 09:00–10:00 | Quá Khứ: Dấu Vết Còn Lại | Sơn nhặt một mảnh khăn và lấy sổ từ kho mình biết. |
| 11 | 10:00–11:00 | Bảy Ngày Không Chạy | Mây nhìn thấy nguy cơ, Sơn chấp nhận để lại một đường liên lạc. |
| 12 | 11:00–12:00 | Rừng Dương | Sơn chống phục kích, cứu người sau khi thuốc gây bất động. |
| 13 | 12:00–13:00 | Phòng Khám | Bác sĩ xác định dấu hiệu Tê, Mây có vật chứng thay vì đoán bằng mặt. |
| 14 | 13:00–14:00 | Còng Và Bằng Chứng | Sơn đưa bằng chứng kiểm chứng được, Mây nhận ra Hạ qua ảnh rời. |
| 15 | 14:00–15:00 | Quá Khứ: Đường Về | Hạ gieo kiến thức hải đăng và mục tiêu mở sạp hoa. |
| 16 | 15:00–16:00 | Hải Đăng Và Một Câu Hỏi | Mây tìm chứng cứ sống và kiểm tra lối kỹ thuật trước cao trào. |
| 17 | 16:00–17:00 | Phần Dữ Liệu Bị Khóa | Bằng chứng có đường xác minh và hạn chuyển người cụ thể. |
| 18 | 17:00–18:00 | Dũng Tới Biển | Dũng đe dọa bằng phần khăn còn lại, để lộ lệnh về thành phố. |
| 19 | 18:00–19:00 | Hai Mảnh Khăn | Hai mảnh cùng một chiếc khăn khớp nhau và thúc đẩy chuyến đi. |
| 20 | 19:00–20:00 | Lời Mời Không Tên | Người môi giới chứng minh biết Hạ và muốn Sơn phục vụ kế hoạch riêng. |
| 21 | 20:00–21:00 | Xe Đò Đêm | Hai người vào thành phố với trạng thái trang phục rõ. |
| 22 | 21:00–22:00 | Két Sau Bình Phong | Lấy khóa số và sổ đỏ, Bà Hai chủ động giữ họ lại. |
| 23 | 22:00–23:00 | Giá Của Một Người | Bà Hai bán Hạ, Mây chọn bảo vệ bằng chứng thay vì nghe thêm. |
| 24 | 23:00–24:00 | Bãi Xe: Một Người Đồng Hành | Dũng bị chặn, Mây dùng chiếc còng thứ hai và rút lui. |
| 25 | 24:00–25:00 | Chữ Ký Và Giờ Rời Bến | Dữ liệu khóa được mở, xác định giờ chuyển Hạ và nơi cần xác minh. |
| 26 | 25:00–26:00 | Xưởng Bên Sông | Lấy bằng chứng hiện trường và thoát bằng đường đã khảo sát. |
| 27 | 26:00–27:00 | Hạ Trong Khung Hình | Hạ gửi manh mối bằng hành động trong video, xác nhận còn sống. |
| 28 | 27:00–28:00 | Quá Khứ: Cánh Cửa Đầu Tiên | Sơn chọn bỏ vũ khí hiện tại sau khi nhớ lần đầu gây hại. |
| 29 | 28:00–29:00 | Cái Giá Của Chuyến Đi | Thành bảo vệ dân rồi bị giữ, Sơn kéo Dũng khỏi con tin. |
| 30 | 29:00–30:00 | Lối Qua Chợ Cá | Dân hỗ trợ thoát người, lực lượng hỗ trợ xử lý đám truy đuổi. |
| 31 | 30:00–31:00 | Bà Hai Ở Hải Đăng | Bà Hai muốn lấy lại Sơn, anh đặt điều kiện gặp trực tiếp Hạ. |
| 32 | 31:00–32:00 | Đường Rút Cho Người Sống | Kế hoạch cứu người có hỗ trợ, Tê không phải mẹo giả chết. |
| 33 | 32:00–33:00 | Quá Khứ: Một Lời Hứa Chưa Xong | Hạ đòi lời nói thật, bông hoa chỉ thuộc đêm quá khứ. |
| 34 | 33:00–34:00 | Vạch Thứ Bảy | Bằng chứng giao nhận rõ, Sơn giữ bản sao cho cuộc trao đổi. |
| 35 | 34:00–35:00 | Những Việc Nhỏ Của Thị Trấn | Thị trấn chuẩn bị bằng các nhiệm vụ an toàn khác nhau. |
| 36 | 35:00–36:00 | Khách Hàng Áo Trắng | Đối mặt Kiên, buộc kẻ giữ người chứng minh Hạ có mặt. |
| 37 | 36:00–37:00 | Điều Kiện Không Đổi | Mây và Sơn điều chỉnh kế theo điều kiện mới, không kể lại kế cũ. |
| 38 | 37:00–38:00 | Quá Khứ: Đôi Găng Đầu Tiên | Ơn nuôi dưỡng biến thành quyền sở hữu qua một món quà. |
| 39 | 38:00–39:00 | Bản Đồ Lúc Hoàng Hôn | Thiết lập một lần địa lý và vị trí lực lượng cho toàn cao trào. |
| 40 | 39:00–40:00 | Hai Chiếc Xe | Hai phe tới một bãi trao đổi, Hạ có vị trí và hướng thoát rõ. |
| 41 | 40:00–41:00 | Cuộc Trao Đổi Đổi Luật | Kiên phá điều kiện, Hạ làm Sơn chọn người thay vì giao kèo. |
| 42 | 41:00–42:00 | Bóng Ma Ngã Xuống | Dũng dùng Tê giữ người sống, Sơn không tự làm giả chết. |
| 43 | 42:00–43:00 | Không Ai Còn Là Món Hàng | Hai phe tranh quyền giữ Sơn, lực lượng vào khi thấy hành vi khống chế. |
| 44 | 43:00–44:00 | Lối Thoát Bị Chặn | Kiên lên tháp qua lối phụ, tuyến cứu Sơn và truy bắt tách rõ. |
| 45 | 44:00–45:00 | Những Người Đang Chờ | Dựng song song chăm sóc Sơn và Hạ trì hoãn Kiên. |
| 46 | 45:00–46:00 | Mây Giữ Cửa | Mây khống chế Dũng bằng còng mới, Sơn trở lại từng chút. |
| 47 | 46:00–47:00 | Tỉnh Lại | Sơn chấp nhận đi cùng Mây trong vai trò hỗ trợ, không tự lao đi. |
| 48 | 47:00–48:00 | Hai Lối Lên Tháp | Hai tổ tiến tới, Hạ giữ lối phụ hé, Sơn không tự đi một mình. |
| 49 | 48:00–49:00 | Chiếc Vòng Ngọc | Bà Hai bị bắt bởi tổ dưới cảng, trả giá cho việc coi người là hàng. |
| 50 | 49:00–50:00 | Đỉnh Hải Đăng | Mây giữ đối thoại, Hạ nhận ra lối thoát, Sơn không áp sát nòng súng. |
| 51 | 50:00–51:00 | Tay Không Giữ Người | Hạ tạo khoảng hở, Sơn cứu cả kẻ thù, Mây bắt Kiên. |
| 52 | 51:00–52:00 | Lần Đầu Mở Đồng Hồ | Trả lời lời hẹn bằng một hành động duy nhất, khăn được trao lại có nguồn. |
| 53 | 52:00–53:00 | Người Không Chạy Nữa | Sơn tự nhận trách nhiệm, Hạ chấp nhận thay vì cản luật. |
| 54 | 53:00–54:00 | Lời Khai Của Hạ | Hạ kể các lựa chọn mình đã làm và cung cấp chứng cứ mới. |
| 55 | 54:00–55:00 | Tên Của Những Cánh Cửa | Sơn nhận trách nhiệm cụ thể, không coi cứu Hạ là xóa tội. |
| 56 | 55:00–56:00 | Sổ Tiền Thành Hồ Sơ | Bằng chứng được xác minh và đời sống thị trấn bắt đầu trở lại. |
| 57 | 56:00–57:00 | Chỗ Của Hạ | Hạ có mục tiêu đời sống riêng và bắt đầu thực hiện. |
| 58 | 57:00–58:00 | Qua Ô Cửa Xe | Chia tay bằng một ánh nhìn, không diễn lại nhiều lần. |
| 59 | 58:00–59:00 | Căn Nhà Còn Mở Cửa | Thị trấn giữ ký ức nhưng tiếp tục sống, Hạ bắt tay làm sạp. |
| 60 | 59:00–60:00 | Buổi Sáng Có Người Về | Kết bằng đời sống Hạ đã xây và một người trở lại. |

### CẢNH 01: Ngày Thứ Nhất
*Thời gian truyện: D1 dawn*
Sơn tới Hòn Sóng và tự đặt hạn chờ.

**Clip 1 · OPEN · CROSSROAD · W**
- Đầu: Coach door open, Sơn still inside.
- Hành động: Sơn steps down once with his canvas bag, the coach pulls away.
- Thoại: Sơn, lời dẫn ngoài hình: Tôi tới nơi cô ấy từng muốn về.
- Cuối: Sơn alone at the crossroad, bag in left hand.

**Clip 2 · J · STREET · T**
- Đầu: Sơn approaching the coffee stall from screen left.
- Hành động: He catches a crate rolling toward the road and returns it to Bảy.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Cảm ơn chú. Cần tìm ai?
- Cuối: Bảy holds the recovered crate, Sơn beside the stall.

**Clip 3 · CUT · STALL · M**
- Đầu: Bảy behind his counter, Sơn facing him.
- Hành động: Sơn asks for a quiet room, Bảy turns toward the dune.
- Thoại: Sơn (@Son), nói trong hình: Chú có chỗ nào yên không?
- Cuối: Bảy pointing uphill, Sơn following his eyeline.

**Clip 4 · L · DUNE · W**
- Đầu: Both men already halfway up the dune path.
- Hành động: They reach the cabin porch, Bảy passes Sơn the key.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Nhà trống. Gió thì không.
- Cuối: Key resting in Sơn's open right palm.

**Clip 5 · MATCH · CABIN · I**
- Đầu: Key set beside a small carving tool.
- Hành động: Sơn cuts the first short mark into the bare doorframe.
- Thoại: Sơn, lời dẫn ngoài hình: Bảy ngày. Để tìm ra sự thật.
- Cuối: One fresh mark, tool lowered out of frame.

**Clip 6 · CUT · PORCH · M**
- Đầu: Sơn seated on the porch with his closed watch.
- Hành động: He turns the engraved lid toward the light without opening it.
- Thoại: —
- Cuối: Closed watch in his hand, sea beyond his shoulder.

Âm nối sang cảnh sau: Let the porch sea wind fall under rain on the silk-shop awning. Cut to the existing silk curtain, not to another coach arrival.

### CẢNH 02: Quá Khứ: Hợp Đồng Cuối
*Thời gian truyện: PAST one month earlier night*
Bà Hai giao việc cuối và Dũng lộ sự ghen tức.

**Clip 1 · L · SILK · W**
- Đầu: Silk curtain at left, three figures around a teak desk.
- Hành động: Sơn stops before Bà Hai, Dũng quietly closes the rear door.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Ngồi đi con.
- Cuối: Sơn standing opposite Bà Hai, Dũng by the shut door.

**Clip 2 · CUT · SILK · I**
- Đầu: Bà Hai's left hand beside a face-down photograph.
- Hành động: She slides Kiên's portrait toward Sơn, jade bracelet visible.
- Thoại: Bà Hai, ngoài khung hình: Kiên giữ sổ gốc. Má cần lấy lại.
- Cuối: Kiên's portrait beside Sơn's black glove.

**Clip 3 · CUT · SILK · M**
- Đầu: Sơn facing Bà Hai across the desk.
- Hành động: He leaves the photograph untouched and sets a return ticket down.
- Thoại: Sơn (@Son), nói trong hình: Xong việc này, con nghỉ.
- Cuối: Ticket between the two, Sơn's hands still.

**Clip 4 · CONTINUE · SILK · M**
- Đầu: Ticket between the two, Sơn's hands still.
- Hành động: Bà Hai covers the ticket with a folded strip of silk.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Con đi thì ai giữ nhà cho má?
- Cuối: Her hand rests on the silk covering Sơn's ticket.

**Clip 5 · CUT · SILK · O**
- Đầu: Dũng holding the rear door for Sơn.
- Hành động: Dũng looks at the untouched chair, then blocks the doorway briefly.
- Thoại: Dũng (@Dũng), nói trong hình: Má để ghế cho mày hoài.
- Cuối: Sơn and Dũng separated by the door edge.

**Clip 6 · L · ALLEY · P**
- Đầu: Sơn already outside, silk door closing behind him.
- Hành động: He turns Kiên's photo over and studies a building entrance sketch.
- Thoại: —
- Cuối: Photo back beside the real tower across the street.

Âm nối sang cảnh sau: Match the rectangle of the building sketch to the stall mirror edge. Replace city rain with present-day coastal morning sound.

### CẢNH 03: Khách Không Nhìn Biển
*Thời gian truyện: D1 morning*
Mây chú ý cách Sơn chọn chỗ và quan sát đường.

**Clip 1 · MATCH · STALL · W**
- Đầu: Rectangular stall mirror under the green tarp, Sơn at the sea-facing table edge.
- Hành động: He sits with his back to the sea and watches the road reflection.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Biển phía sau chú kìa.
- Cuối: Sơn facing the street, Bảy placing coffee on his right.

**Clip 2 · J · STREET · T**
- Đầu: Thành riding slowly, Mây behind him wearing a helmet.
- Hành động: Mây notices a deliberate glance from the coffee stall off screen and signals Thành to stop.
- Thoại: Mây (@May), nói trong hình: Dừng chỗ này.
- Cuối: Motorcycle stopped beyond the stall, both helmets still on.

**Clip 3 · CUT · STALL · M**
- Đầu: Mây seated facing Sơn, notebook still closed.
- Hành động: She asks his name while he moves his bag away from the walkway.
- Thoại: Mây (@May), nói trong hình: Anh tên gì?
- Cuối: Bag under Sơn's chair, Mây looking at his bare hands.

**Clip 4 · CONTINUE · STALL · M**
- Đầu: Bag under Sơn's chair, Mây looking at his bare hands.
- Hành động: Sơn answers and finally meets her eyes.
- Thoại: Sơn (@Son), nói trong hình: Sơn. Tôi thuê nhà trên đồi.
- Cuối: Mây opens her notebook, Sơn's cup remains untouched.

**Clip 5 · L · STREET · O**
- Đầu: Mây beside the parked motorcycle, Thành ready to leave.
- Hành động: She gives Thành the name and asks him to check the rental report.
- Thoại: Mây (@May), nói trong hình: Kiểm tra giúp chị. Kín thôi.
- Cuối: Thành noting the name, Mây glancing toward the hill.

**Clip 6 · CUT · STALL · I**
- Đầu: Sơn's right hand beside the coffee cup.
- Hành động: He stops touching the closed watch and turns the cup handle outward.
- Thoại: —
- Cuối: Cup handle facing the road, watch still closed at his belt.

Âm nối sang cảnh sau: Introduce the flower-shop bell over the final coffee-cup detail, then cut into the first visit. No repeated cup movement.

### CẢNH 04: Quá Khứ: Ba Lần Ghé Tiệm
*Thời gian truyện: PAST one month earlier afternoon*
Tình cảm nảy từ hành vi cụ thể qua ba lần gặp.

**Clip 1 · J · FLOWER · W**
- Đầu: Hạ cutting lilies as the entrance bell rings.
- Hành động: Sơn enters, sees Kiên's lobby across the road, chooses the window chair.
- Thoại: Hạ (@Ha), nói trong hình: Anh mua hoa cho ai?
- Cuối: Sơn at the window, Hạ behind the flower counter.

**Clip 2 · CUT · FLOWER · M**
- Đầu: A single lily between Hạ and Sơn.
- Hành động: A delivery boy bumps a bucket outside, Sơn steadies Hạ's falling vase.
- Thoại: Sơn (@Son), nói trong hình: Cho người không biết nhận hoa.
- Cuối: Vase safe between their hands, Sơn releases it first.

**Clip 3 · MATCH · FLOWER · M**
- Đầu: Same window chair on the following afternoon, fresh flowers changed.
- Hành động: Hạ places a second lily on the counter before Sơn can ask.
- Thoại: Hạ (@Ha), nói trong hình: Hôm nay vẫn người đó hả?
- Cuối: Two lilies in separate paper sleeves, Hạ suppressing a smile.

**Clip 4 · CUT · FLOWER · O**
- Đầu: Hạ facing the window, Sơn beside the second lily.
- Hành động: She follows his eyeline to Kiên's lobby and then looks back at him.
- Thoại: —
- Cuối: Hạ waiting for an answer, Sơn no longer watching the lobby.

**Clip 5 · MATCH · FLOWER · M**
- Đầu: Third afternoon, Sơn holding a repaired bucket handle.
- Hành động: He returns the bucket he repaired without being asked.
- Thoại: Hạ (@Ha), nói trong hình: Anh nhớ cái xô hơn nhớ tiền.
- Cuối: Hạ holding the repaired bucket, Sơn with empty hands.

**Clip 6 · CUT · FLOWER · P**
- Đầu: Sơn standing by the open shop door.
- Hành động: He starts to leave, then turns back to hear Hạ finish laughing.
- Thoại: —
- Cuối: Sơn staying in the doorway, Hạ smiling behind the counter.

Âm nối sang cảnh sau: Carry the shop-door bell resonance briefly into the quiet cabin, cut to the already-open bag and new evidence action.

### CẢNH 05: Sổ Đen Và Hạn Chót
*Thời gian truyện: D1 noon*
Giới thiệu bằng chứng bị lấy và lịch giao hàng trong bảy ngày.

**Clip 1 · L · CABIN · M**
- Đầu: Canvas bag open on the cabin table.
- Hành động: Sơn lays out the black ledger, a sealed tin and a concealed handgun case.
- Thoại: Sơn, lời dẫn ngoài hình: Tôi mang theo thứ họ cần bịt lại.
- Cuối: Three separate objects on the table, bag empty beside them.

**Clip 2 · CUT · CABIN · I**
- Đầu: Black ledger open, USB taped inside the back cover.
- Hành động: He removes the USB and finds the matching dispatch receipt underneath.
- Thoại: —
- Cuối: USB and receipt placed side by side, ledger still open.

**Clip 3 · CONTINUE · CABIN · I**
- Đầu: USB and receipt placed side by side, ledger still open.
- Hành động: Sơn traces seven dated boxes on the receipt and stops at a ship stamp.
- Thoại: Sơn, ngoài khung hình: Bảy ngày nữa, chuyến hàng rời bến.
- Cuối: His fingertip on the last box beside the ship stamp.

**Clip 4 · CUT · CABIN · I**
- Đầu: Tin open, three sealed fictional Tê vials in fitted slots.
- Hành động: He counts the intact seals, closes the lid without using anything.
- Thoại: —
- Cuối: Sealed tin closed, three vials accounted for inside.

**Clip 5 · CUT · CABIN · M**
- Đầu: Sơn below the cabin's exposed roof beam.
- Hành động: He secures the closed handgun case above the beam, away from reach.
- Thoại: —
- Cuối: Case hidden above the beam, Sơn's empty hands below.

**Clip 6 · J · CABIN · M**
- Đầu: Bảy at the porch threshold carrying a meal.
- Hành động: Sơn covers the ledger, Bảy leaves the meal without crossing the room.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Ăn đi. Cái xô hôm qua giúp tui nhiều.
- Cuối: Meal by the door, covered ledger farther inside.

Âm nối sang cảnh sau: The meal container settling at the cabin door bridges to the flower-shop cash drawer. Do not replay the tin being closed.

### CẢNH 06: Quá Khứ: Lời Mời Về Biển
*Thời gian truyện: PAST one month earlier night*
Hạ đặt giới hạn rồi tặng đồng hồ như một lời hẹn.

**Clip 1 · L · FLOWER_BACK · M**
- Đầu: Hạ putting the day's cash away, Sơn near the rear door.
- Hành động: His jacket shifts, showing the closed holster, Hạ stops moving.
- Thoại: Hạ (@Ha), nói trong hình: Anh làm việc gì vậy?
- Cuối: Hạ's hand resting on the cash drawer, distance between them.

**Clip 2 · CONTINUE · FLOWER_BACK · M**
- Đầu: Hạ's hand resting on the cash drawer, distance between them.
- Hành động: Sơn cannot answer, Hạ closes the drawer and steps back.
- Thoại: Hạ (@Ha), nói trong hình: Em không muốn sống trong lời giấu.
- Cuối: Sơn remaining by the door, Hạ beyond the table.

**Clip 3 · CONTINUE · FLOWER_BACK · M**
- Đầu: Sơn remaining by the door, Hạ beyond the table.
- Hành động: Sơn removes his right glove and lays it on the table.
- Thoại: Sơn (@Son), nói trong hình: Anh muốn dừng. Chưa biết cách.
- Cuối: Bare right hand beside one black glove, Hạ watching.

**Clip 4 · CUT · FLOWER_BACK · I**
- Đầu: Hạ holding a closed silver pocket watch by its chain.
- Hành động: She winds it with the lid still shut, the ticking becomes audible.
- Thoại: Hạ, ngoài khung hình: Của ba em. Nó còn chạy.
- Cuối: Closed watch resting on Hạ's open palm.

**Clip 5 · CUT · FLOWER_BACK · M**
- Đầu: Hạ extending the watch toward Sơn's bare right hand.
- Hành động: She sets it in his palm, lets him decide to close his fingers.
- Thoại: Hạ (@Ha), nói trong hình: Hết việc, mở ra. Rồi về biển.
- Cuối: Sơn holding the closed watch, Hạ's hand withdrawn.

**Clip 6 · CONTINUE · FLOWER_BACK · M**
- Đầu: Sơn holding the closed watch, Hạ's hand withdrawn.
- Hành động: Sơn pockets the watch, leaves the glove on the table for a moment.
- Thoại: Sơn (@Son), nói trong hình: Anh sẽ về nói thật với em.
- Cuối: His bare hand returns for the glove, Hạ turns off the kettle.

Âm nối sang cảnh sau: Let the kettle hiss finish. Cut to the next morning doorframe and its second tally, daylight replacing the warm room.

### CẢNH 07: Mây Gõ Cửa
*Thời gian truyện: D2 morning*
Mây tìm thấy giấy giả và chọn theo dõi người truy tìm Sơn.

**Clip 1 · OPEN · CABIN · I**
- Đầu: One mark on the doorframe, tool below it.
- Hành động: Sơn carves the second mark, a motorcycle stops outside.
- Thoại: —
- Cuối: Two marks, tool put on the shelf.

**Clip 2 · J · PORCH · M**
- Đầu: Mây outside the threshold, Sơn holding the door open.
- Hành động: She waits for permission before asking for his papers.
- Thoại: Mây (@May), nói trong hình: Tôi cần xác nhận người thuê nhà.
- Cuối: Sơn passing a card across the threshold.

**Clip 3 · CUT · CABIN · O**
- Đầu: Mây at the doorway with the card, Sơn beside the table.
- Hành động: She studies the card and his face without entering deeper.
- Thoại: Mây (@May), nói trong hình: Anh định ở tới khi nào?
- Cuối: Card returned to Sơn, notebook still open.

**Clip 4 · CUT · CABIN · M**
- Đầu: Sơn beside the two fresh marks.
- Hành động: He looks at the marks instead of answering, Mây notices the evasion.
- Thoại: Sơn (@Son), nói trong hình: Hết tuần này.
- Cuối: Mây's eyeline fixed on the doorframe.

**Clip 5 · L · POST · I**
- Đầu: Thành at the old computer, Mây standing behind him.
- Hành động: A record check returns a mismatched identity, Thành prints the result.
- Thoại: Thành, ngoài khung hình: Giấy không khớp hồ sơ, chị.
- Cuối: Printer feeding one page, Mây taking it.

**Clip 6 · CUT · POST · M**
- Đầu: Mây laying the result in a new investigation folder.
- Hành động: She assigns one discreet observer and asks for outside vehicle reports.
- Thoại: Mây (@May), nói trong hình: Theo người tìm anh ta nữa.
- Cuối: Folder open with Sơn's rental note, Thành calling for support.

Âm nối sang cảnh sau: Introduce garage ventilation hum before the flashback cut away from the station radio and folder.

### CẢNH 08: Quá Khứ: Đêm Bị Gài
*Thời gian truyện: PAST one month earlier night*
Sơn bị gài với bằng chứng giả và đồng hồ hỏng khi thoát.

**Clip 1 · J · GARAGE · W**
- Đầu: Sơn behind a pillar, a white car at the far lift.
- Hành động: He checks the lift reflection without drawing his handgun.
- Thoại: —
- Cuối: Sơn concealed behind the pillar, lift doors opening.

**Clip 2 · CUT · GARAGE · M**
- Đầu: Dũng emerging alone from the lift.
- Hành động: He slides a document envelope toward Sơn with a shoe, blocks the lift.
- Thoại: Dũng (@Dũng), nói trong hình: Má đổi chỗ giao. Nhặt đi.
- Cuối: Envelope on the floor between them, Dũng in front of the lift.

**Clip 3 · CUT · GARAGE · I**
- Đầu: Sơn's gloved hand above the open envelope.
- Hành động: He sees his own staged photograph and a stolen seal inside.
- Thoại: Sơn, ngoài khung hình: Mày muốn tao để dấu tay.
- Cuối: His hand withdrawing from the planted evidence.

**Clip 4 · J · GARAGE · H**
- Đầu: Light beams sweeping toward Sơn's pillar.
- Hành động: He ducks behind a parked car, the closed watch strikes concrete.
- Thoại: —
- Cuối: Sơn behind the car with the watch chain taut, alarm sounding.

**Clip 5 · CUT · GARAGE_EXIT · T**
- Đầu: Sơn at a low maintenance door, jacket still on.
- Hành động: He slips through the door and pulls it shut without dropping his clothes.
- Thoại: —
- Cuối: Sơn outside the closed maintenance door, black gloves still on.

**Clip 6 · L · ALLEY · P**
- Đầu: Sơn under the rear awning, closed watch in his hand.
- Hành động: He listens at the shut lid, hears no ticking, then sees the flower-shop lights.
- Thoại: Sơn, lời dẫn ngoài hình: Đêm đó, thứ đầu tiên ngừng là đồng hồ.
- Cuối: His face turning toward the distant flower shop.

Âm nối sang cảnh sau: City rain falls away, the arriving black car establishes present-day afternoon. Do not replay the garage escape.

### CẢNH 09: Hai Người Lạ
*Thời gian truyện: D2 afternoon*
Bảy và Thành tạo mạng quan sát, kẻ truy tìm để lại dấu.

**Clip 1 · OPEN · STREET · W**
- Đầu: A black car parking outside Bảy's stall.
- Hành động: Two unnamed men step out and display Sơn's surveillance photograph.
- Thoại: Người trong cảnh, nói trong hình: Chú thấy người này không?
- Cuối: Photograph extended toward Bảy, car door left open.

**Clip 2 · CUT · STALL · M**
- Đầu: Bảy behind the counter studying the offered photograph.
- Hành động: He gives a vague answer while sliding his phone below the counter.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Ở đây người giống người nhiều lắm.
- Cuối: Phone hidden beneath the counter, Bảy still holding the photo.

**Clip 3 · L · MARKET · O**
- Đầu: Sơn behind a fish stall with a clear view of the black car.
- Hành động: He notices one man's dock-worker wristband and stays out of sight.
- Thoại: —
- Cuối: Wristband visible through a gap, Sơn concealed behind a crate.

**Clip 4 · CUT · STREET · I**
- Đầu: Thành beside his parked motorcycle, notebook partly hidden.
- Hành động: He records the plate and the same dock-company emblem.
- Thoại: —
- Cuối: Plate sketch and company emblem on separate notebook lines.

**Clip 5 · CUT · STALL · W**
- Đầu: The two men returning to their black car.
- Hành động: They leave a contact card, Bảy waits until the car drives off.
- Thoại: —
- Cuối: Contact card under Bảy's glass, road clear.

**Clip 6 · J · POST · M**
- Đầu: Thành placing his notes beside Bảy's contact card.
- Hành động: Mây connects the emblem to the dispatch company and requests a check.
- Thoại: Mây (@May), nói trong hình: Họ tìm người. Ta tìm đường đi.
- Cuối: Mây marking the company entry, Thành preparing the request.

Âm nối sang cảnh sau: Introduce wind through the damaged shop door before cutting from the company inquiry to the torn scarf trace.

### CẢNH 10: Quá Khứ: Dấu Vết Còn Lại
*Thời gian truyện: PAST one month earlier dawn*
Sơn nhặt một mảnh khăn và lấy sổ từ kho mình biết.

**Clip 1 · J · FLOWER · W**
- Đầu: Broken shop glass, a pale-blue strip caught on the latch.
- Hành động: Sơn enters carefully and stops at the torn strip.
- Thoại: —
- Cuối: Sơn facing the latch, torn strip still attached.

**Clip 2 · CUT · FLOWER · I**
- Đầu: Sơn's right glove beside the broken latch.
- Hành động: He removes the glove once and frees only the small torn strip.
- Thoại: Sơn, ngoài khung hình: Hạ để lại cái này.
- Cuối: Bare right hand holding the short scarf fragment.

**Clip 3 · J · FLOWER · M**
- Đầu: Sơn near the broken doorway, a neighbor outside the frame.
- Hành động: He listens to the neighbor describe a black car and three men.
- Thoại: Người trong cảnh, ngoài khung hình: Cổ bị đưa đi. Còn quay lại nhìn cửa.
- Cuối: Sơn looking toward the tire tracks outside.

**Clip 4 · CUT · FLOWER · C**
- Đầu: Sơn's phone vibrating against his jacket.
- Hành động: He answers, hears Bà Hai claim Hạ has left him, ends the call.
- Thoại: Bà Hai, qua thiết bị: Về tiệm, má còn giữ chỗ cho con.
- Cuối: Phone lowered, Sơn's bare right hand steady again.

**Clip 5 · L · SILK_STORE · T**
- Đầu: Rear stockroom door of the silk shop already ajar before opening hours.
- Hành động: Sơn uses his old key and reaches the shelf he once guarded.
- Thoại: —
- Cuối: Sơn beside the stock shelf, black ledger and tin visible.

**Clip 6 · CUT · SILK_STORE · M**
- Đầu: Ledger and sealed tin on the stockroom shelf.
- Hành động: Sơn takes the ledger, attached receipt and sealed tin into his bag.
- Thoại: Sơn, lời dẫn ngoài hình: Tôi lấy sổ của họ. Không lấy lại được cô ấy.
- Cuối: Shelf empty at those slots, bag clasp closed.

Âm nối sang cảnh sau: Match the closed bag clasp to the sealed tin latch in the lamplit cabin. No second theft or opening of the tin.

### CẢNH 11: Bảy Ngày Không Chạy
*Thời gian truyện: D2 night*
Mây nhìn thấy nguy cơ, Sơn chấp nhận để lại một đường liên lạc.

**Clip 1 · MATCH · CABIN · I**
- Đầu: Closed tin beside the dispatch receipt under lamplight.
- Hành động: Sơn puts a pencil mark at the last shipping date, leaving the tin sealed.
- Thoại: Sơn, lời dẫn ngoài hình: Chuyến hàng đi rồi, dấu vết cũng đi.
- Cuối: Receipt weighted flat by the sealed tin.

**Clip 2 · CUT · CABIN · M**
- Đầu: Sơn seated with a loose photograph of Hạ from his wallet.
- Hành động: He places the photograph face down when a distant motorcycle stops.
- Thoại: —
- Cuối: Loose photograph face down, Sơn looking toward the window.

**Clip 3 · CUT · DUNE · O**
- Đầu: Mây behind a pine trunk overlooking the lit cabin.
- Hành động: She observes the concealed case above the beam and makes one note.
- Thoại: —
- Cuối: Binoculars lowered, Mây recording the observation.

**Clip 4 · J · DUNE · M**
- Đầu: Thành joining Mây below the ridge.
- Hành động: He hands her confirmation that the black car belongs to the dock company.
- Thoại: Thành (@Phó Thành), nói trong hình: Xe cùng công ty trên tờ giao hàng.
- Cuối: Company report in Mây's hand, cabin light behind them.

**Clip 5 · CUT · CABIN · C**
- Đầu: Sơn at the cabin window with the watch lid still closed.
- Hành động: He senses the observer, switches on the porch light and steps back.
- Thoại: Sơn, ngoài khung hình: Tôi ở đây. Không đi đâu.
- Cuối: Porch lit, Sơn visible inside but no longer at the window.

**Clip 6 · L · DUNE · W**
- Đầu: Mây and Thành below the newly lit porch.
- Hành động: Mây folds her notebook and orders the suspect approached in daylight.
- Thoại: Mây (@May), nói trong hình: Sáng mai hỏi thẳng. Đừng để dân tới gần.
- Cuối: Both moving down the dune path away from the cabin.

Âm nối sang cảnh sau: Carry pine wind across the night-to-morning cut, with a clear daylight change. The third mark is a new action.

### CẢNH 12: Rừng Dương
*Thời gian truyện: D3 morning*
Sơn chống phục kích, cứu người sau khi thuốc gây bất động.

**Clip 1 · OPEN · CABIN · I**
- Đầu: Two marks on the frame, sunlight just reaching the wood.
- Hành động: Sơn makes the third mark, hears footsteps and leaves by the rear door.
- Thoại: —
- Cuối: Three marks, rear door moving closed behind him.

**Clip 2 · CUT · CABIN · W**
- Đầu: Empty cabin interior, front door pushed inward by two unnamed men.
- Hành động: They search the empty bed and see fresh footprints leading out back.
- Thoại: Người trong cảnh, nói trong hình: Nó vừa ra sau.
- Cuối: Both intruders turning toward the rear door, cabin otherwise empty.

**Clip 3 · CUT · DUNE · H**
- Đầu: One pursuer stepping around a pine, Sơn behind the trunk.
- Hành động: Sơn takes his balance and pins his weapon hand without striking his head.
- Thoại: Sơn (@Son), nói trong hình: Bỏ xuống.
- Cuối: Pursuer seated against the trunk, Sơn holding the wrist away.

**Clip 4 · CONTINUE · DUNE · H**
- Đầu: Pursuer seated against the trunk, Sơn holding the wrist away.
- Hành động: The second pursuer lunges with a fictional Tê applicator, Sơn deflects the arm.
- Thoại: —
- Cuối: Second man stumbling into sand, applicator out of his grasp.

**Clip 5 · CUT · DUNE · M**
- Đầu: Second man motionless but visibly breathing, first man still conscious.
- Hành động: Sơn checks the fallen man's breathing and calls toward the road for help.
- Thoại: Sơn (@Son), nói trong hình: Có người cần bác sĩ. Đồi dương.
- Cuối: Sơn kneeling beside the breathing man, phone at his ear.

**Clip 6 · J · DUNE · W**
- Đầu: Mây and Thành arriving with a stretcher at the tree line.
- Hành động: Sơn steps away with empty hands, Mây takes control of the two men.
- Thoại: Mây (@May), nói trong hình: Anh ở lại. Tôi cần nghe hết.
- Cuối: Mây by the stretcher, Sơn standing where she can see him.

Âm nối sang cảnh sau: Carry the fallen man breathing under the cut to the clinic. No replay of the fall or stretcher arrival.

### CẢNH 13: Phòng Khám
*Thời gian truyện: D3 noon*
Bác sĩ xác định dấu hiệu Tê, Mây có vật chứng thay vì đoán bằng mặt.

**Clip 1 · L · CLINIC · W**
- Đầu: Two attackers on separate beds, one sitting up under supervision.
- Hành động: Linh checks the immobile man's breathing while Mây records the time.
- Thoại: Bác sĩ Linh (@Bác sĩ Linh), nói trong hình: Còn thở. Chưa được rời mắt.
- Cuối: Linh at bedside, Thành watching the conscious attacker.

**Clip 2 · CUT · CLINIC · I**
- Đầu: Seized applicator sealed on a tray, Linh beside it.
- Hành động: He compares its unusual cap to a reference case photograph he kept.
- Thoại: Bác sĩ Linh, ngoài khung hình: Tôi từng gặp loại Tê này.
- Cuối: Two matching cap shapes, both separate from the patient.

**Clip 3 · CUT · CLINIC · M**
- Đầu: Mây facing Linh beside the closed treatment curtain.
- Hành động: He explains that recovery varies and requires monitoring, not an exact timer.
- Thoại: Bác sĩ Linh (@Bác sĩ Linh), nói trong hình: Đừng tin ai hẹn đúng phút tỉnh.
- Cuối: Mây crossing out her tentative time estimate.

**Clip 4 · CUT · CLINIC · M**
- Đầu: Thành beside the conscious attacker, Mây holding the evidence bag.
- Hành động: The attacker recognizes the shipping emblem and stops answering.
- Thoại: Mây (@May), nói trong hình: Ai đưa các anh tới đây?
- Cuối: Attacker looking away from the bag, Thành noting the reaction.

**Clip 5 · CUT · CLINIC · C**
- Đầu: The conscious attacker off screen, Mây listening without interrupting.
- Hành động: He lets slip Sơn's nickname, Mây closes the evidence folder.
- Thoại: Người trong cảnh, ngoài khung hình: Bóng Ma giữ sổ. Dũng cần sổ.
- Cuối: Mây's closed folder resting against her chest.

**Clip 6 · L · POST · M**
- Đầu: Mây returning to the station, Thành at the support radio.
- Hành động: She requests a district team to protect the town and heads up the hill.
- Thoại: Mây (@May), nói trong hình: Giữ người và vật chứng. Tôi gặp Sơn.
- Cuối: Thành confirming the support request, Mây leaving with the folder.

Âm nối sang cảnh sau: Station radio fades into porch wind. Cut to Mây joining the waiting Sơn and placing her cuffs once.

### CẢNH 14: Còng Và Bằng Chứng
*Thời gian truyện: D3 afternoon*
Sơn đưa bằng chứng kiểm chứng được, Mây nhận ra Hạ qua ảnh rời.

**Clip 1 · CUT · PORCH · M**
- Đầu: Two tea glasses on the porch table, Sơn already seated.
- Hành động: Mây sits opposite and places her cuffs beside her notebook.
- Thoại: Mây (@May), nói trong hình: Anh là người họ gọi Bóng Ma?
- Cuối: Cuffs between the glasses, neither person touching them.

**Clip 2 · CUT · PORCH · I**
- Đầu: Sơn's closed bag on the table, Mây's evidence folder beside it.
- Hành động: He removes the black ledger and USB, places both within her reach.
- Thoại: Sơn, ngoài khung hình: Đối chiếu công ty đó với sổ này.
- Cuối: Ledger and USB beside Mây's folder, Sơn's hands withdrawn.

**Clip 3 · CUT · PORCH · M**
- Đầu: Mây checking an entry against the vehicle report.
- Hành động: She finds the matching dispatch company, takes a photograph of the page.
- Thoại: Mây (@May), nói trong hình: Chuyện này tôi sẽ báo lên.
- Cuối: Mây's phone above the matching entry, Sơn waiting.

**Clip 4 · CONTINUE · PORCH · M**
- Đầu: Mây's phone above the matching entry, Sơn waiting.
- Hành động: Sơn agrees to remain available and names the final shipment.
- Thoại: Sơn (@Son), nói trong hình: Tôi khai. Nhưng còn người bị giữ.
- Cuối: Mây writing the deadline, Sơn no longer hiding his bag.

**Clip 5 · CUT · PORCH · I**
- Đầu: Sơn sliding Hạ's loose photograph across the table.
- Hành động: Mây recognizes the face and holds the photograph by its white edge.
- Thoại: Mây, ngoài khung hình: Hạ. Bạn hồi nhỏ của tôi.
- Cuối: Hạ's loose portrait in Mây's hand, watch nowhere opened.

**Clip 6 · CUT · PORCH · C**
- Đầu: Mây looking up from the photograph at Sơn.
- Hành động: She asks where Hạ is, Sơn has to hold her gaze.
- Thoại: Mây (@May), nói trong hình: Anh kể từ đầu.
- Cuối: Mây waiting, Sơn unable to lower his eyes.

Âm nối sang cảnh sau: A ferry horn enters while Mây waits for an answer. Cut to Hạ alive at the city pier, not to a second photo reveal.

### CẢNH 15: Quá Khứ: Đường Về
*Thời gian truyện: PAST one month earlier evening*
Hạ gieo kiến thức hải đăng và mục tiêu mở sạp hoa.

**Clip 1 · J · CITY_PIER · W**
- Đầu: Hạ walking along the city pier, Sơn beside her.
- Hành động: She stops at a ferry's distant light and names her home town.
- Thoại: Hạ (@Ha), nói trong hình: Hòn Sóng. Nhà em ở đó.
- Cuối: Both facing the water, ferry light far beyond.

**Clip 2 · CUT · CITY_PIER · M**
- Đầu: Hạ drawing a round tower in condensation on a railing panel.
- Hành động: She sketches a small maintenance hatch below the gallery.
- Thoại: Hạ (@Ha), nói trong hình: Ba em giữ đèn. Em thuộc từng cửa.
- Cuối: Her fingertip at the hatch sketch, Sơn watching.

**Clip 3 · CONTINUE · CITY_PIER · M**
- Đầu: Her fingertip at the hatch sketch, Sơn watching.
- Hành động: Sơn asks about the sea, she points to the town in an old photo.
- Thoại: Hạ (@Ha), nói trong hình: Mất điện vẫn có đèn dự phòng.
- Cuối: Old lighthouse photo held between them, maintenance hatch visible.

**Clip 4 · CONTINUE · CITY_PIER · M**
- Đầu: Old lighthouse photo held between them, maintenance hatch visible.
- Hành động: Hạ puts the photograph away and names the life she wants.
- Thoại: Hạ (@Ha), nói trong hình: Em muốn mở sạp hoa cạnh chợ cá.
- Cuối: Her empty hands resting on the rail, Sơn beside her.

**Clip 5 · CUT · CITY_PIER · C**
- Đầu: Hạ with her pale-blue scarf loose at her neck.
- Hành động: Wind lifts one end, Sơn catches it before it touches dirty water.
- Thoại: —
- Cuối: Scarf back in Hạ's hand, his gloved hand released.

**Clip 6 · CUT · CITY_PIER · W**
- Đầu: The two standing at the pier rail, a ship horn beginning.
- Hành động: Hạ starts walking back, Sơn chooses to follow her instead of the ferry.
- Thoại: Sơn (@Son), nói trong hình: Bạn em còn giữ chỗ đó không?
- Cuối: Both leaving left to right, open water behind.

Âm nối sang cảnh sau: Retain the city ferry horn briefly over the coastal lighthouse entrance, then change to local wind.

### CẢNH 16: Hải Đăng Và Một Câu Hỏi
*Thời gian truyện: D3 late afternoon*
Mây tìm chứng cứ sống và kiểm tra lối kỹ thuật trước cao trào.

**Clip 1 · L · LIGHTHOUSE_BASE · W**
- Đầu: Mây unlocking the lighthouse's lower iron door, Sơn behind her.
- Hành động: She shows him the old service route and starts up the stairs.
- Thoại: Mây (@May), nói trong hình: Hạ lớn lên ở đây.
- Cuối: Main door open, service hatch visible beside the stair base.

**Clip 2 · CUT · LIGHTHOUSE · M**
- Đầu: Both on the gallery, facing the houses below.
- Hành động: Mây identifies Hạ's family home without romanticizing Sơn's account.
- Thoại: Mây (@May), nói trong hình: Tôi chưa thấy nó về gần tháng.
- Cuối: Mây pointing down to the house, Sơn facing her.

**Clip 3 · CONTINUE · LIGHTHOUSE · M**
- Đầu: Mây pointing down to the house, Sơn facing her.
- Hành động: Sơn admits he has only a threat and a torn piece of cloth.
- Thoại: Sơn (@Son), nói trong hình: Tôi tưởng họ đã giết cô ấy.
- Cuối: Mây looking directly at him, Sơn's hands empty on the rail.

**Clip 4 · CONTINUE · LIGHTHOUSE · M**
- Đầu: Mây looking directly at him, Sơn's hands empty on the rail.
- Hành động: Mây refuses the assumption and asks for verifiable contact details.
- Thoại: Mây (@May), nói trong hình: Chưa có chứng cứ. Ta tìm người sống.
- Cuối: Sơn offering the phone, Mây taking it.

**Clip 5 · CUT · LIGHTHOUSE_SERVICE · I**
- Đầu: Mây at the labeled-in-shapes backup-light lever, no readable text.
- Hành động: She tests the relay once and confirms the lamp works, then switches it off.
- Thoại: —
- Cuối: Backup lamp dark again, lever pointing down.

**Clip 6 · L · LIGHTHOUSE_BASE · W**
- Đầu: Both already at the open lower doorway after the descent.
- Hành động: Mây locks the public entrance and keeps the service key accessible.
- Thoại: Mây (@May), nói trong hình: Đem USB tới đồn. Ngay tối nay.
- Cuối: Key clipped to Mây's belt, Sơn heading toward the station.

Âm nối sang cảnh sau: The clipped service key settles, incoming station fan introduces the USB desk. Do not replay the backup-lamp test.

### CẢNH 17: Phần Dữ Liệu Bị Khóa
*Thời gian truyện: D3 night*
Bằng chứng có đường xác minh và hạn chuyển người cụ thể.

**Clip 1 · J · POST · W**
- Đầu: Three people around the station computer, USB on the desk.
- Hành động: Thành makes a working copy before opening the accounts.
- Thoại: Thành (@Phó Thành), nói trong hình: Giữ bản gốc. Em mở bản sao.
- Cuối: Original USB in evidence bag, copy connected to the computer.

**Clip 2 · CUT · POST · I**
- Đầu: Account folders open without readable text.
- Hành động: Thành matches the ledger dates to paid shipments at the river factory.
- Thoại: Thành, ngoài khung hình: Cùng xưởng. Cùng ngày chuyển tiền.
- Cuối: A matching sequence highlighted, ledger open beside the keyboard.

**Clip 3 · CUT · POST · M**
- Đầu: Mây looking from the matched shipments to Sơn.
- Hành động: He identifies Kiên as the payer named in the open accounts.
- Thoại: Sơn (@Son), nói trong hình: Kiên trả tiền. Bà Hai giữ đường hàng.
- Cuối: Mây separating Kiên's file from Bà Hai's file.

**Clip 4 · CUT · POST · I**
- Đầu: A locked dispatch folder beside an open weekly schedule.
- Hành động: They establish that the final departure is day seven at night.
- Thoại: Mây, ngoài khung hình: Ngày bảy. Sau đó người bị đưa đi.
- Cuối: Mây circling the last departure on her paper copy.

**Clip 5 · CUT · POST · M**
- Đầu: Sơn recognizing a small token icon in the locked folder.
- Hành động: He describes the hardware key kept beside the red original ledger.
- Thoại: Sơn (@Son), nói trong hình: Khóa trong két. Cạnh sổ đỏ.
- Cuối: Thành drawing the token shape in his notebook.

**Clip 6 · CUT · POST · W**
- Đầu: Mây on the station phone, Thành with the copied evidence.
- Hành động: She briefs district support and assigns town protection before going to the city.
- Thoại: Mây (@May), nói trong hình: Tôi theo dấu Hạ. Không rút người giữ thị trấn.
- Cuối: Protection roster on the desk, Thành acknowledging his post.

Âm nối sang cảnh sau: Close the night station sound cleanly. New morning engines establish Dũng arriving with changed stakes, not a repeated visitor search.

### CẢNH 18: Dũng Tới Biển
*Thời gian truyện: D4 morning*
Dũng đe dọa bằng phần khăn còn lại, để lộ lệnh về thành phố.

**Clip 1 · OPEN · STREET · W**
- Đầu: Two black cars stopping outside the coffee stall.
- Hành động: Dũng steps out, knocks one empty chair aside, asks after his men.
- Thoại: Dũng (@Dũng), nói trong hình: Hai người tao gửi đâu?
- Cuối: Chair on its side, Bảy behind the counter.

**Clip 2 · CUT · STALL · M**
- Đầu: Bảy setting his glass down before answering.
- Hành động: He points toward the clinic, refusing to let Dũng pass behind his counter.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Phòng khám. Muốn gặp thì hỏi công an.
- Cuối: Bảy blocking the counter entrance, Dũng in the public aisle.

**Clip 3 · J · STREET · W**
- Đầu: Mây and Thành approaching on foot, a support vehicle farther back.
- Hành động: Mây makes Dũng put the chair back before continuing.
- Thoại: Mây (@May), nói trong hình: Dựng lại. Rồi nói chuyện.
- Cuối: Chair upright, Dũng's men waiting by their cars.

**Clip 4 · CUT · STALL · I**
- Đầu: Dũng's hand above the counter holding a long torn blue scarf.
- Hành động: He lays the remaining scarf down without letting Mây approach him.
- Thoại: Dũng, ngoài khung hình: Đưa cho Sơn. Nó biết của ai.
- Cuối: Long scarf flat on the counter, one end torn.

**Clip 5 · CUT · STREET · C**
- Đầu: Dũng beside his open car door, phone vibrating.
- Hành động: He hears a recall to the silk shop and ends the call angrily.
- Thoại: Bà Hai, qua thiết bị: Về tiệm. Đêm nay có khách.
- Cuối: Dũng getting into the car, no longer waiting at the stall.

**Clip 6 · L · STALL · M**
- Đầu: Mây collecting the scarf after the cars leave.
- Hành động: She asks Thành to keep patrols on the clinic and the harbour road.
- Thoại: Mây (@May), nói trong hình: Hắn đi rồi. Vẫn giữ cửa ngõ.
- Cuối: Thành heading toward the patrol vehicle, scarf in Mây's bag.

Âm nối sang cảnh sau: The evidence-bag rustle bridges to two separated scarf pieces on the cabin table. Do not repeat Dũng laying it down.

### CẢNH 19: Hai Mảnh Khăn
*Thời gian truyện: D4 noon*
Hai mảnh cùng một chiếc khăn khớp nhau và thúc đẩy chuyến đi.

**Clip 1 · MATCH · CABIN · I**
- Đầu: Two separate pieces of pale-blue cloth on the table.
- Hành động: Sơn aligns the torn edges without pretending they are repaired.
- Thoại: Sơn, ngoài khung hình: Một chiếc. Hạ xé đầu này.
- Cuối: Matched torn edges separated by a narrow gap.

**Clip 2 · CUT · CABIN · M**
- Đầu: Three marks on the frame, Sơn beside the shelf.
- Hành động: He makes only the fourth mark and puts the tool away.
- Thoại: —
- Cuối: Exactly four marks, tool on shelf.

**Clip 3 · CUT · CABIN · M**
- Đầu: Sơn placing the small piece in an envelope.
- Hành động: Mây takes custody of the long remainder in her evidence bag.
- Thoại: Mây (@May), nói trong hình: Tôi giữ phần này làm chứng.
- Cuối: Small fragment with Sơn, long remainder sealed with Mây.

**Clip 4 · CONTINUE · CABIN · M**
- Đầu: Small fragment with Sơn, long remainder sealed with Mây.
- Hành động: Mây shows the confirmed town-protection roster and lays out her denim jacket for the trip.
- Thoại: Mây (@May), nói trong hình: Thành có người hỗ trợ. Ta đi.
- Cuối: Denim jacket ready beside Mây's bag, both still by the table.

**Clip 5 · CUT · PORCH · O**
- Đầu: Sơn and Mây facing the path down from the porch.
- Hành động: Sơn warns her about Bà Hai, Mây names her own reason for going.
- Thoại: Mây (@May), nói trong hình: Tôi đi tìm Hạ. Không đi trốn với anh.
- Cuối: Both committed to the same path, bags ready.

**Clip 6 · J · PORCH · I**
- Đầu: Old phone lying on the porch table beside Sơn's bag.
- Hành động: It vibrates from an unknown caller, Sơn waits for Mây's nod.
- Thoại: —
- Cuối: Sơn's finger answering, Mây beside him.

Âm nối sang cảnh sau: The phone vibration stops when answered. Cut wider for speaker mode, without a second ring or second answering gesture.

### CẢNH 20: Lời Mời Không Tên
*Thời gian truyện: D4 afternoon*
Người môi giới chứng minh biết Hạ và muốn Sơn phục vụ kế hoạch riêng.

**Clip 1 · CUT · PORCH · M**
- Đầu: Phone answered in Sơn's hand, Mây beside him at the table.
- Hành động: Sơn puts the caller on speaker, Mây starts a recording on her phone.
- Thoại: Người gọi giấu tên, qua thiết bị: Hạ vẫn giữ cái kẹp tóc màu bạc.
- Cuối: Two phones apart on the table, both listening.

**Clip 2 · CUT · PORCH · C**
- Đầu: Sơn listening without touching either phone.
- Hành động: The private detail makes him lean forward despite himself.
- Thoại: Sơn (@Son), nói trong hình: Anh gặp cô ấy ở đâu?
- Cuối: Sơn's expression changed, Mây noticing the change.

**Clip 3 · CONTINUE · PORCH · C**
- Đầu: Sơn's expression changed, Mây noticing the change.
- Hành động: The caller refuses a location and names the red ledger in Bà Hai's safe.
- Thoại: Người gọi giấu tên, qua thiết bị: Lấy sổ đỏ. Tôi cho anh thấy cô ấy.
- Cuối: Sơn looking toward his bag, recorder still running.

**Clip 4 · CUT · PORCH · M**
- Đầu: Mây holding the recorder steady beside Sơn.
- Hành động: She signals that the caller is steering them toward a conflict.
- Thoại: Mây (@May), nói trong hình: Đừng nhận thêm điều kiện.
- Cuối: Sơn's hand hovering over the end-call button.

**Clip 5 · CONTINUE · PORCH · M**
- Đầu: Sơn's hand hovering over the end-call button.
- Hành động: Sơn demands proof of life before discussing any other job.
- Thoại: Sơn (@Son), nói trong hình: Cho tôi thấy Hạ còn sống trước.
- Cuối: His hand ends the call rather than waiting for permission.

**Clip 6 · L · STREET · W**
- Đầu: Night coach approaching the town stop, both travelers waiting.
- Hành động: They board separately with their bags, watched by Thành from across the road.
- Thoại: —
- Cuối: Coach door closing, Thành remaining in town.

Âm nối sang cảnh sau: Keep the same departing coach engine into the on-board view. No second boarding or repeat door close.

### CẢNH 21: Xe Đò Đêm
*Thời gian truyện: D4 night*
Hai người vào thành phố với trạng thái trang phục rõ.

**Clip 1 · J · BUS · W**
- Đầu: Sơn seated by the coach window, Mây across the narrow aisle.
- Hành động: Mây checks the patrol confirmation while Sơn opens his travel bag.
- Thoại: —
- Cuối: Patrol message acknowledged, folded black suit visible in the bag.

**Clip 2 · CUT · BUS · M**
- Đầu: Black suit folded across Sơn's knees, gloves tucked inside.
- Hành động: He touches the gloves, Mây keeps her attention on his face.
- Thoại: Mây (@May), nói trong hình: Anh vẫn cần bộ đó sao?
- Cuối: Gloves still folded, Sơn's hand withdrawn.

**Clip 3 · CONTINUE · BUS · M**
- Đầu: Gloves still folded, Sơn's hand withdrawn.
- Hành động: Sơn closes the bag and speaks about his first employer without a full flashback.
- Thoại: Sơn (@Son), nói trong hình: Bà cho tôi chỗ ở. Rồi giữ luôn lối ra.
- Cuối: Bag closed between his feet, Mây listening.

**Clip 4 · L · REST_STOP · W**
- Đầu: Coach stopped under a rest-stop awning, travelers already outside.
- Hành động: Sơn walks toward the changing room, Mây waits beside the coach.
- Thoại: —
- Cuối: Mây beside the coach door, Sơn beyond the changing-room entrance.

**Clip 5 · CUT · REST_ROOM · M**
- Đầu: Sơn before the mirror, suit already on and gloves in his hand.
- Hành động: He pockets the gloves unused, leaving both hands bare.
- Thoại: Sơn, lời dẫn ngoài hình: Tôi mặc lại vest. Không mang lại đôi tay cũ.
- Cuối: Sơn in black suit with bare hands, olive jacket folded in his bag.

**Clip 6 · L · REST_STOP · W**
- Đầu: Mây holding the coach door open, Sơn returning with his bag.
- Hành động: They reboard, Sơn puts the bag above his seat.
- Thoại: —
- Cuối: Both back on the coach, olive jacket stored inside the bag.

Âm nối sang cảnh sau: Coach-window rain becomes rain on the silk-shop rear awning. The city arrival is a time ellipsis, not another travel montage.

### CẢNH 22: Két Sau Bình Phong
*Thời gian truyện: D4 late night*
Lấy khóa số và sổ đỏ, Bà Hai chủ động giữ họ lại.

**Clip 1 · J · SILK_REAR · W**
- Đầu: Sơn and Mây at the closed rear door in the rain.
- Hành động: He uses the old shop key while Mây watches the alley.
- Thoại: Sơn (@Son), nói trong hình: Chìa cửa cũ. Tôi giữ hai mươi lăm năm.
- Cuối: Rear door opening inward, both travelers at the threshold.

**Clip 2 · CUT · SILK · T**
- Đầu: Both inside the dim shop, rear door behind screen left.
- Hành động: Sơn leads along the silk racks to the screen covering the safe.
- Thoại: —
- Cuối: Screen pulled aside, safe in front of Sơn, Mây by the exit.

**Clip 3 · CUT · SILK · I**
- Đầu: Safe open, red ledger and USB-shaped hardware token inside.
- Hành động: Sơn removes only the red ledger and hardware token.
- Thoại: Sơn, ngoài khung hình: Khóa số đây. Không phải chìa cửa.
- Cuối: Red ledger under his left arm, token in right hand.

**Clip 4 · J · SILK · W**
- Đầu: Desk lamp switching on behind the open safe.
- Hành động: Bà Hai is revealed at the desk as both visitors turn toward her.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Má để cửa cho con.
- Cuối: All three visible, safe open behind Sơn.

**Clip 5 · CUT · SILK · M**
- Đầu: Bà Hai facing Sơn with both palms on the desk.
- Hành động: She permits him to keep the ledger while asking for Kiên's return.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Giữ sổ. Đổi lại, đưa Kiên về đây.
- Cuối: Sơn retaining the ledger, Mây beside the rear exit.

**Clip 6 · CONTINUE · SILK · M**
- Đầu: Sơn retaining the ledger, Mây beside the rear exit.
- Hành động: Mây stays standing as Sơn draws a chair away from the desk.
- Thoại: Sơn (@Son), nói trong hình: Hạ ở đâu?
- Cuối: Chair angled toward the exit, three separate tea cups untouched.

Âm nối sang cảnh sau: Keep the same desk room tone, match the three untouched cups and angled chair before Bà Hai offers tea.

### CẢNH 23: Giá Của Một Người
*Thời gian truyện: D4 late night*
Bà Hai bán Hạ, Mây chọn bảo vệ bằng chứng thay vì nghe thêm.

**Clip 1 · MATCH · SILK · M**
- Đầu: Three untouched cups, Sơn's chair angled toward the rear exit.
- Hành động: Bà Hai offers tea, neither visitor reaches for it.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Kiên trả tiền để con im miệng.
- Cuối: Cup offered but untouched between Bà Hai and Sơn.

**Clip 2 · CUT · SILK · C**
- Đầu: Sơn standing beside the angled chair.
- Hành động: He repeats the question without accepting her bargaining language.
- Thoại: Sơn (@Son), nói trong hình: Con hỏi Hạ.
- Cuối: Sơn still standing, Bà Hai lowering the cup.

**Clip 3 · CONTINUE · SILK · C**
- Đầu: Sơn still standing, Bà Hai lowering the cup.
- Hành động: Bà Hai admits transferring Hạ to Kiên but cannot prove her present condition.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Má không giết. Má bán.
- Cuối: Cup touching the saucer, Bà Hai's bracelet fixed in frame.

**Clip 4 · CUT · SILK · M**
- Đầu: Mây between the rear door and the desk, Sơn holding the red ledger.
- Hành động: She photographs Bà Hai beside the open safe, preparing to leave.
- Thoại: Mây (@May), nói trong hình: Đủ rồi. Chúng tôi giữ lời bà vừa nói.
- Cuối: Phone lowered, evidence bag ready in Mây's hand.

**Clip 5 · CUT · SILK · H**
- Đầu: Two unnamed guards blocking the rear exit.
- Hành động: Sơn rolls one silk bolt into their path, Mây restrains the nearer guard with one pair of cuffs.
- Thoại: —
- Cuối: One guard cuffed to the desk leg, exit temporarily clear.

**Clip 6 · L · SILK_REAR · W**
- Đầu: Sơn and Mây moving through the rear doorway, Bà Hai inside.
- Hành động: Bà Hai signals the other guard to follow instead of risking the ledger in a struggle.
- Thoại: Bà Hai, ngoài khung hình: Dũng. Cửa sau.
- Cuối: Travelers outside, guard lifting a phone, Bà Hai staying by the desk.

Âm nối sang cảnh sau: Accelerating footsteps give way to garage echo before the ramp picture. Do not replay the silk-bolt obstruction.

### CẢNH 24: Bãi Xe: Một Người Đồng Hành
*Thời gian truyện: D4 late night*
Dũng bị chặn, Mây dùng chiếc còng thứ hai và rút lui.

**Clip 1 · J · GARAGE · W**
- Đầu: Sơn and Mây already entering the garage ramp from the alley.
- Hành động: They move along the same car row, rear exit visible beyond.
- Thoại: —
- Cuối: Both behind a parked van, exit two pillars ahead.

**Clip 2 · CUT · GARAGE · H**
- Đầu: One guard reaching around the van toward Mây.
- Hành động: Sơn closes the car door between guard and Mây, keeping their path clear.
- Thoại: Mây (@May), nói trong hình: Lối bên trái.
- Cuối: Guard stopped by the door, Mây moving past the next pillar.

**Clip 3 · CUT · GARAGE · W**
- Đầu: Dũng coming down from the ramp in response to Bà Hai's call.
- Hành động: He cuts off the direct exit, forcing Sơn back toward a railing.
- Thoại: Dũng (@Dũng), nói trong hình: Má còn chưa nói xong.
- Cuối: Dũng between the travelers and exit, railing behind Sơn.

**Clip 4 · CUT · GARAGE · H**
- Đầu: Dũng reaching for the ledger, Sơn protecting it under his left arm.
- Hành động: Dũng drives Sơn's left wrist into the pillar, Mây circles behind him.
- Thoại: —
- Cuối: Sơn down on one knee, ledger secure, Mây at Dũng's right side.

**Clip 5 · CONTINUE · GARAGE · H**
- Đầu: Sơn down on one knee, ledger secure, Mây at Dũng's right side.
- Hành động: Mây cuffs Dũng's right wrist to the solid ramp rail using her second pair.
- Thoại: Mây (@May), nói trong hình: Đủ hai chiếc rồi.
- Cuối: Dũng restrained to the intact rail, Mây helping Sơn up.

**Clip 6 · L · GARAGE_EXIT · W**
- Đầu: The two travelers crossing the exit, Dũng behind them at the rail.
- Hành động: An unnamed guard arrives with bolt cutters after they clear the doorway.
- Thoại: —
- Cuối: Travelers gone, cutters beside the cuff chain, Dũng still restrained.

Âm nối sang cảnh sau: Garage echo and the cutter sound fall away as the motel fan introduces dawn. Show no second capture of Dũng.

### CẢNH 25: Chữ Ký Và Giờ Rời Bến
*Thời gian truyện: D5 dawn*
Dữ liệu khóa được mở, xác định giờ chuyển Hạ và nơi cần xác minh.

**Clip 1 · J · MOTEL · M**
- Đầu: Sơn seated on the bed, jacket off, left wrist visibly swollen without a wound.
- Hành động: Mây wraps the left wrist and leaves his right hand free.
- Thoại: Mây (@May), nói trong hình: Đừng giấu đau nữa.
- Cuối: Left wrist bandaged, black jacket on the bed beside him.

**Clip 2 · CUT · MOTEL · I**
- Đầu: Borrowed laptop on the table, working USB copy already connected.
- Hành động: Thành guides Mây by phone as she inserts the hardware token.
- Thoại: Thành, qua thiết bị: Đúng khóa. Mở được rồi.
- Cuối: Locked folder opened, original evidence kept separately.

**Clip 3 · CONTINUE · MOTEL · I**
- Đầu: Locked folder opened, original evidence kept separately.
- Hành động: Mây matches the digital authorization to Kiên's signature in the red ledger.
- Thoại: —
- Cuối: Matched signature shapes, Mây saving a local copy.

**Clip 4 · CUT · MOTEL · M**
- Đầu: Mây reading the newly opened transport schedule.
- Hành động: They learn Hạ is registered as a passenger on the day-seven night departure.
- Thoại: Mây (@May), nói trong hình: Hạ được đưa lên tàu đêm ngày bảy.
- Cuối: Sơn looking at the departure marker, left wrist held against his chest.

**Clip 5 · CONTINUE · MOTEL · M**
- Đầu: Sơn looking at the departure marker, left wrist held against his chest.
- Hành động: Sơn names the river factory and points to its loading door on Mây's map with his right hand.
- Thoại: Sơn (@Son), nói trong hình: Xưởng này. Tôi biết cửa xuống sông.
- Cuối: Factory circled on the map, pier route beside it.

**Clip 6 · CUT · MOTEL · I**
- Đầu: Mây uploading the copied files to the assigned investigator.
- Hành động: A receipt confirms delivery before she closes the laptop.
- Thoại: Mây, ngoài khung hình: Bản sao đã tới người nhận.
- Cuối: Confirmed receipt saved, laptop shut, originals packed.

Âm nối sang cảnh sau: Laptop confirmation fades into distant factory pumps before the roof-vent shot. No repeat unlocking montage.

### CẢNH 26: Xưởng Bên Sông
*Thời gian truyện: D5 afternoon*
Lấy bằng chứng hiện trường và thoát bằng đường đã khảo sát.

**Clip 1 · J · LAB_ROOF · W**
- Đầu: The pair crouched behind a roof vent overlooking the factory yard.
- Hành động: Mây films the loading emblem and the same seal shown in the accounts.
- Thoại: —
- Cuối: Phone aimed at the matched shipment seal, Sơn watching the route.

**Clip 2 · CUT · LAB · T**
- Đầu: Both inside the loading aisle, river door visible ahead.
- Hành động: Sơn takes one sealed sample carton from a documented shelf as Mây films the location.
- Thoại: Sơn, ngoài khung hình: Niêm phong nguyên. Đừng mở.
- Cuối: Single carton in Mây's evidence bag, shelf location recorded.

**Clip 3 · CUT · LAB · H**
- Đầu: A guard turning into the loading aisle behind them.
- Hành động: Sơn holds the guard behind a closing sliding screen while Mây reaches the river door.
- Thoại: —
- Cuối: Guard separated by the screen, Mây at the open river door.

**Clip 4 · CUT · LAB_DOCK · W**
- Đầu: Mây at the dock gate, another guard approaching from the stairs.
- Hành động: She loops a dock rope around the gate and pulls it shut between them.
- Thoại: Mây (@May), nói trong hình: Đi tiếp. Tôi giữ cửa.
- Cuối: Gate held by rope, both travelers beyond it, no new cuffs.

**Clip 5 · CONTINUE · LAB_DOCK · W**
- Đầu: Gate held by rope, both travelers beyond it, no new cuffs.
- Hành động: Sơn steadies a tied workboat as Mây steps aboard, then releases the mooring.
- Thoại: —
- Cuối: Both aboard the workboat, loose rope clear of the propeller.

**Clip 6 · CUT · RIVER · W**
- Đầu: Workboat clearing the factory dock, carton secured under the bench.
- Hành động: Sơn keeps the boat on the open channel, Mây sends the recorded clip.
- Thoại: Mây (@May), nói trong hình: Giờ họ có cả sổ và xưởng.
- Cuối: Factory falling behind, phone transmission confirmed.

Âm nối sang cảnh sau: Keep the established boat engine as the view changes from wide channel to the two travelers. No repeat departure from the dock.

### CẢNH 27: Hạ Trong Khung Hình
*Thời gian truyện: D5 dusk*
Hạ gửi manh mối bằng hành động trong video, xác nhận còn sống.

**Clip 1 · CUT · RIVER · M**
- Đầu: Both travelers in the boat, factory now distant behind them.
- Hành động: The unknown caller sends a short video, Sơn reduces the engine noise.
- Thoại: Người gọi giấu tên, qua thiết bị: Anh đòi thấy. Đây.
- Cuối: Phone angled between both travelers, boat idling in open water.

**Clip 2 · CUT · VIDEO_ROOM · C**
- Đầu: Hạ alone in a plain bright room, camera at her eye level.
- Hành động: She says Sơn's name and deliberately turns her hair clip toward the ventilation window.
- Thoại: Hạ (@Ha), nói trong hình: Sơn. Em còn đây.
- Cuối: Silver clip held beside a small fan with a ferry emblem beyond it.

**Clip 3 · CUT · RIVER · M**
- Đầu: Sơn and Mây watching the phone in the boat.
- Hành động: Mây freezes the received video locally after the meaningful gesture, not the film image.
- Thoại: Mây (@May), nói trong hình: Nó muốn mình nhìn phía sau.
- Cuối: Mây pointing at the vent detail on the phone, Sơn steadying it.

**Clip 4 · CUT · RIVER · C**
- Đầu: Sơn on the live audio line, Mây preserving the video.
- Hành động: The caller demands he remove Bà Hai before the departure deadline.
- Thoại: Người gọi giấu tên, qua thiết bị: Bà Hai ra khỏi cuộc. Hạ mới về.
- Cuối: Sơn ending the demand without agreeing to kill.

**Clip 5 · CUT · RIVER · M**
- Đầu: Mây comparing the ferry emblem to the dispatch paperwork.
- Hành động: She identifies the holding company's coastal route rather than an exact room.
- Thoại: Mây (@May), nói trong hình: Cùng tuyến tàu. Hạ đang gần biển.
- Cuối: Route marked toward Hòn Sóng, video saved with evidence.

**Clip 6 · CUT · RIVER · W**
- Đầu: Boat bow facing the coastal channel, daylight fading.
- Hành động: Sơn commits to returning for a controlled exchange with police support.
- Thoại: Sơn (@Son), nói trong hình: Đưa cô ấy ra chỗ sáng. Rồi bắt họ.
- Cuối: Boat heading toward the coast, both watching ahead.

Âm nối sang cảnh sau: River wind bridges into corridor rain in the distant memory. Do not bring back phone-video fan noise after that video has ended.

### CẢNH 28: Quá Khứ: Cánh Cửa Đầu Tiên
*Thời gian truyện: PAST twenty-five years earlier night / D6 dawn from clip 4*
Sơn chọn bỏ vũ khí hiện tại sau khi nhớ lần đầu gây hại.

**Clip 1 · L · OLD_CORRIDOR · W**
- Đầu: Twenty-year-old Sơn outside a closed wooden door, new gloves tucked in his pocket.
- Hành động: He hears an ordinary family sound inside and hesitates before knocking.
- Thoại: Sơn, lời dẫn ngoài hình: Lần đầu, tôi còn kịp quay đi.
- Cuối: Young Sơn's bare right hand just below the door knocker.

**Clip 2 · CONTINUE · OLD_CORRIDOR · W**
- Đầu: Young Sơn's bare right hand just below the door knocker.
- Hành động: The door opens inward, Sơn enters, camera remains outside without showing harm.
- Thoại: —
- Cuối: Door closed, empty corridor, rain audible beyond the stairwell.

**Clip 3 · CUT · OLD_CORRIDOR · M**
- Đầu: Young Sơn stepping back into the corridor after an unshown interval.
- Hành động: He looks at his bare hands, puts on the new gloves without relief.
- Thoại: Sơn, lời dẫn ngoài hình: Tôi đã không quay đi.
- Cuối: Both gloved hands lowered, young Sơn turning away.

**Clip 4 · MATCH · CABIN · M**
- Đầu: Present-day Sơn at the cabin table, Mây beside the closed handgun case.
- Hành động: He passes the complete locked case and its key to Mây.
- Thoại: Sơn (@Son), nói trong hình: Tôi không mang thứ này nữa.
- Cuối: Entire handgun case in Mây's custody, Sơn unarmed.

**Clip 5 · CUT · CABIN · I**
- Đầu: Four marks on the frame with two small travel-date notes beside them.
- Hành động: Back from the city, Sơn carves the missing day-five and day-six marks in order.
- Thoại: —
- Cuối: Exactly six marks, two freshest side by side.

**Clip 6 · J · PORCH · W**
- Đầu: Both at the porch looking down on the town road.
- Hành động: They hear an abrupt radio warning, then see market shutters closing.
- Thoại: Thành, qua thiết bị: Dũng quay lại. Quán ông Bảy.
- Cuối: Mây answering her radio, Sơn looking toward Bảy's stall.

Âm nối sang cảnh sau: Thành radio warning carries into the present-day blocked street. The town threat is the next event, not another flashback.

### CẢNH 29: Cái Giá Của Chuyến Đi
*Thời gian truyện: D6 morning*
Thành bảo vệ dân rồi bị giữ, Sơn kéo Dũng khỏi con tin.

**Clip 1 · OPEN · STREET · W**
- Đầu: Mây and Sơn at the upper road, black car near the coffee stall.
- Hành động: They see a patrol barricade damaged and choose the side lane.
- Thoại: —
- Cuối: Both concealed behind the side-lane wall, view of the stall clear.

**Clip 2 · CUT · STALL · W**
- Đầu: Thành seated with tied wrists, Bảy held behind the counter.
- Hành động: Dũng demands the ledger, Thành keeps the civilian rear door out of his sight.
- Thoại: Dũng (@Dũng), nói trong hình: Sổ đâu? Đừng bắt tao hỏi ông già.
- Cuối: Thành watching the rear door, Dũng facing the road.

**Clip 3 · CUT · STREET · M**
- Đầu: Sơn and Mây behind the wall, Sơn looking at the rear stall door.
- Hành động: They divide tasks: Sơn draws Dũng away, Mây reaches Thành from behind.
- Thoại: Sơn (@Son), nói trong hình: Tôi kéo hắn ra. Cô đưa Thành đi.
- Cuối: Mây taking the side lane, Sơn stepping toward the road.

**Clip 4 · L · STREET · W**
- Đầu: Sơn visible in the road, Dũng at the stall threshold.
- Hành động: Sơn calls him and moves toward the market entrance without exposing a weapon.
- Thoại: Sơn (@Son), nói trong hình: Dũng. Muốn sổ thì theo tao.
- Cuối: Dũng following Sơn, stall entrance momentarily clear.

**Clip 5 · CUT · STALL_REAR · M**
- Đầu: Mây entering the stall from the rear, Bảy by Thành's chair.
- Hành động: She cuts Thành's ties while Bảy opens the civilian exit.
- Thoại: Mây (@May), nói trong hình: Đưa dân ra. Không đuổi theo hắn.
- Cuối: Thành free, Bảy ushering two unnamed civilians out back.

**Clip 6 · J · MARKET_ENTRY · W**
- Đầu: Sơn already at the market entrance, Dũng several paces behind.
- Hành động: Sơn ducks into a narrow aisle as a cart blocks Dũng's direct line.
- Thoại: —
- Cuối: Sơn beyond the cart, Dũng forced to go around.

Âm nối sang cảnh sau: Keep pursuing footsteps and cut past the entry cart into the aisle. Do not perform the cart obstruction twice.

### CẢNH 30: Lối Qua Chợ Cá
*Thời gian truyện: D6 morning*
Dân hỗ trợ thoát người, lực lượng hỗ trợ xử lý đám truy đuổi.

**Clip 1 · CUT · MARKET · T**
- Đầu: Sơn just past the entry cart inside the market aisle.
- Hành động: Sơn moves deeper along the narrow aisle, keeping a stack of crates between him and pursuers.
- Thoại: —
- Cuối: Sơn at the aisle junction, pursuers slowed by the crates.

**Clip 2 · CUT · MARKET · W**
- Đầu: Bảy at a side door with two fish sellers, Sơn approaching.
- Hành động: They move a wheeled ice cart across the empty aisle after Sơn passes.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Đi lối này. Cửa sau trống.
- Cuối: Cart blocking the aisle, civilians already behind a closed door.

**Clip 3 · J · MARKET_REAR · W**
- Đầu: Mây and Thành at the rear market exit, support officers arriving behind them.
- Hành động: They take two separated pursuers into custody without involving civilians.
- Thoại: Mây (@May), nói trong hình: Giữ lối thoát cho dân.
- Cuối: Pursuers held by support officers, rear exit protected.

**Clip 4 · CUT · MARKET · M**
- Đầu: Dũng at the far end of the obstructed aisle, Sơn beyond reach.
- Hành động: He threatens the day-seven transfer rather than another immediate fight.
- Thoại: Dũng (@Dũng), nói trong hình: Đợi thêm, Hạ lên tàu mất.
- Cuối: Dũng lowering his phone with the ship schedule visible as shapes.

**Clip 5 · CUT · MARKET_ENTRY · W**
- Đầu: Dũng retreating toward his car with his two remaining men.
- Hành động: He leaves a meeting place and time before withdrawing.
- Thoại: Dũng (@Dũng), nói trong hình: Bà Hai chờ ở hải đăng tối nay.
- Cuối: Black car backing away, Sơn staying inside the market entrance.

**Clip 6 · L · MARKET_REAR · M**
- Đầu: Thành seated safely at the rear exit, one glasses arm bent.
- Hành động: Mây acknowledges the cost of her absence and restores the patrol roster.
- Thoại: Mây (@May), nói trong hình: Lần này chị giữ đủ người ở đây.
- Cuối: Thành taking the replacement roster, Sơn listening nearby.

Âm nối sang cảnh sau: Let market noise end before establishing night lighthouse wind and Bà Hai already waiting. No second market confrontation.

### CẢNH 31: Bà Hai Ở Hải Đăng
*Thời gian truyện: D6 night*
Bà Hai muốn lấy lại Sơn, anh đặt điều kiện gặp trực tiếp Hạ.

**Clip 1 · OPEN · LIGHTHOUSE · W**
- Đầu: Bà Hai and Dũng on the gallery, Sơn emerging from the stairs.
- Hành động: Sơn stops outside Dũng's reach with one copied ledger page.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Về với má. Chuyện này má lo.
- Cuối: Copied page in Sơn's right hand, stair route behind him clear.

**Clip 2 · CUT · LIGHTHOUSE · M**
- Đầu: Bà Hai facing Sơn across the gallery.
- Hành động: She offers to clear his old debts if he brings Kiên under her control.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Đưa Kiên tới. Má lấy lại người cho con.
- Cuối: Sơn listening without stepping closer.

**Clip 3 · CONTINUE · LIGHTHOUSE · M**
- Đầu: Sơn listening without stepping closer.
- Hành động: Sơn asks whether she knows Hạ's holding place, Bà Hai cannot answer.
- Thoại: Sơn (@Son), nói trong hình: Má bán cô ấy mà không biết đi đâu?
- Cuối: Bà Hai avoiding the question, Sơn looking toward the stairs.

**Clip 4 · CUT · LIGHTHOUSE · I**
- Đầu: Copied ledger page held above the gallery rail.
- Hành động: Sơn shows the signature and folds the copy back into his pocket.
- Thoại: Sơn, ngoài khung hình: Bản gốc có người giữ. Đụng tôi cũng vô ích.
- Cuối: Folded copy returned to Sơn's inner pocket, no book left behind.

**Clip 5 · CUT · LIGHTHOUSE · M**
- Đầu: Dũng taking a step toward Sơn, Bà Hai raises one hand.
- Hành động: She stops Dũng and accepts a public exchange at the harbour.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Má tới. Con giữ lời.
- Cuối: Dũng stopped behind Bà Hai's hand, Sơn by the stairs.

**Clip 6 · L · LIGHTHOUSE_BASE · W**
- Đầu: Mây waiting below the tower where she monitored the meeting.
- Hành động: Sơn rejoins her and reports the exchange will include both parties.
- Thoại: Sơn (@Son), nói trong hình: Họ sẽ tới cảng. Phải thấy Hạ trước.
- Cuối: Two figures leaving by the same open main path.

Âm nối sang cảnh sau: Introduce clinic room tone over footsteps leaving the tower. The clinic meeting remains the same night.

### CẢNH 32: Đường Rút Cho Người Sống
*Thời gian truyện: D6 night*
Kế hoạch cứu người có hỗ trợ, Tê không phải mẹo giả chết.

**Clip 1 · J · CLINIC · M**
- Đầu: Linh examining the sealed sample carton without opening it.
- Hành động: Mây asks him to stand by near the planned exchange, outside the danger area.
- Thoại: Mây (@May), nói trong hình: Ông giúp phần cứu người. Không ra giữa cảng.
- Cuối: Linh putting the sealed carton into locked evidence storage.

**Clip 2 · CONTINUE · CLINIC · M**
- Đầu: Linh putting the sealed carton into locked evidence storage.
- Hành động: Sơn explains that Dũng uses Tê to take people alive, Linh listens carefully.
- Thoại: Sơn (@Son), nói trong hình: Hắn muốn giữ người sống để ép khai.
- Cuối: Linh recording that risk on the emergency note.

**Clip 3 · CONTINUE · CLINIC · M**
- Đầu: Linh recording that risk on the emergency note.
- Hành động: Linh rejects any plan relying on a guaranteed waking time.
- Thoại: Bác sĩ Linh (@Bác sĩ Linh), nói trong hình: Gặp thuốc thì đưa về ngay. Đừng chờ phút nào.
- Cuối: Sơn nodding, Mây removing a timer from the tactical sketch.

**Clip 4 · CUT · CLINIC · I**
- Đầu: Simple harbour map on the desk, two protected exits marked by shapes.
- Hành động: Mây assigns rescue extraction to the van and civilians to evacuation only.
- Thoại: Mây, ngoài khung hình: Dân rút trước. Người của tôi giữ hai đầu.
- Cuối: Van route separated from the police approach, map complete.

**Clip 5 · CUT · CLINIC · M**
- Đầu: Sơn facing Mây across the plan.
- Hành động: He agrees to withdraw if Hạ cannot be seen directly at the meeting.
- Thoại: Sơn (@Son), nói trong hình: Không thấy Hạ, không trao gì hết.
- Cuối: Mây's finger on the abort route, Sơn acknowledging.

**Clip 6 · L · CLINIC · W**
- Đầu: Linh placing ordinary monitoring equipment in his bag.
- Hành động: Mây radios the agreed positions while Sơn steps back from the plan.
- Thoại: Mây (@May), nói trong hình: Ưu tiên đưa cả hai người ra.
- Cuối: Medical bag ready, route map with Mây, Sơn unarmed.

Âm nối sang cảnh sau: Flower-shop shutter sound introduces the memory after the current radio check. No repeated medical explanation.

### CẢNH 33: Quá Khứ: Một Lời Hứa Chưa Xong
*Thời gian truyện: PAST one month earlier night*
Hạ đòi lời nói thật, bông hoa chỉ thuộc đêm quá khứ.

**Clip 1 · J · FLOWER · W**
- Đầu: Hạ lowering half the shop shutter, Sơn still inside.
- Hành động: She leaves a gap for him and waits rather than filling the silence.
- Thoại: Hạ (@Ha), nói trong hình: Mai anh còn quay lại không?
- Cuối: Half-closed shutter behind Sơn, Hạ at the counter.

**Clip 2 · CUT · FLOWER · M**
- Đầu: Sơn with both gloves on, looking at Hạ directly.
- Hành động: He admits the job is dangerous instead of promising an effortless return.
- Thoại: Sơn (@Son), nói trong hình: Anh không biết. Anh không muốn nói dối nữa.
- Cuối: Hạ listening, Sơn no longer touching the door handle.

**Clip 3 · CUT · FLOWER · I**
- Đầu: Hạ holding a single white lily beside Sơn's jacket.
- Hành động: She tucks the stem into his breast pocket and checks it stays upright.
- Thoại: —
- Cuối: One lily in his breast pocket, Hạ's hands withdrawn.

**Clip 4 · CUT · FLOWER · M**
- Đầu: Sơn holding the still-closed watch at chest height.
- Hành động: Hạ touches the lid once, asking for an ordinary future rather than a symbol.
- Thoại: Hạ (@Ha), nói trong hình: Về rồi mình ăn sáng. Chỉ vậy thôi.
- Cuối: Her hand leaving the closed watch, Sơn putting it away.

**Clip 5 · CONTINUE · FLOWER · M**
- Đầu: Her hand leaving the closed watch, Sơn putting it away.
- Hành động: Sơn gives a small honest nod, Hạ leans her forehead briefly against his shoulder.
- Thoại: —
- Cuối: Two figures close without an embrace performed for the camera.

**Clip 6 · L · FLOWER_FRONT · W**
- Đầu: Sơn outside the shop, Hạ inside at the shutter.
- Hành động: She lowers the shutter fully after he leaves, no return to present inside this clip.
- Thoại: —
- Cuối: Shutter closed, empty pavement in warm street light.

Âm nối sang cảnh sau: Match the closed shutter lines to the cabin frame at dawn, then carve the seventh tally once.

### CẢNH 34: Vạch Thứ Bảy
*Thời gian truyện: D7 dawn*
Bằng chứng giao nhận rõ, Sơn giữ bản sao cho cuộc trao đổi.

**Clip 1 · MATCH · CABIN · I**
- Đầu: Exactly six marks on the frame, first dawn light across the wood.
- Hành động: Sơn adds only the seventh mark and puts the carving tool away.
- Thoại: Sơn, lời dẫn ngoài hình: Ngày bảy. Lần này tôi ở lại để khai.
- Cuối: Seven distinct marks, tool on the shelf.

**Clip 2 · CUT · CABIN · M**
- Đầu: Original ledger books and hardware on the table, Mây with evidence seals.
- Hành động: Mây brings the original black ledger and USB from the station, Sơn adds red ledger and token, they seal all originals for the investigator.
- Thoại: Mây (@May), nói trong hình: Bản gốc đi trước. Anh cầm bản sao.
- Cuối: Originals sealed with Mây, only a copy envelope before Sơn.

**Clip 3 · CUT · CABIN · I**
- Đầu: Sơn passing the small scarf fragment to Mây's evidence bag.
- Hành động: She stores both pieces in separate sleeves inside the same bag.
- Thoại: —
- Cuối: Both scarf pieces with Mây, sleeve edges visible.

**Clip 4 · CUT · PORCH · M**
- Đầu: Sơn holding his closed watch while Mây prepares to leave.
- Hành động: He asks her to keep it safe during the exchange, she accepts it.
- Thoại: Sơn (@Son), nói trong hình: Giữ giúp. Tôi muốn tự lấy lại.
- Cuối: Closed watch in Mây's right hand, Sơn's belt chain empty.

**Clip 5 · L · POST · W**
- Đầu: Mây handing the sealed originals to an assigned officer at the station.
- Hành động: Thành records the handover while copies remain with the local team.
- Thoại: —
- Cuối: Signed handover receipt with Thành, originals departing under escort.

**Clip 6 · CUT · POST · M**
- Đầu: Confirmed road team on the station radio, Mây beside Thành.
- Hành động: The team reports it will take position before the meeting, not during a later rescue.
- Thoại: Bộ đàm, qua thiết bị: Hai đầu đường đã có người.
- Cuối: Thành marking the confirmed positions, Mây acknowledging.

Âm nối sang cảnh sau: Radio confirmation yields to coffee-stall glass sounds before the morning safety briefing. Orders here assign new practical tasks.

### CẢNH 35: Những Việc Nhỏ Của Thị Trấn
*Thời gian truyện: D7 morning*
Thị trấn chuẩn bị bằng các nhiệm vụ an toàn khác nhau.

**Clip 1 · J · STALL · W**
- Đầu: Mây beside a harbour sketch, Bảy and Thành listening.
- Hành động: Thành gives Mây two fresh pairs of cuffs, she assigns the van to the rear lane and orders civilians off the pier.
- Thoại: Mây (@May), nói trong hình: Chiều nay đóng sạp sớm. Không ai xuống cầu.
- Cuối: Three people each taking their own route away from the table.

**Clip 2 · CUT · VAN_REAR · W**
- Đầu: Bảy parking the van beyond the market wall, Linh beside him.
- Hành động: They clear fish crates and secure a clean mattress and medical bag.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Xe sạch rồi. Đường cũng trống.
- Cuối: Van ready behind cover, rear doors opening toward the safe lane.

**Clip 3 · CUT · MARKET_ROOF · M**
- Đầu: Thành on the market roof with repaired glasses and radio.
- Hành động: He checks sightlines to both pier approaches and confirms the radio works.
- Thoại: Thành (@Phó Thành), nói trong hình: Tôi thấy cả hai đầu.
- Cuối: Binoculars lowered, radio clipped at his collar.

**Clip 4 · CUT · CABIN · M**
- Đầu: Sơn already wearing the black suit, left wrist bandage exposed.
- Hành động: He folds both black gloves into the canvas bag and leaves the bag in the cabin.
- Thoại: —
- Cuối: Gloves inside the bag on the bed, Sơn with bare hands.

**Clip 5 · L · STREET · T**
- Đầu: Sơn leaving the hill path for the main road.
- Hành động: He walks openly past shutters being secured for the afternoon.
- Thoại: —
- Cuối: Sơn approaching the sea-facing coffee table.

**Clip 6 · CUT · STALL · M**
- Đầu: Sơn seated facing the sea, Bảy carrying coffee.
- Hành động: Bảy sets the glass down and leaves Sơn the open view.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Chỗ này nhìn biển được rồi.
- Cuối: Coffee glass on Sơn's right, sea in front of him.

Âm nối sang cảnh sau: The coffee glass settles, the approaching white-car engine begins before the street cut. Kiên arrives only once.

### CẢNH 36: Khách Hàng Áo Trắng
*Thời gian truyện: D7 afternoon*
Đối mặt Kiên, buộc kẻ giữ người chứng minh Hạ có mặt.

**Clip 1 · J · STREET · W**
- Đầu: White car stopping across from the stall, Sơn already seated.
- Hành động: Kiên steps out with two unnamed guards, walks to Sơn's table.
- Thoại: Kiên (@Vũ Kiên), nói trong hình: Anh làm tôi tìm lâu quá.
- Cuối: Kiên standing opposite Sơn, car kept in view behind him.

**Clip 2 · CUT · STALL · M**
- Đầu: Kiên seated across from Sơn, no handshake offered.
- Hành động: He admits the first trap was meant to silence Sơn, then states why he kept Hạ.
- Thoại: Kiên (@Vũ Kiên), nói trong hình: Anh trốn được. Tôi giữ Hạ để anh quay lại.
- Cuối: Sơn listening without giving him the copy envelope.

**Clip 3 · CUT · WHITE_CAR · O**
- Đầu: Rear car window lowered, Hạ visible inside with Kiên outside.
- Hành động: Hạ meets Sơn's eyes and deliberately rests her hand on the inner door handle.
- Thoại: Hạ (@Ha), nói trong hình: Em tự đi được.
- Cuối: Hạ's fingers on the handle, Sơn seeing the gesture from outside.

**Clip 4 · CUT · STREET · M**
- Đầu: Kiên closing the rear car window, Sơn beside the table.
- Hành động: Sơn refuses a private transfer and specifies the open harbour exchange.
- Thoại: Sơn (@Son), nói trong hình: Cảng cá. Thấy cô ấy bước ra rồi mới trao.
- Cuối: Window closed, Sơn still standing outside the car's reach.

**Clip 5 · CUT · STALL · M**
- Đầu: Kiên returning toward Sơn's table before leaving.
- Hành động: He adds the demand that Sơn bring Bà Hai and sign a confession protecting Kiên.
- Thoại: Kiên (@Vũ Kiên), nói trong hình: Đưa bà ta tới. Rồi ký phần của anh.
- Cuối: Blank confession folder placed on the table, Sơn not touching it.

**Clip 6 · L · STREET · W**
- Đầu: Kiên getting into the front passenger seat, Sơn remaining by the stall.
- Hành động: The white car drives toward its temporary lodging, not directly out of town.
- Thoại: —
- Cuối: White car receding, confession folder still unopened on the table.

Âm nối sang cảnh sau: White-car engine recedes under the rear-stall discussion. Keep the car gone and the confession folder with Mây.

### CẢNH 37: Điều Kiện Không Đổi
*Thời gian truyện: D7 afternoon*
Mây và Sơn điều chỉnh kế theo điều kiện mới, không kể lại kế cũ.

**Clip 1 · L · STALL_REAR · M**
- Đầu: Mây and Sơn behind the stall with the unopened confession folder.
- Hành động: Mây identifies the new trap, Sơn agrees the folder will remain blank.
- Thoại: Mây (@May), nói trong hình: Hắn cần người nhận tội thay.
- Cuối: Folder closed in Mây's hand, Sơn's hands empty.

**Clip 2 · CUT · STALL_REAR · I**
- Đầu: Copy envelope open between them, only selected ledger pages inside.
- Hành động: They mark it as a preview, originals already with the investigator.
- Thoại: Sơn, ngoài khung hình: Tôi chỉ đưa bản xem trước.
- Cuối: Preview pages separated from the blank confession folder.

**Clip 3 · CUT · STALL_REAR · M**
- Đầu: Mây beside the confirmed road map, Sơn looking toward the harbour.
- Hành động: Mây assigns the remaining road officer to the main cliff-road turnoff; the narrow service footpath is a separate route below the wall.
- Thoại: Mây (@May), nói trong hình: Chặn đường chính lên tháp. Báo ngay nếu hắn đổi hướng.
- Cuối: Main cliff road marked as covered, Sơn acknowledging; service footpath remains a separate gap to watch.

**Clip 4 · CONTINUE · STALL_REAR · M**
- Đầu: Main cliff road marked as covered, Sơn acknowledging; service footpath remains a separate gap to watch.
- Hành động: Sơn agrees to stop if Hạ is not released from the car.
- Thoại: Sơn (@Son), nói trong hình: Không thả người, tôi không bước tiếp.
- Cuối: Mây closing the map, both understanding the abort signal.

**Clip 5 · CONTINUE · STALL_REAR · M**
- Đầu: Mây closing the map, both understanding the abort signal.
- Hành động: Mây gives him the rescue signal: lay the envelope down and step away.
- Thoại: Mây (@May), nói trong hình: Đặt xuống. Lùi lại. Người tôi sẽ vào.
- Cuối: Envelope flat on the table as a rehearsal, nobody repeating the action twice.

**Clip 6 · CUT · STALL_REAR · I**
- Đầu: Sơn's bare right hand picking up the preview envelope.
- Hành động: He leaves the confession folder with Mây and takes only the copy.
- Thoại: —
- Cuối: Copy envelope in right hand, left wrist bandaged, no weapon.

Âm nối sang cảnh sau: Match present Sơn bare hand holding the copy to young Sơn empty palms under the awning. No glove-box reveal until 38.4.

### CẢNH 38: Quá Khứ: Đôi Găng Đầu Tiên
*Thời gian truyện: PAST twenty-five years earlier rainy evening*
Ơn nuôi dưỡng biến thành quyền sở hữu qua một món quà.

**Clip 1 · MATCH · SILK_REAR · W**
- Đầu: Young Sơn empty bare palms below the silk-shop awning, young Bà Hai watching from within.
- Hành động: She offers shelter, Sơn enters without a bag or trade tools.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Vào ăn trước đã.
- Cuối: Young Sơn under the awning, rain behind him.

**Clip 2 · CUT · SILK · M**
- Đầu: Young Sơn seated with a bowl, Bà Hai across the table.
- Hành động: He begins to eat only after she moves the bowl closer.
- Thoại: —
- Cuối: Bowl near young Sơn, Bà Hai's hands withdrawn.

**Clip 3 · MATCH · SILK · M**
- Đầu: Later season, same table with folded silk instead of the bowl.
- Hành động: Bà Hai teaches him to fold a bolt and listen to the shop bell.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Nghe hết. Nói ít.
- Cuối: Neatly folded silk between them, young Sơn looking toward the door.

**Clip 4 · CUT · SILK · I**
- Đầu: A glove box open on the teak desk.
- Hành động: Bà Hai places new black gloves in young Sơn's bare palms.
- Thoại: Bà Hai, ngoài khung hình: Từ nay con giữ cửa sau.
- Cuối: Gloves resting across both palms, not yet worn.

**Clip 5 · CUT · SILK · M**
- Đầu: Young Sơn by the rear door, Bà Hai at the desk.
- Hành động: He realizes his sleeping mat has been moved inside the locked stockroom.
- Thoại: Sơn, lời dẫn ngoài hình: Chỗ ở dần thành chỗ không được đi.
- Cuối: Young Sơn looking at the stockroom lock, Bà Hai watching him.

**Clip 6 · MATCH · CABIN · I**
- Đầu: Present-day folded gloves in the canvas bag, Sơn's bare hands beside them.
- Hành động: Sơn zips the bag closed and leaves it on the bed.
- Thoại: —
- Cuối: Bag closed on the bed, bare hands leaving the frame.

Âm nối sang cảnh sau: Present-day bag zipper finishes under the cut to the harbour overview, then sea wind takes over. Gloves stay in the cabin.

### CẢNH 39: Bản Đồ Lúc Hoàng Hôn
*Thời gian truyện: D7 sunset*
Thiết lập một lần địa lý và vị trí lực lượng cho toàn cao trào.

**Clip 1 · L · HARBOUR · W**
- Đầu: Whole harbour in one view, market on landward side, lighthouse road uphill west.
- Hành động: Mây checks the protected landward junction while Thành takes the roof post.
- Thoại: —
- Cuối: Pier, market lane and uphill service path all readable in frame.

**Clip 2 · CUT · HARBOUR_REAR · M**
- Đầu: Van behind the market wall, rear lane clear to the clinic.
- Hành động: Mây confirms Linh's protected position and a clear stretcher path.
- Thoại: Mây (@May), nói trong hình: Đưa người qua lối này. Không qua chợ.
- Cuối: Van and stretcher path clear, Mây heading back to the pier.

**Clip 3 · CUT · MARKET_ROOF · O**
- Đầu: Thành looking down at two officers covering the harbour junction.
- Hành động: He confirms both arrival roads are watched and civilians have left.
- Thoại: Thành (@Phó Thành), nói trong hình: Đủ vị trí. Chợ đã rút hết.
- Cuối: Empty public pier below, officers concealed at the junction.

**Clip 4 · CUT · HARBOUR · T**
- Đầu: Sơn entering from the market side, envelope in his right hand.
- Hành động: He stops on the agreed painted seam, facing both approaches.
- Thoại: —
- Cuối: Sơn on the seam, sea behind him, open retreat toward land.

**Clip 5 · CUT · HARBOUR · C**
- Đầu: Sơn at the seam, wind moving his jacket naturally.
- Hành động: He looks once toward Mây's covered position and steadies his left wrist.
- Thoại: —
- Cuối: Sơn's gaze back toward the road, both hands visible.

**Clip 6 · J · HARBOUR · W**
- Đầu: Empty arrival roads beyond Sơn, two engines heard off screen.
- Hành động: Black and white headlights appear from different landward roads.
- Thoại: —
- Cuối: Both headlights approaching the junction, neither car stopped yet.

Âm nối sang cảnh sau: Keep the two approaching engines into the arrivals. The next shot shows parking, not a repeated approach from the road.

### CẢNH 40: Hai Chiếc Xe
*Thời gian truyện: D7 sunset*
Hai phe tới một bãi trao đổi, Hạ có vị trí và hướng thoát rõ.

**Clip 1 · CUT · HARBOUR · W**
- Đầu: Black car reaching the east landward apron, Sơn on the center seam.
- Hành động: Black car parks on the east side of the landward apron, Bà Hai steps out.
- Thoại: —
- Cuối: Black car east, Bà Hai and Dũng beside it, Sơn still on the seam.

**Clip 2 · CUT · HARBOUR · W**
- Đầu: White car approaching the west apron, black car already parked in background.
- Hành động: White car stops on the west apron, Kiên opens the rear door for Hạ.
- Thoại: Kiên (@Vũ Kiên), nói trong hình: Người đây. Phần anh đâu?
- Cuối: White car west, Hạ still seated in the open rear doorway.

**Clip 3 · CUT · HARBOUR · M**
- Đầu: Hạ seated at the white car threshold, Kiên holding the door.
- Hành động: She steps out on her own and studies the landward escape lane.
- Thoại: —
- Cuối: Hạ beside the car, thin sandals on concrete, landward lane to her right.

**Clip 4 · CUT · HARBOUR · W**
- Đầu: All five positions visible around the marked seam.
- Hành động: Both leaders approach but stop on opposite sides of Sơn, keeping Hạ west.
- Thoại: Bà Hai, ngoài khung hình: Con giữ người kiểu đó hả Kiên?
- Cuối: Bà Hai east, Kiên and Hạ west, Sơn center, landward route open.

**Clip 5 · CUT · HARBOUR · M**
- Đầu: Sơn holding the preview envelope low, Kiên beside Hạ.
- Hành động: Sơn asks Kiên to let Hạ cross to the marked safe line.
- Thoại: Sơn (@Son), nói trong hình: Cho cô ấy qua đây.
- Cuối: Sơn pointing to the safe line with empty left hand.

**Clip 6 · CUT · HARBOUR · C**
- Đầu: Hạ looking from Sơn to the safe line, Kiên gripping her arm.
- Hành động: She shifts one sandal toward the line, testing how tightly she is held.
- Thoại: —
- Cuối: Hạ's foot pointed toward land, Kiên's hand still on her upper arm.

Âm nối sang cảnh sau: Keep both engines idling under the first new demand. Do not re-establish the same five positions again.

### CẢNH 41: Cuộc Trao Đổi Đổi Luật
*Thời gian truyện: D7 last light*
Kiên phá điều kiện, Hạ làm Sơn chọn người thay vì giao kèo.

**Clip 1 · CUT · HARBOUR · M**
- Đầu: Kiên holding Hạ just short of the safe line, Sơn opposite.
- Hành động: Kiên demands the signed confession before releasing her, changing the agreement.
- Thoại: Kiên (@Vũ Kiên), nói trong hình: Ký trước. Tôi mới thả.
- Cuối: Blank folder extended toward Sơn, Hạ held back.

**Clip 2 · CUT · HARBOUR · M**
- Đầu: Bà Hai east of Sơn, Dũng a pace behind her.
- Hành động: She orders Sơn to bring Kiên closer in exchange for her protection.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Đưa nó về phía má.
- Cuối: Dũng edging around Sơn's retreat path, Bà Hai watching.

**Clip 3 · CUT · HARBOUR · C**
- Đầu: Hạ's arm held by Kiên, eyes fixed on Sơn.
- Hành động: She tells Sơn not to accept blame for Kiên, then makes herself face the safe lane.
- Thoại: Hạ (@Ha), nói trong hình: Đừng ký. Em không đổi bằng chuyện đó.
- Cuối: Hạ standing upright despite Kiên's grip, Sơn hearing her.

**Clip 4 · CUT · HARBOUR · M**
- Đầu: Sơn between the confession folder and the safe line.
- Hành động: He places his copy envelope flat on the seam and steps back once.
- Thoại: Sơn (@Son), nói trong hình: Tôi ở lại. Để cô ấy đi.
- Cuối: Envelope on concrete, Sơn one full step behind it.

**Clip 5 · CUT · HARBOUR · O**
- Đầu: Mây behind cover with a clear view of the laid-down envelope.
- Hành động: She signals the officers forward slowly while watching Hạ's blocked path.
- Thoại: Mây (@May), nói trong hình: Tiếp cận. Chưa có lối cho con tin.
- Cuối: Two officers advancing behind cover, Mây tracking Kiên's hand.

**Clip 6 · CUT · HARBOUR · W**
- Đầu: Dũng blocking Sơn's right side, Kiên pulling Hạ back toward the white car.
- Hành động: Sơn shifts between Hạ and Dũng as the exchange breaks apart.
- Thoại: —
- Cuối: Sơn shielding Hạ's path, Dũng within arm's reach.

Âm nối sang cảnh sau: Keep breath and road engines. Cut from Sơn shielding the path to Dũng reaching him; the envelope is already on the ground.

### CẢNH 42: Bóng Ma Ngã Xuống
*Thời gian truyện: D7 dusk*
Dũng dùng Tê giữ người sống, Sơn không tự làm giả chết.

**Clip 1 · CUT · HARBOUR · H**
- Đầu: Dũng within arm's reach of Sơn, Kiên west of them with Hạ.
- Hành động: Dũng reaches to restrain Sơn while Kiên drags Hạ away from the safe line.
- Thoại: Dũng (@Dũng), nói trong hình: Má nói giữ mày sống.
- Cuối: Dũng holding Sơn's jacket sleeve, Hạ pulled west toward the car.

**Clip 2 · CUT · HARBOUR · M**
- Đầu: Bà Hai watching Dũng press close to Sơn.
- Hành động: She sees the distinctive Tê device in Dũng's hand and tells him to stop.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Dũng. Má chỉ bảo giữ người.
- Cuối: Bà Hai stepping forward, device partly hidden by Dũng's sleeve.

**Clip 3 · CUT · HARBOUR · C**
- Đầu: Sơn's face as he braces against Dũng, Hạ beyond his shoulder.
- Hành động: His grip weakens after contact with the fictional device, no application detail shown.
- Thoại: Hạ, ngoài khung hình: Sơn!
- Cuối: Sơn losing balance, Hạ turning toward him.

**Clip 4 · CUT · HARBOUR · W**
- Đầu: Sơn folding at the knees beside the copy envelope.
- Hành động: He lowers against a mooring bollard, Dũng holds his jacket instead of letting him strike the ground.
- Thoại: —
- Cuối: Sơn seated limp against the bollard, visibly breathing.

**Clip 5 · CUT · HARBOUR · M**
- Đầu: Bà Hai reaching the bollard, Sơn breathing but unable to stand.
- Hành động: She recognizes Tê immediately and orders Dũng to give him room.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Nó còn sống. Tránh ra cho nó thở.
- Cuối: Bà Hai between Sơn and Dũng, her hand on Sơn's shoulder.

**Clip 6 · CUT · HARBOUR · W**
- Đầu: Kiên west with Hạ, Bà Hai beside Sơn at center.
- Hành động: Kiên demands Sơn and the copies, Hạ kicks the envelope away from his guard's reach.
- Thoại: Kiên (@Vũ Kiên), nói trong hình: Tôi cần cả người lẫn sổ.
- Cuối: Envelope sliding toward the landward safe line, Hạ staying out of the guard's grasp.

Âm nối sang cảnh sau: The kicked envelope reaches the safe line. Keep engines and sea; police commands begin only at 43.3, not before.

### CẢNH 43: Không Ai Còn Là Món Hàng
*Thời gian truyện: D7 dusk*
Hai phe tranh quyền giữ Sơn, lực lượng vào khi thấy hành vi khống chế.

**Clip 1 · MATCH · HARBOUR · W**
- Đầu: Copy envelope at the safe line, Bà Hai beside Sơn, Kiên still west with Hạ.
- Hành động: Bà Hai refuses to hand Sơn to Kiên and pulls Dũng away from his demand.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Con tao. Không giao thêm lần nữa.
- Cuối: Bà Hai shielding Sơn's side, Kiên forced to keep Hạ close.

**Clip 2 · CUT · HARBOUR · M**
- Đầu: Kiên tightening his hold on Hạ, facing Bà Hai.
- Hành động: He reminds her she sold both people and signals his guard toward Sơn.
- Thoại: Kiên (@Vũ Kiên), nói trong hình: Bà bán rồi. Giờ muốn lấy lại sao?
- Cuối: Guard moving toward center, Kiên stepping toward the white car.

**Clip 3 · J · HARBOUR · W**
- Đầu: Mây coming out of landward cover, officers behind her.
- Hành động: She activates the harbour floodlight and orders everyone to release their grips.
- Thoại: Mây (@May), nói trong hình: Bỏ người ra. Công an đây.
- Cuối: Harbour lit steadily, Mây advancing along the safe line.

**Clip 4 · CUT · HARBOUR · O**
- Đầu: Thành on the roof, white car and service stair visible below.
- Hành động: He spots Kiên using the car as cover to reach the uphill maintenance path.
- Thoại: Thành, qua thiết bị: Hướng tây. Lối kỹ thuật sau xe trắng.
- Cuối: Kiên and Hạ moving behind the white car toward the stair.

**Clip 5 · CUT · HARBOUR · H**
- Đầu: Dũng trying to pull Sơn behind the black car, Mây within reach.
- Hành động: Mây and an officer separate Dũng from Sơn without dropping the immobile man.
- Thoại: Mây (@May), nói trong hình: Đưa Sơn về xe cứu hộ.
- Cuối: Sơn supported by the officer, Dũng withdrawing behind a crate.

**Clip 6 · L · HARBOUR_SERVICE · W**
- Đầu: Kiên and Hạ at the foot of the narrow maintenance stair behind the apron.
- Hành động: He blocks the lower gate with a tipped cart and forces her upward.
- Thoại: —
- Cuối: Cart blocking the lower gate, pair ascending the service stair.

Âm nối sang cảnh sau: Police commands continue over rescue movement and the service-route cut. No reset to a second stand-off.

### CẢNH 44: Lối Thoát Bị Chặn
*Thời gian truyện: D7 early night*
Kiên lên tháp qua lối phụ, tuyến cứu Sơn và truy bắt tách rõ.

**Clip 1 · J · HARBOUR · W**
- Đầu: Officers securing the two cars and the public pier, no civilians in the fight.
- Hành động: Mây directs one team to clear the blocked service gate, another to secure witnesses.
- Thoại: Mây (@May), nói trong hình: Một tổ lên tháp. Giữ người còn lại.
- Cuối: Cars secured, service-gate team starting to lift the cart.

**Clip 2 · CUT · HARBOUR_REAR · M**
- Đầu: Sơn supported upright on the stretcher, Linh beside him.
- Hành động: Linh checks his breathing as Bảy guides the stretcher into the van.
- Thoại: Bác sĩ Linh (@Bác sĩ Linh), nói trong hình: Vào xe. Tôi theo dõi ở đây.
- Cuối: Sơn on the secured mattress, Linh inside, Bảy by the rear door.

**Clip 3 · CUT · LIGHTHOUSE_SERVICE · W**
- Đầu: Hạ at the top of the service stair, Kiên behind her with a handgun kept low.
- Hành động: She slows at an old hatch, keeping him talking while studying the latch.
- Thoại: Hạ (@Ha), nói trong hình: Lối này không ra đường lớn đâu.
- Cuối: Hạ beside the hatch, Kiên turning to listen for pursuit.

**Clip 4 · CUT · HARBOUR_SERVICE · M**
- Đầu: Thành and an officer at the still-blocked lower gate.
- Hành động: They cut the cart's tangled securing rope and radio the delay.
- Thoại: Thành, qua thiết bị: Lối phụ bị chặn. Đang mở.
- Cuối: Cart partly lifted, space just opening at the gate.

**Clip 5 · CUT · HARBOUR_REAR · O**
- Đầu: Dũng behind a crate seeing the stretcher enter Bảy's van.
- Hành động: He follows the cleared stretcher path as Mây turns back from the pier.
- Thoại: —
- Cuối: Dũng moving along the wall, Mây noticing him before the van.

**Clip 6 · L · VAN · C**
- Đầu: Sơn's eyes open on the van mattress, lamp beside his face.
- Hành động: He tries to move his bandaged left hand but cannot yet lift it.
- Thoại: Sơn, lời dẫn ngoài hình: Tôi nghe được. Chưa giúp được ai.
- Cuối: Breathing visible, left hand still on the mattress.

Âm nối sang cảnh sau: Keep Sơn breathing unchanged across the cut to Linh beside him. Hạ route returns only in its next dedicated shot.

### CẢNH 45: Những Người Đang Chờ
*Thời gian truyện: D7 night continuous*
Dựng song song chăm sóc Sơn và Hạ trì hoãn Kiên.

**Clip 1 · CUT · VAN · M**
- Đầu: Sơn lying on the van mattress with eyes open, Linh at his right side.
- Hành động: Linh steadies Sơn's head and keeps watching his breathing, no miracle timer or instant cure.
- Thoại: Bác sĩ Linh (@Bác sĩ Linh), nói trong hình: Đừng cố đứng. Cứ thở với tôi.
- Cuối: Linh seated beside Sơn, lamp kept steady.

**Clip 2 · CUT · LIGHTHOUSE_SERVICE · M**
- Đầu: Hạ beside the stuck maintenance hatch, Kiên pulling at its wheel.
- Hành động: She gives only the next necessary instruction, deliberately taking time.
- Thoại: Hạ (@Ha), nói trong hình: Chốt dưới trước. Ba tôi làm vậy.
- Cuối: Kiên occupied with the wheel, Hạ's right hand near her hair clip.

**Clip 3 · CUT · HARBOUR_SERVICE · W**
- Đầu: Lower gate now open, two officers starting up the narrow service stair.
- Hành động: Thành sends their position and asks the lighthouse team to keep Kiên talking.
- Thoại: Thành, qua thiết bị: Đã thông. Tổ một lên lối phụ.
- Cuối: Officers already above the gate, Thành moving after them.

**Clip 4 · CUT · LIGHTHOUSE_SERVICE · I**
- Đầu: Hạ's hair clip concealed in her right palm near the inner latch.
- Hành động: She wedges it into the latch gap as Kiên pushes the hatch open.
- Thoại: —
- Cuối: Clip holding the latch short of fully closing behind them.

**Clip 5 · CUT · VAN · M**
- Đầu: Mây at the van door, Linh at Sơn's side.
- Hành động: She tells Sơn the teams are moving and returns his closed watch to his right hand.
- Thoại: Mây (@May), nói trong hình: Hạ đang tự giữ đường cho mình.
- Cuối: Closed watch in Sơn's right palm, Mây's hands free.

**Clip 6 · J · VAN_REAR · W**
- Đầu: Mây stepping out of the van, Dũng approaching along the wall.
- Hành động: She closes one rear door behind herself and blocks his approach.
- Thoại: Dũng (@Dũng), nói trong hình: Để tao đưa nó về cho má.
- Cuối: Mây between Dũng and the van, open retreat lane behind her.

Âm nối sang cảnh sau: The van-door latch leads directly into Dũng first advance. Do not introduce him arriving a second time.

### CẢNH 46: Mây Giữ Cửa
*Thời gian truyện: D7 night continuous*
Mây khống chế Dũng bằng còng mới, Sơn trở lại từng chút.

**Clip 1 · CUT · VAN_REAR · H**
- Đầu: Mây between Dũng and the van doors, loose cart to her left.
- Hành động: Dũng rushes for the van door, Mây angles a loose cart into his direct path.
- Thoại: Mây (@May), nói trong hình: Anh không đưa ai đi nữa.
- Cuối: Cart between them, Dũng off balance, Mây beside its handle.

**Clip 2 · CONTINUE · VAN_REAR · H**
- Đầu: Cart between them, Dũng off balance, Mây beside its handle.
- Hành động: Dũng pushes the cart aside, Mây steps clear toward the arriving officer.
- Thoại: —
- Cuối: Mây beside the officer, Dũng facing two people rather than one.

**Clip 3 · CONTINUE · VAN_REAR · H**
- Đầu: Mây beside the officer, Dũng facing two people rather than one.
- Hành động: Mây and the officer control Dũng's arms against the van side without a head strike.
- Thoại: —
- Cuối: Dũng restrained standing, both arms controlled.

**Clip 4 · CUT · VAN_REAR · I**
- Đầu: A fresh intact pair of Mây's issued cuffs in her hands.
- Hành động: She secures Dũng's wrists together and hands him to the officer.
- Thoại: Mây, ngoài khung hình: Niêm phong cả chiếc cũ trên tay hắn.
- Cuối: Dũng cuffed to himself under escort, old cut cuff still separately visible.

**Clip 5 · CUT · VAN · M**
- Đầu: Sơn still on the mattress, watch closed in his right hand.
- Hành động: His fingers begin moving, Linh helps him sit partway without letting him stand.
- Thoại: Sơn (@Son), nói trong hình: Tôi cử động được rồi.
- Cuối: Sơn propped against a support, left wrist still weak.

**Clip 6 · L · VAN_REAR · M**
- Đầu: Dũng under escort beside the van, Mây checking her radio.
- Hành động: He realizes Sơn remains alive and can testify, stops asking to take him.
- Thoại: Dũng (@Dũng), nói trong hình: Má tưởng giữ được nó mãi.
- Cuối: Dũng led toward the custody vehicle, Mây returning to the van.

Âm nối sang cảnh sau: Custody footsteps recede, incoming van breathing introduces seated Sơn. His watch remains closed and silent.

### CẢNH 47: Tỉnh Lại
*Thời gian truyện: D7 night continuous*
Sơn chấp nhận đi cùng Mây trong vai trò hỗ trợ, không tự lao đi.

**Clip 1 · J · VAN · M**
- Đầu: Sơn seated with support, Mây at the doorway, Linh watching him.
- Hành động: Linh checks that he can follow instructions and move both feet.
- Thoại: Bác sĩ Linh (@Bác sĩ Linh), nói trong hình: Chậm thôi. Anh chưa khỏe lại.
- Cuối: Sơn still seated, feet on van floor, Linh close enough to support.

**Clip 2 · CONTINUE · VAN · M**
- Đầu: Sơn still seated, feet on van floor, Linh close enough to support.
- Hành động: Sơn tells Mây about the lower hatch Hạ described in the past.
- Thoại: Sơn (@Son), nói trong hình: Hạ biết cửa dưới ban công.
- Cuối: Mây drawing the service hatch below the gallery on her notepad.

**Clip 3 · CONTINUE · VAN · M**
- Đầu: Mây drawing the service hatch below the gallery on her notepad.
- Hành động: Mây receives confirmation that the main door is accessible, decides to lead that approach herself.
- Thoại: Mây (@May), nói trong hình: Đi với tôi. Ở phía sau tôi.
- Cuối: Mây closing her notepad, Linh continuing to support Sơn.

**Clip 4 · L · VAN_REAR · W**
- Đầu: Mây helping Sơn step down, Linh beside his weaker left side.
- Hành động: Sơn tests his balance against the van door instead of running.
- Thoại: —
- Cuối: Sơn standing with support, right hand holding the closed watch.

**Clip 5 · CUT · MOTORBIKE · M**
- Đầu: Motorcycle stationary, engine off, two helmets on the seat.
- Hành động: Sơn pockets the closed watch, both fasten their helmets, then Mây takes the front seat and Sơn the pillion seat.
- Thoại: —
- Cuối: Mây riding position, Sơn seated behind, both helmets fastened.

**Clip 6 · CUT · MOTORBIKE · W**
- Đầu: Both seated on the stationary motorcycle, helmets already fastened.
- Hành động: Mây starts the engine, confirms the route by radio, departs slowly with Sơn holding the rail.
- Thoại: Mây (@May), nói trong hình: Chúng tôi lên cửa chính.
- Cuối: Motorcycle leaving left to right, Sơn seated steadily behind her.

Âm nối sang cảnh sau: Keep the same motorcycle ignition after helmets are secured. Cut to the road with movement still left to right.

### CẢNH 48: Hai Lối Lên Tháp
*Thời gian truyện: D7 night continuous*
Hai tổ tiến tới, Hạ giữ lối phụ hé, Sơn không tự đi một mình.

**Clip 1 · CUT · CLIFFROAD · T**
- Đầu: Same motorcycle already on the lower cliff road, travelling left to right.
- Hành động: Mây rides uphill at a controlled speed while Sơn braces against the rear rail.
- Thoại: —
- Cuối: Motorcycle approaching the lighthouse bend, both helmets still on.

**Clip 2 · CUT · LIGHTHOUSE_BASE · W**
- Đầu: Motorcycle stopped at the main entrance, engine switched off.
- Hành động: They dismount and leave both helmets on the seat before entering.
- Thoại: —
- Cuối: Both on foot at the main door, helmets left on the motorcycle.

**Clip 3 · L · LIGHTHOUSE_STAIR · T**
- Đầu: Mây leading up the spiral stair, Sơn a step below.
- Hành động: He climbs using the rail, pauses once to regain balance, Mây waits.
- Thoại: —
- Cuối: Both below the final landing, no overtaking or running.

**Clip 4 · CUT · LIGHTHOUSE_SERVICE · M**
- Đầu: Kiên testing the gallery hatch behind him, Hạ facing the sea wall.
- Hành động: The hair clip prevents a full latch, he fails to secure it and pulls Hạ upward.
- Thoại: —
- Cuối: Service hatch still slightly ajar, Hạ noticing it stayed open.

**Clip 5 · CUT · LIGHTHOUSE_SERVICE · I**
- Đầu: An officer's hand reaching the same hatch from below, Thành behind him.
- Hành động: They see the clip keeping the latch open and enter quietly.
- Thoại: Thành, qua thiết bị: Con tin để cửa cho mình.
- Cuối: Officer through the gap, clip still in latch, Thành following.

**Clip 6 · L · LIGHTHOUSE_STAIR · M**
- Đầu: Mây and Sơn at the last stair corner, Kiên heard above.
- Hành động: Mây announces herself and asks him to move away from Hạ.
- Thoại: Mây (@May), nói trong hình: Kiên. Tôi lên nói chuyện.
- Cuối: Mây at the corner, Sơn one step lower and behind her.

Âm nối sang cảnh sau: Keep wind and restrained radio traffic through the parallel cut to Bà Hai arrest below. The climb continues off screen.

### CẢNH 49: Chiếc Vòng Ngọc
*Thời gian truyện: D7 night simultaneous with the climb*
Bà Hai bị bắt bởi tổ dưới cảng, trả giá cho việc coi người là hàng.

**Clip 1 · CUT · HARBOUR · W**
- Đầu: Bà Hai on the stone bench under the floodlight, one officer in front of her.
- Hành động: She looks toward the custody road off screen and sets her unlit holder down, unable to give another order.
- Thoại: —
- Cuối: Holder on bench, Bà Hai's hands resting on her knees.

**Clip 2 · CUT · HARBOUR · M**
- Đầu: Dũng pausing under escort within sight of the bench.
- Hành động: He waits for an order, Bà Hai cannot give him one that changes anything.
- Thoại: Dũng (@Dũng), nói trong hình: Má còn muốn con giữ ai nữa?
- Cuối: Dũng facing the road again, Bà Hai looking at her bracelet.

**Clip 3 · CUT · HARBOUR · I**
- Đầu: Jade bracelet on Bà Hai's left wrist.
- Hành động: She removes it deliberately and places it beside the unlit holder.
- Thoại: —
- Cuối: Bracelet and holder together on stone, both wrists bare.

**Clip 4 · CUT · HARBOUR · M**
- Đầu: Bà Hai standing before the officer with bare wrists.
- Hành động: She submits to the arrest, speaks about Sơn as if ownership were an explanation.
- Thoại: Bà Hai (@HaiNgoc), nói trong hình: Nó là con tôi nuôi.
- Cuối: Cuffs secured, Bà Hai looking toward the lighthouse.

**Clip 5 · CUT · HARBOUR · C**
- Đầu: Bà Hai listening to the officer, no one touching her bracelet.
- Hành động: The officer records her words without accepting them as an excuse.
- Thoại: Cán bộ hỗ trợ, ngoài khung hình: Vậy bà sẽ khai cả chuyện đã bán người.
- Cuối: Bà Hai lowering her gaze away from the tower.

**Clip 6 · L · HARBOUR · W**
- Đầu: Custody vehicle waiting on the protected road, bench behind her.
- Hành động: She walks under escort, leaving the bracelet for the evidence officer.
- Thoại: —
- Cuối: Empty bench with bracelet in an evidence tray, vehicle door open.

Âm nối sang cảnh sau: Incoming gallery wind replaces pier custody sounds before returning to Mây at the main stair entrance.

### CẢNH 50: Đỉnh Hải Đăng
*Thời gian truyện: D7 night continuous*
Mây giữ đối thoại, Hạ nhận ra lối thoát, Sơn không áp sát nòng súng.

**Clip 1 · J · LIGHTHOUSE · W**
- Đầu: Mây at the gallery entrance, Sơn behind her, Kiên holding Hạ near the rail.
- Hành động: Mây stops short and keeps a clear space between herself and the hostage pair.
- Thoại: Mây (@May), nói trong hình: Cho Hạ đứng riêng. Tôi nghe anh.
- Cuối: Four positions readable, service hatch at Kiên's far side.

**Clip 2 · CUT · LIGHTHOUSE · M**
- Đầu: Kiên gripping Hạ, handgun low but visible in his other hand.
- Hành động: He asks for a vehicle off the coast road, refusing to surrender.
- Thoại: Kiên (@Vũ Kiên), nói trong hình: Một xe. Không ai theo.
- Cuối: Hạ looking toward the service hatch as Kiên watches Mây.

**Clip 3 · CUT · LIGHTHOUSE · M**
- Đầu: Mây staying at the entrance with her hands visible.
- Hành động: She keeps him engaged while an officer reaches the service side unseen by Kiên.
- Thoại: Mây (@May), nói trong hình: Muốn đi, trước hết bỏ tay khỏi cô ấy.
- Cuối: Kiên facing the main entrance, service side outside his attention.

**Clip 4 · CUT · LIGHTHOUSE · C**
- Đầu: Hạ recognizing Sơn's bare hands and bandaged left wrist behind Mây.
- Hành động: She gives him the same small downward glance used beside the old hatch.
- Thoại: —
- Cuối: Sơn following Hạ's eyeline toward the backup-light cable.

**Clip 5 · CUT · LIGHTHOUSE_SERVICE · I**
- Đầu: Thành below the gallery at the tested backup-light lever.
- Hành động: He sees the open route and waits for Mây's radio cue instead of touching anything accidentally.
- Thoại: Thành, qua thiết bị: Tôi ở đèn dự phòng. Chờ lệnh.
- Cuối: Thành's hand near but not on the lever.

**Clip 6 · CUT · LIGHTHOUSE · M**
- Đầu: Hạ angled toward the inner wall, Kiên still holding her upper arm.
- Hành động: She asks to steady herself, shifting them one step away from the rail.
- Thoại: Hạ (@Ha), nói trong hình: Cho tôi vịn tường. Tôi chóng mặt.
- Cuối: Hạ nearer the inner wall, Kiên pulled slightly off his preferred position.

Âm nối sang cảnh sau: Keep the established gallery wind and faint cable rattle. Backup light turns on only on the cue at 51.1.

### CẢNH 51: Tay Không Giữ Người
*Thời gian truyện: D7 night continuous*
Hạ tạo khoảng hở, Sơn cứu cả kẻ thù, Mây bắt Kiên.

**Clip 1 · MATCH · LIGHTHOUSE · M**
- Đầu: Hạ near the inner wall, Kiên holding her arm, Mây still at the entrance.
- Hành động: Mây gives the short radio cue, the backup lamp turns on toward the sea, not into anyone's eyes.
- Thoại: Mây (@May), nói trong hình: Bật đèn. Giữ cửa phụ.
- Cuối: Kiên looking toward the unexpected lamp, Hạ already near the inner wall.

**Clip 2 · CUT · LIGHTHOUSE · H**
- Đầu: Kiên's attention shifted toward the lamp, Hạ beside the inner wall.
- Hành động: Hạ turns out of his loose grip and steps behind the doorway toward Mây.
- Thoại: —
- Cuối: Hạ behind Mây's line, Kiên no longer holding her.

**Clip 3 · CONTINUE · LIGHTHOUSE · H**
- Đầu: Hạ behind Mây's line, Kiên no longer holding her.
- Hành động: Kiên lunges after Hạ, Sơn uses his sound right arm to interrupt the reach.
- Thoại: —
- Cuối: Kiên stumbling backward toward the rail, Sơn off balance beside him.

**Clip 4 · CONTINUE · LIGHTHOUSE · H**
- Đầu: Kiên stumbling backward toward the rail, Sơn off balance beside him.
- Hành động: Kiên's heel catches the low rail, Sơn chooses to pull his jacket inward instead of letting him fall.
- Thoại: Sơn (@Son), nói trong hình: Giữ lấy tay tôi.
- Cuối: Both men on the inner gallery floor, handgun released away from them.

**Clip 5 · CUT · LIGHTHOUSE · W**
- Đầu: Released handgun on the inner floor, both men down and Hạ safely by the door.
- Hành động: Mây secures the handgun, an officer controls Kiên, Hạ steadies Sơn.
- Thoại: Mây (@May), nói trong hình: Kiên, hết đường giữ người rồi.
- Cuối: Kiên restrained under officer control, handgun secured as evidence.

**Clip 6 · CUT · LIGHTHOUSE · M**
- Đầu: Sơn seated against the inner wall, Hạ beside him, Mây a few paces away.
- Hành động: Mây checks they are safe and gives them a moment while maintaining custody of Kiên.
- Thoại: —
- Cuối: Hạ and Sơn seated together, clear gallery space between them and Kiên.

Âm nối sang cảnh sau: Only breathing and the steady backup lamp remain. Cut to the quiet watch scene without replaying the restraint.

### CẢNH 52: Lần Đầu Mở Đồng Hồ
*Thời gian truyện: D7 night continuous*
Trả lời lời hẹn bằng một hành động duy nhất, khăn được trao lại có nguồn.

**Clip 1 · CUT · LIGHTHOUSE · M**
- Đầu: Hạ and Sơn seated safely against the inner wall, officer with Kiên out of focus beyond.
- Hành động: Sơn takes the same closed watch from his inside pocket and shows Hạ the dented lid.
- Thoại: Sơn (@Son), nói trong hình: Nó dừng đêm anh chạy khỏi em.
- Cuối: Closed watch between them, his bandaged left hand resting on his knee.

**Clip 2 · CUT · LIGHTHOUSE · I**
- Đầu: Sơn's right thumb at the closed watch clasp.
- Hành động: He opens the lid for the first time in the film, revealing cracked glass and Hạ's small photograph.
- Thoại: —
- Cuối: Watch open, stopped hands and photograph clearly visible without text.

**Clip 3 · CONTINUE · LIGHTHOUSE · I**
- Đầu: Watch open, stopped hands and photograph clearly visible without text.
- Hành động: Hạ steadies the open case while Sơn winds the crown once.
- Thoại: Hạ, ngoài khung hình: Nó vẫn còn sửa được.
- Cuối: Second hand moving again, both hands steady around the single watch.

**Clip 4 · CUT · LIGHTHOUSE · C**
- Đầu: Both listening to the newly audible ticking, no one looking into camera.
- Hành động: Sơn exhales into a small unforced smile, Hạ stays close without speaking.
- Thoại: —
- Cuối: Sơn looking at Hạ, open watch lower in frame.

**Clip 5 · CUT · LIGHTHOUSE · M**
- Đầu: Mây holding the two previously sealed scarf sleeves beside them.
- Hành động: She returns the documented long scarf to Hạ and keeps the small fragment with the case file.
- Thoại: Mây (@May), nói trong hình: Phần còn lại của mày đây.
- Cuối: Long scarf in Hạ's hands, short fragment still sealed with Mây.

**Clip 6 · CUT · LIGHTHOUSE · M**
- Đầu: Hạ wrapping the long scarf loosely over the same grey dress.
- Hành động: Sơn closes the watch and looks toward Mây waiting by the stairs.
- Thoại: Sơn (@Son), nói trong hình: Tôi còn một việc phải nói hết.
- Cuối: Hạ still in grey dress with scarf, watch closed in Sơn's hand.

Âm nối sang cảnh sau: Renewed ticking continues briefly under the custody footsteps, then falls away naturally. Do not reopen the watch.

### CẢNH 53: Người Không Chạy Nữa
*Thời gian truyện: D7 night continuous*
Sơn tự nhận trách nhiệm, Hạ chấp nhận thay vì cản luật.

**Clip 1 · L · LIGHTHOUSE · W**
- Đầu: Mây waiting at the gallery doorway, Hạ and Sơn standing with care.
- Hành động: Sơn approaches Mây on his own, keeping his hands where she can see them.
- Thoại: Sơn (@Son), nói trong hình: Tôi đi với cô.
- Cuối: Sơn in front of Mây, Hạ one step behind.

**Clip 2 · CUT · LIGHTHOUSE · M**
- Đầu: Hạ beside Sơn before he reaches the doorway.
- Hành động: She asks if this is his choice, he answers without blaming her.
- Thoại: Hạ (@Ha), nói trong hình: Anh tự chọn chứ?
- Cuối: Hạ releasing his sleeve deliberately.

**Clip 3 · CUT · LIGHTHOUSE · M**
- Đầu: Sơn holding both hands forward, left wrist still bandaged.
- Hành động: Mây applies the cuffs carefully while an officer documents the condition of his wrist.
- Thoại: Sơn (@Son), nói trong hình: Ừ. Lần này là anh chọn.
- Cuối: Cuffs fitted without pressing the bandage, Sơn standing upright.

**Clip 4 · CUT · LIGHTHOUSE · I**
- Đầu: Closed watch in Sơn's cupped right hand, cuff chain below.
- Hành động: Hạ places it safely into his breast pocket with his consent.
- Thoại: —
- Cuối: One closed watch in his breast pocket, her hand withdrawn.

**Clip 5 · L · LIGHTHOUSE_STAIR · W**
- Đầu: Kiên already under escort farther down the stairs, group behind him separated.
- Hành động: Mây escorts Sơn, Thành supports Hạ, nobody overtakes on the narrow stair.
- Thoại: —
- Cuối: Both escorted groups descending in order, gallery empty behind.

**Clip 6 · CUT · LIGHTHOUSE_BASE · W**
- Đầu: Group emerging from the main doorway, backup beam moving over the sea.
- Hành động: Hạ pauses to see her father's lighthouse working, then joins the others.
- Thoại: Hạ (@Ha), nói trong hình: Để đèn sáng tới khi mọi người về.
- Cuối: Hạ walking toward the waiting vehicle, light continuing behind her.

Âm nối sang cảnh sau: Incoming station kettle and fan introduce the later interview after Hạ clothing change. Do not show the descent twice.

### CẢNH 54: Lời Khai Của Hạ
*Thời gian truyện: D7 late night*
Hạ kể các lựa chọn mình đã làm và cung cấp chứng cứ mới.

**Clip 1 · J · POST · W**
- Đầu: A later station scene, Hạ already changed into borrowed white blouse and jeans.
- Hành động: Mây brings tea, Thành starts a fresh witness record at a separate desk.
- Thoại: Mây (@May), nói trong hình: Mệt thì nghỉ. Tao vẫn ở đây.
- Cuối: Hạ seated freely with scarf on chair, tea before her.

**Clip 2 · CUT · POST · I**
- Đầu: Small scarf fragment sealed between Mây and Hạ.
- Hành động: Hạ explains she tore it on the flower-shop latch to leave a trace for anyone searching.
- Thoại: Hạ, ngoài khung hình: Tao xé lúc bị đưa ra cửa.
- Cuối: Hạ pointing to the torn edge without touching the seal.

**Clip 3 · CUT · POST · M**
- Đầu: Thành showing Hạ the saved video on a tablet.
- Hành động: She identifies the ferry emblem and the meal-delivery rhythm she used to count days.
- Thoại: Hạ (@Ha), nói trong hình: Còi tàu tới trước bữa tối. Ngày nào cũng vậy.
- Cuối: Thành adding the identifiable transport detail to the statement.

**Clip 4 · CUT · POST · C**
- Đầu: Hạ holding her own empty palms above the table.
- Hành động: She describes deciding to keep the service hatch open when Kiên took her upward.
- Thoại: Hạ (@Ha), nói trong hình: Tao chỉ cần họ vào được sau tao.
- Cuối: Mây listening without interrupting, Hạ's hands relaxing.

**Clip 5 · CUT · POST · I**
- Đầu: Hair clip recovered from the hatch, now in its own sealed bag.
- Hành động: Thành photographs Hạ identifying it and adds the recovery location.
- Thoại: —
- Cuối: Clip bag and station record together, chain of custody intact.

**Clip 6 · L · POST · M**
- Đầu: Interview ended, Thành stopping the recorder in the background.
- Hành động: Hạ asks to see her father's house the following morning instead of asking only about Sơn.
- Thoại: Hạ (@Ha), nói trong hình: Mai đưa tao về nhà ba nhé.
- Cuối: Mây placing the old family-house key on the table.

Âm nối sang cảnh sau: Match the central placement of the house key on Hạ table to the recorder on Sơn interview table, then begin a different account.

### CẢNH 55: Tên Của Những Cánh Cửa
*Thời gian truyện: D7 late night*
Sơn nhận trách nhiệm cụ thể, không coi cứu Hạ là xóa tội.

**Clip 1 · MATCH · INTERVIEW · M**
- Đầu: Recorder centered on the interview desk, Sơn seated on the other side.
- Hành động: Mây checks he understands the interview and starts the recording.
- Thoại: Mây (@May), nói trong hình: Anh muốn khai từ việc nào?
- Cuối: Recorder light steady, Sơn facing Mây.

**Clip 2 · CONTINUE · INTERVIEW · M**
- Đầu: Recorder light steady, Sơn facing Mây.
- Hành động: Sơn names the first address and year, choosing facts instead of his nickname.
- Thoại: Sơn (@Son), nói trong hình: Địa chỉ đầu tiên. Tôi nhớ người mở cửa.
- Cuối: Mây writing an address in the private record, Sơn remaining seated.

**Clip 3 · CUT · INTERVIEW · C**
- Đầu: Sơn looking at the paper rather than at his reflection in the window.
- Hành động: He states that fear and debt do not excuse what he did.
- Thoại: Sơn (@Son), nói trong hình: Không ai bắt tay tôi làm. Tôi phải chịu.
- Cuối: His bare hands flat on the table, no watch used as a prop.

**Clip 4 · CUT · INTERVIEW · M**
- Đầu: Mây separating verified facts from items needing investigation.
- Hành động: She asks for names of people who can confirm the account and records each answer.
- Thoại: Mây (@May), nói trong hình: Ai còn sống để xác nhận chuyện này?
- Cuối: Two evidence columns on paper without readable text, Sơn cooperating.

**Clip 5 · CONTINUE · INTERVIEW · M**
- Đầu: Two evidence columns on paper without readable text, Sơn cooperating.
- Hành động: Sơn gives the next contact and signs the statement after reading it.
- Thoại: —
- Cuối: Statement signed, pen set aside once, hands withdrawn.

**Clip 6 · L · HOLDING · W**
- Đầu: Sơn seated in the holding room after the interview, corridor light outside.
- Hành động: He closes his eyes and rests with the wrist bandage visible, no new speech.
- Thoại: —
- Cuối: Sơn finally sleeping, closed watch secured in his pocket.

Âm nối sang cảnh sau: Carry the station fan from the quiet holding room into morning evidence handover. Do not replay the statement or signature.

### CẢNH 56: Sổ Tiền Thành Hồ Sơ
*Thời gian truyện: D8 morning*
Bằng chứng được xác minh và đời sống thị trấn bắt đầu trở lại.

**Clip 1 · J · POST · W**
- Đầu: Investigator reviewing the sealed originals against Thành's handover record.
- Hành động: Mây delivers the remaining local witness files for the same case.
- Thoại: Bộ đàm, qua thiết bị: Đã khớp sổ với xưởng và chuyến tàu.
- Cuối: Complete evidence handover recorded, local copies retained.

**Clip 2 · CUT · STALL · M**
- Đầu: Bảy returning an overturned chair to its regular place, Thành nearby.
- Hành động: They reopen the stall together, without retelling the whole fight.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Giờ bán cà phê lại được chưa?
- Cuối: Chair upright, first clean glass on the counter.

**Clip 3 · L · MARKET · W**
- Đầu: Mây walking through the reopening fish market.
- Hành động: She checks on sellers who evacuated and thanks them for keeping the routes clear.
- Thoại: Mây (@May), nói trong hình: Cảm ơn mọi người đã đưa dân ra.
- Cuối: Mây with two unnamed sellers at the repaired side gate.

**Clip 4 · CUT · CLINIC · M**
- Đầu: Linh at the clinic sink after filing his medical notes.
- Hành động: He hangs the emptied response bag to dry and sits down at last.
- Thoại: —
- Cuối: Bag drying above the bench, Linh resting with a cup of water.

**Clip 5 · CUT · POST · M**
- Đầu: Thành wearing replacement glasses, Mây at the case board.
- Hành động: They remove the emergency duty roster and restore the normal shift plan.
- Thoại: Thành (@Phó Thành), nói trong hình: Đêm nay trực lại như cũ hả chị?
- Cuối: Emergency roster filed away, ordinary patrol map visible.

**Clip 6 · L · STREET · W**
- Đầu: Hạ at the station doorway, Mây joining her with the family-house key.
- Hành động: They walk toward the harbour houses instead of the crime-scene pier.
- Thoại: Mây (@May), nói trong hình: Về nhà trước. Chuyện khác tính sau.
- Cuối: Both walking side by side in morning light.

Âm nối sang cảnh sau: Keep ordinary town morning sound from the walk to the family-house threshold. Market-stall planning happens after the home entry.

### CẢNH 57: Chỗ Của Hạ
*Thời gian truyện: D8 morning*
Hạ có mục tiêu đời sống riêng và bắt đầu thực hiện.

**Clip 1 · CUT · HA_HOME · W**
- Đầu: Hạ and Mây at the family-house doorstep, key in Hạ's right hand.
- Hành động: Hạ unlocks her father's house, Mây remains outside until invited.
- Thoại: Hạ (@Ha), nói trong hình: Vào đi. Nhà tao mà.
- Cuối: Door open, Hạ inside her own threshold.

**Clip 2 · CUT · HA_HOME · M**
- Đầu: Hạ before an old workbench with a lighthouse photograph.
- Hành động: She wipes a clear space and sets her own bag down, claiming the room.
- Thoại: —
- Cuối: Clean patch on the workbench, her bag beside it.

**Clip 3 · L · STALL_SITE · W**
- Đầu: Empty strip beside the fish-market entrance, no finished flower stall yet.
- Hành động: Hạ measures a modest place for a folding table, Mây holds the tape end.
- Thoại: Hạ (@Ha), nói trong hình: Tao mở ở đây. Sáng người ta đi qua đông.
- Cuối: Space marked with chalk, both facing the future stall position.

**Clip 4 · CUT · STALL_SITE · M**
- Đầu: Hạ at the chalk mark, Mây holding the other end of the tape.
- Hành động: Mây asks whether Hạ wants to wait until the case ends, Hạ keeps measuring.
- Thoại: Hạ (@Ha), nói trong hình: Tao mở cho tao sống trước đã.
- Cuối: Tape extended to the agreed edge, Hạ making her own decision.

**Clip 5 · CUT · HA_HOME · I**
- Đầu: One white lily from her father's small yard vase on the windowsill.
- Hành động: Hạ trims the stem and wraps only this flower in plain paper.
- Thoại: —
- Cuối: Single wrapped lily in Hạ's hand, remaining vase undisturbed.

**Clip 6 · J · HARBOUR_WALK · W**
- Đầu: Hạ and Mây reaching the public walkway, transport engine heard near the station.
- Hành động: Hạ stays on the safe side of the walkway with the flower rather than running into the road.
- Thoại: Hạ (@Ha), nói trong hình: Tao đứng đây. Ảnh sẽ thấy.
- Cuối: Hạ visible from the transport lane, Mây beside her.

Âm nối sang cảnh sau: Keep the approaching transport engine into Sơn window-side view. Hạ already holds the single lily; do not wrap it again.

### CẢNH 58: Qua Ô Cửa Xe
*Thời gian truyện: D8 late morning*
Chia tay bằng một ánh nhìn, không diễn lại nhiều lần.

**Clip 1 · J · TRANSPORT · M**
- Đầu: Inside the prisoner transport, Sơn in olive jacket after a documented clothing change.
- Hành động: Thành sits opposite with the transfer file, signals the public walkway ahead.
- Thoại: Thành (@Phó Thành), nói trong hình: Bên phải. Cạnh hàng cây.
- Cuối: Sơn turning toward the side window, Thành giving him space.

**Clip 2 · CUT · TRANSPORT_VIEW · O**
- Đầu: View from Sơn's window, Hạ at the public walkway with one wrapped lily.
- Hành động: She lifts the flower only to chest height as the vehicle approaches.
- Thoại: —
- Cuối: Hạ holding one lily against her chest, eyes on the moving window.

**Clip 3 · CUT · TRANSPORT · C**
- Đầu: Sơn beside the mesh window, closed watch chain secured inside his jacket.
- Hành động: He acknowledges Hạ with one small nod, keeping his cuffed hands low.
- Thoại: —
- Cuối: Sơn's nod finished, eyes still following her.

**Clip 4 · L · STREET · W**
- Đầu: Transport already beyond Hạ, both women on the walkway.
- Hành động: Hạ lowers the flower and turns toward her chosen stall site.
- Thoại: —
- Cuối: Both women walking back toward the market, vehicle continuing away.

**Clip 5 · CUT · TRANSPORT · M**
- Đầu: Sơn facing forward again as the town thins outside.
- Hành động: Thành opens the destination transfer file, the journey continues without another farewell.
- Thoại: Sơn, lời dẫn ngoài hình: Tôi rời đi bằng tên mình.
- Cuối: Sơn seated quietly, file open in Thành's lap.

**Clip 6 · CUT · CROSSROAD · W**
- Đầu: Transport approaching the crossroad where the coach once stopped.
- Hành động: It takes the inland road and leaves the sea visible after it exits frame.
- Thoại: —
- Cuối: Empty crossroad, transport sound receding inland.

Âm nối sang cảnh sau: Let the inland vehicle engine recede into cabin wind after the transport has left the picture.

### CẢNH 59: Căn Nhà Còn Mở Cửa
*Thời gian truyện: D8 afternoon*
Thị trấn giữ ký ức nhưng tiếp tục sống, Hạ bắt tay làm sạp.

**Clip 1 · L · CABIN · W**
- Đầu: Cabin door open, Bảy carrying a repair box, Mây with the final rental inventory.
- Hành động: They check the now-empty room together rather than preserving it as a shrine.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Mai tui sửa lại cửa. Còn cho thuê.
- Cuối: Empty bed, cleared table, repair box by the threshold.

**Clip 2 · CUT · CABIN · I**
- Đầu: Seven marks on the damaged doorframe, no eighth mark.
- Hành động: Mây photographs the marks once for the file, then puts the camera away.
- Thoại: —
- Cuối: Seven marks still in wood, Mây's phone lowered.

**Clip 3 · J · PORCH · W**
- Đầu: Hạ arriving with a folded market table, Bảy already outside.
- Hành động: She asks to use the porch to prepare flower buckets while the stall site is finished.
- Thoại: Hạ (@Ha), nói trong hình: Cho con mượn chỗ làm cái sạp nhé.
- Cuối: Folded table on porch, Bảy clearing space for it.

**Clip 4 · CUT · PORCH · M**
- Đầu: Folded table on the porch, Bảy at one end, Hạ holding an empty bucket.
- Hành động: Bảy unfolds the table, Hạ checks its balance with an empty flower bucket.
- Thoại: Ông Bảy (@Ông Bảy), nói trong hình: Nhà này gió. Làm chân bàn chắc vào.
- Cuối: Stable table, one empty bucket upright on it.

**Clip 5 · CUT · PORCH · M**
- Đầu: Mây holding the old damaged doorframe strip removed during repair.
- Hành động: Hạ asks to keep the small marked strip for the underside of her future counter.
- Thoại: Hạ (@Ha), nói trong hình: Để dưới quầy. Nhắc mình đã đi qua.
- Cuối: Marked wood strip in Hạ's hands, new doorframe behind them.

**Clip 6 · L · PORCH · W**
- Đầu: Three people working around the unfinished flower table.
- Hành động: They sand and fit its legs in natural afternoon light, no one adding another tally.
- Thoại: —
- Cuối: Table standing straight, sawdust brushing away from its surface.

Âm nối sang cảnh sau: Match the newly sanded table surface to the finished flower counter years later, with a clear morning/time change and older faces.

### CẢNH 60: Buổi Sáng Có Người Về
*Thời gian truyện: LATER many years after the case*
Kết bằng đời sống Hạ đã xây và một người trở lại.

**Clip 1 · MATCH · FLOWER_STALL · W**
- Đầu: Finished flower counter years later, older Hạ arranging fresh lilies.
- Hành động: She opens the shutters of a working shop, old marked wood discreetly fixed underneath.
- Thoại: —
- Cuối: Shop open, Hạ behind the counter, morning customers blurred beyond.

**Clip 2 · CUT · FLOWER_STALL · M**
- Đầu: Older Mây stopping outside the shop with her helmet in hand.
- Hành động: She buys one ordinary bunch and exchanges a familiar look with Hạ.
- Thoại: Mây (@May), nói trong hình: Chiều ghé ăn cơm nhé.
- Cuối: Flowers in Mây's hand, Hạ handing back change.

**Clip 3 · J · STALL · W**
- Đầu: Older Bảy behind the same coffee counter, coach engine heard off screen.
- Hành động: He looks toward the crossroad, leaves a clean glass ready on the sea-facing table.
- Thoại: —
- Cuối: One empty chair at the sea-facing table, coach sound closer.

**Clip 4 · CUT · CROSSROAD · M**
- Đầu: Coach door open, only an older man's jacket, bag and hands framed below shoulders.
- Hành động: The man steps down once, same repaired watch chain visible inside the jacket, coach departs.
- Thoại: —
- Cuối: Man standing with bag in left hand, right hand bare at his side.

**Clip 5 · L · FLOWER_STALL · C**
- Đầu: Hạ hearing the coach fade outside, one lily still in her hand.
- Hành động: She looks toward approaching footsteps, recognition arriving gradually without a run.
- Thoại: —
- Cuối: Hạ setting the single lily on the counter, eyes at the doorway.

**Clip 6 · CUT · FLOWER_STALL · M**
- Đầu: From inside the shop, Hạ behind the counter, a bare hand entering the doorway edge.
- Hành động: The arriving hand rests on the counter without a new watch, Hạ makes room for him.
- Thoại: Hạ (@Ha), nói trong hình: Hôm nay ngồi nhìn biển với em nhé.
- Cuối: Hạ facing the unseen visitor, one lily between them, daylight beyond the door.

Âm nối sang cảnh sau: End on Hạ recognition with continuing sea wind. Any title and final fade are added only in the edit.
