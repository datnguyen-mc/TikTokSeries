# Kẻ Sống Sót: Bóng Ma — Cảnh 01: Ngày Thứ Nhất

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 00:00–01:00 · Thời gian truyện: D1 dawn

Sơn tới Hòn Sóng và tự đặt hạn chờ.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | OPEN · Cắt thiết lập thời gian/không gian | Coach door open, Sơn still inside. | Sơn steps down once with his canvas bag, the coach pulls away. | Sơn alone at the crossroad, bag in left hand. | Sơn, lời dẫn ngoài hình: Tôi tới nơi cô ấy từng muốn về. |
| [2](clip-2.md) | J · J-cut: âm mới đến trước hình | Sơn approaching the coffee stall from screen left. | He catches a crate rolling toward the road and returns it to Bảy. | Bảy holds the recovered crate, Sơn beside the stall. | Ông Bảy (@Ông Bảy), nói trong hình: Cảm ơn chú. Cần tìm ai? |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bảy behind his counter, Sơn facing him. | Sơn asks for a quiet room, Bảy turns toward the dune. | Bảy pointing uphill, Sơn following his eyeline. | Sơn (@Son), nói trong hình: Chú có chỗ nào yên không? |
| [4](clip-4.md) | L · L-cut: âm cũ đi qua cú cắt | Both men already halfway up the dune path. | They reach the cabin porch, Bảy passes Sơn the key. | Key resting in Sơn's open right palm. | Ông Bảy (@Ông Bảy), nói trong hình: Nhà trống. Gió thì không. |
| [5](clip-5.md) | MATCH · Match cut hình dạng/tư thế, không morph | Key set beside a small carving tool. | Sơn cuts the first short mark into the bare doorframe. | One fresh mark, tool lowered out of frame. | Sơn, lời dẫn ngoài hình: Bảy ngày. Để tìm ra sự thật. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn seated on the porch with his closed watch. | He turns the engraved lid toward the light without opening it. | Closed watch in his hand, sea beyond his shoulder. | — |

**Âm nối sang cảnh sau:** Let the porch sea wind fall under rain on the silk-shop awning. Cut to the existing silk curtain, not to another coach arrival.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
