# Kẻ Sống Sót: Bóng Ma — Cảnh 02: Quá Khứ: Hợp Đồng Cuối

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 01:00–02:00 · Thời gian truyện: PAST one month earlier night

Bà Hai giao việc cuối và Dũng lộ sự ghen tức.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | L · L-cut: âm cũ đi qua cú cắt | Silk curtain at left, three figures around a teak desk. | Sơn stops before Bà Hai, Dũng quietly closes the rear door. | Sơn standing opposite Bà Hai, Dũng by the shut door. | Bà Hai (@HaiNgoc), nói trong hình: Ngồi đi con. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bà Hai's left hand beside a face-down photograph. | She slides Kiên's portrait toward Sơn, jade bracelet visible. | Kiên's portrait beside Sơn's black glove. | Bà Hai, ngoài khung hình: Kiên giữ sổ gốc. Má cần lấy lại. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn facing Bà Hai across the desk. | He leaves the photograph untouched and sets a return ticket down. | Ticket between the two, Sơn's hands still. | Sơn (@Son), nói trong hình: Xong việc này, con nghỉ. |
| [4](clip-4.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Ticket between the two, Sơn's hands still. | Bà Hai covers the ticket with a folded strip of silk. | Her hand rests on the silk covering Sơn's ticket. | Bà Hai (@HaiNgoc), nói trong hình: Con đi thì ai giữ nhà cho má? |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng holding the rear door for Sơn. | Dũng looks at the untouched chair, then blocks the doorway briefly. | Sơn and Dũng separated by the door edge. | Dũng (@Dũng), nói trong hình: Má để ghế cho mày hoài. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Sơn already outside, silk door closing behind him. | He turns Kiên's photo over and studies a building entrance sketch. | Photo back beside the real tower across the street. | — |

**Âm nối sang cảnh sau:** Match the rectangle of the building sketch to the stall mirror edge. Replace city rain with present-day coastal morning sound.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
