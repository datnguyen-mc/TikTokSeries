[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Son = Sơn: same approved identity, age 45; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. recent past, cropped greying hair, black suit, open-collar white shirt, black leather gloves, black shoes. Voice: low, dry, unhurried Southern Vietnamese male voice.
@HaiNgoc = Bà Hai: same approved identity, age 60; Vietnamese woman, small upright build, composed face, jade bracelet on LEFT wrist. silver hair in a tight bun, violet silk áo bà ba, black trousers, embroidered slippers, unlit black holder. Voice: soft, slow Southern Vietnamese female voice with precise diction.
@Dũng = Dũng: same approved identity, age 35; Vietnamese man, heavy shoulders, buzz cut, nail-shaped silver earring in LEFT ear. black sleeveless shirt, black jeans, boots, shoulder bag for work gear. Voice: rough Southern Vietnamese male voice.


[PICTURE-ONLY REFERENCES]
@Vũ Kiên: approved face for the PRINTED PHOTOGRAPH ONLY. Do not add this person physically to the room or street.


[TIMELINE AND LOCATION]
Scene 02/60, clip 2/6; shot 02.2. Story time: PAST one month earlier night.
City silk shop, teak desk to east, screened safe behind it, rear stock door west, warm practical lamps.
Night interior, warm desk lamp and shop practicals, wet alley beyond.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 02.1, ending with Sơn standing opposite Bà Hai, Dũng by the shut door.
Intentional editorial cut, not a continuous take. Start only in the new composition; preserve compatible screen direction and eyelines. No morph or duplicated gesture.

[START FRAME — state only, not an action to repeat]
Bà Hai's left hand beside a face-down photograph.

[CAMERA]
85mm locked detail shot. Hands and the relevant object remain spatially readable; no impossible macro reflections.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
She slides Kiên's portrait toward Sơn, jade bracelet visible.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–4.1s, one unhurried line only. Speech from the specified off-screen person. Do not add their face or animate the listener speaking.

Bà Hai, ngoài khung hình: Kiên giữ sổ gốc. Má cần lấy lại.
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
- Photograph of Kiên in white suit with a hand-drawn building sketch on its back; no legible words.

[SOUND]
Location bed: silk shifting and muted rain outside. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. 

[END FRAME — natural motion continues]
Kiên's portrait beside Sơn's black glove.
Next shot 02.3: Cắt dựng đúng vị trí/ánh nhìn. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
