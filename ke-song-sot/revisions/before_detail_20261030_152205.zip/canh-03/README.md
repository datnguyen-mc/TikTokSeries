# Kẻ Sống Sót: Bóng Ma — Cảnh 03: Khách Không Nhìn Biển

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 02:00–03:00 · Thời gian truyện: D1 morning

Mây chú ý cách Sơn chọn chỗ và quan sát đường.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | MATCH · Match cut hình dạng/tư thế, không morph | Rectangular stall mirror under the green tarp, Sơn at the sea-facing table edge. | He sits with his back to the sea and watches the road reflection. | Sơn facing the street, Bảy placing coffee on his right. | Ông Bảy (@Ông Bảy), nói trong hình: Biển phía sau chú kìa. |
| [2](clip-2.md) | J · J-cut: âm mới đến trước hình | Thành riding slowly, Mây behind him wearing a helmet. | Mây notices a deliberate glance from the coffee stall off screen and signals Thành to stop. | Motorcycle stopped beyond the stall, both helmets still on. | Mây (@May), nói trong hình: Dừng chỗ này. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây seated facing Sơn, notebook still closed. | She asks his name while he moves his bag away from the walkway. | Bag under Sơn's chair, Mây looking at his bare hands. | Mây (@May), nói trong hình: Anh tên gì? |
| [4](clip-4.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Bag under Sơn's chair, Mây looking at his bare hands. | Sơn answers and finally meets her eyes. | Mây opens her notebook, Sơn's cup remains untouched. | Sơn (@Son), nói trong hình: Sơn. Tôi thuê nhà trên đồi. |
| [5](clip-5.md) | L · L-cut: âm cũ đi qua cú cắt | Mây beside the parked motorcycle, Thành ready to leave. | She gives Thành the name and asks him to check the rental report. | Thành noting the name, Mây glancing toward the hill. | Mây (@May), nói trong hình: Kiểm tra giúp chị. Kín thôi. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn's right hand beside the coffee cup. | He stops touching the closed watch and turns the cup handle outward. | Cup handle facing the road, watch still closed at his belt. | — |

**Âm nối sang cảnh sau:** Introduce the flower-shop bell over the final coffee-cup detail, then cut into the first visit. No repeated cup movement.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
