[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Son = Sơn: same approved identity, age 45; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. cropped hair greying at the temples, faded olive field jacket over grey shirt, dark trousers, worn brown boots, bare hands. Voice: low, dry, unhurried Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 03/60, clip 6/6; shot 03.6. Story time: D1 morning.
Bảy coffee stall, green canvas awning, counter landward, plastic tables seaward, street visible in the counter mirror.
Morning coastal daylight, cool shadows under the green awning, natural skin tones.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 03.5, ending with Thành noting the name, Mây glancing toward the hill.
Intentional editorial cut, not a continuous take. Start only in the new composition; preserve compatible screen direction and eyelines. No morph or duplicated gesture.

[START FRAME — state only, not an action to repeat]
Sơn's right hand beside the coffee cup.

[CAMERA]
85mm locked detail shot. Hands and the relevant object remain spatially readable; no impossible macro reflections.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
He stops touching the closed watch and turns the cup handle outward.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
No speech, narration, improvised dialogue or vocal filler. Keep the scene alive through the specified action and location sound.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
- ONE silver pocket watch with engraved flower lid, same chain, lid CLOSED in this shot. No second matching watch. After the escape it has stopped; do not add ticking or show the inner photo.

[SOUND]
Location bed: glasses touching and awning cloth in sea wind. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. Introduce the flower-shop bell over the final coffee-cup detail, then cut into the first visit. No repeated cup movement.

[END FRAME — natural motion continues]
Cup handle facing the road, watch still closed at his belt.
Next shot 04.1: J-cut: âm mới đến trước hình. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
