# Kẻ Sống Sót: Bóng Ma — Cảnh 04: Quá Khứ: Ba Lần Ghé Tiệm

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 03:00–04:00 · Thời gian truyện: PAST one month earlier afternoon

Tình cảm nảy từ hành vi cụ thể qua ba lần gặp.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Hạ cutting lilies as the entrance bell rings. | Sơn enters, sees Kiên's lobby across the road, chooses the window chair. | Sơn at the window, Hạ behind the flower counter. | Hạ (@Ha), nói trong hình: Anh mua hoa cho ai? |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | A single lily between Hạ and Sơn. | A delivery boy bumps a bucket outside, Sơn steadies Hạ's falling vase. | Vase safe between their hands, Sơn releases it first. | Sơn (@Son), nói trong hình: Cho người không biết nhận hoa. |
| [3](clip-3.md) | MATCH · Match cut hình dạng/tư thế, không morph | Same window chair on the following afternoon, fresh flowers changed. | Hạ places a second lily on the counter before Sơn can ask. | Two lilies in separate paper sleeves, Hạ suppressing a smile. | Hạ (@Ha), nói trong hình: Hôm nay vẫn người đó hả? |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ facing the window, Sơn beside the second lily. | She follows his eyeline to Kiên's lobby and then looks back at him. | Hạ waiting for an answer, Sơn no longer watching the lobby. | — |
| [5](clip-5.md) | MATCH · Match cut hình dạng/tư thế, không morph | Third afternoon, Sơn holding a repaired bucket handle. | He returns the bucket he repaired without being asked. | Hạ holding the repaired bucket, Sơn with empty hands. | Hạ (@Ha), nói trong hình: Anh nhớ cái xô hơn nhớ tiền. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn standing by the open shop door. | He starts to leave, then turns back to hear Hạ finish laughing. | Sơn staying in the doorway, Hạ smiling behind the counter. | — |

**Âm nối sang cảnh sau:** Carry the shop-door bell resonance briefly into the quiet cabin, cut to the already-open bag and new evidence action.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
