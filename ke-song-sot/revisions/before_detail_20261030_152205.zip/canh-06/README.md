# Kẻ Sống Sót: Bóng Ma — Cảnh 06: Quá Khứ: Lời Mời Về Biển

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 05:00–06:00 · Thời gian truyện: PAST one month earlier night

Hạ đặt giới hạn rồi tặng đồng hồ như một lời hẹn.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | L · L-cut: âm cũ đi qua cú cắt | Hạ putting the day's cash away, Sơn near the rear door. | His jacket shifts, showing the closed holster, Hạ stops moving. | Hạ's hand resting on the cash drawer, distance between them. | Hạ (@Ha), nói trong hình: Anh làm việc gì vậy? |
| [2](clip-2.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Hạ's hand resting on the cash drawer, distance between them. | Sơn cannot answer, Hạ closes the drawer and steps back. | Sơn remaining by the door, Hạ beyond the table. | Hạ (@Ha), nói trong hình: Em không muốn sống trong lời giấu. |
| [3](clip-3.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Sơn remaining by the door, Hạ beyond the table. | Sơn removes his right glove and lays it on the table. | Bare right hand beside one black glove, Hạ watching. | Sơn (@Son), nói trong hình: Anh muốn dừng. Chưa biết cách. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ holding a closed silver pocket watch by its chain. | She winds it with the lid still shut, the ticking becomes audible. | Closed watch resting on Hạ's open palm. | Hạ, ngoài khung hình: Của ba em. Nó còn chạy. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ extending the watch toward Sơn's bare right hand. | She sets it in his palm, lets him decide to close his fingers. | Sơn holding the closed watch, Hạ's hand withdrawn. | Hạ (@Ha), nói trong hình: Hết việc, mở ra. Rồi về biển. |
| [6](clip-6.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Sơn holding the closed watch, Hạ's hand withdrawn. | Sơn pockets the watch, leaves the glove on the table for a moment. | His bare hand returns for the glove, Hạ turns off the kettle. | Sơn (@Son), nói trong hình: Anh sẽ về nói thật với em. |

**Âm nối sang cảnh sau:** Let the kettle hiss finish. Cut to the next morning doorframe and its second tally, daylight replacing the warm room.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
