Continue the scene from the final frame of clip 5. Same composition at the seam, new action after the seam.
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Son = Sơn: same approved identity, age 45; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. recent past, cropped greying hair, black suit, open-collar white shirt, black leather gloves, black shoes. Voice: low, dry, unhurried Southern Vietnamese male voice.
@Ha = Hạ: same approved identity, age 32; Vietnamese woman, slim build, gentle alert eyes, long black hair. cream linen dress, green florist apron, pale-blue scarf at neck, flat sandals. Voice: warm, clear Southern Vietnamese female voice.
Sơn right hand bare, left hand still gloved. He retrieves the loose right glove before leaving.


[TIMELINE AND LOCATION]
Scene 06/60, clip 6/6; shot 06.6. Story time: PAST one month earlier night.
Back room of Hạ flower shop, kettle and small wooden table, rear doorway toward main counter.
Recent-past night, warm back-room bulbs and soft street spill, kettle steam.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 06.5, ending with Sơn holding the closed watch, Hạ's hand withdrawn.
Use that last frame as this start frame. Preserve lens, axis, positions, light and props. Advance the action immediately; do not replay the preceding gesture or words. No freeze at the seam.

[START FRAME — state only, not an action to repeat]
Sơn holding the closed watch, Hạ's hand withdrawn.

[CAMERA]
50mm locked medium shot at eye level. Let the gesture and reaction develop in the same composition.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
Sơn pockets the watch, leaves the glove on the table for a moment.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–3.8s, one unhurried line only. Visible speaker alone delivers the line, mouth readable in this composition. Other people listen silently.

Sơn (@Son), nói trong hình: Anh sẽ về nói thật với em.
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
- ONE silver pocket watch with engraved flower lid, same chain, lid CLOSED in this shot. No second matching watch. Before the escape it is intact and ticking softly. Do not open it.

[SOUND]
Location bed: kettle and muffled street traffic. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. Let the kettle hiss finish. Cut to the next morning doorframe and its second tally, daylight replacing the warm room.

[END FRAME — natural motion continues]
His bare hand returns for the glove, Hạ turns off the kettle.
Next shot 07.1: Cắt thiết lập thời gian/không gian. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
