# Kẻ Sống Sót: Bóng Ma — Cảnh 07: Mây Gõ Cửa

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 06:00–07:00 · Thời gian truyện: D2 morning

Mây tìm thấy giấy giả và chọn theo dõi người truy tìm Sơn.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | OPEN · Cắt thiết lập thời gian/không gian | One mark on the doorframe, tool below it. | Sơn carves the second mark, a motorcycle stops outside. | Two marks, tool put on the shelf. | — |
| [2](clip-2.md) | J · J-cut: âm mới đến trước hình | Mây outside the threshold, Sơn holding the door open. | She waits for permission before asking for his papers. | Sơn passing a card across the threshold. | Mây (@May), nói trong hình: Tôi cần xác nhận người thuê nhà. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây at the doorway with the card, Sơn beside the table. | She studies the card and his face without entering deeper. | Card returned to Sơn, notebook still open. | Mây (@May), nói trong hình: Anh định ở tới khi nào? |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn beside the two fresh marks. | He looks at the marks instead of answering, Mây notices the evasion. | Mây's eyeline fixed on the doorframe. | Sơn (@Son), nói trong hình: Hết tuần này. |
| [5](clip-5.md) | L · L-cut: âm cũ đi qua cú cắt | Thành at the old computer, Mây standing behind him. | A record check returns a mismatched identity, Thành prints the result. | Printer feeding one page, Mây taking it. | Thành, ngoài khung hình: Giấy không khớp hồ sơ, chị. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây laying the result in a new investigation folder. | She assigns one discreet observer and asks for outside vehicle reports. | Folder open with Sơn's rental note, Thành calling for support. | Mây (@May), nói trong hình: Theo người tìm anh ta nữa. |

**Âm nối sang cảnh sau:** Introduce garage ventilation hum before the flashback cut away from the station radio and folder.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
