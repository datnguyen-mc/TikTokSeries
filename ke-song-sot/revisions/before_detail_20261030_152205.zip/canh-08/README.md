# Kẻ Sống Sót: Bóng Ma — Cảnh 08: Quá Khứ: Đêm Bị Gài

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 07:00–08:00 · Thời gian truyện: PAST one month earlier night

Sơn bị gài với bằng chứng giả và đồng hồ hỏng khi thoát.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Sơn behind a pillar, a white car at the far lift. | He checks the lift reflection without drawing his handgun. | Sơn concealed behind the pillar, lift doors opening. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng emerging alone from the lift. | He slides a document envelope toward Sơn with a shoe, blocks the lift. | Envelope on the floor between them, Dũng in front of the lift. | Dũng (@Dũng), nói trong hình: Má đổi chỗ giao. Nhặt đi. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn's gloved hand above the open envelope. | He sees his own staged photograph and a stolen seal inside. | His hand withdrawing from the planted evidence. | Sơn, ngoài khung hình: Mày muốn tao để dấu tay. |
| [4](clip-4.md) | J · J-cut: âm mới đến trước hình | Light beams sweeping toward Sơn's pillar. | He ducks behind a parked car, the closed watch strikes concrete. | Sơn behind the car with the watch chain taut, alarm sounding. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn at a low maintenance door, jacket still on. | He slips through the door and pulls it shut without dropping his clothes. | Sơn outside the closed maintenance door, black gloves still on. | — |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Sơn under the rear awning, closed watch in his hand. | He listens at the shut lid, hears no ticking, then sees the flower-shop lights. | His face turning toward the distant flower shop. | Sơn, lời dẫn ngoài hình: Đêm đó, thứ đầu tiên ngừng là đồng hồ. |

**Âm nối sang cảnh sau:** City rain falls away, the arriving black car establishes present-day afternoon. Do not replay the garage escape.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
