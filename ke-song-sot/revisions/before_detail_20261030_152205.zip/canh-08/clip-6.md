[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Son = Sơn: same approved identity, age 45; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. recent past, cropped greying hair, black suit, open-collar white shirt, black leather gloves, black shoes. Voice: low, dry, unhurried Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 08/60, clip 6/6; shot 08.6. Story time: PAST one month earlier night.
City rear lane, tower visible across the road, flower shop at street level beyond the corner.
Recent-past garage at night, amber fluorescent practicals, moving search beams, no gunfire.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 08.5, ending with Sơn outside the closed maintenance door, black gloves still on.
L-cut in the edit: retain the preceding diegetic sound about 0.25s after the picture cut, then let it fall away. This generated clip contains only the new shot.

[START FRAME — state only, not an action to repeat]
Sơn under the rear awning, closed watch in his hand.

[CAMERA]
50mm very slow straight push-in, no lens change, no orbit. The final expression remains readable.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
He listens at the shut lid, hears no ticking, then sees the flower-shop lights.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–4.4s, one unhurried line only. Narration outside the scene. Visible mouths remain naturally at rest; do not lip-sync the narration.

Sơn, lời dẫn ngoài hình: Đêm đó, thứ đầu tiên ngừng là đồng hồ.
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
- ONE silver pocket watch with engraved flower lid, same chain, lid CLOSED in this shot. No second matching watch. After the escape it has stopped; do not add ticking or show the inner photo.

[SOUND]
Location bed: rain drips and faint traffic. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. City rain falls away, the arriving black car establishes present-day afternoon. Do not replay the garage escape.

[END FRAME — natural motion continues]
His face turning toward the distant flower shop.
Next shot 09.1: Cắt thiết lập thời gian/không gian. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
