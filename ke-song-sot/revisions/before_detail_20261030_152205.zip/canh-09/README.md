# Kẻ Sống Sót: Bóng Ma — Cảnh 09: Hai Người Lạ

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 08:00–09:00 · Thời gian truyện: D2 afternoon

Bảy và Thành tạo mạng quan sát, kẻ truy tìm để lại dấu.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | OPEN · Cắt thiết lập thời gian/không gian | A black car parking outside Bảy's stall. | Two unnamed men step out and display Sơn's surveillance photograph. | Photograph extended toward Bảy, car door left open. | Người trong cảnh, nói trong hình: Chú thấy người này không? |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bảy behind the counter studying the offered photograph. | He gives a vague answer while sliding his phone below the counter. | Phone hidden beneath the counter, Bảy still holding the photo. | Ông Bảy (@Ông Bảy), nói trong hình: Ở đây người giống người nhiều lắm. |
| [3](clip-3.md) | L · L-cut: âm cũ đi qua cú cắt | Sơn behind a fish stall with a clear view of the black car. | He notices one man's dock-worker wristband and stays out of sight. | Wristband visible through a gap, Sơn concealed behind a crate. | — |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Thành beside his parked motorcycle, notebook partly hidden. | He records the plate and the same dock-company emblem. | Plate sketch and company emblem on separate notebook lines. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | The two men returning to their black car. | They leave a contact card, Bảy waits until the car drives off. | Contact card under Bảy's glass, road clear. | — |
| [6](clip-6.md) | J · J-cut: âm mới đến trước hình | Thành placing his notes beside Bảy's contact card. | Mây connects the emblem to the dispatch company and requests a check. | Mây marking the company entry, Thành preparing the request. | Mây (@May), nói trong hình: Họ tìm người. Ta tìm đường đi. |

**Âm nối sang cảnh sau:** Introduce wind through the damaged shop door before cutting from the company inquiry to the torn scarf trace.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
