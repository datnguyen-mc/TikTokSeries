[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Ông Bảy = Ông Bảy: same approved identity, age 70; Vietnamese man, stocky, white moustache, deeply tanned face. white singlet, shorts, rubber sandals, conical hat outside, cloth for cleaning glasses. Voice: resonant, friendly elderly Southern Vietnamese male voice.


[PICTURE-ONLY REFERENCES]
@Son: approved face for the PRINTED PHOTOGRAPH ONLY. Do not add this person physically to the room or street.


[TIMELINE AND LOCATION]
Scene 09/60, clip 1/6; shot 09.1. Story time: D2 afternoon.
Hòn Sóng main street between inland crossroad and market, coffee stall beside the sea wall.
Present-day afternoon sun, bright road outside cool stall and market shade.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 08.6, ending with His face turning toward the distant flower shop.
Editorial cut to the explicitly stated new time/place. Establish the supplied opening composition once; do not replay travel or arrival.

[START FRAME — state only, not an action to repeat]
A black car parking outside Bảy's stall.

[CAMERA]
35mm locked wide shot at human eye level. Preserve readable geography and screen direction.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
Two unnamed men step out and display Sơn's surveillance photograph.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–3.8s, one unhurried line only. Visible speaker alone delivers the line, mouth readable in this composition. Other people listen silently.
The unnamed background person specified by the action: natural Southern Vietnamese voice, no new named lead character.
Người trong cảnh, nói trong hình: Chú thấy người này không?
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
No new featured prop. Preserve already established carried items; introduce no extra symbolic objects.

[SOUND]
Location bed: distant motorcycles and muted market voices. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. 

[END FRAME — natural motion continues]
Photograph extended toward Bảy, car door left open.
Next shot 09.2: Cắt dựng đúng vị trí/ánh nhìn. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
