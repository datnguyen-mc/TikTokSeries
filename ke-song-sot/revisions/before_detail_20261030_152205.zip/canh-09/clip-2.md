[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Ông Bảy = Ông Bảy: same approved identity, age 70; Vietnamese man, stocky, white moustache, deeply tanned face. white singlet, shorts, rubber sandals, conical hat outside, cloth for cleaning glasses. Voice: resonant, friendly elderly Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 09/60, clip 2/6; shot 09.2. Story time: D2 afternoon.
Bảy coffee stall, green canvas awning, counter landward, plastic tables seaward, street visible in the counter mirror.
Present-day afternoon sun, bright road outside cool stall and market shade.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 09.1, ending with Photograph extended toward Bảy, car door left open.
Intentional editorial cut, not a continuous take. Start only in the new composition; preserve compatible screen direction and eyelines. No morph or duplicated gesture.

[START FRAME — state only, not an action to repeat]
Bảy behind the counter studying the offered photograph.

[CAMERA]
50mm locked medium shot at eye level. Let the gesture and reaction develop in the same composition.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
He gives a vague answer while sliding his phone below the counter.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–3.8s, one unhurried line only. Visible speaker alone delivers the line, mouth readable in this composition. Other people listen silently.

Ông Bảy (@Ông Bảy), nói trong hình: Ở đây người giống người nhiều lắm.
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
No new featured prop. Preserve already established carried items; introduce no extra symbolic objects.

[SOUND]
Location bed: glasses touching and awning cloth in sea wind. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. 

[END FRAME — natural motion continues]
Phone hidden beneath the counter, Bảy still holding the photo.
Next shot 09.3: L-cut: âm cũ đi qua cú cắt. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
