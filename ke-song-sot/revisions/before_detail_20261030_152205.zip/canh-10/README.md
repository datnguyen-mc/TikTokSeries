# Kẻ Sống Sót: Bóng Ma — Cảnh 10: Quá Khứ: Dấu Vết Còn Lại

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 09:00–10:00 · Thời gian truyện: PAST one month earlier dawn

Sơn nhặt một mảnh khăn và lấy sổ từ kho mình biết.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Broken shop glass, a pale-blue strip caught on the latch. | Sơn enters carefully and stops at the torn strip. | Sơn facing the latch, torn strip still attached. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn's right glove beside the broken latch. | He removes the glove once and frees only the small torn strip. | Bare right hand holding the short scarf fragment. | Sơn, ngoài khung hình: Hạ để lại cái này. |
| [3](clip-3.md) | J · J-cut: âm mới đến trước hình | Sơn near the broken doorway, a neighbor outside the frame. | He listens to the neighbor describe a black car and three men. | Sơn looking toward the tire tracks outside. | Người trong cảnh, ngoài khung hình: Cổ bị đưa đi. Còn quay lại nhìn cửa. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn's phone vibrating against his jacket. | He answers, hears Bà Hai claim Hạ has left him, ends the call. | Phone lowered, Sơn's bare right hand steady again. | Bà Hai, qua thiết bị: Về tiệm, má còn giữ chỗ cho con. |
| [5](clip-5.md) | L · L-cut: âm cũ đi qua cú cắt | Rear stockroom door of the silk shop already ajar before opening hours. | Sơn uses his old key and reaches the shelf he once guarded. | Sơn beside the stock shelf, black ledger and tin visible. | — |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Ledger and sealed tin on the stockroom shelf. | Sơn takes the ledger, attached receipt and sealed tin into his bag. | Shelf empty at those slots, bag clasp closed. | Sơn, lời dẫn ngoài hình: Tôi lấy sổ của họ. Không lấy lại được cô ấy. |

**Âm nối sang cảnh sau:** Match the closed bag clasp to the sealed tin latch in the lamplit cabin. No second theft or opening of the tin.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
