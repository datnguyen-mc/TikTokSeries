[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Son = Sơn: same approved identity, age 45; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. recent past, cropped greying hair, black suit, open-collar white shirt, black leather gloves, black shoes. Voice: low, dry, unhurried Southern Vietnamese male voice.
Sơn right glove removed at 10.2 and kept in jacket pocket, left glove still on; jacket never discarded.


[TIMELINE AND LOCATION]
Scene 10/60, clip 6/6; shot 10.6. Story time: PAST one month earlier dawn.
Rear stockroom of the silk shop, known shelf beside loading door, ledger and sealed tin stored together.
Recent-past dawn after rain, pale shop window light, dim stockroom practical.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 10.5, ending with Sơn beside the stock shelf, black ledger and tin visible.
Intentional editorial cut, not a continuous take. Start only in the new composition; preserve compatible screen direction and eyelines. No morph or duplicated gesture.

[START FRAME — state only, not an action to repeat]
Ledger and sealed tin on the stockroom shelf.

[CAMERA]
50mm locked medium shot at eye level. Let the gesture and reaction develop in the same composition.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
Sơn takes the ledger, attached receipt and sealed tin into his bag.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–5.0s, one unhurried line only. Narration outside the scene. Visible mouths remain naturally at rest; do not lip-sync the narration.

Sơn, lời dẫn ngoài hình: Tôi lấy sổ của họ. Không lấy lại được cô ấy.
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
- Original BLACK leather ledger, receipt and original USB initially fixed inside back cover.
- Original USB from black ledger, preserved in an evidence sleeve at the station after 17.1.
- Dented fitted tin containing three sealed fictional Tê vials, no opening or use instructions.
- Dispatch receipt with seven dated boxes and a ship stamp, no readable generated text.

[SOUND]
Location bed: wooden latch and distant morning traffic. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. Match the closed bag clasp to the sealed tin latch in the lamplit cabin. No second theft or opening of the tin.

[END FRAME — natural motion continues]
Shelf empty at those slots, bag clasp closed.
Next shot 11.1: Match cut hình dạng/tư thế, không morph. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
