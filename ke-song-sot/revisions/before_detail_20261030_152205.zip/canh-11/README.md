# Kẻ Sống Sót: Bóng Ma — Cảnh 11: Bảy Ngày Không Chạy

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 10:00–11:00 · Thời gian truyện: D2 night

Mây nhìn thấy nguy cơ, Sơn chấp nhận để lại một đường liên lạc.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | MATCH · Match cut hình dạng/tư thế, không morph | Closed tin beside the dispatch receipt under lamplight. | Sơn puts a pencil mark at the last shipping date, leaving the tin sealed. | Receipt weighted flat by the sealed tin. | Sơn, lời dẫn ngoài hình: Chuyến hàng đi rồi, dấu vết cũng đi. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn seated with a loose photograph of Hạ from his wallet. | He places the photograph face down when a distant motorcycle stops. | Loose photograph face down, Sơn looking toward the window. | — |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây behind a pine trunk overlooking the lit cabin. | She observes the concealed case above the beam and makes one note. | Binoculars lowered, Mây recording the observation. | — |
| [4](clip-4.md) | J · J-cut: âm mới đến trước hình | Thành joining Mây below the ridge. | He hands her confirmation that the black car belongs to the dock company. | Company report in Mây's hand, cabin light behind them. | Thành (@Phó Thành), nói trong hình: Xe cùng công ty trên tờ giao hàng. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn at the cabin window with the watch lid still closed. | He senses the observer, switches on the porch light and steps back. | Porch lit, Sơn visible inside but no longer at the window. | Sơn, ngoài khung hình: Tôi ở đây. Không đi đâu. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Mây and Thành below the newly lit porch. | Mây folds her notebook and orders the suspect approached in daylight. | Both moving down the dune path away from the cabin. | Mây (@May), nói trong hình: Sáng mai hỏi thẳng. Đừng để dân tới gần. |

**Âm nối sang cảnh sau:** Carry pine wind across the night-to-morning cut, with a clear daylight change. The third mark is a new action.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
