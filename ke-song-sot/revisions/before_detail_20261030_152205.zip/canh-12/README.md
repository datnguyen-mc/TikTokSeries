# Kẻ Sống Sót: Bóng Ma — Cảnh 12: Rừng Dương

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 11:00–12:00 · Thời gian truyện: D3 morning

Sơn chống phục kích, cứu người sau khi thuốc gây bất động.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | OPEN · Cắt thiết lập thời gian/không gian | Two marks on the frame, sunlight just reaching the wood. | Sơn makes the third mark, hears footsteps and leaves by the rear door. | Three marks, rear door moving closed behind him. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Empty cabin interior, front door pushed inward by two unnamed men. | They search the empty bed and see fresh footprints leading out back. | Both intruders turning toward the rear door, cabin otherwise empty. | Người trong cảnh, nói trong hình: Nó vừa ra sau. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | One pursuer stepping around a pine, Sơn behind the trunk. | Sơn takes his balance and pins his weapon hand without striking his head. | Pursuer seated against the trunk, Sơn holding the wrist away. | Sơn (@Son), nói trong hình: Bỏ xuống. |
| [4](clip-4.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Pursuer seated against the trunk, Sơn holding the wrist away. | The second pursuer lunges with a fictional Tê applicator, Sơn deflects the arm. | Second man stumbling into sand, applicator out of his grasp. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Second man motionless but visibly breathing, first man still conscious. | Sơn checks the fallen man's breathing and calls toward the road for help. | Sơn kneeling beside the breathing man, phone at his ear. | Sơn (@Son), nói trong hình: Có người cần bác sĩ. Đồi dương. |
| [6](clip-6.md) | J · J-cut: âm mới đến trước hình | Mây and Thành arriving with a stretcher at the tree line. | Sơn steps away with empty hands, Mây takes control of the two men. | Mây by the stretcher, Sơn standing where she can see him. | Mây (@May), nói trong hình: Anh ở lại. Tôi cần nghe hết. |

**Âm nối sang cảnh sau:** Carry the fallen man breathing under the cut to the clinic. No replay of the fall or stretcher arrival.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
