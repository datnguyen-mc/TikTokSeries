Continue the scene from the final frame of clip 3. Same composition at the seam, new action after the seam.
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Son = Sơn: same approved identity, age 45; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. cropped hair greying at the temples, faded olive field jacket over grey shirt, dark trousers, worn brown boots, bare hands. Voice: low, dry, unhurried Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 12/60, clip 4/6; shot 12.4. Story time: D3 morning.
White-sand dune under casuarina pines, cabin uphill, main path down toward market.
Present-day morning, raking daylight between pines, natural sandy reflections.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 12.3, ending with Pursuer seated against the trunk, Sơn holding the wrist away.
Use that last frame as this start frame. Preserve lens, axis, positions, light and props. Advance the action immediately; do not replay the preceding gesture or words. No freeze at the seam.

[START FRAME — state only, not an action to repeat]
Pursuer seated against the trunk, Sơn holding the wrist away.

[CAMERA]
35mm restrained handheld medium-wide. Keep the entire defensive action readable from one side of the axis, no speed ramp.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
The second pursuer lunges with a fictional Tê applicator, Sơn deflects the arm.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
No speech, narration, improvised dialogue or vocal filler. Keep the scene alive through the specified action and location sound.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
- Fictional Tê device or sealed vial associated with the attackers. No real substance, dose or application technique.

[SOUND]
Location bed: wind moving pine needles and distant surf. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. 

[END FRAME — natural motion continues]
Second man stumbling into sand, applicator out of his grasp.
Next shot 12.5: Cắt dựng đúng vị trí/ánh nhìn. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
