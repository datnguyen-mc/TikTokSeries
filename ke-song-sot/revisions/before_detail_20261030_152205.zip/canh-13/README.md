# Kẻ Sống Sót: Bóng Ma — Cảnh 13: Phòng Khám

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 12:00–13:00 · Thời gian truyện: D3 noon

Bác sĩ xác định dấu hiệu Tê, Mây có vật chứng thay vì đoán bằng mặt.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | L · L-cut: âm cũ đi qua cú cắt | Two attackers on separate beds, one sitting up under supervision. | Linh checks the immobile man's breathing while Mây records the time. | Linh at bedside, Thành watching the conscious attacker. | Bác sĩ Linh (@Bác sĩ Linh), nói trong hình: Còn thở. Chưa được rời mắt. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Seized applicator sealed on a tray, Linh beside it. | He compares its unusual cap to a reference case photograph he kept. | Two matching cap shapes, both separate from the patient. | Bác sĩ Linh, ngoài khung hình: Tôi từng gặp loại Tê này. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây facing Linh beside the closed treatment curtain. | He explains that recovery varies and requires monitoring, not an exact timer. | Mây crossing out her tentative time estimate. | Bác sĩ Linh (@Bác sĩ Linh), nói trong hình: Đừng tin ai hẹn đúng phút tỉnh. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Thành beside the conscious attacker, Mây holding the evidence bag. | The attacker recognizes the shipping emblem and stops answering. | Attacker looking away from the bag, Thành noting the reaction. | Mây (@May), nói trong hình: Ai đưa các anh tới đây? |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | The conscious attacker off screen, Mây listening without interrupting. | He lets slip Sơn's nickname, Mây closes the evidence folder. | Mây's closed folder resting against her chest. | Người trong cảnh, ngoài khung hình: Bóng Ma giữ sổ. Dũng cần sổ. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Mây returning to the station, Thành at the support radio. | She requests a district team to protect the town and heads up the hill. | Thành confirming the support request, Mây leaving with the folder. | Mây (@May), nói trong hình: Giữ người và vật chứng. Tôi gặp Sơn. |

**Âm nối sang cảnh sau:** Station radio fades into porch wind. Cut to Mây joining the waiting Sơn and placing her cuffs once.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
