# Kẻ Sống Sót: Bóng Ma — Cảnh 14: Còng Và Bằng Chứng

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 13:00–14:00 · Thời gian truyện: D3 afternoon

Sơn đưa bằng chứng kiểm chứng được, Mây nhận ra Hạ qua ảnh rời.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Two tea glasses on the porch table, Sơn already seated. | Mây sits opposite and places her cuffs beside her notebook. | Cuffs between the glasses, neither person touching them. | Mây (@May), nói trong hình: Anh là người họ gọi Bóng Ma? |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn's closed bag on the table, Mây's evidence folder beside it. | He removes the black ledger and USB, places both within her reach. | Ledger and USB beside Mây's folder, Sơn's hands withdrawn. | Sơn, ngoài khung hình: Đối chiếu công ty đó với sổ này. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây checking an entry against the vehicle report. | She finds the matching dispatch company, takes a photograph of the page. | Mây's phone above the matching entry, Sơn waiting. | Mây (@May), nói trong hình: Chuyện này tôi sẽ báo lên. |
| [4](clip-4.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Mây's phone above the matching entry, Sơn waiting. | Sơn agrees to remain available and names the final shipment. | Mây writing the deadline, Sơn no longer hiding his bag. | Sơn (@Son), nói trong hình: Tôi khai. Nhưng còn người bị giữ. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn sliding Hạ's loose photograph across the table. | Mây recognizes the face and holds the photograph by its white edge. | Hạ's loose portrait in Mây's hand, watch nowhere opened. | Mây, ngoài khung hình: Hạ. Bạn hồi nhỏ của tôi. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây looking up from the photograph at Sơn. | She asks where Hạ is, Sơn has to hold her gaze. | Mây waiting, Sơn unable to lower his eyes. | Mây (@May), nói trong hình: Anh kể từ đầu. |

**Âm nối sang cảnh sau:** A ferry horn enters while Mây waits for an answer. Cut to Hạ alive at the city pier, not to a second photo reveal.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
