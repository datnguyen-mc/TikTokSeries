# Kẻ Sống Sót: Bóng Ma — Cảnh 15: Quá Khứ: Đường Về

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 14:00–15:00 · Thời gian truyện: PAST one month earlier evening

Hạ gieo kiến thức hải đăng và mục tiêu mở sạp hoa.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Hạ walking along the city pier, Sơn beside her. | She stops at a ferry's distant light and names her home town. | Both facing the water, ferry light far beyond. | Hạ (@Ha), nói trong hình: Hòn Sóng. Nhà em ở đó. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ drawing a round tower in condensation on a railing panel. | She sketches a small maintenance hatch below the gallery. | Her fingertip at the hatch sketch, Sơn watching. | Hạ (@Ha), nói trong hình: Ba em giữ đèn. Em thuộc từng cửa. |
| [3](clip-3.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Her fingertip at the hatch sketch, Sơn watching. | Sơn asks about the sea, she points to the town in an old photo. | Old lighthouse photo held between them, maintenance hatch visible. | Hạ (@Ha), nói trong hình: Mất điện vẫn có đèn dự phòng. |
| [4](clip-4.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Old lighthouse photo held between them, maintenance hatch visible. | Hạ puts the photograph away and names the life she wants. | Her empty hands resting on the rail, Sơn beside her. | Hạ (@Ha), nói trong hình: Em muốn mở sạp hoa cạnh chợ cá. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ with her pale-blue scarf loose at her neck. | Wind lifts one end, Sơn catches it before it touches dirty water. | Scarf back in Hạ's hand, his gloved hand released. | — |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | The two standing at the pier rail, a ship horn beginning. | Hạ starts walking back, Sơn chooses to follow her instead of the ferry. | Both leaving left to right, open water behind. | Sơn (@Son), nói trong hình: Bạn em còn giữ chỗ đó không? |

**Âm nối sang cảnh sau:** Retain the city ferry horn briefly over the coastal lighthouse entrance, then change to local wind.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
