# Kẻ Sống Sót: Bóng Ma — Cảnh 16: Hải Đăng Và Một Câu Hỏi

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 15:00–16:00 · Thời gian truyện: D3 late afternoon

Mây tìm chứng cứ sống và kiểm tra lối kỹ thuật trước cao trào.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | L · L-cut: âm cũ đi qua cú cắt | Mây unlocking the lighthouse's lower iron door, Sơn behind her. | She shows him the old service route and starts up the stairs. | Main door open, service hatch visible beside the stair base. | Mây (@May), nói trong hình: Hạ lớn lên ở đây. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Both on the gallery, facing the houses below. | Mây identifies Hạ's family home without romanticizing Sơn's account. | Mây pointing down to the house, Sơn facing her. | Mây (@May), nói trong hình: Tôi chưa thấy nó về gần tháng. |
| [3](clip-3.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Mây pointing down to the house, Sơn facing her. | Sơn admits he has only a threat and a torn piece of cloth. | Mây looking directly at him, Sơn's hands empty on the rail. | Sơn (@Son), nói trong hình: Tôi tưởng họ đã giết cô ấy. |
| [4](clip-4.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Mây looking directly at him, Sơn's hands empty on the rail. | Mây refuses the assumption and asks for verifiable contact details. | Sơn offering the phone, Mây taking it. | Mây (@May), nói trong hình: Chưa có chứng cứ. Ta tìm người sống. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây at the labeled-in-shapes backup-light lever, no readable text. | She tests the relay once and confirms the lamp works, then switches it off. | Backup lamp dark again, lever pointing down. | — |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Both already at the open lower doorway after the descent. | Mây locks the public entrance and keeps the service key accessible. | Key clipped to Mây's belt, Sơn heading toward the station. | Mây (@May), nói trong hình: Đem USB tới đồn. Ngay tối nay. |

**Âm nối sang cảnh sau:** The clipped service key settles, incoming station fan introduces the USB desk. Do not replay the backup-lamp test.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
