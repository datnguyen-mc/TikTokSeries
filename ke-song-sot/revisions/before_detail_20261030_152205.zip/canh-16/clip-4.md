Continue the scene from the final frame of clip 3. Same composition at the seam, new action after the seam.
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@May = Mây: same approved identity, age 38; Vietnamese woman, athletic build, sun-lined face, short black hair with a distinctive white front streak. plain khaki shirt with rolled sleeves, dark trousers, no readable insignia, small notebook, discreet crossbody case pouch. Voice: firm, clear Southern Vietnamese female voice.
@Son = Sơn: same approved identity, age 45; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. cropped hair greying at the temples, faded olive field jacket over grey shirt, dark trousers, worn brown boots, bare hands. Voice: low, dry, unhurried Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 16/60, clip 4/6; shot 16.4. Story time: D3 late afternoon.
Lighthouse gallery: main stair door east, service hatch north, inner masonry wall center, sea rail south, backup lamp aimed seaward.
Present-day late afternoon at sea cliff, fading daylight, lamp only during its deliberate test.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 16.3, ending with Mây looking directly at him, Sơn's hands empty on the rail.
Use that last frame as this start frame. Preserve lens, axis, positions, light and props. Advance the action immediately; do not replay the preceding gesture or words. No freeze at the seam.

[START FRAME — state only, not an action to repeat]
Mây looking directly at him, Sơn's hands empty on the rail.

[CAMERA]
50mm locked medium shot at eye level. Let the gesture and reaction develop in the same composition.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
Mây refuses the assumption and asks for verifiable contact details.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–4.1s, one unhurried line only. Visible speaker alone delivers the line, mouth readable in this composition. Other people listen silently.

Mây (@May), nói trong hình: Chưa có chứng cứ. Ta tìm người sống.
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
No new featured prop. Preserve already established carried items; introduce no extra symbolic objects.

[SOUND]
Location bed: strong sea wind, fabric and restrained footsteps. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. 

[END FRAME — natural motion continues]
Sơn offering the phone, Mây taking it.
Next shot 16.5: Cắt dựng đúng vị trí/ánh nhìn. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
