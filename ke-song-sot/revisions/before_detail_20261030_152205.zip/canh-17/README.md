# Kẻ Sống Sót: Bóng Ma — Cảnh 17: Phần Dữ Liệu Bị Khóa

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 16:00–17:00 · Thời gian truyện: D3 night

Bằng chứng có đường xác minh và hạn chuyển người cụ thể.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Three people around the station computer, USB on the desk. | Thành makes a working copy before opening the accounts. | Original USB in evidence bag, copy connected to the computer. | Thành (@Phó Thành), nói trong hình: Giữ bản gốc. Em mở bản sao. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Account folders open without readable text. | Thành matches the ledger dates to paid shipments at the river factory. | A matching sequence highlighted, ledger open beside the keyboard. | Thành, ngoài khung hình: Cùng xưởng. Cùng ngày chuyển tiền. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây looking from the matched shipments to Sơn. | He identifies Kiên as the payer named in the open accounts. | Mây separating Kiên's file from Bà Hai's file. | Sơn (@Son), nói trong hình: Kiên trả tiền. Bà Hai giữ đường hàng. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | A locked dispatch folder beside an open weekly schedule. | They establish that the final departure is day seven at night. | Mây circling the last departure on her paper copy. | Mây, ngoài khung hình: Ngày bảy. Sau đó người bị đưa đi. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn recognizing a small token icon in the locked folder. | He describes the hardware key kept beside the red original ledger. | Thành drawing the token shape in his notebook. | Sơn (@Son), nói trong hình: Khóa trong két. Cạnh sổ đỏ. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây on the station phone, Thành with the copied evidence. | She briefs district support and assigns town protection before going to the city. | Protection roster on the desk, Thành acknowledging his post. | Mây (@May), nói trong hình: Tôi theo dấu Hạ. Không rút người giữ thị trấn. |

**Âm nối sang cảnh sau:** Close the night station sound cleanly. New morning engines establish Dũng arriving with changed stakes, not a repeated visitor search.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
