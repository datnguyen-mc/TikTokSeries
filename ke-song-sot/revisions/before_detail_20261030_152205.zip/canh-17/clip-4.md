[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Phó Thành = Thành: same approved identity, age 26; Vietnamese man, skinny, round glasses, neat side-parted hair. plain light-blue shirt, dark trousers, round glasses, no readable insignia. Voice: quick, polite Southern Vietnamese male voice.
@May = Mây: same approved identity, age 38; Vietnamese woman, athletic build, sun-lined face, short black hair with a distinctive white front streak. plain khaki shirt with rolled sleeves, dark trousers, no readable insignia, small notebook, discreet crossbody case pouch. Voice: firm, clear Southern Vietnamese female voice.
@Son = Sơn: same approved identity, age 45; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. cropped hair greying at the temples, faded olive field jacket over grey shirt, dark trousers, worn brown boots, bare hands. Voice: low, dry, unhurried Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 17/60, clip 4/6; shot 17.4. Story time: D3 night.
Small fictional town police post, public desk in front, evidence room locked behind it, separate interview room and holding room.
Present-day night station, neutral desk practical and monitor fill, no daylight.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 17.3, ending with Mây separating Kiên's file from Bà Hai's file.
Intentional editorial cut, not a continuous take. Start only in the new composition; preserve compatible screen direction and eyelines. No morph or duplicated gesture.

[START FRAME — state only, not an action to repeat]
A locked dispatch folder beside an open weekly schedule.

[CAMERA]
85mm locked detail shot. Hands and the relevant object remain spatially readable; no impossible macro reflections.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
They establish that the final departure is day seven at night.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–4.1s, one unhurried line only. Speech from the specified off-screen person. Do not add their face or animate the listener speaking.

Mây, ngoài khung hình: Ngày bảy. Sau đó người bị đưa đi.
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
- Dispatch receipt with seven dated boxes and a ship stamp, no readable generated text.

[SOUND]
Location bed: ceiling fan and quiet paperwork. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. 

[END FRAME — natural motion continues]
Mây circling the last departure on her paper copy.
Next shot 17.5: Cắt dựng đúng vị trí/ánh nhìn. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
