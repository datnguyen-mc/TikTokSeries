# Kẻ Sống Sót: Bóng Ma — Cảnh 18: Dũng Tới Biển

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 17:00–18:00 · Thời gian truyện: D4 morning

Dũng đe dọa bằng phần khăn còn lại, để lộ lệnh về thành phố.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | OPEN · Cắt thiết lập thời gian/không gian | Two black cars stopping outside the coffee stall. | Dũng steps out, knocks one empty chair aside, asks after his men. | Chair on its side, Bảy behind the counter. | Dũng (@Dũng), nói trong hình: Hai người tao gửi đâu? |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bảy setting his glass down before answering. | He points toward the clinic, refusing to let Dũng pass behind his counter. | Bảy blocking the counter entrance, Dũng in the public aisle. | Ông Bảy (@Ông Bảy), nói trong hình: Phòng khám. Muốn gặp thì hỏi công an. |
| [3](clip-3.md) | J · J-cut: âm mới đến trước hình | Mây and Thành approaching on foot, a support vehicle farther back. | Mây makes Dũng put the chair back before continuing. | Chair upright, Dũng's men waiting by their cars. | Mây (@May), nói trong hình: Dựng lại. Rồi nói chuyện. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng's hand above the counter holding a long torn blue scarf. | He lays the remaining scarf down without letting Mây approach him. | Long scarf flat on the counter, one end torn. | Dũng, ngoài khung hình: Đưa cho Sơn. Nó biết của ai. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng beside his open car door, phone vibrating. | He hears a recall to the silk shop and ends the call angrily. | Dũng getting into the car, no longer waiting at the stall. | Bà Hai, qua thiết bị: Về tiệm. Đêm nay có khách. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Mây collecting the scarf after the cars leave. | She asks Thành to keep patrols on the clinic and the harbour road. | Thành heading toward the patrol vehicle, scarf in Mây's bag. | Mây (@May), nói trong hình: Hắn đi rồi. Vẫn giữ cửa ngõ. |

**Âm nối sang cảnh sau:** The evidence-bag rustle bridges to two separated scarf pieces on the cabin table. Do not repeat Dũng laying it down.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
