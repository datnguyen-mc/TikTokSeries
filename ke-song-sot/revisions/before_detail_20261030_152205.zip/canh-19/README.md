# Kẻ Sống Sót: Bóng Ma — Cảnh 19: Hai Mảnh Khăn

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 18:00–19:00 · Thời gian truyện: D4 noon

Hai mảnh cùng một chiếc khăn khớp nhau và thúc đẩy chuyến đi.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | MATCH · Match cut hình dạng/tư thế, không morph | Two separate pieces of pale-blue cloth on the table. | Sơn aligns the torn edges without pretending they are repaired. | Matched torn edges separated by a narrow gap. | Sơn, ngoài khung hình: Một chiếc. Hạ xé đầu này. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Three marks on the frame, Sơn beside the shelf. | He makes only the fourth mark and puts the tool away. | Exactly four marks, tool on shelf. | — |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn placing the small piece in an envelope. | Mây takes custody of the long remainder in her evidence bag. | Small fragment with Sơn, long remainder sealed with Mây. | Mây (@May), nói trong hình: Tôi giữ phần này làm chứng. |
| [4](clip-4.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Small fragment with Sơn, long remainder sealed with Mây. | Mây shows the confirmed town-protection roster and lays out her denim jacket for the trip. | Denim jacket ready beside Mây's bag, both still by the table. | Mây (@May), nói trong hình: Thành có người hỗ trợ. Ta đi. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn and Mây facing the path down from the porch. | Sơn warns her about Bà Hai, Mây names her own reason for going. | Both committed to the same path, bags ready. | Mây (@May), nói trong hình: Tôi đi tìm Hạ. Không đi trốn với anh. |
| [6](clip-6.md) | J · J-cut: âm mới đến trước hình | Old phone lying on the porch table beside Sơn's bag. | It vibrates from an unknown caller, Sơn waits for Mây's nod. | Sơn's finger answering, Mây beside him. | — |

**Âm nối sang cảnh sau:** The phone vibration stops when answered. Cut wider for speaker mode, without a second ring or second answering gesture.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
