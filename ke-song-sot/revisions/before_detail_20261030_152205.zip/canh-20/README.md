# Kẻ Sống Sót: Bóng Ma — Cảnh 20: Lời Mời Không Tên

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 19:00–20:00 · Thời gian truyện: D4 afternoon

Người môi giới chứng minh biết Hạ và muốn Sơn phục vụ kế hoạch riêng.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Phone answered in Sơn's hand, Mây beside him at the table. | Sơn puts the caller on speaker, Mây starts a recording on her phone. | Two phones apart on the table, both listening. | Người gọi giấu tên, qua thiết bị: Hạ vẫn giữ cái kẹp tóc màu bạc. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn listening without touching either phone. | The private detail makes him lean forward despite himself. | Sơn's expression changed, Mây noticing the change. | Sơn (@Son), nói trong hình: Anh gặp cô ấy ở đâu? |
| [3](clip-3.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Sơn's expression changed, Mây noticing the change. | The caller refuses a location and names the red ledger in Bà Hai's safe. | Sơn looking toward his bag, recorder still running. | Người gọi giấu tên, qua thiết bị: Lấy sổ đỏ. Tôi cho anh thấy cô ấy. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây holding the recorder steady beside Sơn. | She signals that the caller is steering them toward a conflict. | Sơn's hand hovering over the end-call button. | Mây (@May), nói trong hình: Đừng nhận thêm điều kiện. |
| [5](clip-5.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Sơn's hand hovering over the end-call button. | Sơn demands proof of life before discussing any other job. | His hand ends the call rather than waiting for permission. | Sơn (@Son), nói trong hình: Cho tôi thấy Hạ còn sống trước. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Night coach approaching the town stop, both travelers waiting. | They board separately with their bags, watched by Thành from across the road. | Coach door closing, Thành remaining in town. | — |

**Âm nối sang cảnh sau:** Keep the same departing coach engine into the on-board view. No second boarding or repeat door close.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
