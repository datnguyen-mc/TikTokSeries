# Kẻ Sống Sót: Bóng Ma — Cảnh 21: Xe Đò Đêm

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 20:00–21:00 · Thời gian truyện: D4 night

Hai người vào thành phố với trạng thái trang phục rõ.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Sơn seated by the coach window, Mây across the narrow aisle. | Mây checks the patrol confirmation while Sơn opens his travel bag. | Patrol message acknowledged, folded black suit visible in the bag. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Black suit folded across Sơn's knees, gloves tucked inside. | He touches the gloves, Mây keeps her attention on his face. | Gloves still folded, Sơn's hand withdrawn. | Mây (@May), nói trong hình: Anh vẫn cần bộ đó sao? |
| [3](clip-3.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Gloves still folded, Sơn's hand withdrawn. | Sơn closes the bag and speaks about his first employer without a full flashback. | Bag closed between his feet, Mây listening. | Sơn (@Son), nói trong hình: Bà cho tôi chỗ ở. Rồi giữ luôn lối ra. |
| [4](clip-4.md) | L · L-cut: âm cũ đi qua cú cắt | Coach stopped under a rest-stop awning, travelers already outside. | Sơn walks toward the changing room, Mây waits beside the coach. | Mây beside the coach door, Sơn beyond the changing-room entrance. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn before the mirror, suit already on and gloves in his hand. | He pockets the gloves unused, leaving both hands bare. | Sơn in black suit with bare hands, olive jacket folded in his bag. | Sơn, lời dẫn ngoài hình: Tôi mặc lại vest. Không mang lại đôi tay cũ. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Mây holding the coach door open, Sơn returning with his bag. | They reboard, Sơn puts the bag above his seat. | Both back on the coach, olive jacket stored inside the bag. | — |

**Âm nối sang cảnh sau:** Coach-window rain becomes rain on the silk-shop rear awning. The city arrival is a time ellipsis, not another travel montage.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
