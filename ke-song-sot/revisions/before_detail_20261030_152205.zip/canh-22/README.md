# Kẻ Sống Sót: Bóng Ma — Cảnh 22: Két Sau Bình Phong

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 21:00–22:00 · Thời gian truyện: D4 late night

Lấy khóa số và sổ đỏ, Bà Hai chủ động giữ họ lại.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Sơn and Mây at the closed rear door in the rain. | He uses the old shop key while Mây watches the alley. | Rear door opening inward, both travelers at the threshold. | Sơn (@Son), nói trong hình: Chìa cửa cũ. Tôi giữ hai mươi lăm năm. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Both inside the dim shop, rear door behind screen left. | Sơn leads along the silk racks to the screen covering the safe. | Screen pulled aside, safe in front of Sơn, Mây by the exit. | — |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Safe open, red ledger and USB-shaped hardware token inside. | Sơn removes only the red ledger and hardware token. | Red ledger under his left arm, token in right hand. | Sơn, ngoài khung hình: Khóa số đây. Không phải chìa cửa. |
| [4](clip-4.md) | J · J-cut: âm mới đến trước hình | Desk lamp switching on behind the open safe. | Bà Hai is revealed at the desk as both visitors turn toward her. | All three visible, safe open behind Sơn. | Bà Hai (@HaiNgoc), nói trong hình: Má để cửa cho con. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bà Hai facing Sơn with both palms on the desk. | She permits him to keep the ledger while asking for Kiên's return. | Sơn retaining the ledger, Mây beside the rear exit. | Bà Hai (@HaiNgoc), nói trong hình: Giữ sổ. Đổi lại, đưa Kiên về đây. |
| [6](clip-6.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Sơn retaining the ledger, Mây beside the rear exit. | Mây stays standing as Sơn draws a chair away from the desk. | Chair angled toward the exit, three separate tea cups untouched. | Sơn (@Son), nói trong hình: Hạ ở đâu? |

**Âm nối sang cảnh sau:** Keep the same desk room tone, match the three untouched cups and angled chair before Bà Hai offers tea.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
