# Kẻ Sống Sót: Bóng Ma — Cảnh 24: Bãi Xe: Một Người Đồng Hành

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 23:00–24:00 · Thời gian truyện: D4 late night

Dũng bị chặn, Mây dùng chiếc còng thứ hai và rút lui.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Sơn and Mây already entering the garage ramp from the alley. | They move along the same car row, rear exit visible beyond. | Both behind a parked van, exit two pillars ahead. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | One guard reaching around the van toward Mây. | Sơn closes the car door between guard and Mây, keeping their path clear. | Guard stopped by the door, Mây moving past the next pillar. | Mây (@May), nói trong hình: Lối bên trái. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng coming down from the ramp in response to Bà Hai's call. | He cuts off the direct exit, forcing Sơn back toward a railing. | Dũng between the travelers and exit, railing behind Sơn. | Dũng (@Dũng), nói trong hình: Má còn chưa nói xong. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng reaching for the ledger, Sơn protecting it under his left arm. | Dũng drives Sơn's left wrist into the pillar, Mây circles behind him. | Sơn down on one knee, ledger secure, Mây at Dũng's right side. | — |
| [5](clip-5.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Sơn down on one knee, ledger secure, Mây at Dũng's right side. | Mây cuffs Dũng's right wrist to the solid ramp rail using her second pair. | Dũng restrained to the intact rail, Mây helping Sơn up. | Mây (@May), nói trong hình: Đủ hai chiếc rồi. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | The two travelers crossing the exit, Dũng behind them at the rail. | An unnamed guard arrives with bolt cutters after they clear the doorway. | Travelers gone, cutters beside the cuff chain, Dũng still restrained. | — |

**Âm nối sang cảnh sau:** Garage echo and the cutter sound fall away as the motel fan introduces dawn. Show no second capture of Dũng.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
