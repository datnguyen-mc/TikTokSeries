[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Son = Sơn: same approved identity, age 45; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. present timeline, black suit, open-collar white shirt, BARE hands, no gloves, no flower in breast pocket. Voice: low, dry, unhurried Southern Vietnamese male voice.
@May = Mây: same approved identity, age 38; Vietnamese woman, athletic build, sun-lined face, short black hair with a distinctive white front streak. denim jacket, dark T-shirt, jeans, sneakers, small backpack, no uniform shirt visible. Voice: firm, clear Southern Vietnamese female voice.
@Dũng = Dũng: same approved identity, age 35; Vietnamese man, heavy shoulders, buzz cut, nail-shaped silver earring in LEFT ear. black sleeveless shirt, black jeans, boots, shoulder bag for work gear. Voice: rough Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 24/60, clip 3/6; shot 24.3. Story time: D4 late night.
Underground city car park, ramp north, lift east, pillar rows, solid ramp railing, low maintenance door west.
Present-day night car park, stable amber practicals and car reflections, no day light.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 24.2, ending with Guard stopped by the door, Mây moving past the next pillar.
Intentional editorial cut, not a continuous take. Start only in the new composition; preserve compatible screen direction and eyelines. No morph or duplicated gesture.

[START FRAME — state only, not an action to repeat]
Dũng coming down from the ramp in response to Bà Hai's call.

[CAMERA]
35mm locked wide shot at human eye level. Preserve readable geography and screen direction.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
He cuts off the direct exit, forcing Sơn back toward a railing.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–3.8s, one unhurried line only. Visible speaker alone delivers the line, mouth readable in this composition. Other people listen silently.

Dũng (@Dũng), nói trong hình: Má còn chưa nói xong.
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
No new featured prop. Preserve already established carried items; introduce no extra symbolic objects.

[SOUND]
Location bed: fluorescent hum and footsteps echoing on concrete. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. 

[END FRAME — natural motion continues]
Dũng between the travelers and exit, railing behind Sơn.
Next shot 24.4: Cắt dựng đúng vị trí/ánh nhìn. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
