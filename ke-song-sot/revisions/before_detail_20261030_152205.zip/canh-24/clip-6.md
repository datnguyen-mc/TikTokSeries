[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Son = Sơn: same approved identity, age 45; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. present timeline, black suit, open-collar white shirt, BARE hands, no gloves, no flower in breast pocket. Voice: low, dry, unhurried Southern Vietnamese male voice.
@May = Mây: same approved identity, age 38; Vietnamese woman, athletic build, sun-lined face, short black hair with a distinctive white front streak. denim jacket, dark T-shirt, jeans, sneakers, small backpack, no uniform shirt visible. Voice: firm, clear Southern Vietnamese female voice.
@Dũng = Dũng: same approved identity, age 35; Vietnamese man, heavy shoulders, buzz cut, nail-shaped silver earring in LEFT ear. black sleeveless shirt, black jeans, boots, shoulder bag for work gear. Voice: rough Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 24/60, clip 6/6; shot 24.6. Story time: D4 late night.
West maintenance exit of the same car park, steps to a sheltered city rear lane.
Present-day night car park, stable amber practicals and car reflections, no day light.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 24.5, ending with Dũng restrained to the intact rail, Mây helping Sơn up.
L-cut in the edit: retain the preceding diegetic sound about 0.25s after the picture cut, then let it fall away. This generated clip contains only the new shot.

[START FRAME — state only, not an action to repeat]
The two travelers crossing the exit, Dũng behind them at the rail.

[CAMERA]
35mm locked wide shot at human eye level. Preserve readable geography and screen direction.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
An unnamed guard arrives with bolt cutters after they clear the doorway.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
No speech, narration, improvised dialogue or vocal filler. Keep the scene alive through the specified action and location sound.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
- Original RED cloth ledger, handwritten signature shapes, distinct from black leather ledger.
- USB-shaped hardware security token from the safe; NOT the metal door key.

[SOUND]
Location bed: garage echo fading into rain. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. Garage echo and the cutter sound fall away as the motel fan introduces dawn. Show no second capture of Dũng.

[END FRAME — natural motion continues]
Travelers gone, cutters beside the cuff chain, Dũng still restrained.
Next shot 25.1: J-cut: âm mới đến trước hình. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
