# Kẻ Sống Sót: Bóng Ma — Cảnh 26: Xưởng Bên Sông

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 25:00–26:00 · Thời gian truyện: D5 afternoon

Lấy bằng chứng hiện trường và thoát bằng đường đã khảo sát.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | The pair crouched behind a roof vent overlooking the factory yard. | Mây films the loading emblem and the same seal shown in the accounts. | Phone aimed at the matched shipment seal, Sơn watching the route. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Both inside the loading aisle, river door visible ahead. | Sơn takes one sealed sample carton from a documented shelf as Mây films the location. | Single carton in Mây's evidence bag, shelf location recorded. | Sơn, ngoài khung hình: Niêm phong nguyên. Đừng mở. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | A guard turning into the loading aisle behind them. | Sơn holds the guard behind a closing sliding screen while Mây reaches the river door. | Guard separated by the screen, Mây at the open river door. | — |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây at the dock gate, another guard approaching from the stairs. | She loops a dock rope around the gate and pulls it shut between them. | Gate held by rope, both travelers beyond it, no new cuffs. | Mây (@May), nói trong hình: Đi tiếp. Tôi giữ cửa. |
| [5](clip-5.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Gate held by rope, both travelers beyond it, no new cuffs. | Sơn steadies a tied workboat as Mây steps aboard, then releases the mooring. | Both aboard the workboat, loose rope clear of the propeller. | — |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Workboat clearing the factory dock, carton secured under the bench. | Sơn keeps the boat on the open channel, Mây sends the recorded clip. | Factory falling behind, phone transmission confirmed. | Mây (@May), nói trong hình: Giờ họ có cả sổ và xưởng. |

**Âm nối sang cảnh sau:** Keep the established boat engine as the view changes from wide channel to the two travelers. No repeat departure from the dock.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
