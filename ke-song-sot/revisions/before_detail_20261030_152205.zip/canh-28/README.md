# Kẻ Sống Sót: Bóng Ma — Cảnh 28: Quá Khứ: Cánh Cửa Đầu Tiên

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 27:00–28:00 · Thời gian truyện: PAST twenty-five years earlier night / D6 dawn from clip 4

Sơn chọn bỏ vũ khí hiện tại sau khi nhớ lần đầu gây hại.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | L · L-cut: âm cũ đi qua cú cắt | Twenty-year-old Sơn outside a closed wooden door, new gloves tucked in his pocket. | He hears an ordinary family sound inside and hesitates before knocking. | Young Sơn's bare right hand just below the door knocker. | Sơn, lời dẫn ngoài hình: Lần đầu, tôi còn kịp quay đi. |
| [2](clip-2.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Young Sơn's bare right hand just below the door knocker. | The door opens inward, Sơn enters, camera remains outside without showing harm. | Door closed, empty corridor, rain audible beyond the stairwell. | — |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Young Sơn stepping back into the corridor after an unshown interval. | He looks at his bare hands, puts on the new gloves without relief. | Both gloved hands lowered, young Sơn turning away. | Sơn, lời dẫn ngoài hình: Tôi đã không quay đi. |
| [4](clip-4.md) | MATCH · Match cut hình dạng/tư thế, không morph | Present-day Sơn at the cabin table, Mây beside the closed handgun case. | He passes the complete locked case and its key to Mây. | Entire handgun case in Mây's custody, Sơn unarmed. | Sơn (@Son), nói trong hình: Tôi không mang thứ này nữa. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Four marks on the frame with two small travel-date notes beside them. | Back from the city, Sơn carves the missing day-five and day-six marks in order. | Exactly six marks, two freshest side by side. | — |
| [6](clip-6.md) | J · J-cut: âm mới đến trước hình | Both at the porch looking down on the town road. | They hear an abrupt radio warning, then see market shutters closing. | Mây answering her radio, Sơn looking toward Bảy's stall. | Thành, qua thiết bị: Dũng quay lại. Quán ông Bảy. |

**Âm nối sang cảnh sau:** Thành radio warning carries into the present-day blocked street. The town threat is the next event, not another flashback.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
