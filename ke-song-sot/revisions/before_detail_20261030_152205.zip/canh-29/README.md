# Kẻ Sống Sót: Bóng Ma — Cảnh 29: Cái Giá Của Chuyến Đi

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 28:00–29:00 · Thời gian truyện: D6 morning

Thành bảo vệ dân rồi bị giữ, Sơn kéo Dũng khỏi con tin.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | OPEN · Cắt thiết lập thời gian/không gian | Mây and Sơn at the upper road, black car near the coffee stall. | They see a patrol barricade damaged and choose the side lane. | Both concealed behind the side-lane wall, view of the stall clear. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Thành seated with tied wrists, Bảy held behind the counter. | Dũng demands the ledger, Thành keeps the civilian rear door out of his sight. | Thành watching the rear door, Dũng facing the road. | Dũng (@Dũng), nói trong hình: Sổ đâu? Đừng bắt tao hỏi ông già. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn and Mây behind the wall, Sơn looking at the rear stall door. | They divide tasks: Sơn draws Dũng away, Mây reaches Thành from behind. | Mây taking the side lane, Sơn stepping toward the road. | Sơn (@Son), nói trong hình: Tôi kéo hắn ra. Cô đưa Thành đi. |
| [4](clip-4.md) | L · L-cut: âm cũ đi qua cú cắt | Sơn visible in the road, Dũng at the stall threshold. | Sơn calls him and moves toward the market entrance without exposing a weapon. | Dũng following Sơn, stall entrance momentarily clear. | Sơn (@Son), nói trong hình: Dũng. Muốn sổ thì theo tao. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây entering the stall from the rear, Bảy by Thành's chair. | She cuts Thành's ties while Bảy opens the civilian exit. | Thành free, Bảy ushering two unnamed civilians out back. | Mây (@May), nói trong hình: Đưa dân ra. Không đuổi theo hắn. |
| [6](clip-6.md) | J · J-cut: âm mới đến trước hình | Sơn already at the market entrance, Dũng several paces behind. | Sơn ducks into a narrow aisle as a cart blocks Dũng's direct line. | Sơn beyond the cart, Dũng forced to go around. | — |

**Âm nối sang cảnh sau:** Keep pursuing footsteps and cut past the entry cart into the aisle. Do not perform the cart obstruction twice.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
