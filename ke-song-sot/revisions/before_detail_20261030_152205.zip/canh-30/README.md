# Kẻ Sống Sót: Bóng Ma — Cảnh 30: Lối Qua Chợ Cá

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 29:00–30:00 · Thời gian truyện: D6 morning

Dân hỗ trợ thoát người, lực lượng hỗ trợ xử lý đám truy đuổi.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn just past the entry cart inside the market aisle. | Sơn moves deeper along the narrow aisle, keeping a stack of crates between him and pursuers. | Sơn at the aisle junction, pursuers slowed by the crates. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bảy at a side door with two fish sellers, Sơn approaching. | They move a wheeled ice cart across the empty aisle after Sơn passes. | Cart blocking the aisle, civilians already behind a closed door. | Ông Bảy (@Ông Bảy), nói trong hình: Đi lối này. Cửa sau trống. |
| [3](clip-3.md) | J · J-cut: âm mới đến trước hình | Mây and Thành at the rear market exit, support officers arriving behind them. | They take two separated pursuers into custody without involving civilians. | Pursuers held by support officers, rear exit protected. | Mây (@May), nói trong hình: Giữ lối thoát cho dân. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng at the far end of the obstructed aisle, Sơn beyond reach. | He threatens the day-seven transfer rather than another immediate fight. | Dũng lowering his phone with the ship schedule visible as shapes. | Dũng (@Dũng), nói trong hình: Đợi thêm, Hạ lên tàu mất. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng retreating toward his car with his two remaining men. | He leaves a meeting place and time before withdrawing. | Black car backing away, Sơn staying inside the market entrance. | Dũng (@Dũng), nói trong hình: Bà Hai chờ ở hải đăng tối nay. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Thành seated safely at the rear exit, one glasses arm bent. | Mây acknowledges the cost of her absence and restores the patrol roster. | Thành taking the replacement roster, Sơn listening nearby. | Mây (@May), nói trong hình: Lần này chị giữ đủ người ở đây. |

**Âm nối sang cảnh sau:** Let market noise end before establishing night lighthouse wind and Bà Hai already waiting. No second market confrontation.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
