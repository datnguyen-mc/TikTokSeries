# Kẻ Sống Sót: Bóng Ma — Cảnh 32: Đường Rút Cho Người Sống

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 31:00–32:00 · Thời gian truyện: D6 night

Kế hoạch cứu người có hỗ trợ, Tê không phải mẹo giả chết.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Linh examining the sealed sample carton without opening it. | Mây asks him to stand by near the planned exchange, outside the danger area. | Linh putting the sealed carton into locked evidence storage. | Mây (@May), nói trong hình: Ông giúp phần cứu người. Không ra giữa cảng. |
| [2](clip-2.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Linh putting the sealed carton into locked evidence storage. | Sơn explains that Dũng uses Tê to take people alive, Linh listens carefully. | Linh recording that risk on the emergency note. | Sơn (@Son), nói trong hình: Hắn muốn giữ người sống để ép khai. |
| [3](clip-3.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Linh recording that risk on the emergency note. | Linh rejects any plan relying on a guaranteed waking time. | Sơn nodding, Mây removing a timer from the tactical sketch. | Bác sĩ Linh (@Bác sĩ Linh), nói trong hình: Gặp thuốc thì đưa về ngay. Đừng chờ phút nào. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Simple harbour map on the desk, two protected exits marked by shapes. | Mây assigns rescue extraction to the van and civilians to evacuation only. | Van route separated from the police approach, map complete. | Mây, ngoài khung hình: Dân rút trước. Người của tôi giữ hai đầu. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn facing Mây across the plan. | He agrees to withdraw if Hạ cannot be seen directly at the meeting. | Mây's finger on the abort route, Sơn acknowledging. | Sơn (@Son), nói trong hình: Không thấy Hạ, không trao gì hết. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Linh placing ordinary monitoring equipment in his bag. | Mây radios the agreed positions while Sơn steps back from the plan. | Medical bag ready, route map with Mây, Sơn unarmed. | Mây (@May), nói trong hình: Ưu tiên đưa cả hai người ra. |

**Âm nối sang cảnh sau:** Flower-shop shutter sound introduces the memory after the current radio check. No repeated medical explanation.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
