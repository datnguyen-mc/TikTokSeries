# Kẻ Sống Sót: Bóng Ma — Cảnh 34: Vạch Thứ Bảy

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 33:00–34:00 · Thời gian truyện: D7 dawn

Bằng chứng giao nhận rõ, Sơn giữ bản sao cho cuộc trao đổi.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | MATCH · Match cut hình dạng/tư thế, không morph | Exactly six marks on the frame, first dawn light across the wood. | Sơn adds only the seventh mark and puts the carving tool away. | Seven distinct marks, tool on the shelf. | Sơn, lời dẫn ngoài hình: Ngày bảy. Lần này tôi ở lại để khai. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Original ledger books and hardware on the table, Mây with evidence seals. | Mây brings the original black ledger and USB from the station, Sơn adds red ledger and token, they seal all originals for the investigator. | Originals sealed with Mây, only a copy envelope before Sơn. | Mây (@May), nói trong hình: Bản gốc đi trước. Anh cầm bản sao. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn passing the small scarf fragment to Mây's evidence bag. | She stores both pieces in separate sleeves inside the same bag. | Both scarf pieces with Mây, sleeve edges visible. | — |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn holding his closed watch while Mây prepares to leave. | He asks her to keep it safe during the exchange, she accepts it. | Closed watch in Mây's right hand, Sơn's belt chain empty. | Sơn (@Son), nói trong hình: Giữ giúp. Tôi muốn tự lấy lại. |
| [5](clip-5.md) | L · L-cut: âm cũ đi qua cú cắt | Mây handing the sealed originals to an assigned officer at the station. | Thành records the handover while copies remain with the local team. | Signed handover receipt with Thành, originals departing under escort. | — |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Confirmed road team on the station radio, Mây beside Thành. | The team reports it will take position before the meeting, not during a later rescue. | Thành marking the confirmed positions, Mây acknowledging. | Bộ đàm, qua thiết bị: Hai đầu đường đã có người. |

**Âm nối sang cảnh sau:** Radio confirmation yields to coffee-stall glass sounds before the morning safety briefing. Orders here assign new practical tasks.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
