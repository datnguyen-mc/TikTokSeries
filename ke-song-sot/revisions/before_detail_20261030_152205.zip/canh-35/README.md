# Kẻ Sống Sót: Bóng Ma — Cảnh 35: Những Việc Nhỏ Của Thị Trấn

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 34:00–35:00 · Thời gian truyện: D7 morning

Thị trấn chuẩn bị bằng các nhiệm vụ an toàn khác nhau.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Mây beside a harbour sketch, Bảy and Thành listening. | Thành gives Mây two fresh pairs of cuffs, she assigns the van to the rear lane and orders civilians off the pier. | Three people each taking their own route away from the table. | Mây (@May), nói trong hình: Chiều nay đóng sạp sớm. Không ai xuống cầu. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bảy parking the van beyond the market wall, Linh beside him. | They clear fish crates and secure a clean mattress and medical bag. | Van ready behind cover, rear doors opening toward the safe lane. | Ông Bảy (@Ông Bảy), nói trong hình: Xe sạch rồi. Đường cũng trống. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Thành on the market roof with repaired glasses and radio. | He checks sightlines to both pier approaches and confirms the radio works. | Binoculars lowered, radio clipped at his collar. | Thành (@Phó Thành), nói trong hình: Tôi thấy cả hai đầu. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn already wearing the black suit, left wrist bandage exposed. | He folds both black gloves into the canvas bag and leaves the bag in the cabin. | Gloves inside the bag on the bed, Sơn with bare hands. | — |
| [5](clip-5.md) | L · L-cut: âm cũ đi qua cú cắt | Sơn leaving the hill path for the main road. | He walks openly past shutters being secured for the afternoon. | Sơn approaching the sea-facing coffee table. | — |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn seated facing the sea, Bảy carrying coffee. | Bảy sets the glass down and leaves Sơn the open view. | Coffee glass on Sơn's right, sea in front of him. | Ông Bảy (@Ông Bảy), nói trong hình: Chỗ này nhìn biển được rồi. |

**Âm nối sang cảnh sau:** The coffee glass settles, the approaching white-car engine begins before the street cut. Kiên arrives only once.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
