# Kẻ Sống Sót: Bóng Ma — Cảnh 36: Khách Hàng Áo Trắng

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 35:00–36:00 · Thời gian truyện: D7 afternoon

Đối mặt Kiên, buộc kẻ giữ người chứng minh Hạ có mặt.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | White car stopping across from the stall, Sơn already seated. | Kiên steps out with two unnamed guards, walks to Sơn's table. | Kiên standing opposite Sơn, car kept in view behind him. | Kiên (@Vũ Kiên), nói trong hình: Anh làm tôi tìm lâu quá. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Kiên seated across from Sơn, no handshake offered. | He admits the first trap was meant to silence Sơn, then states why he kept Hạ. | Sơn listening without giving him the copy envelope. | Kiên (@Vũ Kiên), nói trong hình: Anh trốn được. Tôi giữ Hạ để anh quay lại. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Rear car window lowered, Hạ visible inside with Kiên outside. | Hạ meets Sơn's eyes and deliberately rests her hand on the inner door handle. | Hạ's fingers on the handle, Sơn seeing the gesture from outside. | Hạ (@Ha), nói trong hình: Em tự đi được. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Kiên closing the rear car window, Sơn beside the table. | Sơn refuses a private transfer and specifies the open harbour exchange. | Window closed, Sơn still standing outside the car's reach. | Sơn (@Son), nói trong hình: Cảng cá. Thấy cô ấy bước ra rồi mới trao. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Kiên returning toward Sơn's table before leaving. | He adds the demand that Sơn bring Bà Hai and sign a confession protecting Kiên. | Blank confession folder placed on the table, Sơn not touching it. | Kiên (@Vũ Kiên), nói trong hình: Đưa bà ta tới. Rồi ký phần của anh. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Kiên getting into the front passenger seat, Sơn remaining by the stall. | The white car drives toward its temporary lodging, not directly out of town. | White car receding, confession folder still unopened on the table. | — |

**Âm nối sang cảnh sau:** White-car engine recedes under the rear-stall discussion. Keep the car gone and the confession folder with Mây.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
