# Kẻ Sống Sót: Bóng Ma — Cảnh 37: Điều Kiện Không Đổi

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 36:00–37:00 · Thời gian truyện: D7 afternoon

Mây và Sơn điều chỉnh kế theo điều kiện mới, không kể lại kế cũ.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | L · L-cut: âm cũ đi qua cú cắt | Mây and Sơn behind the stall with the unopened confession folder. | Mây identifies the new trap, Sơn agrees the folder will remain blank. | Folder closed in Mây's hand, Sơn's hands empty. | Mây (@May), nói trong hình: Hắn cần người nhận tội thay. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Copy envelope open between them, only selected ledger pages inside. | They mark it as a preview, originals already with the investigator. | Preview pages separated from the blank confession folder. | Sơn, ngoài khung hình: Tôi chỉ đưa bản xem trước. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây beside the confirmed road map, Sơn looking toward the harbour. | Mây assigns the remaining road officer to the main cliff-road turnoff; the narrow service footpath is a separate route below the wall. | Main cliff road marked as covered, Sơn acknowledging; service footpath remains a separate gap to watch. | Mây (@May), nói trong hình: Chặn đường chính lên tháp. Báo ngay nếu hắn đổi hướng. |
| [4](clip-4.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Main cliff road marked as covered, Sơn acknowledging; service footpath remains a separate gap to watch. | Sơn agrees to stop if Hạ is not released from the car. | Mây closing the map, both understanding the abort signal. | Sơn (@Son), nói trong hình: Không thả người, tôi không bước tiếp. |
| [5](clip-5.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Mây closing the map, both understanding the abort signal. | Mây gives him the rescue signal: lay the envelope down and step away. | Envelope flat on the table as a rehearsal, nobody repeating the action twice. | Mây (@May), nói trong hình: Đặt xuống. Lùi lại. Người tôi sẽ vào. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn's bare right hand picking up the preview envelope. | He leaves the confession folder with Mây and takes only the copy. | Copy envelope in right hand, left wrist bandaged, no weapon. | — |

**Âm nối sang cảnh sau:** Match present Sơn bare hand holding the copy to young Sơn empty palms under the awning. No glove-box reveal until 38.4.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
