# Kẻ Sống Sót: Bóng Ma — Cảnh 38: Quá Khứ: Đôi Găng Đầu Tiên

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 37:00–38:00 · Thời gian truyện: PAST twenty-five years earlier rainy evening

Ơn nuôi dưỡng biến thành quyền sở hữu qua một món quà.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | MATCH · Match cut hình dạng/tư thế, không morph | Young Sơn empty bare palms below the silk-shop awning, young Bà Hai watching from within. | She offers shelter, Sơn enters without a bag or trade tools. | Young Sơn under the awning, rain behind him. | Bà Hai (@HaiNgoc), nói trong hình: Vào ăn trước đã. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Young Sơn seated with a bowl, Bà Hai across the table. | He begins to eat only after she moves the bowl closer. | Bowl near young Sơn, Bà Hai's hands withdrawn. | — |
| [3](clip-3.md) | MATCH · Match cut hình dạng/tư thế, không morph | Later season, same table with folded silk instead of the bowl. | Bà Hai teaches him to fold a bolt and listen to the shop bell. | Neatly folded silk between them, young Sơn looking toward the door. | Bà Hai (@HaiNgoc), nói trong hình: Nghe hết. Nói ít. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | A glove box open on the teak desk. | Bà Hai places new black gloves in young Sơn's bare palms. | Gloves resting across both palms, not yet worn. | Bà Hai, ngoài khung hình: Từ nay con giữ cửa sau. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Young Sơn by the rear door, Bà Hai at the desk. | He realizes his sleeping mat has been moved inside the locked stockroom. | Young Sơn looking at the stockroom lock, Bà Hai watching him. | Sơn, lời dẫn ngoài hình: Chỗ ở dần thành chỗ không được đi. |
| [6](clip-6.md) | MATCH · Match cut hình dạng/tư thế, không morph | Present-day folded gloves in the canvas bag, Sơn's bare hands beside them. | Sơn zips the bag closed and leaves it on the bed. | Bag closed on the bed, bare hands leaving the frame. | — |

**Âm nối sang cảnh sau:** Present-day bag zipper finishes under the cut to the harbour overview, then sea wind takes over. Gloves stay in the cabin.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
