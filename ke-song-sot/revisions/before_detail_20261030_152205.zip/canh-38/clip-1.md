[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@HaiNgoc = Bà Hai: same approved identity, age 35; Vietnamese woman, small upright build, composed face, jade bracelet on LEFT wrist. distant past, black hair in the same tight bun, simpler violet áo bà ba, black trousers, left jade bracelet. Voice: soft, slow Southern Vietnamese female voice with precise diction.
@Son = Sơn: same approved identity, age 20; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. distant past, black hair without grey, plain dark shirt and cheap dark trousers, BARE hands. Voice: low, dry, unhurried Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 38/60, clip 1/6; shot 38.1. Story time: PAST twenty-five years earlier rainy evening.
Narrow rear alley of the silk shop, stockroom door beneath a shallow awning.
Distant-past rainy evening, warm silk-shop lamps and cooler street rain.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 37.6, ending with Copy envelope in right hand, left wrist bandaged, no weapon.
Intentional match cut using the related shape or pose. Cut cleanly to the new time/place; no transformation, morph, dissolve or replay of the old shot.

[START FRAME — state only, not an action to repeat]
Young Sơn empty bare palms below the silk-shop awning, young Bà Hai watching from within.

[CAMERA]
35mm locked wide shot at human eye level. Preserve readable geography and screen direction.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
She offers shelter, Sơn enters without a bag or trade tools.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–3.8s, one unhurried line only. Visible speaker alone delivers the line, mouth readable in this composition. Other people listen silently.

Bà Hai (@HaiNgoc), nói trong hình: Vào ăn trước đã.
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
No new featured prop. Preserve already established carried items; introduce no extra symbolic objects.

[SOUND]
Location bed: rain on the awning and city traffic far away. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. 

[END FRAME — natural motion continues]
Young Sơn under the awning, rain behind him.
Next shot 38.2: Cắt dựng đúng vị trí/ánh nhìn. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
