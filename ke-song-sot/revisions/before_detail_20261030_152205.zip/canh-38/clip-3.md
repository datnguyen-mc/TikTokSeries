[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@HaiNgoc = Bà Hai: same approved identity, age 35; Vietnamese woman, small upright build, composed face, jade bracelet on LEFT wrist. distant past, black hair in the same tight bun, simpler violet áo bà ba, black trousers, left jade bracelet. Voice: soft, slow Southern Vietnamese female voice with precise diction.
@Son = Sơn: same approved identity, age 20; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. distant past, black hair without grey, plain dark shirt and cheap dark trousers, BARE hands. Voice: low, dry, unhurried Southern Vietnamese male voice.
Time ellipsis: several weeks after first shelter, same year.


[TIMELINE AND LOCATION]
Scene 38/60, clip 3/6; shot 38.3. Story time: PAST twenty-five years earlier rainy evening.
City silk shop, teak desk to east, screened safe behind it, rear stock door west, warm practical lamps.
Distant-past rainy evening, warm silk-shop lamps and cooler street rain.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 38.2, ending with Bowl near young Sơn, Bà Hai's hands withdrawn.
Intentional match cut using the related shape or pose. Cut cleanly to the new time/place; no transformation, morph, dissolve or replay of the old shot.

[START FRAME — state only, not an action to repeat]
Later season, same table with folded silk instead of the bowl.

[CAMERA]
50mm locked medium shot at eye level. Let the gesture and reaction develop in the same composition.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
Bà Hai teaches him to fold a bolt and listen to the shop bell.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–3.8s, one unhurried line only. Visible speaker alone delivers the line, mouth readable in this composition. Other people listen silently.

Bà Hai (@HaiNgoc), nói trong hình: Nghe hết. Nói ít.
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
No new featured prop. Preserve already established carried items; introduce no extra symbolic objects.

[SOUND]
Location bed: silk shifting and muted rain outside. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. 

[END FRAME — natural motion continues]
Neatly folded silk between them, young Sơn looking toward the door.
Next shot 38.4: Cắt dựng đúng vị trí/ánh nhìn. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
