[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Son = Sơn: same approved identity, age 45; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. present timeline, black suit, open-collar white shirt, BARE hands, no gloves, no flower in breast pocket. LEFT wrist bandage from 25.1 onward; right hand uninjured; unarmed: complete handgun case was surrendered at 28.4; current-day bare hands in this return from memory. Voice: low, dry, unhurried Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 38/60, clip 6/6; shot 38.6. Story time: D7 late afternoon.
One-room wooden cabin, porch on south seaward side, table below east window, cot west, rear exit north, marked entry frame.
Present-day day-seven late afternoon at cabin, warm low sun and cool window shadow.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 38.5, ending with Young Sơn looking at the stockroom lock, Bà Hai watching him.
Intentional match cut using the related shape or pose. Cut cleanly to the new time/place; no transformation, morph, dissolve or replay of the old shot.

[START FRAME — state only, not an action to repeat]
Present-day folded gloves in the canvas bag, Sơn's bare hands beside them.

[CAMERA]
85mm locked detail shot. Hands and the relevant object remain spatially readable; no impossible macro reflections.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
Sơn zips the bag closed and leaves it on the bed.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
No speech, narration, improvised dialogue or vocal filler. Keep the scene alive through the specified action and location sound.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
No new featured prop. Preserve already established carried items; introduce no extra symbolic objects.

[SOUND]
Location bed: wind through wood joints and remote surf. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. Present-day bag zipper finishes under the cut to the harbour overview, then sea wind takes over. Gloves stay in the cabin.

[END FRAME — natural motion continues]
Bag closed on the bed, bare hands leaving the frame.
Next shot 39.1: L-cut: âm cũ đi qua cú cắt. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
