# Kẻ Sống Sót: Bóng Ma — Cảnh 39: Bản Đồ Lúc Hoàng Hôn

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 38:00–39:00 · Thời gian truyện: D7 sunset

Thiết lập một lần địa lý và vị trí lực lượng cho toàn cao trào.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | L · L-cut: âm cũ đi qua cú cắt | Whole harbour in one view, market on landward side, lighthouse road uphill west. | Mây checks the protected landward junction while Thành takes the roof post. | Pier, market lane and uphill service path all readable in frame. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Van behind the market wall, rear lane clear to the clinic. | Mây confirms Linh's protected position and a clear stretcher path. | Van and stretcher path clear, Mây heading back to the pier. | Mây (@May), nói trong hình: Đưa người qua lối này. Không qua chợ. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Thành looking down at two officers covering the harbour junction. | He confirms both arrival roads are watched and civilians have left. | Empty public pier below, officers concealed at the junction. | Thành (@Phó Thành), nói trong hình: Đủ vị trí. Chợ đã rút hết. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn entering from the market side, envelope in his right hand. | He stops on the agreed painted seam, facing both approaches. | Sơn on the seam, sea behind him, open retreat toward land. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn at the seam, wind moving his jacket naturally. | He looks once toward Mây's covered position and steadies his left wrist. | Sơn's gaze back toward the road, both hands visible. | — |
| [6](clip-6.md) | J · J-cut: âm mới đến trước hình | Empty arrival roads beyond Sơn, two engines heard off screen. | Black and white headlights appear from different landward roads. | Both headlights approaching the junction, neither car stopped yet. | — |

**Âm nối sang cảnh sau:** Keep the two approaching engines into the arrivals. The next shot shows parking, not a repeated approach from the road.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
