# Kẻ Sống Sót: Bóng Ma — Cảnh 40: Hai Chiếc Xe

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 39:00–40:00 · Thời gian truyện: D7 sunset

Hai phe tới một bãi trao đổi, Hạ có vị trí và hướng thoát rõ.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Black car reaching the east landward apron, Sơn on the center seam. | Black car parks on the east side of the landward apron, Bà Hai steps out. | Black car east, Bà Hai and Dũng beside it, Sơn still on the seam. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | White car approaching the west apron, black car already parked in background. | White car stops on the west apron, Kiên opens the rear door for Hạ. | White car west, Hạ still seated in the open rear doorway. | Kiên (@Vũ Kiên), nói trong hình: Người đây. Phần anh đâu? |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ seated at the white car threshold, Kiên holding the door. | She steps out on her own and studies the landward escape lane. | Hạ beside the car, thin sandals on concrete, landward lane to her right. | — |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | All five positions visible around the marked seam. | Both leaders approach but stop on opposite sides of Sơn, keeping Hạ west. | Bà Hai east, Kiên and Hạ west, Sơn center, landward route open. | Bà Hai, ngoài khung hình: Con giữ người kiểu đó hả Kiên? |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn holding the preview envelope low, Kiên beside Hạ. | Sơn asks Kiên to let Hạ cross to the marked safe line. | Sơn pointing to the safe line with empty left hand. | Sơn (@Son), nói trong hình: Cho cô ấy qua đây. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ looking from Sơn to the safe line, Kiên gripping her arm. | She shifts one sandal toward the line, testing how tightly she is held. | Hạ's foot pointed toward land, Kiên's hand still on her upper arm. | — |

**Âm nối sang cảnh sau:** Keep both engines idling under the first new demand. Do not re-establish the same five positions again.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
