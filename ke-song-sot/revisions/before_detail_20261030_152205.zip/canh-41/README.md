# Kẻ Sống Sót: Bóng Ma — Cảnh 41: Cuộc Trao Đổi Đổi Luật

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 40:00–41:00 · Thời gian truyện: D7 last light

Kiên phá điều kiện, Hạ làm Sơn chọn người thay vì giao kèo.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Kiên holding Hạ just short of the safe line, Sơn opposite. | Kiên demands the signed confession before releasing her, changing the agreement. | Blank folder extended toward Sơn, Hạ held back. | Kiên (@Vũ Kiên), nói trong hình: Ký trước. Tôi mới thả. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bà Hai east of Sơn, Dũng a pace behind her. | She orders Sơn to bring Kiên closer in exchange for her protection. | Dũng edging around Sơn's retreat path, Bà Hai watching. | Bà Hai (@HaiNgoc), nói trong hình: Đưa nó về phía má. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ's arm held by Kiên, eyes fixed on Sơn. | She tells Sơn not to accept blame for Kiên, then makes herself face the safe lane. | Hạ standing upright despite Kiên's grip, Sơn hearing her. | Hạ (@Ha), nói trong hình: Đừng ký. Em không đổi bằng chuyện đó. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn between the confession folder and the safe line. | He places his copy envelope flat on the seam and steps back once. | Envelope on concrete, Sơn one full step behind it. | Sơn (@Son), nói trong hình: Tôi ở lại. Để cô ấy đi. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây behind cover with a clear view of the laid-down envelope. | She signals the officers forward slowly while watching Hạ's blocked path. | Two officers advancing behind cover, Mây tracking Kiên's hand. | Mây (@May), nói trong hình: Tiếp cận. Chưa có lối cho con tin. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng blocking Sơn's right side, Kiên pulling Hạ back toward the white car. | Sơn shifts between Hạ and Dũng as the exchange breaks apart. | Sơn shielding Hạ's path, Dũng within arm's reach. | — |

**Âm nối sang cảnh sau:** Keep breath and road engines. Cut from Sơn shielding the path to Dũng reaching him; the envelope is already on the ground.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
