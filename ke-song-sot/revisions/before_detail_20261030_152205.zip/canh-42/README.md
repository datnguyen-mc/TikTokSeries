# Kẻ Sống Sót: Bóng Ma — Cảnh 42: Bóng Ma Ngã Xuống

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 41:00–42:00 · Thời gian truyện: D7 dusk

Dũng dùng Tê giữ người sống, Sơn không tự làm giả chết.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng within arm's reach of Sơn, Kiên west of them with Hạ. | Dũng reaches to restrain Sơn while Kiên drags Hạ away from the safe line. | Dũng holding Sơn's jacket sleeve, Hạ pulled west toward the car. | Dũng (@Dũng), nói trong hình: Má nói giữ mày sống. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bà Hai watching Dũng press close to Sơn. | She sees the distinctive Tê device in Dũng's hand and tells him to stop. | Bà Hai stepping forward, device partly hidden by Dũng's sleeve. | Bà Hai (@HaiNgoc), nói trong hình: Dũng. Má chỉ bảo giữ người. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn's face as he braces against Dũng, Hạ beyond his shoulder. | His grip weakens after contact with the fictional device, no application detail shown. | Sơn losing balance, Hạ turning toward him. | Hạ, ngoài khung hình: Sơn! |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn folding at the knees beside the copy envelope. | He lowers against a mooring bollard, Dũng holds his jacket instead of letting him strike the ground. | Sơn seated limp against the bollard, visibly breathing. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bà Hai reaching the bollard, Sơn breathing but unable to stand. | She recognizes Tê immediately and orders Dũng to give him room. | Bà Hai between Sơn and Dũng, her hand on Sơn's shoulder. | Bà Hai (@HaiNgoc), nói trong hình: Nó còn sống. Tránh ra cho nó thở. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Kiên west with Hạ, Bà Hai beside Sơn at center. | Kiên demands Sơn and the copies, Hạ kicks the envelope away from his guard's reach. | Envelope sliding toward the landward safe line, Hạ staying out of the guard's grasp. | Kiên (@Vũ Kiên), nói trong hình: Tôi cần cả người lẫn sổ. |

**Âm nối sang cảnh sau:** The kicked envelope reaches the safe line. Keep engines and sea; police commands begin only at 43.3, not before.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
