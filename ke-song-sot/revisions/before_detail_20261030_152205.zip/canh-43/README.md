# Kẻ Sống Sót: Bóng Ma — Cảnh 43: Không Ai Còn Là Món Hàng

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 42:00–43:00 · Thời gian truyện: D7 dusk

Hai phe tranh quyền giữ Sơn, lực lượng vào khi thấy hành vi khống chế.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | MATCH · Match cut hình dạng/tư thế, không morph | Copy envelope at the safe line, Bà Hai beside Sơn, Kiên still west with Hạ. | Bà Hai refuses to hand Sơn to Kiên and pulls Dũng away from his demand. | Bà Hai shielding Sơn's side, Kiên forced to keep Hạ close. | Bà Hai (@HaiNgoc), nói trong hình: Con tao. Không giao thêm lần nữa. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Kiên tightening his hold on Hạ, facing Bà Hai. | He reminds her she sold both people and signals his guard toward Sơn. | Guard moving toward center, Kiên stepping toward the white car. | Kiên (@Vũ Kiên), nói trong hình: Bà bán rồi. Giờ muốn lấy lại sao? |
| [3](clip-3.md) | J · J-cut: âm mới đến trước hình | Mây coming out of landward cover, officers behind her. | She activates the harbour floodlight and orders everyone to release their grips. | Harbour lit steadily, Mây advancing along the safe line. | Mây (@May), nói trong hình: Bỏ người ra. Công an đây. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Thành on the roof, white car and service stair visible below. | He spots Kiên using the car as cover to reach the uphill maintenance path. | Kiên and Hạ moving behind the white car toward the stair. | Thành, qua thiết bị: Hướng tây. Lối kỹ thuật sau xe trắng. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng trying to pull Sơn behind the black car, Mây within reach. | Mây and an officer separate Dũng from Sơn without dropping the immobile man. | Sơn supported by the officer, Dũng withdrawing behind a crate. | Mây (@May), nói trong hình: Đưa Sơn về xe cứu hộ. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Kiên and Hạ at the foot of the narrow maintenance stair behind the apron. | He blocks the lower gate with a tipped cart and forces her upward. | Cart blocking the lower gate, pair ascending the service stair. | — |

**Âm nối sang cảnh sau:** Police commands continue over rescue movement and the service-route cut. No reset to a second stand-off.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
