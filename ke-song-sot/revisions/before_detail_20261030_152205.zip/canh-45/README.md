# Kẻ Sống Sót: Bóng Ma — Cảnh 45: Những Người Đang Chờ

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 44:00–45:00 · Thời gian truyện: D7 night continuous

Dựng song song chăm sóc Sơn và Hạ trì hoãn Kiên.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn lying on the van mattress with eyes open, Linh at his right side. | Linh steadies Sơn's head and keeps watching his breathing, no miracle timer or instant cure. | Linh seated beside Sơn, lamp kept steady. | Bác sĩ Linh (@Bác sĩ Linh), nói trong hình: Đừng cố đứng. Cứ thở với tôi. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ beside the stuck maintenance hatch, Kiên pulling at its wheel. | She gives only the next necessary instruction, deliberately taking time. | Kiên occupied with the wheel, Hạ's right hand near her hair clip. | Hạ (@Ha), nói trong hình: Chốt dưới trước. Ba tôi làm vậy. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Lower gate now open, two officers starting up the narrow service stair. | Thành sends their position and asks the lighthouse team to keep Kiên talking. | Officers already above the gate, Thành moving after them. | Thành, qua thiết bị: Đã thông. Tổ một lên lối phụ. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ's hair clip concealed in her right palm near the inner latch. | She wedges it into the latch gap as Kiên pushes the hatch open. | Clip holding the latch short of fully closing behind them. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây at the van door, Linh at Sơn's side. | She tells Sơn the teams are moving and returns his closed watch to his right hand. | Closed watch in Sơn's right palm, Mây's hands free. | Mây (@May), nói trong hình: Hạ đang tự giữ đường cho mình. |
| [6](clip-6.md) | J · J-cut: âm mới đến trước hình | Mây stepping out of the van, Dũng approaching along the wall. | She closes one rear door behind herself and blocks his approach. | Mây between Dũng and the van, open retreat lane behind her. | Dũng (@Dũng), nói trong hình: Để tao đưa nó về cho má. |

**Âm nối sang cảnh sau:** The van-door latch leads directly into Dũng first advance. Do not introduce him arriving a second time.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
