# Kẻ Sống Sót: Bóng Ma — Cảnh 46: Mây Giữ Cửa

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 45:00–46:00 · Thời gian truyện: D7 night continuous

Mây khống chế Dũng bằng còng mới, Sơn trở lại từng chút.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây between Dũng and the van doors, loose cart to her left. | Dũng rushes for the van door, Mây angles a loose cart into his direct path. | Cart between them, Dũng off balance, Mây beside its handle. | Mây (@May), nói trong hình: Anh không đưa ai đi nữa. |
| [2](clip-2.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Cart between them, Dũng off balance, Mây beside its handle. | Dũng pushes the cart aside, Mây steps clear toward the arriving officer. | Mây beside the officer, Dũng facing two people rather than one. | — |
| [3](clip-3.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Mây beside the officer, Dũng facing two people rather than one. | Mây and the officer control Dũng's arms against the van side without a head strike. | Dũng restrained standing, both arms controlled. | — |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | A fresh intact pair of Mây's issued cuffs in her hands. | She secures Dũng's wrists together and hands him to the officer. | Dũng cuffed to himself under escort, old cut cuff still separately visible. | Mây, ngoài khung hình: Niêm phong cả chiếc cũ trên tay hắn. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn still on the mattress, watch closed in his right hand. | His fingers begin moving, Linh helps him sit partway without letting him stand. | Sơn propped against a support, left wrist still weak. | Sơn (@Son), nói trong hình: Tôi cử động được rồi. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Dũng under escort beside the van, Mây checking her radio. | He realizes Sơn remains alive and can testify, stops asking to take him. | Dũng led toward the custody vehicle, Mây returning to the van. | Dũng (@Dũng), nói trong hình: Má tưởng giữ được nó mãi. |

**Âm nối sang cảnh sau:** Custody footsteps recede, incoming van breathing introduces seated Sơn. His watch remains closed and silent.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
