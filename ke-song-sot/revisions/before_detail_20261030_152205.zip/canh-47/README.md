# Kẻ Sống Sót: Bóng Ma — Cảnh 47: Tỉnh Lại

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 46:00–47:00 · Thời gian truyện: D7 night continuous

Sơn chấp nhận đi cùng Mây trong vai trò hỗ trợ, không tự lao đi.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Sơn seated with support, Mây at the doorway, Linh watching him. | Linh checks that he can follow instructions and move both feet. | Sơn still seated, feet on van floor, Linh close enough to support. | Bác sĩ Linh (@Bác sĩ Linh), nói trong hình: Chậm thôi. Anh chưa khỏe lại. |
| [2](clip-2.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Sơn still seated, feet on van floor, Linh close enough to support. | Sơn tells Mây about the lower hatch Hạ described in the past. | Mây drawing the service hatch below the gallery on her notepad. | Sơn (@Son), nói trong hình: Hạ biết cửa dưới ban công. |
| [3](clip-3.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Mây drawing the service hatch below the gallery on her notepad. | Mây receives confirmation that the main door is accessible, decides to lead that approach herself. | Mây closing her notepad, Linh continuing to support Sơn. | Mây (@May), nói trong hình: Đi với tôi. Ở phía sau tôi. |
| [4](clip-4.md) | L · L-cut: âm cũ đi qua cú cắt | Mây helping Sơn step down, Linh beside his weaker left side. | Sơn tests his balance against the van door instead of running. | Sơn standing with support, right hand holding the closed watch. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Motorcycle stationary, engine off, two helmets on the seat. | Sơn pockets the closed watch, both fasten their helmets, then Mây takes the front seat and Sơn the pillion seat. | Mây riding position, Sơn seated behind, both helmets fastened. | — |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Both seated on the stationary motorcycle, helmets already fastened. | Mây starts the engine, confirms the route by radio, departs slowly with Sơn holding the rail. | Motorcycle leaving left to right, Sơn seated steadily behind her. | Mây (@May), nói trong hình: Chúng tôi lên cửa chính. |

**Âm nối sang cảnh sau:** Keep the same motorcycle ignition after helmets are secured. Cut to the road with movement still left to right.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
