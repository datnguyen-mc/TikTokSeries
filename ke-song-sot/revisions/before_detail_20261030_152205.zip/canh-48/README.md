# Kẻ Sống Sót: Bóng Ma — Cảnh 48: Hai Lối Lên Tháp

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 47:00–48:00 · Thời gian truyện: D7 night continuous

Hai tổ tiến tới, Hạ giữ lối phụ hé, Sơn không tự đi một mình.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Same motorcycle already on the lower cliff road, travelling left to right. | Mây rides uphill at a controlled speed while Sơn braces against the rear rail. | Motorcycle approaching the lighthouse bend, both helmets still on. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Motorcycle stopped at the main entrance, engine switched off. | They dismount and leave both helmets on the seat before entering. | Both on foot at the main door, helmets left on the motorcycle. | — |
| [3](clip-3.md) | L · L-cut: âm cũ đi qua cú cắt | Mây leading up the spiral stair, Sơn a step below. | He climbs using the rail, pauses once to regain balance, Mây waits. | Both below the final landing, no overtaking or running. | — |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Kiên testing the gallery hatch behind him, Hạ facing the sea wall. | The hair clip prevents a full latch, he fails to secure it and pulls Hạ upward. | Service hatch still slightly ajar, Hạ noticing it stayed open. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | An officer's hand reaching the same hatch from below, Thành behind him. | They see the clip keeping the latch open and enter quietly. | Officer through the gap, clip still in latch, Thành following. | Thành, qua thiết bị: Con tin để cửa cho mình. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Mây and Sơn at the last stair corner, Kiên heard above. | Mây announces herself and asks him to move away from Hạ. | Mây at the corner, Sơn one step lower and behind her. | Mây (@May), nói trong hình: Kiên. Tôi lên nói chuyện. |

**Âm nối sang cảnh sau:** Keep wind and restrained radio traffic through the parallel cut to Bà Hai arrest below. The climb continues off screen.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
