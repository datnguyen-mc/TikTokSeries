# Kẻ Sống Sót: Bóng Ma — Cảnh 49: Chiếc Vòng Ngọc

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 48:00–49:00 · Thời gian truyện: D7 night simultaneous with the climb

Bà Hai bị bắt bởi tổ dưới cảng, trả giá cho việc coi người là hàng.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bà Hai on the stone bench under the floodlight, one officer in front of her. | She looks toward the custody road off screen and sets her unlit holder down, unable to give another order. | Holder on bench, Bà Hai's hands resting on her knees. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Dũng pausing under escort within sight of the bench. | He waits for an order, Bà Hai cannot give him one that changes anything. | Dũng facing the road again, Bà Hai looking at her bracelet. | Dũng (@Dũng), nói trong hình: Má còn muốn con giữ ai nữa? |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Jade bracelet on Bà Hai's left wrist. | She removes it deliberately and places it beside the unlit holder. | Bracelet and holder together on stone, both wrists bare. | — |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bà Hai standing before the officer with bare wrists. | She submits to the arrest, speaks about Sơn as if ownership were an explanation. | Cuffs secured, Bà Hai looking toward the lighthouse. | Bà Hai (@HaiNgoc), nói trong hình: Nó là con tôi nuôi. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bà Hai listening to the officer, no one touching her bracelet. | The officer records her words without accepting them as an excuse. | Bà Hai lowering her gaze away from the tower. | Cán bộ hỗ trợ, ngoài khung hình: Vậy bà sẽ khai cả chuyện đã bán người. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Custody vehicle waiting on the protected road, bench behind her. | She walks under escort, leaving the bracelet for the evidence officer. | Empty bench with bracelet in an evidence tray, vehicle door open. | — |

**Âm nối sang cảnh sau:** Incoming gallery wind replaces pier custody sounds before returning to Mây at the main stair entrance.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
