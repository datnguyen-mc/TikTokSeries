[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@HaiNgoc = Bà Hai: same approved identity, age 60; Vietnamese woman, small upright build, composed face. silver hair in a tight bun, violet silk áo bà ba, black trousers, embroidered slippers, unlit black holder; bracelet removed at 49.3 and remains in evidence, wrists bare. Voice: soft, slow Southern Vietnamese female voice with precise diction.



[TIMELINE AND LOCATION]
Scene 49/60, clip 6/6; shot 49.6. Story time: D7 night simultaneous with the climb.
Hòn Sóng concrete harbour apron: sea south, market landward north, black car east, white car west, center painted seam, safe line landward. Lighthouse service stair rises west behind white car.
Same night simultaneously, steady harbour floodlight on the stone bench.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 49.5, ending with Bà Hai lowering her gaze away from the tower.
L-cut in the edit: retain the preceding diegetic sound about 0.25s after the picture cut, then let it fall away. This generated clip contains only the new shot.

[START FRAME — state only, not an action to repeat]
Custody vehicle waiting on the protected road, bench behind her.

[CAMERA]
35mm locked wide shot at human eye level. Preserve readable geography and screen direction.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
She walks under escort, leaving the bracelet for the evidence officer.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
No speech, narration, improvised dialogue or vocal filler. Keep the scene alive through the specified action and location sound.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
No new featured prop. Preserve already established carried items; introduce no extra symbolic objects.

[SOUND]
Location bed: boat ropes, small waves and engines only when visible. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. Incoming gallery wind replaces pier custody sounds before returning to Mây at the main stair entrance.

[END FRAME — natural motion continues]
Empty bench with bracelet in an evidence tray, vehicle door open.
Next shot 50.1: J-cut: âm mới đến trước hình. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
