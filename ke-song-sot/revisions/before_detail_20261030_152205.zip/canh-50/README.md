# Kẻ Sống Sót: Bóng Ma — Cảnh 50: Đỉnh Hải Đăng

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 49:00–50:00 · Thời gian truyện: D7 night continuous

Mây giữ đối thoại, Hạ nhận ra lối thoát, Sơn không áp sát nòng súng.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Mây at the gallery entrance, Sơn behind her, Kiên holding Hạ near the rail. | Mây stops short and keeps a clear space between herself and the hostage pair. | Four positions readable, service hatch at Kiên's far side. | Mây (@May), nói trong hình: Cho Hạ đứng riêng. Tôi nghe anh. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Kiên gripping Hạ, handgun low but visible in his other hand. | He asks for a vehicle off the coast road, refusing to surrender. | Hạ looking toward the service hatch as Kiên watches Mây. | Kiên (@Vũ Kiên), nói trong hình: Một xe. Không ai theo. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây staying at the entrance with her hands visible. | She keeps him engaged while an officer reaches the service side unseen by Kiên. | Kiên facing the main entrance, service side outside his attention. | Mây (@May), nói trong hình: Muốn đi, trước hết bỏ tay khỏi cô ấy. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ recognizing Sơn's bare hands and bandaged left wrist behind Mây. | She gives him the same small downward glance used beside the old hatch. | Sơn following Hạ's eyeline toward the backup-light cable. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Thành below the gallery at the tested backup-light lever. | He sees the open route and waits for Mây's radio cue instead of touching anything accidentally. | Thành's hand near but not on the lever. | Thành, qua thiết bị: Tôi ở đèn dự phòng. Chờ lệnh. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ angled toward the inner wall, Kiên still holding her upper arm. | She asks to steady herself, shifting them one step away from the rail. | Hạ nearer the inner wall, Kiên pulled slightly off his preferred position. | Hạ (@Ha), nói trong hình: Cho tôi vịn tường. Tôi chóng mặt. |

**Âm nối sang cảnh sau:** Keep the established gallery wind and faint cable rattle. Backup light turns on only on the cue at 51.1.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
