# Kẻ Sống Sót: Bóng Ma — Cảnh 51: Tay Không Giữ Người

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 50:00–51:00 · Thời gian truyện: D7 night continuous

Hạ tạo khoảng hở, Sơn cứu cả kẻ thù, Mây bắt Kiên.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | MATCH · Match cut hình dạng/tư thế, không morph | Hạ near the inner wall, Kiên holding her arm, Mây still at the entrance. | Mây gives the short radio cue, the backup lamp turns on toward the sea, not into anyone's eyes. | Kiên looking toward the unexpected lamp, Hạ already near the inner wall. | Mây (@May), nói trong hình: Bật đèn. Giữ cửa phụ. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Kiên's attention shifted toward the lamp, Hạ beside the inner wall. | Hạ turns out of his loose grip and steps behind the doorway toward Mây. | Hạ behind Mây's line, Kiên no longer holding her. | — |
| [3](clip-3.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Hạ behind Mây's line, Kiên no longer holding her. | Kiên lunges after Hạ, Sơn uses his sound right arm to interrupt the reach. | Kiên stumbling backward toward the rail, Sơn off balance beside him. | — |
| [4](clip-4.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Kiên stumbling backward toward the rail, Sơn off balance beside him. | Kiên's heel catches the low rail, Sơn chooses to pull his jacket inward instead of letting him fall. | Both men on the inner gallery floor, handgun released away from them. | Sơn (@Son), nói trong hình: Giữ lấy tay tôi. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Released handgun on the inner floor, both men down and Hạ safely by the door. | Mây secures the handgun, an officer controls Kiên, Hạ steadies Sơn. | Kiên restrained under officer control, handgun secured as evidence. | Mây (@May), nói trong hình: Kiên, hết đường giữ người rồi. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn seated against the inner wall, Hạ beside him, Mây a few paces away. | Mây checks they are safe and gives them a moment while maintaining custody of Kiên. | Hạ and Sơn seated together, clear gallery space between them and Kiên. | — |

**Âm nối sang cảnh sau:** Only breathing and the steady backup lamp remain. Cut to the quiet watch scene without replaying the restraint.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
