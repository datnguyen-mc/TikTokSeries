# Kẻ Sống Sót: Bóng Ma — Cảnh 53: Người Không Chạy Nữa

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 52:00–53:00 · Thời gian truyện: D7 night continuous

Sơn tự nhận trách nhiệm, Hạ chấp nhận thay vì cản luật.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | L · L-cut: âm cũ đi qua cú cắt | Mây waiting at the gallery doorway, Hạ and Sơn standing with care. | Sơn approaches Mây on his own, keeping his hands where she can see them. | Sơn in front of Mây, Hạ one step behind. | Sơn (@Son), nói trong hình: Tôi đi với cô. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ beside Sơn before he reaches the doorway. | She asks if this is his choice, he answers without blaming her. | Hạ releasing his sleeve deliberately. | Hạ (@Ha), nói trong hình: Anh tự chọn chứ? |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn holding both hands forward, left wrist still bandaged. | Mây applies the cuffs carefully while an officer documents the condition of his wrist. | Cuffs fitted without pressing the bandage, Sơn standing upright. | Sơn (@Son), nói trong hình: Ừ. Lần này là anh chọn. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Closed watch in Sơn's cupped right hand, cuff chain below. | Hạ places it safely into his breast pocket with his consent. | One closed watch in his breast pocket, her hand withdrawn. | — |
| [5](clip-5.md) | L · L-cut: âm cũ đi qua cú cắt | Kiên already under escort farther down the stairs, group behind him separated. | Mây escorts Sơn, Thành supports Hạ, nobody overtakes on the narrow stair. | Both escorted groups descending in order, gallery empty behind. | — |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Group emerging from the main doorway, backup beam moving over the sea. | Hạ pauses to see her father's lighthouse working, then joins the others. | Hạ walking toward the waiting vehicle, light continuing behind her. | Hạ (@Ha), nói trong hình: Để đèn sáng tới khi mọi người về. |

**Âm nối sang cảnh sau:** Incoming station kettle and fan introduce the later interview after Hạ clothing change. Do not show the descent twice.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
