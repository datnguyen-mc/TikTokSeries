# Kẻ Sống Sót: Bóng Ma — Cảnh 54: Lời Khai Của Hạ

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 53:00–54:00 · Thời gian truyện: D7 late night

Hạ kể các lựa chọn mình đã làm và cung cấp chứng cứ mới.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | A later station scene, Hạ already changed into borrowed white blouse and jeans. | Mây brings tea, Thành starts a fresh witness record at a separate desk. | Hạ seated freely with scarf on chair, tea before her. | Mây (@May), nói trong hình: Mệt thì nghỉ. Tao vẫn ở đây. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Small scarf fragment sealed between Mây and Hạ. | Hạ explains she tore it on the flower-shop latch to leave a trace for anyone searching. | Hạ pointing to the torn edge without touching the seal. | Hạ, ngoài khung hình: Tao xé lúc bị đưa ra cửa. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Thành showing Hạ the saved video on a tablet. | She identifies the ferry emblem and the meal-delivery rhythm she used to count days. | Thành adding the identifiable transport detail to the statement. | Hạ (@Ha), nói trong hình: Còi tàu tới trước bữa tối. Ngày nào cũng vậy. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ holding her own empty palms above the table. | She describes deciding to keep the service hatch open when Kiên took her upward. | Mây listening without interrupting, Hạ's hands relaxing. | Hạ (@Ha), nói trong hình: Tao chỉ cần họ vào được sau tao. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hair clip recovered from the hatch, now in its own sealed bag. | Thành photographs Hạ identifying it and adds the recovery location. | Clip bag and station record together, chain of custody intact. | — |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Interview ended, Thành stopping the recorder in the background. | Hạ asks to see her father's house the following morning instead of asking only about Sơn. | Mây placing the old family-house key on the table. | Hạ (@Ha), nói trong hình: Mai đưa tao về nhà ba nhé. |

**Âm nối sang cảnh sau:** Match the central placement of the house key on Hạ table to the recorder on Sơn interview table, then begin a different account.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
