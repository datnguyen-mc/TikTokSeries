# Kẻ Sống Sót: Bóng Ma — Cảnh 55: Tên Của Những Cánh Cửa

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 54:00–55:00 · Thời gian truyện: D7 late night

Sơn nhận trách nhiệm cụ thể, không coi cứu Hạ là xóa tội.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | MATCH · Match cut hình dạng/tư thế, không morph | Recorder centered on the interview desk, Sơn seated on the other side. | Mây checks he understands the interview and starts the recording. | Recorder light steady, Sơn facing Mây. | Mây (@May), nói trong hình: Anh muốn khai từ việc nào? |
| [2](clip-2.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Recorder light steady, Sơn facing Mây. | Sơn names the first address and year, choosing facts instead of his nickname. | Mây writing an address in the private record, Sơn remaining seated. | Sơn (@Son), nói trong hình: Địa chỉ đầu tiên. Tôi nhớ người mở cửa. |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn looking at the paper rather than at his reflection in the window. | He states that fear and debt do not excuse what he did. | His bare hands flat on the table, no watch used as a prop. | Sơn (@Son), nói trong hình: Không ai bắt tay tôi làm. Tôi phải chịu. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây separating verified facts from items needing investigation. | She asks for names of people who can confirm the account and records each answer. | Two evidence columns on paper without readable text, Sơn cooperating. | Mây (@May), nói trong hình: Ai còn sống để xác nhận chuyện này? |
| [5](clip-5.md) | CONTINUE · Nối đúng frame, hành động tiếp diễn | Two evidence columns on paper without readable text, Sơn cooperating. | Sơn gives the next contact and signs the statement after reading it. | Statement signed, pen set aside once, hands withdrawn. | — |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Sơn seated in the holding room after the interview, corridor light outside. | He closes his eyes and rests with the wrist bandage visible, no new speech. | Sơn finally sleeping, closed watch secured in his pocket. | — |

**Âm nối sang cảnh sau:** Carry the station fan from the quiet holding room into morning evidence handover. Do not replay the statement or signature.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
