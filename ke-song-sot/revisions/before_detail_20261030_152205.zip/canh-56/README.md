# Kẻ Sống Sót: Bóng Ma — Cảnh 56: Sổ Tiền Thành Hồ Sơ

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 55:00–56:00 · Thời gian truyện: D8 morning

Bằng chứng được xác minh và đời sống thị trấn bắt đầu trở lại.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Investigator reviewing the sealed originals against Thành's handover record. | Mây delivers the remaining local witness files for the same case. | Complete evidence handover recorded, local copies retained. | Bộ đàm, qua thiết bị: Đã khớp sổ với xưởng và chuyến tàu. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Bảy returning an overturned chair to its regular place, Thành nearby. | They reopen the stall together, without retelling the whole fight. | Chair upright, first clean glass on the counter. | Ông Bảy (@Ông Bảy), nói trong hình: Giờ bán cà phê lại được chưa? |
| [3](clip-3.md) | L · L-cut: âm cũ đi qua cú cắt | Mây walking through the reopening fish market. | She checks on sellers who evacuated and thanks them for keeping the routes clear. | Mây with two unnamed sellers at the repaired side gate. | Mây (@May), nói trong hình: Cảm ơn mọi người đã đưa dân ra. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Linh at the clinic sink after filing his medical notes. | He hangs the emptied response bag to dry and sits down at last. | Bag drying above the bench, Linh resting with a cup of water. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Thành wearing replacement glasses, Mây at the case board. | They remove the emergency duty roster and restore the normal shift plan. | Emergency roster filed away, ordinary patrol map visible. | Thành (@Phó Thành), nói trong hình: Đêm nay trực lại như cũ hả chị? |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Hạ at the station doorway, Mây joining her with the family-house key. | They walk toward the harbour houses instead of the crime-scene pier. | Both walking side by side in morning light. | Mây (@May), nói trong hình: Về nhà trước. Chuyện khác tính sau. |

**Âm nối sang cảnh sau:** Keep ordinary town morning sound from the walk to the family-house threshold. Market-stall planning happens after the home entry.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
