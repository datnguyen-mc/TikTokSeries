# Kẻ Sống Sót: Bóng Ma — Cảnh 57: Chỗ Của Hạ

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 56:00–57:00 · Thời gian truyện: D8 morning

Hạ có mục tiêu đời sống riêng và bắt đầu thực hiện.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ and Mây at the family-house doorstep, key in Hạ's right hand. | Hạ unlocks her father's house, Mây remains outside until invited. | Door open, Hạ inside her own threshold. | Hạ (@Ha), nói trong hình: Vào đi. Nhà tao mà. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ before an old workbench with a lighthouse photograph. | She wipes a clear space and sets her own bag down, claiming the room. | Clean patch on the workbench, her bag beside it. | — |
| [3](clip-3.md) | L · L-cut: âm cũ đi qua cú cắt | Empty strip beside the fish-market entrance, no finished flower stall yet. | Hạ measures a modest place for a folding table, Mây holds the tape end. | Space marked with chalk, both facing the future stall position. | Hạ (@Ha), nói trong hình: Tao mở ở đây. Sáng người ta đi qua đông. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Hạ at the chalk mark, Mây holding the other end of the tape. | Mây asks whether Hạ wants to wait until the case ends, Hạ keeps measuring. | Tape extended to the agreed edge, Hạ making her own decision. | Hạ (@Ha), nói trong hình: Tao mở cho tao sống trước đã. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | One white lily from her father's small yard vase on the windowsill. | Hạ trims the stem and wraps only this flower in plain paper. | Single wrapped lily in Hạ's hand, remaining vase undisturbed. | — |
| [6](clip-6.md) | J · J-cut: âm mới đến trước hình | Hạ and Mây reaching the public walkway, transport engine heard near the station. | Hạ stays on the safe side of the walkway with the flower rather than running into the road. | Hạ visible from the transport lane, Mây beside her. | Hạ (@Ha), nói trong hình: Tao đứng đây. Ảnh sẽ thấy. |

**Âm nối sang cảnh sau:** Keep the approaching transport engine into Sơn window-side view. Hạ already holds the single lily; do not wrap it again.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
