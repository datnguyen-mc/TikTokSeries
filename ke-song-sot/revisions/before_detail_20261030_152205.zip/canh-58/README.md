# Kẻ Sống Sót: Bóng Ma — Cảnh 58: Qua Ô Cửa Xe

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 57:00–58:00 · Thời gian truyện: D8 late morning

Chia tay bằng một ánh nhìn, không diễn lại nhiều lần.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | J · J-cut: âm mới đến trước hình | Inside the prisoner transport, Sơn in olive jacket after a documented clothing change. | Thành sits opposite with the transfer file, signals the public walkway ahead. | Sơn turning toward the side window, Thành giving him space. | Thành (@Phó Thành), nói trong hình: Bên phải. Cạnh hàng cây. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | View from Sơn's window, Hạ at the public walkway with one wrapped lily. | She lifts the flower only to chest height as the vehicle approaches. | Hạ holding one lily against her chest, eyes on the moving window. | — |
| [3](clip-3.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn beside the mesh window, closed watch chain secured inside his jacket. | He acknowledges Hạ with one small nod, keeping his cuffed hands low. | Sơn's nod finished, eyes still following her. | — |
| [4](clip-4.md) | L · L-cut: âm cũ đi qua cú cắt | Transport already beyond Hạ, both women on the walkway. | Hạ lowers the flower and turns toward her chosen stall site. | Both women walking back toward the market, vehicle continuing away. | — |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Sơn facing forward again as the town thins outside. | Thành opens the destination transfer file, the journey continues without another farewell. | Sơn seated quietly, file open in Thành's lap. | Sơn, lời dẫn ngoài hình: Tôi rời đi bằng tên mình. |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Transport approaching the crossroad where the coach once stopped. | It takes the inland road and leaves the sea visible after it exits frame. | Empty crossroad, transport sound receding inland. | — |

**Âm nối sang cảnh sau:** Let the inland vehicle engine recede into cabin wind after the transport has left the picture.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
