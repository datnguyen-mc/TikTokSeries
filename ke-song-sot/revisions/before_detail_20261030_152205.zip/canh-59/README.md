# Kẻ Sống Sót: Bóng Ma — Cảnh 59: Căn Nhà Còn Mở Cửa

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 58:00–59:00 · Thời gian truyện: D8 afternoon

Thị trấn giữ ký ức nhưng tiếp tục sống, Hạ bắt tay làm sạp.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | L · L-cut: âm cũ đi qua cú cắt | Cabin door open, Bảy carrying a repair box, Mây with the final rental inventory. | They check the now-empty room together rather than preserving it as a shrine. | Empty bed, cleared table, repair box by the threshold. | Ông Bảy (@Ông Bảy), nói trong hình: Mai tui sửa lại cửa. Còn cho thuê. |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Seven marks on the damaged doorframe, no eighth mark. | Mây photographs the marks once for the file, then puts the camera away. | Seven marks still in wood, Mây's phone lowered. | — |
| [3](clip-3.md) | J · J-cut: âm mới đến trước hình | Hạ arriving with a folded market table, Bảy already outside. | She asks to use the porch to prepare flower buckets while the stall site is finished. | Folded table on porch, Bảy clearing space for it. | Hạ (@Ha), nói trong hình: Cho con mượn chỗ làm cái sạp nhé. |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Folded table on the porch, Bảy at one end, Hạ holding an empty bucket. | Bảy unfolds the table, Hạ checks its balance with an empty flower bucket. | Stable table, one empty bucket upright on it. | Ông Bảy (@Ông Bảy), nói trong hình: Nhà này gió. Làm chân bàn chắc vào. |
| [5](clip-5.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Mây holding the old damaged doorframe strip removed during repair. | Hạ asks to keep the small marked strip for the underside of her future counter. | Marked wood strip in Hạ's hands, new doorframe behind them. | Hạ (@Ha), nói trong hình: Để dưới quầy. Nhắc mình đã đi qua. |
| [6](clip-6.md) | L · L-cut: âm cũ đi qua cú cắt | Three people working around the unfinished flower table. | They sand and fit its legs in natural afternoon light, no one adding another tally. | Table standing straight, sawdust brushing away from its surface. | — |

**Âm nối sang cảnh sau:** Match the newly sanded table surface to the finished flower counter years later, with a clear morning/time change and older faces.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
