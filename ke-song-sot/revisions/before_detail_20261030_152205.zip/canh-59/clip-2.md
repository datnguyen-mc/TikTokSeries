[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@May = Mây: same approved identity, age 38; Vietnamese woman, athletic build, sun-lined face, short black hair with a distinctive white front streak. plain khaki shirt with rolled sleeves, dark trousers, no readable insignia, small notebook, discreet crossbody case pouch. Voice: firm, clear Southern Vietnamese female voice.



[TIMELINE AND LOCATION]
Scene 59/60, clip 2/6; shot 59.2. Story time: D8 afternoon.
One-room wooden cabin, porch on south seaward side, table below east window, cot west, rear exit north, marked entry frame.
Day-eight afternoon, warm working porch light, pine shadows moving naturally.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 59.1, ending with Empty bed, cleared table, repair box by the threshold.
Intentional editorial cut, not a continuous take. Start only in the new composition; preserve compatible screen direction and eyelines. No morph or duplicated gesture.

[START FRAME — state only, not an action to repeat]
Seven marks on the damaged doorframe, no eighth mark.

[CAMERA]
85mm locked detail shot. Hands and the relevant object remain spatially readable; no impossible macro reflections.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
Mây photographs the marks once for the file, then puts the camera away.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
No speech, narration, improvised dialogue or vocal filler. Keep the scene alive through the specified action and location sound.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
- Same wooden doorframe. Exactly 7 tally marks at the start and 7 at the end of THIS shot. No other tally row.

[SOUND]
Location bed: wind through wood joints and remote surf. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. 

[END FRAME — natural motion continues]
Seven marks still in wood, Mây's phone lowered.
Next shot 59.3: J-cut: âm mới đến trước hình. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
