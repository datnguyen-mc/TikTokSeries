# Kẻ Sống Sót: Bóng Ma — Cảnh 60: Buổi Sáng Có Người Về

**Bản 3 · 6 clip × 10 giây · 16:9 đầy khung · nguồn PHAN_CANH_V3.json**

Phút 59:00–60:00 · Thời gian truyện: LATER many years after the case

Kết bằng đời sống Hạ đã xây và một người trở lại.

Một clip là một cú máy. Chỉ dùng frame cuối làm đầu vào khi bảng ghi **CONTINUE**; các hàng khác là cú cắt có chủ đích và đính lại reference. Shot chỉ có người nền, không có reference được chỉ định, dùng text-to-video. Không dùng frame cũ để kéo qua địa điểm mới.

| Clip | Cách nối vào | Đầu clip | Hành động mới | Cuối clip | Thoại |
|---|---|---|---|---|---|
| [1](clip-1.md) | MATCH · Match cut hình dạng/tư thế, không morph | Finished flower counter years later, older Hạ arranging fresh lilies. | She opens the shutters of a working shop, old marked wood discreetly fixed underneath. | Shop open, Hạ behind the counter, morning customers blurred beyond. | — |
| [2](clip-2.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Older Mây stopping outside the shop with her helmet in hand. | She buys one ordinary bunch and exchanges a familiar look with Hạ. | Flowers in Mây's hand, Hạ handing back change. | Mây (@May), nói trong hình: Chiều ghé ăn cơm nhé. |
| [3](clip-3.md) | J · J-cut: âm mới đến trước hình | Older Bảy behind the same coffee counter, coach engine heard off screen. | He looks toward the crossroad, leaves a clean glass ready on the sea-facing table. | One empty chair at the sea-facing table, coach sound closer. | — |
| [4](clip-4.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | Coach door open, only an older man's jacket, bag and hands framed below shoulders. | The man steps down once, same repaired watch chain visible inside the jacket, coach departs. | Man standing with bag in left hand, right hand bare at his side. | — |
| [5](clip-5.md) | L · L-cut: âm cũ đi qua cú cắt | Hạ hearing the coach fade outside, one lily still in her hand. | She looks toward approaching footsteps, recognition arriving gradually without a run. | Hạ setting the single lily on the counter, eyes at the doorway. | — |
| [6](clip-6.md) | CUT · Cắt dựng đúng vị trí/ánh nhìn | From inside the shop, Hạ behind the counter, a bare hand entering the doorway edge. | The arriving hand rests on the counter without a new watch, Hạ makes room for him. | Hạ facing the unseen visitor, one lily between them, daylight beyond the door. | Hạ (@Ha), nói trong hình: Hôm nay ngồi nhìn biển với em nhé. |

**Âm nối sang cảnh sau:** End on Hạ recognition with continuing sea wind. Any title and final fade are added only in the edit.

[Bảng nối toàn phim](../BANG_NOI_CLIP.md) · [Kịch bản](../KICH_BAN_60_PHUT.md) · [Khóa và đạo cụ](../FLOW_PROMPTS.md)

Kiểm tra video render: mặt/đồ/đạo cụ, ánh nhìn, hướng đi, âm nền, không lặp động tác ở mối nối. Prompt quy định ý đồ; video vẫn cần xem nối đôi trước khi chốt dựng.
