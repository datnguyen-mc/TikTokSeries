[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Ông Bảy = Ông Bảy: same approved identity, age 90; Vietnamese man, stocky, white moustache, deeply tanned face. much older face and hands, same white moustache, white singlet, shorts, working slowly behind the coffee counter. Voice: resonant, friendly elderly Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 60/60, clip 3/6; shot 60.3. Story time: LATER many years after the case.
Bảy coffee stall, green canvas awning, counter landward, plastic tables seaward, street visible in the counter mirror.
Many years later, soft coastal morning, same geography, mature faces with natural skin texture.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 60.2, ending with Flowers in Mây's hand, Hạ handing back change.
J-cut in the edit: introduce the incoming location sound about 0.25s before the picture cut. This generated clip contains only the new shot, not a two-location montage.

[START FRAME — state only, not an action to repeat]
Older Bảy behind the same coffee counter, coach engine heard off screen.

[CAMERA]
35mm locked wide shot at human eye level. Preserve readable geography and screen direction.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
He looks toward the crossroad, leaves a clean glass ready on the sea-facing table.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
No speech, narration, improvised dialogue or vocal filler. Keep the scene alive through the specified action and location sound.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
No new featured prop. Preserve already established carried items; introduce no extra symbolic objects.

[SOUND]
Location bed: glasses touching and awning cloth in sea wind. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. 

[END FRAME — natural motion continues]
One empty chair at the sea-facing table, coach sound closer.
Next shot 60.4: Cắt dựng đúng vị trí/ánh nhìn. Do not perform its action inside this clip.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
