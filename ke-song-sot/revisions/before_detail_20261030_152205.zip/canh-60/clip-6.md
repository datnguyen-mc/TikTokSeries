[FORMAT]
10 seconds, full-frame horizontal 16:9, 24 fps, photorealistic live-action Vietnamese neo-noir drama. Natural 180-degree shutter and continuous human motion. Exactly ONE camera setup and ONE location per clip. No automatic montage, extra angle, opening recap or closing fade.

[CHARACTERS — approved identities and current appearances]
@Ha = Hạ: same approved identity, age 52; Vietnamese woman, slim build, gentle alert eyes, long black hair. older face, long hair with a little grey tied back, cream work blouse, green florist apron, the same pale-blue scarf. Voice: warm, clear Southern Vietnamese female voice.
@Son = Sơn: same approved identity, age 65; Vietnamese man, lean build, quiet dark eyes, thin white scar across the bridge of the nose. later years, older weathered hands, faded olive jacket, canvas bag, bare hands, frame below shoulders only without a face reveal. Voice: low, dry, unhurried Southern Vietnamese male voice.



[TIMELINE AND LOCATION]
Scene 60/60, clip 6/6; shot 60.6. Story time: LATER many years after the case.
Hạ completed flower stall years later at market entrance, working counter, old seven-mark wood strip discreetly fixed underneath, doorway toward coach stop.
Many years later, soft coastal morning, same geography, mature faces with natural skin texture.

[EDIT IN — do not render the previous shot again]
Previous editorial shot: 60.5, ending with Hạ setting the single lily on the counter, eyes at the doorway.
Intentional editorial cut, not a continuous take. Start only in the new composition; preserve compatible screen direction and eyelines. No morph or duplicated gesture.

[START FRAME — state only, not an action to repeat]
From inside the shop, Hạ behind the counter, a bare hand entering the doorway edge.

[CAMERA]
50mm locked medium shot at eye level. Let the gesture and reaction develop in the same composition.
For an editorial cut within the same room, choose a clearly distinct coverage angle (at least about 30 degrees) or a motivated detail shot, while remaining on the established side of the action axis. For CONTINUE keep the exact prior camera instead. Do not cut internally to satisfy this note.

[ACTION — 0–10s, one evolving take]
The arriving hand rests on the counter without a new watch, Hạ makes room for him.
Begin from the stated start state, complete this action once, and arrive at the stated end state. Do not pad with a second performance. Let breathing, fabric, water or other existing movement continue naturally through the final frame.

[DIALOGUE]
0.8–4.1s, one unhurried line only. Visible speaker alone delivers the line, mouth readable in this composition. Other people listen silently.

Hạ (@Ha), nói trong hình: Hôm nay ngồi nhìn biển với em nhé.
Speak only the words following the final colon. Do not read names, tags, timing or directions. No subtitles.

[PROPS]
Identity/history reference only. Perform only the current ACTION, never a future handover mentioned in a prop history.
No new featured prop. Preserve already established carried items; introduce no extra symbolic objects.

[SOUND]
Location bed: sea breeze, flower wrapping and distant town morning sounds. Use only established diegetic sources, including motivated off-screen ambience and the specified edit bridge. No independently generated score, recurring stock sting or invented weapon/impact effect. Dialogue above ambience. End on Hạ recognition with continuing sea wind. Any title and final fade are added only in the edit.

[END FRAME — natural motion continues]
Hạ facing the unseen visitor, one lily between them, daylight beyond the door.
End the film on this living composition. Any title and final fade are added in the edit, never generated inside the image.

[AVOID]
repeated action or line from adjacent clips, frozen tail frames, premature scene change, arbitrary slow motion or speed ramps, identity/age/costume drift, extra watches or scarves, wrong prop owner, reversed movement axis, readable text, generated captions, logos, real actor likeness, graphic injury, blood, gunfire or instructional drug-use detail.
