Continue the scene seamlessly from the final frame of clip 2, matching position, light and 16:9 framing exactly, as one unbroken take.
Widescreen 16:9 (2.39:1 anamorphic ratio), 10-second clip, photorealistic live-action Vietnamese neo-noir mystery drama film style. 24fps high-budget cinematography, crisp 90-degree shutter angle, razor-sharp motion. Bleached white-sun colour grade with cool shadows for the present day. Clean cinematic staging. Spoken dialogue in natural Southern Vietnamese with accurate lip-sync; voice-over narration allowed. Cut only where the shot list says. No subtitles or on-screen text.

[CHARACTERS — unchanged]
@May = MÂY: Vietnamese woman, 38, short hair with a white streak at the front, sun-lined face, khaki shirt with rolled sleeves, notebook in her chest pocket, steel cuffs on her belt, no insignia; firm, dry Southern female voice.

[SETTING]
CABIN IN THE CASUARINA PINES: an old wooden cabin on a dune above a small seaside town, sagging porch with a wooden table, tin roof, one room with a cot, a table, a radio, an oil lamp, carved day-marks on the doorframe; wind and sea sound; white glaring sun outside.
Story setting: Hiên nhà gỗ, chiều ngày 3, nắng vàng nghiêng, gió, bàn gỗ ngoài hiên.
Scene 14/60, timecode 13:00 – 14:00, clip 3/6 (20–30s of the scene). Atmosphere: quiet noir melancholy, cinematic Vietnamese neo-noir.

[CAMERA & LIGHT]
Patient neo-noir 50mm and 85mm prime-lens cinematography with shallow depth of field, slow dolly moves, long close-ups on weathered faces, hands and small objects. White bleached daylight for the present or warm amber lamp light for the past, deep shadows, natural skin tones, light cinematic grain.

[SHOT LIST]
00:00–00:03.5 | Static 28mm wide, natural directional light shaping the scene — Không có khoảng dừng giữa hai clip: Mây (@May) ngồi xuống; radio rè một bản tin xa.
00:03.5–00:07.0 | 50mm medium close-up on the speaker's face, clear lip-sync — không chạm cả hai thứ, nói về mình: cô làm công an thị trấn mười năm, chưa bắt ai lớn hơn kẻ trộm ghe. Một câu, một hơi, môi khớp từng âm: Mây (@May): "Tôi giữ luật. Luật không có bốn ngày."
00:07.0–00:10.0 | 50mm medium close-up with shallow depth of field — cô là người giữ luật. Bất động 0.5s ở khung này.

[SOUND]
Âm thanh nền: mạt gỗ rơi, cửa gỗ kẽo kẹt; không nhạc, chỉ nền. Lời thoại nổi trên nền.

[END FRAME]
Hold on Cô là người giữ luật for 0.5s, no camera drift, so the next clip extends seamlessly.

[AVOID]
subtitles, captions, on-screen text, readable signs or documents, real brand logos, real police insignia, watermarks, text overlays, extra fingers, distorted hands, cartoon or anime look, slow sluggish motion, blurry motion smear, jump cuts, likeness of any real actor.
