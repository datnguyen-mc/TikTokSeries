[FORMAT]
Widescreen 16:9 (2.39:1 anamorphic ratio), 10-second clip, photorealistic live-action Vietnamese neo-noir mystery drama film style set in a small Vietnamese seaside town and a big city at night. 24fps high-budget cinematography, crisp 90-degree shutter angle, razor-sharp motion. Bleached white-sun colour grade with cool shadows for the present day. Clean cinematic staging. Dialogue in Vietnamese with natural Southern accent and accurate lip-sync; first-person narration allowed as voice-over. No subtitles or on-screen text.

[CHARACTERS — match attached reference images]
@Son = SƠN (45, a legendary former underground operative known as the Ghost, now hiding in a small seaside town): a real Vietnamese man, about 176 cm tall, lean and quiet, cropped black hair greying at the temples, a weathered calm face with deep lines, dark unreadable eyes, a thin old white scar across the bridge of his nose (signature detail), a silver pocket-watch chain hanging from his belt (signature detail). Present-day outfit: a faded olive field jacket over a grey shirt, dark trousers, worn brown boots. Voice: low, dry, unhurried Southern Vietnamese male voice, mid-40s. Not resembling any real actor.
@May = MÂY (38, head of the small-town police post of Hòn Sóng): a real Vietnamese woman, about 166 cm tall, athletic, sun-lined face, sharp warm eyes, short black hair with a single white streak at the front (signature detail). Outfit: a plain khaki shirt with sleeves rolled, dark trousers, canvas shoes, no badge or readable insignia, a small notebook in her chest pocket, steel cuffs on her belt. Voice: firm, dry, slightly amused Southern Vietnamese female voice, late 30s.

[SETTING]
SMALL-TOWN POLICE POST: a tiled front room with a steel desk, a ceiling fan, an old computer, a holding room with a barred window, a motorbike outside; no readable insignia.
Story setting: Phòng giữ của đồn, đêm khuya, cửa sổ song sắt, đèn vàng.
Scene 55/60, timecode 54:00 – 55:00, clip 1/6 (0–10s of the scene). Atmosphere: cold ticking tension, cinematic Vietnamese neo-noir.

[CAMERA & LIGHT]
Controlled 50mm and 85mm push-ins on faces, phones, radios and documents, balanced two-shots across the space, slow dolly around the room. Cold fluorescent or grey window light, high contrast, held breath pacing.

[SHOT LIST]
00:00–00:03.5 | Close-up on the key object, then smooth tilt up to the face — Mở màn cảnh này: Sơn (@Son) tỉnh dậy trên băng ghế; quạt trần quay chậm trên đầu.
00:03.5–00:07.0 | 50mm medium close-up on the speaker's face, clear lip-sync — Mây (@May) ngồi ghế đối diện với sổ tay mở, máy ghi âm nhỏ trên bàn. Thoại khớp môi, người nghe ở nửa khung còn lại: Mây (@May): "Anh khai không?" · Sơn (@Son): "Khai hết. Mọi cánh cửa."
00:07.0–00:10.0 | 50mm medium close-up on the reaction, held steady — cô hỏi anh có khai không. Dừng ở khung này nửa giây để clip 2 nối vào.

[SOUND]
Âm thanh nền: còng va bàn thép; dây đàn căng một nốt. Nền nhỏ hơn giọng người.

[END FRAME]
End on: Cô hỏi anh có khai không. Hold that exact frame still for 0.5s; clip 2 starts from it.

[AVOID]
subtitles, captions, on-screen text, readable signs or documents, real brand logos, real police insignia, watermarks, text overlays, extra fingers, distorted hands, cartoon or anime look, slow sluggish motion, blurry motion smear, jump cuts, likeness of any real actor.
