import json, subprocess, sys, numpy as np, soundfile as sf
sys.path.insert(0,'/home/claude/k1000'); sys.path.insert(0,'/home/claude/dope'); sys.path.insert(0,'/home/claude/film')
from music import music
import sfx2
from scipy.ndimage import uniform_filter1d, maximum_filter1d
SR=48000
CH=json.load(open('chapters.json')); TZ=json.load(open('cards/teaser.json'))
def dur(p): return float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',p],capture_output=True,text=True).stdout)
seq=[('teaser','cards/teaser.mp4',None),('title','cards/title.mp4',None)]
for i,c in enumerate(CH): seq+= [(f'ch{i+1}',f'cards/ch{i+1}.mp4',None),(c['key'],f"src/{c['key']}/clean.mp4",c)]
seq.append(('outro','cards/outro.mp4',None))
XF={('teaser','title'):0.3}
items=[]; t=0.0
for k,(name,path,c) in enumerate(seq):
    d=dur(path); x= 0 if k==0 else XF.get((seq[k-1][0],name),0.4)
    start=t-x; items.append(dict(name=name,path=path,d=d,start=round(start,4),xf=x,ch=c)); t=start+d
TOTAL=t; json.dump(dict(items=items,total=TOTAL),open('edl.json','w'),indent=1,ensure_ascii=False)
print('total',round(TOTAL,2))
# ---------- picture ----------
inp=[]; fc=[]
for k,it in enumerate(items): inp+=['-i',it['path']]; fc.append(f"[{k}:v]fps=30,format=yuv420p,setsar=1,settb=AVTB[s{k}]")
prev='s0'
for k in range(1,len(items)):
    it=items[k]; kind='fade'; out=f'x{k}'
    fc.append(f"[{prev}][s{k}]xfade=transition={kind}:duration={it['xf']}:offset={it['start']:.4f}[{out}]"); prev=out
GRADE="eq=contrast=1.06:saturation=1.08:gamma=0.98,colorbalance=rs=-0.02:bs=0.03:rh=0.03:gh=0.01:bh=-0.03,vignette=angle=PI/5,noise=alls=3:allf=t"
fc.append(f"[{prev}]{GRADE}[graded]")
subprocess.run(['ffmpeg','-y','-loglevel','error']+inp+['-filter_complex',';'.join(fc),'-map','[graded]','-c:v','libx264','-crf','16','-preset','fast','-pix_fmt','yuv420p','-r','30','out/picture_graded.mp4'],check=True)
print('picture done')
# ---------- sound ----------
N=int((TOTAL+0.5)*SR)
B={k:np.zeros((N,2),np.float32) for k in ['dia','mus','sfx','amb']}
def put(bus,x,t,g=1.0):
    x=np.asarray(x,np.float32)
    if x.ndim==1: x=np.stack([x,x],1)
    p=int(t*SR); 
    if p>=N: return
    n=min(len(x),N-p); B[bus][p:p+n]+=x[:n]*g
def fade(x,fi,fo):
    x=np.array(x,np.float32,copy=True); a=int(fi*SR); b=int(fo*SR)
    if a: x[:a]*=np.linspace(0,1,a)[:,None] if x.ndim==2 else np.linspace(0,1,a)
    if b: x[-b:]*=np.linspace(1,0,b)[:,None] if x.ndim==2 else np.linspace(1,0,b)
    return x
S=lambda k,d=None: sfx2.make(k,d)
it={i['name']:i for i in items}
# teaser: tension bed, hits on every cut, riser into title boom
T0=it['teaser']['start']; Tt=it['title']['start']
bed=music('tense',it['teaser']['d']+it['title']['d']+1)[:int((Tt+it['title']['d']-T0)*SR)]
put('mus',fade(bed,1.2,1.0),T0,0.55)
put('amb',fade(S('low_drone',TZ['open']+0.5),0.6,0.5),T0,0.5)
for i in range(len(TZ['shots'])):
    tc=T0+TZ['open']+i*TZ['shot']
    put('sfx',S('whoosh'),max(0,tc-0.28),0.32); put('sfx',S('thud'),tc,0.7); put('sfx',fade(S('rumble',0.7),0.0,0.4),tc,0.25)
put('sfx',S('swell'),Tt-1.7,0.55); put('sfx',S('thud'),Tt,1.0); put('sfx',fade(S('rumble',2.2),0,1.2),Tt,0.6); put('sfx',S('chime'),Tt+1.2,0.25)
# chapters: card stingers, J-cut ambience under card, L-cut ambience tail
for i,c in enumerate(CH):
    cd=it[f'ch{i+1}']; fm=it[c['key']]
    put('sfx',S('whoosh'),cd['start'],0.4); put('sfx',fade(S('rumble',1.6),0,0.8),cd['start']+0.05,0.35); put('sfx',S('chime'),cd['start']+0.55,0.22)
    a0=cd['start']+0.3; a1=fm['start']+fm['d']+1.2
    put('amb',fade(S(c['amb'],a1-a0),1.0,1.5),a0,0.12)
    src=f"src/{c['key']}"
    for bus,f in [('dia','voice'),('mus','music'),('sfx','sfx')]:
        x,_=sf.read(f'{src}/{f}.wav',dtype='float32'); put(bus,x,fm['start'])
o=it['outro']; put('mus',fade(music('hopeful',o['d']+1.0),0.6,1.6),o['start']-0.3,0.45); put('sfx',S('chime'),o['start']+0.3,0.3)
# duck ambience + teaser music under dialogue
v=np.abs(B['dia']).max(1); env=uniform_filter1d(maximum_filter1d(v,int(0.08*SR)),int(0.3*SR)); duck=(1-0.5*np.clip(env/0.07,0,1))[:,None]
B['amb']*=duck
mix=sum(B.values())
sf.write('/tmp/_m.wav',mix,SR,subtype='FLOAT')
r=subprocess.run(['ffmpeg','-hide_banner','-i','/tmp/_m.wav','-af','ebur128','-f','null','-'],capture_output=True,text=True).stderr
I=float([l for l in r.splitlines() if l.strip().startswith('I:')][-1].split()[1]); g=10**((-14-I)/20)
pk=np.abs(mix).max()*g
if pk>0.89: g*=0.89/pk
for k,x in B.items(): sf.write(f'out/stem_{k}.wav',x*g,SR,subtype='PCM_24')
sf.write('out/mix.wav',mix*g,SR,subtype='PCM_24'); print('audio I',I,'gain',round(20*np.log10(g),2),'peak',round(pk,3))
