import json, subprocess, os
WS='/Users/iseul-a/Documents/TikTokSeries/stickman'; D=f'{WS}/00-phim-tong-hop'; SRC='00-phim-tong-hop/master_clean_graded.mp4'
env=dict(os.environ, PATH='/opt/node24/bin:'+os.environ['PATH'], MAKEMYCLIP_WORKSPACE=WS, MAKEMYCLIP_FFMPEG_PATH='/usr/bin/ffmpeg')
def clip(*a):
    r=subprocess.run(['/home/claude/mmc-run/node_modules/.bin/clip','timeline']+[str(x) for x in a],cwd=WS,env=env,capture_output=True,text=True)
    if r.returncode: raise SystemExit(f'{a[:2]}: {r.stderr[-600:]}')
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
E_=json.load(open('/home/claude/movie/edl.json')); items=E_['items']
total=float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',f'{WS}/{SRC}'],capture_output=True,text=True).stdout)
for f in ['composition.json','composition-ops.json']:
    if os.path.exists(f'{WS}/{f}'): os.remove(f'{WS}/{f}')
clip('new','--width',720,'--height',1280,'--fps',30)
cuts=[0.0]+[round(it['start']+it['xf']/2,3) for it in items[1:]]+[round(total,3)]
for k,it in enumerate(items):
    a,b=cuts[k],cuts[k+1]
    clip('add-media',SRC,a,b,'--start',a,'--track','V1')
import re
ass=open('/home/claude/movie/out/subs_vi.ass',encoding='utf-8').read().splitlines()
def tsec(s): h,m,x=s.split(':'); return int(h)*3600+int(m)*60+float(x)
n=0
for l in ass:
    if not l.startswith('Dialogue: 0,'): continue
    p=l.split(',',9); a,b=tsec(p[1]),tsec(p[2]); tx=re.sub(r'\{[^}]*\}','',p[9])
    clip('add-text',tx,round(max(0.15,b-a),3),'--start',round(a,3),'--track','CAP','--font',64,'--color','white','--anchor','bottom-center'); n+=1
print('sections',len(items),'captions',n)
print(json.dumps(clip('show'))[:300])
