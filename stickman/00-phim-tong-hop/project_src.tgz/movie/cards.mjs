// title / chapter / outro cards, 720x1280 @30
import fs from "node:fs"; import { spawn } from "node:child_process";
import { createRequire } from "node:module"; const require = createRequire(import.meta.url);
const { createCanvas, loadImage, GlobalFonts } = require("/home/claude/repo/stickman-video-director/skills/directing-stickman-videos/node_modules/@napi-rs/canvas");
GlobalFonts.registerFromPath("/home/claude/repo/stickman-video-director/skills/directing-stickman-videos/assets/fonts/Anton.ttf", "Anton");
GlobalFonts.registerFromPath("/home/claude/repo/stickman-video-director/skills/directing-stickman-videos/assets/fonts/NotoSans.ttf", "Noto");
const W = 720, H = 1280, FPS = 30;
const cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v)), ss = (u) => { u = cl(u); return u * u * (3 - 2 * u); }, lerp = (a, b, u) => a + (b - a) * u;
const ob = (u) => { u = cl(u); const c = 1.7; return 1 + (c + 1) * Math.pow(u - 1, 3) + c * Math.pow(u - 1, 2); };
function text(ctx, s, x, y, size, color, { font = "Anton", alpha = 1, spacing = 0, stroke = 0 } = {}) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.font = `${size}px ${font}`; ctx.textAlign = "center"; ctx.textBaseline = "alphabetic";
  if (spacing) ctx.letterSpacing = `${spacing}px`;
  if (stroke) { ctx.lineJoin = "round"; ctx.lineWidth = stroke; ctx.strokeStyle = "rgba(0,0,0,0.85)"; ctx.strokeText(s, x, y); }
  ctx.fillStyle = color; ctx.fillText(s, x, y); ctx.restore();
}
function grain(ctx, t) { const g = ctx.getImageData(0, 0, W, H); const d = g.data; let seed = (t * 1000) | 0;
  for (let i = 0; i < d.length; i += 4 * 3) { seed = (seed * 1103515245 + 12345) & 0x7fffffff; const n = ((seed >> 16) & 31) - 16; d[i] += n; d[i + 1] += n; d[i + 2] += n; } ctx.putImageData(g, 0, 0); }
function vign(ctx, a = 0.75) { const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.2, W / 2, H / 2, H * 0.75); g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, `rgba(0,0,0,${a})`); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); }
async function render(out, dur, draw) {
  const cv = createCanvas(W, H); const ctx = cv.getContext("2d");
  const ff = spawn("ffmpeg", ["-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${W}x${H}`, "-r", "30", "-i", "-", "-f", "lavfi", "-t", String(dur), "-i", "anullsrc=r=48000:cl=stereo", "-shortest", "-c:v", "libx264", "-crf", "16", "-preset", "medium", "-pix_fmt", "yuv420p", "-c:a", "aac", out], { stdio: ["pipe", "inherit", "inherit"] });
  const N = Math.round(dur * FPS);
  for (let f = 0; f < N; f++) { const t = f / FPS; ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.filter = "none"; ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H); draw(ctx, t, dur); grain(ctx, t);
    if (!ff.stdin.write(Buffer.from(cv.data()))) await new Promise(r => ff.stdin.once("drain", r)); }
  ff.stdin.end(); await new Promise(r => ff.on("close", r)); console.log("card", out);
}
const fadeIO = (ctx, t, dur, i = 0.35, o = 0.35) => { const a = Math.min(cl(t / i), cl((dur - t) / o)); if (a < 1) { ctx.fillStyle = `rgba(0,0,0,${1 - a})`; ctx.fillRect(0, 0, W, H); } };
const CH = JSON.parse(fs.readFileSync("/home/claude/movie/chapters.json", "utf8"));
const only = process.argv[2];
if (!only || only === "title") await render("/home/claude/movie/cards/title.mp4", 3.6, (ctx, t, d) => {
  const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#0b0f1a"); g.addColorStop(1, "#1a1206"); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  const sweep = lerp(-300, W + 300, ss((t - 0.6) / 1.6)); const lg = ctx.createLinearGradient(sweep - 160, 0, sweep + 160, 0); lg.addColorStop(0, "rgba(255,210,120,0)"); lg.addColorStop(0.5, "rgba(255,210,120,0.18)"); lg.addColorStop(1, "rgba(255,210,120,0)"); ctx.fillStyle = lg; ctx.fillRect(0, 0, W, H);
  const k = ob((t - 0.15) / 0.6); ctx.save(); ctx.translate(W / 2, 600); ctx.scale(lerp(1.25, 1, ss(t / 1.2)), lerp(1.25, 1, ss(t / 1.2)));
  text(ctx, "CHUYỆN LẠ", 0, -120, 74, "#ffffff", { alpha: cl(t / 0.5), spacing: 14 });
  text(ctx, "LOÀI NGƯỜI", 0, 40, 150, "#ffd84d", { alpha: cl((t - 0.3) / 0.4), stroke: 10 }); ctx.restore();
  const lw = 420 * ss((t - 0.9) / 0.7); ctx.fillStyle = "#ffd84d"; ctx.fillRect(W / 2 - lw / 2, 690, lw, 5);
  text(ctx, "1902  →  3026", W / 2, 770, 58, "#ffffff", { alpha: cl((t - 1.2) / 0.5), spacing: 6 });
  text(ctx, "4 câu chuyện · từ quá khứ đến tương lai", W / 2, 840, 30, "#c9c9c9", { font: "Noto", alpha: cl((t - 1.6) / 0.5) });
  vign(ctx, 0.8); fadeIO(ctx, t, d, 0.3, 0.45);
});
for (const [i, c] of CH.entries()) { if (only && only !== `ch${i + 1}`) continue;
  const bgImg = await loadImage(c.still);
  await render(`/home/claude/movie/cards/ch${i + 1}.mp4`, 2.6, (ctx, t, d) => {
    ctx.save(); ctx.filter = "blur(14px) brightness(0.45) saturate(0.8)"; const z = lerp(1.15, 1.25, t / d); ctx.translate(W / 2, H / 2); ctx.scale(z, z); ctx.drawImage(bgImg, -W / 2, -H / 2, W, H); ctx.restore();
    vign(ctx, 0.85);
    text(ctx, `CHƯƠNG ${i + 1}`, W / 2, 418, 40, "#ffffff", { alpha: cl(t / 0.35), spacing: 12 });
    const k = ob((t - 0.15) / 0.45); ctx.save(); ctx.translate(W / 2, 640); ctx.scale(k, k); text(ctx, c.year, 0, 0, 190, "#ffd84d", { stroke: 10 }); ctx.restore();
    const lw = 360 * ss((t - 0.4) / 0.5); ctx.fillStyle = "#ffd84d"; ctx.fillRect(W / 2 - lw / 2, 690, lw, 5);
    let fs = 76; ctx.font = `${fs}px Anton`; while (ctx.measureText(c.title).width > 620 && fs > 40) { fs -= 2; ctx.font = `${fs}px Anton`; }
    text(ctx, c.title, W / 2, 790, fs, "#ffffff", { alpha: cl((t - 0.5) / 0.4), stroke: 8 });
    text(ctx, c.sub, W / 2, 850, 30, "#d0d0d0", { font: "Noto", alpha: cl((t - 0.8) / 0.4) });
    fadeIO(ctx, t, d, 0.25, 0.3);
  });
}
if (!only || only === "outro") await render("/home/claude/movie/cards/outro.mp4", 4.5, (ctx, t, d) => {
  const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#0b0f1a"); g.addColorStop(1, "#1a1206"); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  text(ctx, "CÒN TIẾP...", W / 2, 560, 120, "#ffd84d", { alpha: cl(t / 0.5), stroke: 8 });
  text(ctx, "Bạn muốn nghe chuyện nào tiếp theo?", W / 2, 660, 34, "#ffffff", { font: "Noto", alpha: cl((t - 0.6) / 0.5) });
  text(ctx, "Bình luận & theo dõi để xem tập sau", W / 2, 720, 30, "#c9c9c9", { font: "Noto", alpha: cl((t - 1.0) / 0.5) });
  vign(ctx, 0.8); fadeIO(ctx, t, d, 0.4, 0.9);
});
