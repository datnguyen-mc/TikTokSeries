import json
E=json.load(open('edl.json')); it={i['name']:i for i in E['items']}; CH=json.load(open('chapters.json')); TZ=json.load(open('cards/teaser.json'))
def ts(t,ass=True):
    t=max(0,t)
    if ass:
        cs=int(round(t*100)); return f"{cs//360000}:{cs//6000%60:02d}:{cs//100%60:02d}.{cs%100:02d}"
    ms=int(round(t*1000)); return f"{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d},{ms%1000:03d}"
ev=[]
for c in CH:
    st=it[c['key']]['start']; cap=json.load(open(f"src/{c['key']}/captions.json"))
    for g in cap: ev.append((st+g['s']-0.03, st+g['e'], g['text']))
ev.sort()
hdr="""[Script Info]
ScriptType: v4.00+
PlayResX: 720
PlayResY: 1280
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,Anton,90,&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,0,0,0,0,100,100,1,0,1,7,2,2,40,40,285,1
Style: Tease,Anton,78,&H004DD8FF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,3,0,1,6,0,5,40,40,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
lines=[]
for a,b,tx in ev: lines.append(f"Dialogue: 0,{ts(a)},{ts(b)},Cap,,0,0,0,,{{\\fscx82\\fscy82\\t(0,130,\\fscx100\\fscy100)}}{tx}")
T0=it['teaser']['start']
lines.append(f"Dialogue: 1,{ts(T0+0.25)},{ts(T0+TZ['open']-0.05)},Tease,,0,0,0,,{{\\fad(250,200)\\pos(360,620)}}NHỮNG CHUYỆN CÓ THẬT...")
t1=T0+TZ['open']+7*TZ['shot']
lines.append(f"Dialogue: 1,{ts(t1)},{ts(T0+TZ['open']+10*TZ['shot']-0.1)},Tease,,0,0,0,,{{\\fad(200,200)\\pos(360,1080)}}...VÀ NHỮNG ĐIỀU SẮP ĐẾN")
open('out/subs_vi.ass','w',encoding='utf-8').write(hdr+"\n".join(lines)+"\n")
srt=[f"{i+1}\n{ts(a,False)} --> {ts(b,False)}\n{tx}\n" for i,(a,b,tx) in enumerate(ev)]
open('out/Chuyen_la_loai_nguoi_VI.srt','w',encoding='utf-8').write("\n".join(srt))
print(len(ev),'captions')
