import subprocess, json
S = [("rat",10.4),("rat",24.1),("emu",2.4),("emu",10.0),("emu",26.4),("noai",1.6),("noai",8.4),("h1000vi",6.0),("h1000vi",33.6),("h1000vi",46.6)]
SH = 1.3; OPEN = 2.0
parts = []; fc = []
# black cold open
inputs = ["-f","lavfi","-t",str(OPEN),"-i","color=c=black:s=720x1280:r=30"]
fc.append("[0:v]format=yuv420p,setsar=1[v0]")
for i,(k,t) in enumerate(S):
    inputs += ["-ss",str(t),"-t",str(SH),"-i",f"src/{k}/clean.mp4"]
    # subtle push-in punch per shot
    fc.append(f"[{i+1}:v]scale=792:1408,zoompan=z='1+0.0022*on':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=720x1280:fps=30,trim=duration={SH},setpts=PTS-STARTPTS,format=yuv420p,setsar=1[v{i+1}]")
fc.append("".join(f"[v{i}]" for i in range(len(S)+1)) + f"concat=n={len(S)+1}:v=1:a=0[out]")
cmd = ["ffmpeg","-y","-loglevel","error"] + inputs + ["-filter_complex",";".join(fc),"-map","[out]","-c:v","libx264","-crf","16","-preset","medium","-r","30","cards/teaser.mp4"]
subprocess.run(cmd, check=True)
json.dump({"open":OPEN,"shot":SH,"shots":S,"dur":OPEN+SH*len(S)}, open("cards/teaser.json","w"))
print("teaser", OPEN+SH*len(S))
