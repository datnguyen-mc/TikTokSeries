import json
STY="flat 2D cartoon stick-figure style: big round white heads, tiny black dot eyes, simple expressive eyebrows and mouths, thin black stick arms and legs, simple coloured clothes on the torso, thick clean black outlines, flat colours"
CAST=("cast Character lineup sheet 16:9, "+STY+". Five characters standing in one row, full body, same scale, widely separated, plain flat white background, no ground line, no shadows, no text, no letters. "
"1) Victor: a dapper 1920s con man, thin black pencil mustache, black bowler hat, charcoal pinstripe three-piece suit with a red pocket square, holding a slim cane, sly confident smile. "
"2) André: a nervous wealthy 1920s Paris scrap-metal businessman, round spectacles, brown flat cap, brown tweed suit, small bow tie, eager expression. "
"3) a bald 1920s scrap dealer with a bushy grey beard and a grey suit. "
"4) a 1920s French policeman in a dark blue uniform and a round kepi cap. "
"5) a 1920s house painter in white overalls with a paint brush.")
SUF=(" Match the attached reference image exactly for this character's design, face style, hat, clothes, colours and line weight. Plain flat white background, no ground line, no shadows, no scenery, no text, no letters. Full-body poses, same scale, widely separated with empty white space between them, nothing overlapping or touching the image edge.")
def sh(k,who,p): return f"{k} Pose sheet 16:9: {who} from the reference image in {len(p)} different poses in one row. "+" ".join(f"Pose {i+1}: {x}." for i,x in enumerate(p))+" Expressive cartoon acting."+SUF
P={'cast':CAST}
V="Victor (bowler hat, pencil mustache, pinstripe suit)"
P['vic1']=sh('vic1',V,["tipping his bowler hat with a charming smile","reading an open newspaper with a sly grin","pressing a rubber stamp onto a paper on an invisible desk, smug","presenting with both arms open wide, confident salesman"])
P['vic2']=sh('vic2',V,["finger on his lips going shhh, eyes glancing sideways","sighing with a hand on his chest, looking sad and humble","fanning out a big stack of cash with a greedy grin","running away fast to the right carrying a small suitcase"])
P['vic3']=sh('vic3',V,["shrugging with palms up and winking","pointing up proudly at something high above","holding up a single banknote and inspecting it with a magnifying glass","sitting gloomily on a prison bench wearing a black-and-white striped prison uniform, no hat"])
A="André (round spectacles, flat cap, tweed suit, bow tie)"
P['andre1']=sh('andre1',A,["rubbing his hands together eagerly with big hopeful eyes","thinking with a hand on his chin, eyebrows raised","handing over a thick envelope with both hands, nervous smile","face-palming in embarrassment, slumped shoulders"])
P['extras1']=("extras1 Character sheet 16:9 in the same style as the attached reference image: six separate full-body figures in one row. "
"1) the bald bearded scrap dealer sitting on an invisible chair nodding; 2) a second scrap dealer with a flat cap and red scarf sitting on an invisible chair, amazed; 3) the French policeman blowing a whistle and running; "
"4) the French policeman standing with arms crossed, suspicious; 5) the house painter painting upward with a long brush, tired; 6) a newsboy in a cap holding up a newspaper. Same scale, widely separated, plain flat white background, no ground line, no shadows, no text, no letters.")
PS=" Same flat 2D cartoon style as the attached reference. Each item separate with wide white space, plain flat white background, no shadows, no text, no letters, no numbers."
P['props1']="props1 Prop sheet 16:9: 1) a folded 1920s newspaper with blurry grey squiggle lines instead of text; 2) an official letter with a red wax seal; 3) a thick stack of banknotes tied with a paper band; 4) a fat brown envelope; 5) a brown leather suitcase; 6) a bucket of brown paint with a brush; 7) a wooden rubber stamp; 8) a small model of the Eiffel Tower."+PS
P['props2']="props2 Prop sheet 16:9: 1) a pair of steel handcuffs; 2) a brass police whistle; 3) a round pocket watch; 4) a pile of gold coins; 5) a single green banknote; 6) a magnifying glass; 7) a red CONFIDENTIAL-style folder with no writing; 8) a flying stack of money with wings."+PS
BG=(" Vertical 9:16 background plate, stylized 3D animated-film render, semi-realistic textures, cinematic warm lighting, soft depth of field, NO people, NO characters, no text, no letters, no logos, no signs with writing."
    " Keep the lower-middle area open as a clear floor where characters will stand (floor at about 80% of the height). Scene: ")
B={
'k01':"a 1925 Paris cobblestone street with old cars and gas lamps, the Eiffel Tower towering in the background, golden morning light",
'k02':"a close-up looking up at rusty brown iron lattice girders of the Eiffel Tower, wooden scaffolding, paint buckets on a platform, grey Paris sky",
'k03':"a cozy 1920s Paris cafe interior, small round marble table by a window, cup of coffee, warm light",
'k04':"a dim 1920s office desk with an old typewriter, rubber stamps, ink pad, stacks of blank letter paper and a green banker's lamp",
'k05':"a luxurious 1920s Paris grand hotel suite with crystal chandelier, gold mouldings, velvet curtains, tall windows",
'k06':"a private 1920s meeting room with a long polished wooden table, leather chairs, cigar smoke, a window view of Paris rooftops",
'k07':"a dim hotel corridor at night with red carpet, wall sconces and closed doors, moody shadows",
'k08':"a 1920s Paris railway station platform with a steaming black locomotive, iron and glass roof, smoke",
'k09':"a Paris police station entrance at night in the 1920s, blue lamp, wet cobblestones",
'k10':"a gritty 1930s basement with an old printing press, hanging sheets of paper drying, single bulb lighting",
'k11':"Alcatraz island prison on the rock in San Francisco Bay, grey fog, cold blue light, choppy water",
'k12':"an ocean liner deck at night crossing the Atlantic, railing, moonlight on the water",
}
ALL={**P,**{k:k+BG+v+"." for k,v in B.items()}}
json.dump(ALL,open('all.json','w'),indent=1)
print(len(ALL))
