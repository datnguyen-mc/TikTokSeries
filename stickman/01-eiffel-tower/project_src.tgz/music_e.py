import numpy as np, sys
sys.path.insert(0,'/home/claude/k1000')
from music import mtof, lp, SR, bell
def pl(f,d=0.22,bright=2400):
    t=np.arange(int(d*SR))/SR; x=(np.sin(2*np.pi*f*t)+0.5*np.sin(2*np.pi*2*f*t)+0.2*np.sin(2*np.pi*3*f*t))*np.exp(-t*9)
    return lp(x,bright)
def bass(f,d=0.3):
    t=np.arange(int(d*SR))/SR; return lp(np.sin(2*np.pi*f*t)+0.3*np.sin(2*np.pi*2*f*t),600)*np.exp(-t*5)
def brush(d=0.08):
    n=np.random.default_rng(1).standard_normal(int(d*SR)); t=np.arange(len(n))/SR; return lp(n,6000)*np.exp(-t*40)*0.25
def heist(dur, bpm=112):
    beat=60/bpm; out=np.zeros(int((dur+2)*SR))
    prog=[(45,[0,3,7,10]),(50,[0,3,7,10]),(52,[0,4,7,10]),(45,[0,3,7,10])]  # Am7 Dm7 E7 Am7
    i=0; t=0.0
    while t<dur:
        root,ch=prog[(i//4)%4]; b=i%4
        p=int(t*SR)
        walk=[0,7,12,7][b]; x=bass(mtof(root-12+walk))*0.5; out[p:p+len(x)]+=x
        if b in (1,3):
            for iv in ch: y=pl(mtof(root+12+iv),0.18)*0.08; out[p:p+len(y)]+=y
        # swung off-beat brush
        y=brush(); q=int((t+beat*0.66)*SR); out[q:q+len(y)]+=y
        if b==0 and (i//4)%2==1:
            m=root+24+ch[(i//8)%4]; y=bell(mtof(m),1.0)*0.04; out[p:p+len(y)]+=y
        t+=beat; i+=1
    return out[:int(dur*SR)].astype(np.float32)
