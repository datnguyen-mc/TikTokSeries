import { W, H, clamp, lerp, ss, ease, easeOutBack, plate, spr, act, prop, glow, shade, vignette, sparkles, particles, rain, txt, chip, stat } from "./lib.mjs";
export const S = {};
const GY = 1110; // feet line
// pick active shot by word index; each shot fn gets (ctx, local t, shot duration)
function shots(ctx, t, s, list) {
  const st = list.map(([wi]) => wi === 0 ? 0 : s.w[wi] - 0.08);
  let i = 0; while (i + 1 < list.length && t >= st[i + 1]) i++;
  const t0 = st[i], t1 = i + 1 < list.length ? st[i + 1] : s.d; const lt = t - t0;
  ctx.save(); list[i][1](ctx, lt, t1 - t0, (k) => s.w[k] - t0); ctx.restore();
  if (lt < 0.1 && i > 0) { ctx.fillStyle = `rgba(255,255,255,${0.25 * (1 - lt / 0.1)})`; ctx.fillRect(0, 0, W, H); }
}
const bg = (ctx, name, t, d, { z0 = 1.04, z1 = 1.14, x0 = 0, x1 = 0, y0 = 0, y1 = 0, filter } = {}) => {
  const u = ss(t / Math.max(d, 0.01)); const z = lerp(z0, z1, u);
  ctx.save(); ctx.translate(W / 2 + lerp(x0, x1, u), H / 2 + lerp(y0, y1, u)); ctx.scale(z, z); ctx.translate(-W / 2, -H / 2); plate(ctx, name, { filter }); ctx.restore();
};
const zoomIn = (ctx, t, cx, cy, z0, z1, d) => { const z = lerp(z0, z1, ss(t / d)); ctx.translate(cx, cy); ctx.scale(z, z); ctx.translate(-cx, -cy); };
const stampTxt = (ctx, t, t0, s, x, y, color = "#d23a2a", rot = -0.18, size = 110) => {
  if (t < t0) return; const k = clamp((t - t0) / 0.18); const sc = lerp(2.2, 1, ss(k));
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc); ctx.globalAlpha = k;
  ctx.font = `${size}px Archivo`; const w = ctx.measureText(s).width; ctx.lineWidth = 10; ctx.strokeStyle = color; ctx.strokeRect(-w / 2 - 24, -size * 0.92, w + 48, size * 1.2);
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.fillText(s, 0, 0); ctx.restore();
};
const bigNum = (ctx, t, t0, s, x, y, color = "#ffd84d", size = 120) => { if (t < t0) return; const k = easeOutBack(clamp((t - t0) / 0.3)); ctx.save(); ctx.translate(x, y); ctx.scale(k, k); ctx.font = `${size}px Archivo`; ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 16; ctx.strokeStyle = "#000"; ctx.strokeText(s, 0, 0); ctx.fillStyle = color; ctx.fillText(s, 0, 0); ctx.restore(); };
const moneyRain = (ctx, t, n = 14, seed = 3) => { for (let i = 0; i < n; i++) { const x = ((i * 97 + seed * 31) % 680) + 20; const y = ((t * 260 + i * 140) % 1500) - 200; spr(ctx, "banknote", x, y, 0.28, { anchor: "c", rot: Math.sin(t * 3 + i) * 0.8 }); } };

S.hook = { sfx: (w) => [[0.05, "swell", 0.35], [w[4], "pop", 0.3], [w[6], "chime", 0.25], [w[12], "thud", 0.35], [w[14], "pop", 0.25]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k01", lt, d, { z0: 1.0, z1: 1.18, y0: 40, y1: 0 });
      act(c, lt, [[0, { p: "vic_hat", x: 360, y: GY, s: 0.82, popin: 1 }]], 1);
      stampTxt(c, lt, W2(4), "SOLD!", 470, 330, "#e0332a", -0.2, 120); }],
    [8, (c, lt, d, W2) => { bg(c, "k01", lt, d, { z0: 1.3, z1: 1.38, y0: -120, y1: -140 });
      act(c, lt, [[0, { p: "vic_stand", x: 360, y: GY + 60, s: 0.95 }], [W2(13), { p: "vic_shrug" }]], 1);
      if (lt > W2(13)) prop(c, lt, "tower_model", 600, 620, 0.42, { t0: W2(13), rot: 0.2 }); }],
  ]);
} };
S.rust = { sfx: (w) => [[0.1, "creak", 0.3, 2], [w[10], "coins", 0.3, 1.5], [w[13], "whoosh", 0.25], [w[17], "paper", 0.35], [w[24], "pop", 0.2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k02", lt, d, { z0: 1.0, z1: 1.12, y0: 60, y1: -20 });
      prop(c, lt, "paint", 230, 980, 0.55, { t0: 0.1, amp: 2 });
      if (lt > W2(9)) { prop(c, lt, "flying_money", 470, 420, 0.5, { t0: W2(9), amp: 20, rate: 3 }); moneyRain(c, lt - W2(9), 8); }
      if (lt > W2(10)) bigNum(c, lt, W2(10), "$$$", 360, 260, "#7dffa8"); }],
    [13, (c, lt, d, W2) => { bg(c, "k03", lt, d, { z0: 1.02, z1: 1.12 });
      act(c, lt, [[0, { p: "vic_read", x: 340, y: GY, s: 0.84, popin: 1 }]], 1);
      if (lt > W2(24)) { glow(c, 340, 560, 140, "rgba(255,220,120,0.9)", 0.4); sparkles(c, 360, 520, lt, { color: "#fff3b0", r: 120, n: 6 }); } }],
  ]);
} };
S.forge = { sfx: (w) => [[0.1, "typing", 0.35, 2.4], [w[4], "thud", 0.3], [w[9], "chime", 0.25]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k04", lt, d, { z0: 1.0, z1: 1.15 });
      act(c, lt, [[0, { p: "vic_stamp", x: 380, y: GY, s: 0.86, popin: 1 }]], 1);
      prop(c, lt, "letter", 560, 520, 0.0 + 0.6 * ease(lt, W2(2), W2(4)), { t0: W2(1), amp: 4 });
      if (lt > W2(4)) stampTxt(c, lt, W2(4), "OFFICIAL", 540, 420, "#c0392b", -0.15, 70); }],
    [6, (c, lt, d, W2) => { bg(c, "k04", lt, d, { z0: 1.25, z1: 1.32, x0: 40, x1: 20, filter: "brightness(0.75)" });
      act(c, lt, [[0, { p: "vic_hat", x: 360, y: GY + 40, s: 0.92 }]], 1);
      chip(c, lt, W2(9), "Deputy Director", 360, 260, { size: 40, accent: "#ffd84d" });
      chip(c, lt, W2(13), "Ministry of Posts & Telegraphs", 360, 340, { size: 28, accent: "#5fd3ff" }); }],
  ]);
} };
S.hotel = { sfx: (w) => [[0.05, "chime", 0.25], [w[9], "swell", 0.25], [w[14], "paper", 0.3], [w[23], "low_drone", 0.25, 2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k05", lt, d, { z0: 1.12, z1: 1.0, y0: -60, y1: 0 });
      act(c, lt, [[0, { p: "vic_stand", x: -150, y: GY, s: 0.78, walk: 1 }], [0.01, { x: 360, move: 1.2 }], [1.3, { p: "vic_hat" }]], 1);
      if (lt > W2(9)) { glow(c, 360, 200, 260, "rgba(255,230,160,0.9)", 0.35); sparkles(c, 360, 200, lt, { r: 160, n: 8 }); } }],
    [14, (c, lt, d, W2) => { bg(c, "k06", lt, d, { z0: 1.02, z1: 1.12 });
      for (let i = 0; i < 4; i++) { const tt = i * 0.25; if (lt > tt) { const k = ease(lt, tt, tt + 0.9); spr(c, "letter", lerp(-80, 140 + i * 150, k), lerp(300, 380 + (i % 2) * 60, k) - Math.sin(k * 3.14) * 120, 0.28, { anchor: "c", rot: (1 - k) * 3 }); } }
      act(c, lt, [[0.7, { p: "dealer_bald", x: 200, y: GY - 40, s: 0.62, popin: 1 }]], 4);
      act(c, lt, [[0.9, { p: "dealer_cap", x: 520, y: GY - 40, s: 0.62, popin: 1 }]], 5);
      act(c, lt, [[1.1, { p: "andre_eager", x: 360, y: GY + 20, s: 0.7, popin: 1 }]], 6);
      if (lt > W2(23)) { prop(c, lt, "folder", 600, 300, 0.4, { t0: W2(23) }); } }],
  ]);
} };
S.pitch = { sfx: (w) => [[0.1, "pop", 0.2], [w[6], "whoosh", 0.25], [w[11], "thud", 0.4], [w[13], "rumble", 0.3, 1.2], [w[16], "low_drone", 0.2, 2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k06", lt, d, { z0: 1.1, z1: 1.2, x0: -40, x1: 0 });
      act(c, lt, [[0, { p: "vic_point", x: 260, y: GY, s: 0.82 }]], 1);
      prop(c, lt, "tower_model", 520, 560, 0.75, { t0: W2(6) - 0.1, amp: 6 }); }],
    [11, (c, lt, d, W2) => { bg(c, "k02", lt, d, { z0: 1.0, z1: 1.2, filter: "brightness(0.8)" });
      bigNum(c, lt, 0, "7,000", 360, 520, "#ffd84d", 150); bigNum(c, lt, W2(13), "TONS OF IRON", 360, 640, "#ffffff", 64); }],
    [16, (c, lt, d, W2) => { bg(c, "k06", lt, d, { z0: 1.25, z1: 1.3, filter: "brightness(0.7)" });
      act(c, lt, [[0, { p: "vic_shh", x: 360, y: GY + 60, s: 0.98, popin: 1 }]], 1);
      if (lt > W2(21)) stampTxt(c, lt, W2(21), "TOP SECRET", 360, 300, "#e0332a", -0.12, 76); }],
  ]);
} };
S.poisson = { sfx: (w) => [[w[2], "chime", 0.25], [w[6], "coins", 0.25, 1], [w[9], "gasp", 0.2], [w[14], "pop", 0.2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k06", lt, d, { z0: 1.2, z1: 1.3, x0: 30, x1: 10 });
      act(c, lt, [[0, { p: "andre_eager", x: 360, y: GY + 40, s: 0.98, popin: 1 }]], 6);
      chip(c, lt, W2(2), "André Poisson", 360, 220, { size: 40, accent: "#ffd84d" });
      if (lt > W2(4)) { for (let i = 0; i < 3; i++) { const k = ((lt - W2(4)) * 1.2 + i / 3) % 1; c.save(); c.globalAlpha = 1 - k; txt(c, "$", 250 + i * 110, 600 - k * 250, { size: 90, font: "Archivo", color: "#7dffa8", sw: 8 }); c.restore(); } } }],
    [7, (c, lt, d, W2) => { bg(c, "k07", lt, d, { z0: 1.05, z1: 1.15 });
      act(c, lt, [[0, { p: "vic_sigh", x: 240, y: GY, s: 0.8, popin: 1 }]], 1);
      act(c, lt, [[0.2, { p: "andre_think", x: 500, y: GY, s: 0.78, popin: 1 }]], 6);
      if (lt > W2(13)) { prop(c, lt, "coins", 240, 380, 0.3, { t0: W2(13), amp: 3 }); txt(c, "...", 260, 330, { size: 70, font: "Archivo", sw: 8, alpha: ease(lt, W2(13), W2(14)) }); } }],
  ]);
} };
S.bribe = { sfx: (w) => [[0.1, "paper", 0.35], [w[3], "pop", 0.25], [w[11], "coins", 0.35, 1.5], [w[14], "footsteps", 0.3, 1.2], [w[16], "train", 0.3, 2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k07", lt, d, { z0: 1.15, z1: 1.25, filter: "brightness(0.85)" });
      act(c, lt, [[0, { p: "andre_envelope", x: 300, y: GY, s: 0.84, popin: 1 }]], 6);
      act(c, lt, [[0.3, { p: "vic_cash", x: 540, y: GY, s: 0.84, popin: 1 }]], 1); }],
    [4, (c, lt, d, W2) => { bg(c, "k05", lt, d, { z0: 1.15, z1: 1.3, filter: "brightness(0.7)" }); moneyRain(c, lt, 16);
      act(c, lt, [[0, { p: "vic_cash", x: 360, y: GY + 40, s: 0.95, popin: 1 }]], 1);
      bigNum(c, lt, W2(10) - 0.1, "$70,000", 360, 380, "#7dffa8", 120); }],
    [14, (c, lt, d, W2) => { bg(c, "k08", lt, d, { z0: 1.0, z1: 1.12 });
      act(c, lt, [[0, { p: "vic_run", x: 120, y: GY, s: 0.8 }], [0.01, { x: 820, move: d * 0.95 }]], 1);
      prop(c, lt, "watch", 540, 300, 0.42, { t0: W2(17) - 0.2, spin: 0, amp: 3 }); if (lt > W2(17)) bigNum(c, lt, W2(17), "< 1 HOUR", 540, 470, "#ffd84d", 60); }],
  ]);
} };
S.shame = { sfx: (w) => [[w[1], "pop", 0.2], [w[5], "low_drone", 0.25, 2], [w[11], "thud", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k09", lt, d, { z0: 1.0, z1: 1.12 });
      act(c, lt, [[0, { p: "andre_think", x: 360, y: GY, s: 0.84, popin: 1 }], [W2(4), { p: "andre_facepalm" }]], 6);
      if (lt > W2(5)) { c.save(); c.globalAlpha = 0.5 * ease(lt, W2(5), W2(6)); c.fillStyle = "#ff6b8a"; c.beginPath(); c.ellipse(318, 748, 22, 10, 0, 0, 6.283); c.ellipse(398, 748, 22, 10, 0, 0, 6.283); c.fill(); c.restore(); }
      if (lt > W2(7)) { c.save(); c.globalAlpha = ease(lt, W2(7), W2(8)); c.strokeStyle = "#e0332a"; c.lineWidth = 14; c.beginPath(); c.arc(600, 330, 70, 0, 6.283); c.moveTo(550, 280); c.lineTo(650, 380); c.stroke(); c.restore(); prop(c, lt, "whistle", 600, 330, 0.26, { t0: W2(7) }); } }],
  ]);
} };
S.again = { sfx: (w) => [[0.05, "whoosh", 0.3], [w[3], "pop", 0.25], [w[11], "swell", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k01", lt, d, { z0: 1.12, z1: 1.0 });
      act(c, lt, [[0, { p: "vic_run", x: 900, y: GY, s: 0.8, flip: 1 }], [0.01, { x: 360, move: 0.9 }], [W2(3), { p: "vic_hat" }], [W2(7), { p: "vic_point" }]], 1);
      if (lt > W2(11)) bigNum(c, lt, W2(11), "AGAIN?!", 360, 300, "#ff6b6b", 110); }],
  ]);
} };
S.alcatraz = { sfx: (w) => [[w[3], "low_drone", 0.25, 2], [w[7], "siren", 0.25], [w[12], "waves", 0.3, 2], [w[15], "typing", 0.2, 1.2], [w[19], "thud", 0.45], [w[21], "rumble", 0.3, 2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k09", lt, d, { z0: 1.1, z1: 1.2, filter: "brightness(0.8)" });
      act(c, lt, [[0, { p: "vic_shh", x: 230, y: GY, s: 0.8 }]], 1);
      act(c, lt, [[W2(5), { p: "cop_arms", x: 530, y: GY, s: 0.8, popin: 1 }], [W2(7), { p: "cop_whistle" }]], 2);
      if (lt > W2(7)) { const k = (lt * 3) % 1; c.save(); c.globalAlpha = 1 - k; c.strokeStyle = "#5fd3ff"; c.lineWidth = 5; c.beginPath(); c.arc(560, 520, 40 + k * 120, 0, 6.283); c.stroke(); c.restore(); } }],
    [11, (c, lt, d, W2) => { bg(c, "k12", lt, d, { z0: 1.0, z1: 1.1 });
      act(c, lt, [[0, { p: "vic_run", x: -100, y: GY, s: 0.78 }], [0.01, { x: 380, move: 0.8 }], [0.9, { p: "vic_shrug" }]], 1);
      chip(c, lt, W2(13) - 0.1, "OFF TO AMERICA", 360, 260, { size: 40, accent: "#5fd3ff" }); }],
    [15, (c, lt, d, W2) => { bg(c, "k10", lt, d, { z0: 1.05, z1: 1.15 });
      act(c, lt, [[0, { p: "vic_inspect", x: 380, y: GY, s: 0.84, popin: 1 }]], 1);
      prop(c, lt, "banknote", 600, 400, 0.4, { t0: 0.1, amp: 8 }); }],
    [19, (c, lt, d, W2) => { bg(c, "k11", lt, d, { z0: 1.0, z1: 1.18, filter: "saturate(0.8)" });
      act(c, lt, [[0.15, { p: "vic_prison", x: 360, y: GY + 20, s: 0.8, popin: 1 }]], 1);
      prop(c, lt, "cuffs", 560, 360, 0.36, { t0: 0.3 });
      if (lt > W2(22)) bigNum(c, lt, W2(22), "ALCATRAZ", 360, 300, "#ffffff", 96);
      if (lt > d - 0.8) { c.fillStyle = `rgba(0,0,0,${ease(lt, d - 0.8, d)})`; c.fillRect(0, 0, W, H); } }],
  ]);
} };
