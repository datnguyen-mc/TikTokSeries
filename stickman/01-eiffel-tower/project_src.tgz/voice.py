import json, numpy as np, soundfile as sf, re, difflib, glob, sherpa_onnx
from piper import PiperVoice
from piper.config import SynthesisConfig
from scipy.signal import resample_poly
SR=48000
V=PiperVoice.load('/home/claude/tts/vits-piper-en_US-ryan-high/en_US-ryan-high.onnx')
d='/home/claude/tts/sherpa-onnx-zipformer-small-en-2023-06-26'; f=lambda p: glob.glob(f"{d}/{p}*.int8.onnx")[0]
ASR=sherpa_onnx.OfflineRecognizer.from_transducer(encoder=f("encoder"),decoder=f("decoder"),joiner=f("joiner"),tokens=f"{d}/tokens.txt",num_threads=2)
base=lambda w: re.sub(r'[^a-z0-9]','',w.lower().replace('é','e'))
def synth(t):
    ch=list(V.synthesize(t,SynthesisConfig(length_scale=0.93,noise_scale=0.6,noise_w_scale=0.8))); sr=ch[0].sample_rate
    a=np.concatenate([c.audio_float_array for c in ch]).astype(np.float32); i=np.where(np.abs(a)>0.012)[0]; m=int(0.03*sr)
    a=a[max(0,i[0]-m):i[-1]+m]; return resample_poly(a,SR,sr).astype(np.float32)
def words(a):
    s=ASR.create_stream(); s.accept_waveform(16000,resample_poly(a,1,3).astype('float32')); ASR.decode_stream(s)
    W=[]
    for tok,ts in zip(s.result.tokens,s.result.timestamps):
        if tok.startswith('▁') or not W: W.append([tok.replace('▁',''),ts])
        else: W[-1][0]+=tok
    return [(base(w),t) for w,t in W if base(w)]
S=json.load(open('script.json')); t=0.25; pieces=[np.zeros(int(t*SR),np.float32)]; out=[]; WD=[]
for seg in S:
    st=t
    for li,line in enumerate(seg['lines']):
        a=synth(line); hyp=words(a); ref=line.split(); rb=[base(w) for w in ref]
        sm=difflib.SequenceMatcher(None,rb,[h[0] for h in hyp],autojunk=False); tm={}
        for b in sm.get_matching_blocks():
            for q in range(b.size): tm[b.a+q]=hyp[b.b+q][1]
        dur=len(a)/SR; times=[]
        for i in range(len(ref)):
            if i in tm: times.append(tm[i])
            else:
                prev=[(j,tm[j]) for j in tm if j<i]; nxt=[(j,tm[j]) for j in tm if j>i]
                if prev and nxt: (j0,t0),(j1,t1)=max(prev),min(nxt); times.append(t0+(t1-t0)*(i-j0)/(j1-j0))
                elif prev: j0,t0=max(prev); times.append(t0+(dur-t0)*(i-j0)/(len(ref)-j0))
                else: j1,t1=min(nxt) if nxt else (len(ref),dur); times.append(t1*i/max(1,j1))
        for i,w in enumerate(ref): WD.append({'w':w,'s':round(t+max(0,times[i]-0.05),3),'seg':seg['id']})
        pieces.append(a); t+=dur; gap=0.32 if li<len(seg['lines'])-1 else 0.45; pieces.append(np.zeros(int(gap*SR),np.float32)); t+=gap
    out.append({'id':seg['id'],'scene':seg['scene'],'start':round(st,3),'end':round(t,3)})
au=np.concatenate(pieces); au=au/np.abs(au).max()*0.89; sf.write('narration.wav',au,SR,subtype='PCM_16')
json.dump({'duration':round(t,3),'segments':out,'words':WD},open('timeline.json','w'),indent=1)
print('dur',round(t,2),'words',len(WD))
