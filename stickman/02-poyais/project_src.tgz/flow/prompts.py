import json
STY="flat 2D cartoon stick-figure style: big round white heads, tiny black dot eyes, simple expressive eyebrows and mouths, thin black stick arms and legs, simple coloured clothes on the torso, thick clean black outlines, flat colours"
CAST=("cast Character lineup sheet 16:9, "+STY+". Five characters standing in one row, full body, same scale, widely separated, plain flat white background, no ground line, no shadows, no text, no letters. "
"1) Gregor: a charming 1820s Scottish adventurer posing as a prince, red military coat with gold epaulettes and buttons, green tartan sash across the chest, tall black feathered bicorne hat, curly brown sideburns, smug smile. "
"2) a hopeful 1820s Scottish settler man with a brown waistcoat, rolled sleeves and a flat cap. "
"3) a 1820s settler woman in a blue dress and white bonnet. "
"4) a wealthy 1820s London investor in a dark green tailcoat and tall beaver hat with a money bag. "
"5) a stern 1820s French judge in a black robe and white jabot.")
SUF=(" Match the attached reference image exactly for this character's design, face style, hat, clothes, colours and line weight. Plain flat white background, no ground line, no shadows, no scenery, no text, no letters. Full-body poses, same scale, widely separated with empty white space between them, nothing overlapping or touching the image edge."
     " IMPORTANT: keep the exact flat 2D stick-figure style of the reference: big round plain white heads with tiny dot eyes, thin black stick limbs, NOT realistic humans.")
def sh(k,who,p): return f"{k} Pose sheet 16:9: {who} from the reference image in {len(p)} different poses in one row. "+" ".join(f"Pose {i+1}: {x}." for i,x in enumerate(p))+" Expressive cartoon acting."+SUF
G="Gregor (red military coat, gold epaulettes, tartan sash, feathered bicorne hat)"
P={}
P['greg1']=sh('greg1',G,["bowing grandly with one arm sweeping out","proudly holding open a thick book toward the viewer","pointing at a large unrolled map held in his other hand","grinning greedily while holding a bulging money bag in each hand"])
P['greg2']=sh('greg2',G,["finger on his lips going shhh with a sly side glance","waving goodbye cheerfully while walking to the right","shrugging with an innocent face and palms up","saluting proudly with chest puffed out"])
P['people1']=("people1 Character sheet 16:9 in the same style as the attached reference image: six separate full-body figures in one row. "
"1) the settler man holding a shovel and smiling hopefully; 2) the settler woman holding a small child's hand, excited and pointing ahead; 3) the settler man standing in shock with hands on his head; "
"4) a sick settler lying down under a thin blanket, sweating; 5) the wealthy investor in tall beaver hat eagerly handing over a money bag; 6) the French judge banging a wooden gavel."+SUF.split(' Plain flat')[0].replace("this character's","the characters'")+" Plain flat white background, no ground line, no shadows, no text, no letters. IMPORTANT: flat 2D stick-figure style with big round plain white heads and tiny dot eyes, NOT realistic humans.")
PS=" Same flat 2D cartoon style as the attached reference. Each item separate with wide white space, plain flat white background, no shadows, no text, no letters, no numbers."
P['props1']="props1 Prop sheet 16:9: 1) a thick leather-bound guidebook; 2) a rolled parchment map; 3) a pile of shiny gold nuggets; 4) an ornate bond certificate with a red wax seal and no writing; 5) a bulging cloth money bag; 6) a small tall sailing ship; 7) a cartoon mosquito; 8) a wooden judge's gavel."+PS
P['props2']="props2 Prop sheet 16:9: 1) a green flag with a gold cross and no writing; 2) a golden jewelled crown; 3) a stack of silver coins; 4) a wooden shovel; 5) a small thatched hut; 6) a medal with ribbon; 7) a white feather quill pen; 8) a skull and crossbones warning sign with no writing."+PS
BG=(" Vertical 9:16 background plate, stylized 3D animated-film render, semi-realistic textures, cinematic lighting, soft depth of field, NO people, NO characters, no text, no letters, no logos, no signs with writing."
    " Keep the lower-middle area open as a clear floor where characters will stand (floor at about 80% of the height). Scene: ")
B={'p01':"a foggy 1820s London street with Georgian buildings, gas lamps, horse carriages, warm morning light",
'p02':"a lavish 1820s London drawing room with chandeliers, oil portraits, gold frames, velvet sofas",
'p03':"a dreamlike golden tropical paradise city on a green hill with white palaces, a river shining with gold, palm trees, glowing sunset, idealised painting look",
'p04':"an 1820s print shop with a wooden printing press, stacks of fresh books, ink, warm lamplight",
'p05':"a busy 1820s London bank hall with marble columns, wooden counters, ledgers and piles of coins",
'p06':"1820s London docks with a tall three-masted sailing ship, barrels, ropes, grey sky",
'p07':"the deck of an 1820s sailing ship on the open Caribbean sea, blue sky, sails",
'p08':"a wild swampy Central American coast, dense jungle, muddy beach, rain clouds, a few crumbling stone foundations",
'p09':"a miserable makeshift jungle camp at dusk with torn tents, mud, dim campfire, mist",
'p10':"an 1820s Paris street with cream stone buildings and cafes, soft light",
'p11':"a 1820s French courtroom with dark wood panels, judge's bench, tall windows",
'p12':"the interior of a grand candlelit cathedral in Caracas with arches and gold altar",}
ALL={'cast':CAST,**P,**{k:k+BG+v+"." for k,v in B.items()}}
json.dump(ALL,open('all.json','w'),indent=1)
js='window.P='+json.dumps(ALL)+';'
open('set.js','w').write(js)
print(len(ALL), len(js))
