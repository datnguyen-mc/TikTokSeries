import { W, H, clamp, lerp, ss, ease, easeOutBack, plate, spr, act, prop, glow, shade, vignette, sparkles, particles, rain, txt, chip, stat } from "./lib.mjs";
export const S = {};
const GY = 1110; // feet line
// pick active shot by word index; each shot fn gets (ctx, local t, shot duration)
function shots(ctx, t, s, list) {
  const st = list.map(([wi]) => wi === 0 ? 0 : s.w[wi] - 0.08);
  let i = 0; while (i + 1 < list.length && t >= st[i + 1]) i++;
  const t0 = st[i], t1 = i + 1 < list.length ? st[i + 1] : s.d; const lt = t - t0;
  ctx.save(); list[i][1](ctx, lt, t1 - t0, (k) => s.w[k] - t0); ctx.restore();
  if (lt < 0.1 && i > 0) { ctx.fillStyle = `rgba(255,255,255,${0.25 * (1 - lt / 0.1)})`; ctx.fillRect(0, 0, W, H); }
}
const bg = (ctx, name, t, d, { z0 = 1.04, z1 = 1.14, x0 = 0, x1 = 0, y0 = 0, y1 = 0, filter } = {}) => {
  const u = ss(t / Math.max(d, 0.01)); const z = lerp(z0, z1, u);
  ctx.save(); ctx.translate(W / 2 + lerp(x0, x1, u), H / 2 + lerp(y0, y1, u)); ctx.scale(z, z); ctx.translate(-W / 2, -H / 2); plate(ctx, name, { filter }); ctx.restore();
};
const zoomIn = (ctx, t, cx, cy, z0, z1, d) => { const z = lerp(z0, z1, ss(t / d)); ctx.translate(cx, cy); ctx.scale(z, z); ctx.translate(-cx, -cy); };
const stampTxt = (ctx, t, t0, s, x, y, color = "#d23a2a", rot = -0.18, size = 110) => {
  if (t < t0) return; const k = clamp((t - t0) / 0.18); const sc = lerp(2.2, 1, ss(k));
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc); ctx.globalAlpha = k;
  ctx.font = `${size}px Archivo`; const w = ctx.measureText(s).width; ctx.lineWidth = 10; ctx.strokeStyle = color; ctx.strokeRect(-w / 2 - 24, -size * 0.92, w + 48, size * 1.2);
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.fillText(s, 0, 0); ctx.restore();
};
const bigNum = (ctx, t, t0, s, x, y, color = "#ffd84d", size = 120) => { if (t < t0) return; const k = easeOutBack(clamp((t - t0) / 0.3)); ctx.save(); ctx.translate(x, y); ctx.scale(k, k); ctx.font = `${size}px Archivo`; ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 16; ctx.strokeStyle = "#000"; ctx.strokeText(s, 0, 0); ctx.fillStyle = color; ctx.fillText(s, 0, 0); ctx.restore(); };
const rainOf = (ctx, t, name, n = 14, s = 0.22, seed = 3) => { for (let i = 0; i < n; i++) { const x = ((i * 97 + seed * 31) % 680) + 20; const y = ((t * 260 + i * 140) % 1500) - 200; spr(ctx, name, x, y, s, { anchor: "c", rot: Math.sin(t * 3 + i) * 0.8 }); } };


S.hook = { sfx: (w) => [[0.05, "swell", 0.35], [w[4], "pop", 0.3], [w[10], "thud", 0.35], [w[13], "footsteps", 0.3, 2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "p03", lt, d, { z0: 1.0, z1: 1.15 });
      prop(c, lt, "flag", 520, 520, 0.6, { t0: 0.2, amp: 4 });
      act(c, lt, [[0, { p: "g_map", x: 300, y: GY, s: 0.94, popin: 1 }]], 1);
      if (lt > W2(10)) stampTxt(c, lt, W2(10), "FAKE!", 380, 330, "#e0332a", -0.2, 130); }],
    [12, (c, lt, d, W2) => { bg(c, "p06", lt, d, { z0: 1.05, z1: 1.18 });
      act(c, lt, [[0, { p: "settler", x: 200, y: GY, s: 0.87, popin: 1 }]], 2);
      act(c, lt, [[0.25, { p: "woman", x: 470, y: GY, s: 0.87, popin: 1 }]], 3);
      bigNum(c, lt, W2(13), "HUNDREDS", 360, 300, "#ffd84d", 96); }],
  ]);
} };
S.prince = { sfx: (w) => [[w[3], "chime", 0.25], [w[8], "footsteps", 0.25, 1], [w[12], "swell", 0.3], [w[18], "pop", 0.25]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "p01", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "g_salute", x: 360, y: GY, s: 0.94, popin: 1 }]], 1);
      chip(c, lt, W2(3), "Gregor MacGregor", 360, 220, { size: 40, accent: "#ffd84d" }); }],
    [9, (c, lt, d, W2) => { bg(c, "p02", lt, d, { z0: 1.05, z1: 1.18 });
      act(c, lt, [[0, { p: "g_bow", x: 360, y: GY, s: 1.01, popin: 1 }]], 1);
      prop(c, lt, "crown", 380, 420, 0.42, { t0: W2(11), amp: 5 }); if (lt > W2(11)) sparkles(c, 380, 420, lt, { r: 110, n: 7 });
      chip(c, lt, W2(16), "\"Prince of Poyais\"", 360, 220, { size: 38, accent: "#ffd84d" }); }],
    [19, (c, lt, d, W2) => { bg(c, "p03", lt, d, { z0: 1.15, z1: 1.3 });
      prop(c, lt, "flag", 360, 560, 0.75, { t0: 0.05, amp: 6 }); bigNum(c, lt, 0.1, "POYAIS", 360, 330, "#7dffa8", 120); }],
  ]);
} };
S.book = { sfx: (w) => [[w[1], "paper", 0.35], [w[10], "thud", 0.3], [w[15], "swell", 0.3], [w[23], "coins", 0.3, 1.2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "p04", lt, d, { z0: 1.02, z1: 1.15 });
      act(c, lt, [[0, { p: "g_book", x: 360, y: GY, s: 0.96, popin: 1 }]], 1);
      bigNum(c, lt, W2(4), "355 PAGES", 360, 300, "#ffd84d", 92); }],
    [12, (c, lt, d, W2) => { bg(c, "p03", lt, d, { z0: 1.0, z1: 1.22, y0: 40, y1: -40 });
      chip(c, lt, W2(15), "Capital: St. Joseph", 360, 220, { size: 38, accent: "#ffd84d" });
      if (lt > W2(21)) { for (let i = 0; i < 10; i++) { const k = ((lt - W2(21)) * 0.7 + i / 10) % 1; spr(c, "gold", 140 + (i * 53) % 440, lerp(1180, 820, k), 0.14, { anchor: "c", alpha: 1 - k }); } glow(c, 360, 1000, 260, "rgba(255,210,80,0.9)", 0.45); }
      if (lt > W2(23)) bigNum(c, lt, W2(23), "PURE GOLD", 360, 640, "#ffd84d", 84); }],
  ]);
} };
S.money = { sfx: (w) => [[0.05, "footsteps", 0.3, 1.2], [w[4], "coins", 0.3, 1.2], [w[13], "swell", 0.3], [w[16], "coins", 0.4, 1.5]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "p05", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "investor", x: 230, y: GY + 120, s: 1.06, popin: 1 }]], 4);
      act(c, lt, [[0.2, { p: "g_bags", x: 500, y: GY, s: 0.92, popin: 1 }]], 1);
      prop(c, lt, "bond", 360, 360, 0.42, { t0: W2(4), amp: 5 }); chip(c, lt, W2(8), "A few shillings an acre", 360, 210, { size: 34, accent: "#ffd84d" }); }],
    [12, (c, lt, d, W2) => { bg(c, "p05", lt, d, { z0: 1.25, z1: 1.35, filter: "brightness(0.75)" }); rainOf(c, lt, "coins", 14, 0.2);
      act(c, lt, [[0, { p: "g_bags", x: 360, y: GY + 40, s: 1.06, popin: 1 }]], 1);
      bigNum(c, lt, W2(16) - 0.1, "£200,000", 360, 380, "#7dffa8", 120); chip(c, lt, W2(20), "LOAN", 360, 470, { size: 40, accent: "#7dffa8" }); }],
  ]);
} };
S.ships = { sfx: (w) => [[0.05, "waves", 0.35, 4], [w[3], "whoosh", 0.25], [w[9], "pop", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "p07", lt, d, { z0: 1.0, z1: 1.1, x0: 0, x1: -20 });
      c.save(); c.translate(0, Math.sin(lt * 1.6) * 8); c.rotate(Math.sin(lt * 1.2) * 0.01);
      act(c, lt, [[0, { p: "settler", x: 220, y: GY, s: 0.9, popin: 1 }]], 2); act(c, lt, [[0.2, { p: "woman", x: 490, y: GY, s: 0.9, popin: 1 }]], 3); c.restore();
      bigNum(c, lt, W2(8), "~250", 360, 330, "#ffd84d", 140); chip(c, lt, W2(12), "settlers", 360, 420, { size: 40, accent: "#ffd84d" }); }],
  ]);
} };
S.arrival = { sfx: (w) => [[0.05, "rain", 0.3, 5], [w[3], "thud", 0.35], [w[6], "low_drone", 0.3, 3], [w[10], "birds", 0.2, 2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "p08", lt, d, { z0: 1.0, z1: 1.15 }); rain(c, lt, { a: 0.35, n: 70 });
      act(c, lt, [[0, { p: "settler", x: 360, y: GY, s: 0.94 }], [W2(4), { p: "settler_shock", shake: 1.5 }]], 2);
      chip(c, lt, W2(6), "No capital", 200, 260, { size: 34, accent: "#ff6b6b" }); chip(c, lt, W2(8), "No government", 500, 330, { size: 34, accent: "#ff6b6b" });
      if (lt > W2(10)) stampTxt(c, lt, W2(10), "JUST JUNGLE", 360, 500, "#ffd84d", -0.12, 72); }],
  ]);
} };
S.sick = { sfx: (w) => [[w[0], "low_drone", 0.35, 5], [w[8], "heartbeat", 0.35, 2.5]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "p09", lt, d, { z0: 1.0, z1: 1.12, filter: "brightness(0.85)" });
      for (let i = 0; i < 6; i++) { const a = lt * (1.5 + i * 0.3) + i; spr(c, "mosquito", 360 + Math.cos(a) * (160 + i * 20), 520 + Math.sin(a * 1.3) * (200 + i * 15), 0.34, { anchor: "c", flip: Math.cos(a) < 0 }); }
      act(c, lt, [[0, { p: "settler_shock", x: 360, y: GY, s: 0.92, filter: "saturate(0.5) brightness(0.85)", shake: 1 }]], 2);
      prop(c, lt, "skull", 590, 860, 0.36, { t0: W2(4), amp: 3 });
      if (lt > W2(10)) bigNum(c, lt, W2(10), "180+ DIED", 360, 330, "#ff6b6b", 110);
      shade(c, 0.25 * ease(lt, W2(8), d)); }],
  ]);
} };
S.france = { sfx: (w) => [[w[1], "pop", 0.25], [w[3], "whoosh", 0.3], [w[10], "chime", 0.25]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "p10", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "g_wave", x: -100, y: GY, s: 0.94, walk: 1 }], [0.01, { x: 330, move: 1.0 }], [W2(7), { p: "g_shh" }]], 1);
      prop(c, lt, "map", 580, 560, 0.42, { t0: W2(9), amp: 5 }); if (lt > W2(11)) bigNum(c, lt, W2(11), "AGAIN!", 360, 330, "#ff6b6b", 110); }],
  ]);
} };
S.trial = { sfx: (w) => [[w[4], "thud", 0.45], [w[4] + 0.35, "thud", 0.45], [w[10], "gasp", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "p11", lt, d, { z0: 1.05, z1: 1.15 });
      act(c, lt, [[0, { p: "judge", x: 470, y: GY, s: 0.94, popin: 1 }]], 5);
      act(c, lt, [[0.1, { p: "g_salute", x: 200, y: GY, s: 0.87, popin: 1 }], [W2(9), { p: "g_shrug" }]], 1);
      if (lt > W2(10)) stampTxt(c, lt, W2(10), "NOT GUILTY", 360, 330, "#2ecc71", -0.15, 82); }],
  ]);
} };
S.ending = { sfx: (w) => [[0.05, "low_drone", 0.25, 3], [w[8], "chime", 0.3], [w[13], "swell", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "p12", lt, d, { z0: 1.0, z1: 1.14 });
      act(c, lt, [[0, { p: "g_salute", x: 360, y: GY, s: 0.94, fade: 0.4 }]], 1);
      chip(c, lt, W2(3), "Caracas, 1845", 360, 220, { size: 38, accent: "#ffd84d" });
      prop(c, lt, "medal", 520, 640, 0.32, { t0: W2(9), amp: 4 }); if (lt > W2(9)) sparkles(c, 520, 640, lt, { r: 80, n: 6 }); }],
    [13, (c, lt, d, W2) => { bg(c, "p03", lt, d, { z0: 1.2, z1: 1.3, filter: "saturate(0.6) brightness(0.8)" });
      act(c, lt, [[0, { p: "g_shrug", x: 360, y: GY, s: 1.01, popin: 1 }]], 1); prop(c, lt, "crown", 360, 470, 0.4, { t0: 0.2, rot: 0.25 });
      if (lt > W2(17)) bigNum(c, lt, W2(17), "PRINCE OF NOWHERE", 360, 330, "#ffd84d", 60);
      if (lt > d - 0.8) { c.fillStyle = `rgba(0,0,0,${ease(lt, d - 0.8, d)})`; c.fillRect(0, 0, W, H); } }],
  ]);
} };
