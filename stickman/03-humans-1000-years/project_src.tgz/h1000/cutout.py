import numpy as np, json, os, sys
from PIL import Image
from scipy import ndimage as nd
RAW='/home/claude/h1000/raw'; OUT='/home/claude/h1000/assets'
MAP=json.load(open('/home/claude/h1000/idmap.json'))
PAPER=np.array([253,253,252],float)
def normalize(a):
    lum=a.mean(2); p=np.median(a[lum>=np.percentile(lum,60)],axis=0)
    return np.clip(a/p[None,None,:]*PAPER[None,None,:],0,255)
idx=json.load(open(f'{OUT}/index.json')) if os.path.exists(f'{OUT}/index.json') else {}
only=sys.argv[1:]
DILS={}
for rid,name in MAP.items():
    if only and name not in only: continue
    if not os.path.exists(f'{RAW}/{rid}.jpg'): continue
    im=Image.open(f'{RAW}/{rid}.jpg').convert('RGB')
    if name.startswith('f') and len(name)==3 and name[1:].isdigit():
        im.save(f'{OUT}/bg/{name}.jpg',quality=95)
        continue
    a=normalize(np.asarray(im).astype(float))
    d=np.sqrt(((a-PAPER)**2).sum(2))
    line=nd.binary_opening(d>38,iterations=1)|(d>90)
    if name=='cast':
        for r in np.where(line.sum(1)>0.45*line.shape[1])[0]: line[max(0,r-4):r+5]=False; d[max(0,r-4):r+5]=0
    dil=9 if name.startswith('props') else DILS.get(name,6)
    big=nd.binary_dilation(line,iterations=dil)
    lab,n=nd.label(big); comps=[]
    for i,sl in enumerate(nd.find_objects(lab)):
        h=sl[0].stop-sl[0].start; area=(lab[sl]==i+1).sum()
        if h<(50 if name.startswith('props') else 140) or area<3000: continue
        cy=(sl[0].start+sl[0].stop)/2
        row=int(cy>a.shape[0]/2) if name!='cast' else 0
        comps.append((row,sl[1].start,i+1,sl))
    comps.sort(); idx[name]=[]
    for k,(row,x0,li,sl) in enumerate(comps):
        y0,y1,x0,x1=sl[0].start,sl[0].stop,sl[1].start,sl[1].stop
        sub=a[y0:y1,x0:x1]; m=nd.binary_fill_holes(lab[y0:y1,x0:x1]==li)
        dd=d[y0:y1,x0:x1]
        closed=nd.binary_closing(np.pad((dd>20)&m,14),iterations=3)[14:-14,14:-14]
        filled=nd.binary_fill_holes(closed)
        alpha=np.where(filled,1.0,np.clip((dd-8)/40,0,1))*m
        ys,xs=np.where(alpha>0.05)
        Y0,Y1,X0,X1=ys.min(),ys.max()+1,xs.min(),xs.max()+1
        rgba=np.dstack([sub,alpha*255])[Y0:Y1,X0:X1].astype(np.uint8)
        fn=f'{name}_{k+1}'; Image.fromarray(rgba,'RGBA').save(f'{OUT}/sprites/{fn}.png')
        idx[name].append({'id':fn,'w':int(X1-X0),'h':int(Y1-Y0),'x':int(x0+X0),'y':int(y0+Y0)})
    print(name,len(idx[name]),[(s['w'],s['h']) for s in idx[name]])
json.dump(idx,open(f'{OUT}/index.json','w'),indent=1)
