import json, sys, numpy as np, soundfile as sf
sys.path.insert(0,'/home/claude/h1000'); sys.path.insert(0,'/home/claude/dope'); sys.path.insert(0,'/home/claude/film')
from music_e import heist, future, SR
import sfx2
from scipy.ndimage import uniform_filter1d, maximum_filter1d
ev=json.load(open('/home/claude/h1000/events.json')); N=int(ev['duration']*SR)
v,_=sf.read('/home/claude/h1000/narration.wav',dtype='float32'); vv=np.zeros(N,np.float32); vv[:min(N,len(v))]=v[:N]
L=np.zeros(N,np.float32); R=L.copy()
def place(x,t,g):
    p=int(t*SR); 
    if p>=N: return
    n=min(len(x),N-p); L[p:p+n]+=x[:n]*g; R[p:p+n]+=x[:n]*g
m=future(ev["duration"]); f=int(1.5*SR); m[-f:]*=np.linspace(1,0,f); place(m,0,0.2)
for e in ev['events']:
    try: place(np.asarray(sfx2.make(e['k'],e.get('dur')),np.float32),e['t'],e['gain']*0.75)
    except Exception as ex: print('sfx',e['k'],ex)
env=uniform_filter1d(maximum_filter1d(np.abs(vv),int(0.08*SR)),int(0.3*SR)); duck=1-0.6*np.clip(env/0.07,0,1)
L*=duck; R*=duck; L+=vv; R+=vv; o=np.stack([L,R],1); pk=np.abs(o).max()
if pk>0.98: o*=0.98/pk
sf.write(sys.argv[1],o,SR,subtype='PCM_16'); print('peak',pk)
