import { W, H, clamp, lerp, ss, ease, easeOutBack, plate, spr, act, prop, glow, shade, vignette, sparkles, particles, twinkle, chip } from "./lib.mjs";
export const S = {};
const GY = 1110;
function shots(ctx, t, s, list) {
  const st = list.map(([wi]) => wi === 0 ? 0 : s.w[wi] - 0.08);
  let i = 0; while (i + 1 < list.length && t >= st[i + 1]) i++;
  const t0 = st[i], t1 = i + 1 < list.length ? st[i + 1] : s.d; const lt = t - t0;
  ctx.save(); list[i][1](ctx, lt, t1 - t0, (k) => s.w[k] - t0); ctx.restore();
  if (lt < 0.1 && i > 0) { ctx.fillStyle = `rgba(255,255,255,${0.25 * (1 - lt / 0.1)})`; ctx.fillRect(0, 0, W, H); }
}
const bg = (ctx, name, t, d, { z0 = 1.04, z1 = 1.14, x0 = 0, x1 = 0, y0 = 0, y1 = 0, rot = 0, filter } = {}) => {
  const u = ss(t / Math.max(d, 0.01)); const z = lerp(z0, z1, u);
  ctx.save(); ctx.translate(W / 2 + lerp(x0, x1, u), H / 2 + lerp(y0, y1, u)); if (rot) ctx.rotate(rot * t); ctx.scale(z, z); ctx.translate(-W / 2, -H / 2); plate(ctx, name, { filter }); ctx.restore();
};
const stampTxt = (ctx, t, t0, s, x, y, color = "#d23a2a", rot = -0.18, size = 110) => {
  if (t < t0) return; const k = clamp((t - t0) / 0.18); const sc = lerp(2.2, 1, ss(k));
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc); ctx.globalAlpha = k;
  ctx.font = `${size}px Archivo`; const w = ctx.measureText(s).width; ctx.lineWidth = 10; ctx.strokeStyle = color; ctx.strokeRect(-w / 2 - 24, -size * 0.92, w + 48, size * 1.2);
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.fillText(s, 0, 0); ctx.restore();
};
const bigNum = (ctx, t, t0, s, x, y, color = "#ffd84d", size = 120) => { if (t < t0) return; const k = easeOutBack(clamp((t - t0) / 0.3)); ctx.save(); ctx.translate(x, y); ctx.scale(k, k); ctx.font = `${size}px Archivo`; ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 16; ctx.strokeStyle = "#000"; ctx.strokeText(s, 0, 0); ctx.fillStyle = color; ctx.fillText(s, 0, 0); ctx.restore(); };
const fadeOut = (c, lt, d, len = 0.8) => { if (lt > d - len) { c.fillStyle = `rgba(0,0,0,${ease(lt, d - len, d)})`; c.fillRect(0, 0, W, H); } };

// sprite scales so everyone matches the cast
const K = { minh: 1.06, m: 0.83, n: 1.37, o: 1.37, dg: 1.05 };

S.hook = { sfx: (w) => [[0.02, "swell", 0.35], [w[2], "whoosh", 0.25], [w[9], "pop", 0.3], [w[10], "whoosh", 0.3], [w[11], "vortex", 0.3, 1.5], [w[17], "thud", 0.4]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "f01", lt, d, { z0: 1.0, z1: 1.16 });
      bigNum(c, lt, W2(2), "YEAR 3026", 360, 300, "#7df9ff", 104);
      const out = lt > W2(10) ? ss((lt - W2(10)) / 0.6) : 0;
      if (lt > W2(9)) spr(c, "earth", lerp(360, 900, out), lerp(560, 420, out), 0.95 * easeOutBack(clamp((lt - W2(9)) / 0.35)), { anchor: "c", rot: lt * 0.3 });
      act(c, lt, [[0, { p: "minh", x: 360, y: GY + 60, s: K.minh, popin: 1 }], [W2(10), { p: "minh_shock", s: K.m, shake: 1.2 }]], 1); }],
    [11, (c, lt, d, W2) => { bg(c, "f09", lt, d, { z0: 1.05, z1: 1.2 }); particles(c, lt, { n: 50, color: "rgba(120,240,255,0.7)", vy: -60 });
      glow(c, 360, 640, 300, "rgba(80,220,255,0.9)", 0.35);
      act(c, lt, [[0, { p: "digi", x: 360, y: GY, s: K.dg, popin: 1, float: 10 }], [W2(16), { p: "digi_fade", s: 1.6, y: GY - 80 }]], 4);
      if (lt > W2(17)) stampTxt(c, lt, W2(17), "NO BODY?", 360, 330, "#ff4fa0", -0.12, 76); }],
  ]);
} };

S.forty = { sfx: (w) => [[0.02, "vortex", 0.3, 2], [w[6], "pop", 0.3], [w[7], "clock_fast", 0.25, 1.2], [w[10], "thud", 0.4]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "f03", lt, d, { z0: 1.0, z1: 1.25, rot: 0.03 });
      bigNum(c, lt, W2(1), "1000 YEARS", 360, 270, "#ffd84d", 104);
      prop(c, lt, "hourglass", 360, 470, 0.55, { t0: 0.1, spin: 0.6, amp: 4 });
      if (lt > W2(6)) { for (let i = 0; i < 8; i++) { const st = W2(6) + i * 0.09; if (lt < st) continue; const k = i / 7;
        spr(c, "minh", lerp(90, 630, k), lerp(1180, 880, k * 0.15) - 40, lerp(0.42, 0.24, k), { alpha: clamp((lt - st) / 0.15) }); } }
      bigNum(c, lt, W2(6), "40", 360, 720, "#7dffa8", 170); chip(c, lt, W2(7), "generations", 360, 780, { size: 38, accent: "#7dffa8" }); }],
    [8, (c, lt, d, W2) => { bg(c, "f02", lt, d, { z0: 1.06, z1: 1.18 });
      act(c, lt, [[0, { p: "minh_think", x: 400, y: GY, s: K.m, popin: 1 }]], 1);
      prop(c, lt, "dna", 170, 560, 0.75, { t0: W2(12), amp: 8, rot: -0.2 });
      chip(c, lt, W2(12), "Evolution", 360, 220, { size: 40, accent: "#ffd84d" });
      if (lt > W2(10)) stampTxt(c, lt, W2(10), "TOO SHORT", 400, 400, "#e0332a", -0.15, 92); }],
  ]);
} };

S.tech = { sfx: (w) => [[w[2], "pop", 0.3], [w[6], "whoosh", 0.25], [w[9], "chime", 0.3], [w[12], "notify", 0.3], [w[15], "thud", 0.45], [w[18], "pop", 0.25]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "f04", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "minh_point", x: 220, y: GY, s: K.m, popin: 1 }]], 1);
      act(c, lt, [[W2(5), { p: "sci_thumb", x: 540, y: GY, s: K.o, popin: 1 }]], 5);
      bigNum(c, lt, W2(2), "BIG CHANGES", 360, 300, "#ffd84d", 92); chip(c, lt, W2(6), "...made by us", 360, 390, { size: 38, accent: "#ffd84d" }); }],
    [8, (c, lt, d, W2) => { bg(c, "f04", lt, d, { z0: 1.2, z1: 1.32, filter: "brightness(0.8)" });
      act(c, lt, [[0, { p: "sci_dna", x: 470, y: GY, s: K.o, popin: 1 }]], 5);
      glow(c, 420, 640, 150, "rgba(120,200,255,0.9)", 0.4);
      bigNum(c, lt, W2(9) - 0.05, "2023", 360, 290, "#7df9ff", 150);
      chip(c, lt, W2(12), "1st gene-editing therapy", 360, 380, { size: 34, accent: "#7df9ff" });
      prop(c, lt, "syringe", 190, 690, 0.7, { t0: W2(13), amp: 6, rot: 0.1 });
      if (lt > W2(15)) stampTxt(c, lt, W2(15), "APPROVED", 330, 520, "#2ecc71", -0.14, 78);
      chip(c, lt, W2(18), "Sickle cell disease", 360, 220, { size: 32, accent: "#ff6b6b" }); }],
  ]);
} };

S.body = { sfx: (w) => [[0.02, "whoosh", 0.35], [w[3], "pop", 0.25], [w[7], "thud", 0.45], [w[8], "swell", 0.3], [w[14], "footsteps", 0.3, 2], [w[17], "chime", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "f05", lt, d, { z0: 1.0, z1: 1.14 });
      act(c, lt, [[0, { p: "patient", x: 360, y: GY, s: 1.3, popin: 1 }]], 6);
      chip(c, lt, W2(3), "Inherited diseases", 360, 230, { size: 38, accent: "#ff6b6b" });
      if (lt > W2(7)) { stampTxt(c, lt, W2(7), "HISTORY", 360, 420, "#e0332a", -0.15, 104); sparkles(c, 360, 560, lt, { r: 200, n: 8 }); } }],
    [8, (c, lt, d, W2) => { bg(c, "f05", lt, d, { z0: 1.22, z1: 1.36, filter: "brightness(0.75)" });
      glow(c, 360, 600, 300, "rgba(255,90,110,0.9)", 0.45 + 0.1 * Math.sin(lt * 6));
      prop(c, lt, "heartjar", 360, 600, 1.5, { t0: 0.05, amp: 8 });
      chip(c, lt, W2(9), "Grown from your own cells", 360, 230, { size: 34, accent: "#7dffa8" }); }],
    [14, (c, lt, d, W2) => { bg(c, "f01", lt, d, { z0: 1.08, z1: 1.2, x0: 30, x1: -30 });
      act(c, lt, [[0, { p: "oldman", x: -120, y: GY, s: 1.15, walk: 1 }], [0.01, { x: 380, move: 1.3 }]], 7);
      bigNum(c, lt, W2(17), "120", 360, 330, "#ffd84d", 190);
      chip(c, lt, W2(20), "Totally normal", 360, 420, { size: 40, accent: "#ffd84d" }); }],
  ]);
} };

S.brain = { sfx: (w) => [[0.02, "low_drone", 0.3, 5], [w[1], "notify", 0.3], [w[5], "pop", 0.3], [w[7], "pop", 0.3], [w[10], "pop", 0.3], [w[12], "vortex", 0.35, 1.2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "f06", lt, d, { z0: 1.0, z1: 1.12 });
      act(c, lt, [[0, { p: "minh", x: 360, y: GY + 40, s: K.minh, popin: 1 }], [W2(13), { p: "minh_shock", s: K.m, y: GY, shake: 1 }]], 1);
      glow(c, 360, 360, 220, "rgba(90,180,255,0.9)", 0.5); prop(c, lt, "brainchip", 360, 360, 0.95, { t0: 0.05, amp: 5 });
      const items = [["earpiece", W2(5), -2.4], ["calc", W2(7), -0.75], ["wifi", W2(10), -1.57]];
      const suck = lt > W2(12) ? ss((lt - W2(12)) / 0.45) : 0;
      for (const [n, t0, a] of items) { if (lt < t0) continue; const r = lerp(300, 0, suck); const k = easeOutBack(clamp((lt - t0) / 0.3));
        spr(c, n, 360 + Math.cos(a + lt * 0.4) * r, 360 + Math.sin(a + lt * 0.4) * r * 0.9 + 60, 0.55 * k * (1 - suck * 0.9), { anchor: "c", alpha: 1 - suck * 0.8 }); }
      if (suck > 0.9) sparkles(c, 360, 360, lt, { r: 160, n: 9, color: "#9fe8ff" }); }],
  ]);
} };

S.mars = { sfx: (w) => [[0.02, "rumble", 0.45, 1.6], [w[2], "whoosh", 0.35], [w[5], "pop", 0.3], [w[10], "swell", 0.3], [w[14], "strain", 0.25], [w[17], "notify", 0.25], [w[22], "alarm", 0.18]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "f12", lt, d, { z0: 1.05, z1: 1.14 }); c.save(); c.translate(Math.sin(lt * 40) * 3, 0);
      const up = ss(lt / Math.max(d, 0.01)); prop(c, lt, "rocket", 360, lerp(820, 200, up), 0.9, { t0: 0, amp: 0, rot: -0.75 });
      glow(c, 360, lerp(980, 360, up), 160, "rgba(255,160,60,0.9)", 0.6); c.restore(); }],
    [2, (c, lt, d, W2) => { bg(c, "f07", lt, d, { z0: 1.02, z1: 1.14 });
      prop(c, lt, "mars", 560, 420, 0.55, { t0: 0.05, amp: 4, spin: 0.1 });
      bigNum(c, lt, W2(5), "38%", 260, 330, "#ffb347", 170); chip(c, lt, W2(7), "of Earth's gravity", 300, 420, { size: 34, accent: "#ffb347" }); }],
    [10, (c, lt, d, W2) => { bg(c, "f07", lt, d, { z0: 1.15, z1: 1.25, x0: -30, x1: 30 });
      act(c, lt, [[0, { p: "minh", x: 200, y: GY, s: K.minh * 0.92, popin: 1 }]], 1);
      act(c, lt, [[0, { p: "martian", x: 470, y: GY, s: K.n * 0.88, popin: 1 }], [W2(14), { s: K.n * 1.08, move: 0.6 }]], 3);
      if (lt > W2(14)) { const k = ss((lt - W2(14)) / 0.6); c.save(); c.strokeStyle = "#ffd84d"; c.lineWidth = 8; c.beginPath(); c.moveTo(640, GY); c.lineTo(640, lerp(GY - 470, GY - 580, k)); c.stroke(); c.restore();
        bigNum(c, lt, W2(14), "TALLER", 360, 290, "#ffd84d", 100); } }],
    [17, (c, lt, d, W2) => { bg(c, "f07", lt, d, { z0: 1.3, z1: 1.4, filter: "hue-rotate(-10deg) brightness(0.8)" });
      act(c, lt, [[0, { p: "martian2", x: 420, y: GY, s: K.n, popin: 1 }]], 3);
      prop(c, lt, "dna", 180, 560, 0.85, { t0: W2(19), amp: 8, spin: 0.8 });
      chip(c, lt, W2(17), "Edited genes", 360, 230, { size: 38, accent: "#7dffa8" });
      if (lt > W2(22)) { prop(c, lt, "radiation", 590, 330, 0.5, { t0: W2(22), amp: 4 }); c.save(); c.globalAlpha = 0.35 + 0.15 * Math.sin(lt * 8); c.strokeStyle = "#7df9ff"; c.lineWidth = 10; c.beginPath(); c.ellipse(420, GY - 330, 230, 400, 0, 0, Math.PI * 2); c.stroke(); c.restore(); } }],
  ]);
} };
// low-gravity hop for the 38% shot
{ const base = S.mars.draw; S.mars.draw = (ctx, t, s) => { base(ctx, t, s);
  const t0 = s.w[2] - 0.08, t1 = s.w[10] - 0.08; if (t >= t0 && t < t1) { const lt = t - t0; const hop = Math.max(0, Math.sin(lt * 2.0)) * 300;
    ctx.save(); spr(ctx, hop > 20 ? "minh_wave" : "minh", 520, GY - hop, hop > 20 ? K.m : K.minh, { rot: Math.sin(lt * 1.0) * 0.08 }); ctx.restore(); } }; }

S.space = { sfx: (w) => [[0.02, "low_drone", 0.3, 5], [w[7], "whoosh", 0.3], [w[10], "swell", 0.3], [w[12], "pop", 0.25]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "f08", lt, d, { z0: 1.35, z1: 1.45, rot: 0.06 });
      bigNum(c, lt, W2(7), "SPACE CITIES", 360, 300, "#7df9ff", 92);
      spr(c, "astro", 360 + Math.sin(lt * 0.8) * 60, 640 + Math.sin(lt * 1.3) * 30, 0.9, { anchor: "c", rot: lt * 0.5 }); }],
    [11, (c, lt, d, W2) => { bg(c, "f10", lt, d, { z0: 1.02, z1: 1.12 });
      spr(c, "astro", lerp(200, 480, ss(lt / d)), 560 + Math.sin(lt * 1.6) * 25, 0.8, { anchor: "c", rot: -0.6 + lt * 0.4 });
      chip(c, lt, W2(11), "Never touching a planet", 360, 230, { size: 34, accent: "#7df9ff" }); }],
  ]);
} };

S.digital = { sfx: (w) => [[0.02, "typing", 0.25, 1], [w[3], "vortex", 0.4, 1.5], [w[7], "notify", 0.25], [w[9], "whoosh", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "f09", lt, d, { z0: 1.0, z1: 1.18 }); particles(c, lt, { n: 60, color: "rgba(120,240,255,0.7)", vy: -90 });
      const up = lt > W2(3) ? ss((lt - W2(3)) / 0.9) : 0;
      if (up < 1) spr(c, "minh", 360, GY, K.minh, { alpha: 1 - up, filter: up > 0 ? "hue-rotate(160deg) saturate(2)" : undefined });
      if (up > 0) { glow(c, 360, 760, 320, "rgba(80,220,255,0.9)", 0.5 * up); act(c, lt, [[W2(3), { p: "digi", x: 360, y: GY, s: K.dg, fade: 0.8, float: 10 }], [W2(9), { p: "digi_fade", s: 1.6, y: GY - 80 }]], 4); }
      bigNum(c, lt, W2(3), "UPLOAD", 360, 300, "#7df9ff", 120);
      chip(c, lt, W2(7), "Citizens with no body", 360, 390, { size: 34, accent: "#7df9ff" }); }],
  ]);
} };

S.split = { sfx: (w) => [[0.02, "warm_pad", 0.3, 4], [w[2], "pop", 0.25], [w[12], "whoosh", 0.35], [w[14], "pop", 0.35], [w[16], "pop", 0.35], [w[18], "vortex", 0.35, 1.2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "f11", lt, d, { z0: 1.0, z1: 1.14, y0: 40, y1: -20 }); twinkle(c, lt, { n: 50, y0: 0, y1: 500 });
      act(c, lt, [[0, { p: "minh_think", x: 360, y: GY, s: K.m, popin: 1 }]], 1);
      bigNum(c, lt, W2(2), "FIRST TIME", 360, 290, "#ffd84d", 104); chip(c, lt, W2(5), "in tens of thousands of years", 360, 380, { size: 30, accent: "#ffd84d" }); }],
    [12, (c, lt, d, W2) => { bg(c, "f10", lt, d, { z0: 1.1, z1: 1.2 });
      act(c, lt, [[W2(14), { p: "minh_wave", x: 135, y: GY, s: K.m * 0.98, popin: 1 }]], 1);
      act(c, lt, [[W2(16), { p: "martian", x: 360, y: GY, s: K.n * 0.92, popin: 1 }]], 3);
      act(c, lt, [[W2(18), { p: "digi", x: 590, y: GY, s: K.dg * 0.95, popin: 1, float: 8 }]], 4);
      chip(c, lt, W2(14), "EARTH", 135, 360, { size: 30, accent: "#5fd3ff" }); chip(c, lt, W2(16), "MARS", 360, 300, { size: 30, accent: "#ffb347" }); chip(c, lt, W2(18), "???", 590, 360, { size: 30, accent: "#7df9ff" });
      if (lt > W2(18)) glow(c, 590, 800, 200, "rgba(80,220,255,0.9)", 0.35); }],
  ]);
} };

S.ending = { sfx: (w) => [[0.02, "low_drone", 0.25, 3], [w[9], "swell", 0.35], [w[10], "pop", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "f11", lt, d, { z0: 1.12, z1: 1.24 }); twinkle(c, lt, { n: 50, y0: 0, y1: 500 });
      act(c, lt, [[0, { p: "minh_think", x: 230, y: GY, s: K.m, popin: 1 }]], 1);
      act(c, lt, [[0.2, { p: "nova_explain", x: 510, y: GY - 60, s: K.n, popin: 1, float: 14 }]], 2);
      prop(c, lt, "qmark", 360, 470, 0.6, { t0: W2(9), amp: 6 });
      bigNum(c, lt, W2(7), "STILL HUMAN?", 360, 300, "#ffd84d", 76); }],
    [10, (c, lt, d, W2) => { bg(c, "f01", lt, d, { z0: 1.05, z1: 1.15 });
      act(c, lt, [[0, { p: "nova_wave", x: 470, y: GY - 60, s: K.n, popin: 1, float: 14 }]], 2);
      act(c, lt, [[0, { p: "minh_point", x: 200, y: GY, s: K.m, popin: 1 }]], 1);
      prop(c, lt, "bubble", 380, 430, 1.3, { t0: 0.1, amp: 0 });
      if (lt > 0.3) { c.save(); c.font = "44px Archivo"; c.textAlign = "center"; c.fillStyle = "#14161c"; c.fillText("COMMENT", 380, 412); c.fillText("BELOW!", 380, 462); c.restore(); }
      fadeOut(c, lt, d, 0.6); }],
  ]);
} };
