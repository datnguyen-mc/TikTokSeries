// 9:16 short renderer: word-by-word captions, fast shot cuts. usage: node render.mjs [stills=1,2] [events]
import fs from "node:fs";
import { spawn } from "node:child_process";
import { createCanvas, GlobalFonts, W, H, FPS, loadAll, clamp, easeOutBack, txt } from "./lib.mjs";
import { S } from "./scenes.mjs";
GlobalFonts.registerFromPath("/home/claude/repo/stickman-video-director/skills/directing-stickman-videos/assets/fonts/Anton.ttf", "Archivo");
const args = Object.fromEntries(process.argv.slice(2).map(a => a.includes("=") ? a.split("=") : [a, 1]));
const TL = JSON.parse(fs.readFileSync("/home/claude/emu/timeline.json", "utf8"));
const END = TL.duration + 0.6;
const MAP = JSON.parse(fs.readFileSync("/home/claude/emu/map_vi.json", "utf8"));
const segs = TL.segments.map((s, i) => { const start = i === 0 ? 0 : s.start; const end = i === TL.segments.length - 1 ? END : TL.segments[i + 1].start;
  const vw = TL.words.filter(w => w.seg === s.id).map(w => w.s - start); const M = MAP[s.scene] || {}; const words = vw.slice();
  for (const [en, vi] of Object.entries(M)) words[+en] = vw[vi]; for (let k = 0; k < 40; k++) if (words[k] === undefined) words[k] = vw[Math.min(k, vw.length - 1)];
  return { ...s, start, end, d: end - start, w: words }; });
// caption groups: 1-2 words, break after punctuation or long word
const groups = []; { let cur = null;
  TL.words.forEach((w, i) => { const brk = !cur || cur.n >= 2 || /[.,?!:;]$/.test(cur.text) || (cur.text.length + w.w.length > 13);
    if (brk) { cur = { text: w.w, s: w.s, n: 1 }; groups.push(cur); } else { cur.text += " " + w.w; cur.n++; } });
  groups.forEach((g, i) => { g.e = i + 1 < groups.length ? Math.min(groups[i + 1].s, g.s + 1.6) : g.s + 1.2; }); }
if (args.events) { const ev = [];
  for (const s of segs) for (const [t, k, g, d] of (S[s.scene].sfx?.(s.w, s.d) ?? [])) ev.push({ t: +(s.start + t).toFixed(3), k, gain: g, dur: d });
  fs.writeFileSync("/home/claude/emu/events.json", JSON.stringify({ events: ev, duration: END }, null, 1)); console.log("events", ev.length); process.exit(0); }
await loadAll();
const cv = createCanvas(W, H); const ctx = cv.getContext("2d");
function cap(T) {
  const g = groups.find(g => T >= g.s - 0.03 && T < g.e); if (!g) return;
  const k = easeOutBack(clamp((T - g.s + 0.03) / 0.14)); ctx.save(); ctx.translate(W / 2, 985); ctx.scale(0.8 + 0.2 * k, 0.8 + 0.2 * k);
  let size = 78; ctx.font = `${size}px Archivo`; while (ctx.measureText(g.text).width > W - 80 && size > 44) { size -= 4; ctx.font = `${size}px Archivo`; }
  ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 14; ctx.strokeStyle = "#000"; ctx.strokeText(g.text, 0, 0); ctx.fillStyle = "#fff"; ctx.fillText(g.text, 0, 0); ctx.restore();
}
function frame(T) {
  let si = segs.findIndex(x => T >= x.start && T < x.end); if (si < 0) si = segs.length - 1; const s = segs[si];
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.filter = "none"; ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H);
  ctx.save(); S[s.scene].draw(ctx, T - s.start, s); ctx.restore();
  cap(T);
}
if (args.stills) { fs.mkdirSync("/home/claude/emu/stills", { recursive: true });
  for (const v of String(args.stills).split(",")) { frame(+v); fs.writeFileSync(`/home/claude/emu/stills/f_${(+v).toFixed(1)}.jpg`, cv.toBuffer("image/jpeg", 88)); } process.exit(0); }
const out = args.out ?? "/home/claude/emu/out/video.mp4"; fs.mkdirSync("/home/claude/emu/out", { recursive: true });
const ff = spawn("ffmpeg", ["-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${W}x${H}`, "-r", String(FPS), "-i", "-", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", out + ".part.mp4"], { stdio: ["pipe", "inherit", "inherit"] });
const N = Math.round(END * FPS);
for (let f = 0; f < N; f++) { frame(f / FPS); if (!ff.stdin.write(Buffer.from(cv.data()))) await new Promise(r => ff.stdin.once("drain", r)); }
ff.stdin.end(); const code = await new Promise(r => ff.on("close", r)); if (code === 0) fs.renameSync(out + ".part.mp4", out); console.error("done", code, out);
