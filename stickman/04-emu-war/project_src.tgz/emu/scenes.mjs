import { W, H, clamp, lerp, ss, ease, easeOutBack, plate, spr, act, prop, glow, shade, vignette, sparkles, particles, twinkle, chip } from "./lib.mjs";
export const S = {};
const GY = 1110;
function shots(ctx, t, s, list) {
  const st = list.map(([wi]) => wi === 0 ? 0 : s.w[wi] - 0.08);
  let i = 0; while (i + 1 < list.length && t >= st[i + 1]) i++;
  const t0 = st[i], t1 = i + 1 < list.length ? st[i + 1] : s.d; const lt = t - t0;
  ctx.save(); list[i][1](ctx, lt, t1 - t0, (k) => s.w[k] - t0); ctx.restore();
  if (lt < 0.1 && i > 0) { ctx.fillStyle = `rgba(255,255,255,${0.25 * (1 - lt / 0.1)})`; ctx.fillRect(0, 0, W, H); }
}
const bg = (ctx, name, t, d, { z0 = 1.04, z1 = 1.14, x0 = 0, x1 = 0, y0 = 0, y1 = 0, rot = 0, filter } = {}) => {
  const u = ss(t / Math.max(d, 0.01)); const z = lerp(z0, z1, u);
  ctx.save(); ctx.translate(W / 2 + lerp(x0, x1, u), H / 2 + lerp(y0, y1, u)); if (rot) ctx.rotate(rot * t); ctx.scale(z, z); ctx.translate(-W / 2, -H / 2); plate(ctx, name, { filter }); ctx.restore();
};
const stampTxt = (ctx, t, t0, s, x, y, color = "#d23a2a", rot = -0.18, size = 110) => {
  if (t < t0) return; const k = clamp((t - t0) / 0.18); const sc = lerp(2.2, 1, ss(k));
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc); ctx.globalAlpha = k;
  ctx.font = `${size}px Archivo`; const w = ctx.measureText(s).width; ctx.lineWidth = 10; ctx.strokeStyle = color; ctx.strokeRect(-w / 2 - 24, -size * 0.92, w + 48, size * 1.2);
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.fillText(s, 0, 0); ctx.restore();
};
const bigNum = (ctx, t, t0, s, x, y, color = "#ffd84d", size = 120) => { if (t < t0) return; const k = easeOutBack(clamp((t - t0) / 0.3)); ctx.save(); ctx.translate(x, y); ctx.scale(k, k); ctx.font = `${size}px Archivo`; ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 16; ctx.strokeStyle = "#000"; ctx.strokeText(s, 0, 0); ctx.fillStyle = color; ctx.fillText(s, 0, 0); ctx.restore(); };
const fadeOut = (c, lt, d, len = 0.8) => { if (lt > d - len) { c.fillStyle = `rgba(0,0,0,${ease(lt, d - len, d)})`; c.fillRect(0, 0, W, H); } };

// ---- Emu War (VI) ----
const K = { p: 1.08, m: 1.45, s: 1.6, g: 1.45, e: 1.5, bust: 2.0 };
const bust = (c, lt, name, x = 360, s = K.bust, t0 = 0) => act(c, lt, [[t0, { p: name, x, y: H + 20, s, popin: 1 }]], 3);
const flash = (c, lt, x, y, rate = 9) => { if (Math.sin(lt * rate * 6.28) > 0.3) glow(c, x, y, 90, "rgba(255,200,80,0.95)", 0.8); };
const herd = (c, lt, t0, n, { dir = 1, y0 = 700, y1 = 900, speed = 520, s0 = 0.45, s1 = 0.8, seed = 1 } = {}) => {
  if (lt < t0) return; const tt = lt - t0;
  for (let i = 0; i < n; i++) { const r = ((i * 73 + seed * 37) % 100) / 100; const y = lerp(y0, y1, ((i * 41 + seed * 13) % 100) / 100); const s = lerp(s0, s1, (y - y0) / Math.max(1, y1 - y0));
    const x0 = dir > 0 ? -200 - r * 700 : W + 200 + r * 700; const x = x0 + dir * speed * (1 + r * 0.5) * tt;
    spr(c, "emu_1", x, y + Math.abs(Math.sin(tt * 12 + i)) * -10, s, { flip: dir < 0 }); }
};
const dust = (c, lt, a = 0.25) => particles(c, lt, { n: 30, color: `rgba(200,140,90,${a})`, vy: -20, vx: 40, size: 5 });

S.hook = { sfx: (w) => [[0.02, "rumble", 0.3, 1.2], [w[1], "thud", 0.4], [w[6], "typing", 0.4, 1.6], [w[11], "thud", 0.45], [w[12], "whoosh", 0.3], [w[18], "pop", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "b10", lt, d, { z0: 1.0, z1: 1.14 }); dust(c, lt);
      act(c, lt, [[0, { p: "sol_1", x: 320, y: GY, s: K.g, popin: 1, shake: lt > W2(6) && lt < W2(11) ? 1.5 : 0 }]], 2);
      if (lt > W2(6) && lt < W2(11)) flash(c, lt, 520, GY - 330);
      bigNum(c, lt, W2(1), "1932", 360, 300, "#ffd84d", 170);
      if (lt > W2(11)) { stampTxt(c, lt, W2(11), "THUA!", 360, 520, "#e0332a", -0.15, 130); prop(c, lt, "props1_7", 600, 700, 0.6, { t0: W2(11), amp: 4 }); } }],
    [12, (c, lt, d, W2) => { bg(c, "b05", lt, d, { z0: 1.05, z1: 1.18 });
      act(c, lt, [[0, { p: "emu_2", x: 360, y: GY, s: K.e, popin: 1 }], [W2(18), { p: "emu_3", s: K.e * 1.05 }]], 4);
      chip(c, lt, W2(12), "Kẻ thù:", 360, 180, { size: 38, accent: "#ff6b6b" });
      bigNum(c, lt, W2(18), "ĐÀ ĐIỂU", 360, 360, "#ffd84d", 120); }],
  ]);
} };

S.farm = { sfx: (w) => [[0.02, "wind", 0.25, 3], [w[5], "pop", 0.25], [w[16], "rumble", 0.45, 3], [w[18], "pop", 0.35], [w[24], "crack", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "b01", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "lineup_3", x: 360, y: GY, s: K.p, popin: 1 }]], 1);
      chip(c, lt, W2(5), "Cựu binh Thế chiến I", 360, 220, { size: 36, accent: "#ffd84d" });
      chip(c, lt, W2(14), "Tây Úc", 360, 300, { size: 36, accent: "#ffb347" }); }],
    [16, (c, lt, d, W2) => { bg(c, "b05", lt, d, { z0: 1.1, z1: 1.2 }); c.save(); c.translate(Math.sin(lt * 40) * 3, 0);
      herd(c, lt, 0, 16, { dir: 1, y0: 760, y1: 1180, speed: 480, s0: 0.4, s1: 0.95 }); c.restore(); dust(c, lt, 0.35);
      bigNum(c, lt, W2(18), "20.000", 360, 330, "#ffd84d", 170); chip(c, lt, W2(19), "con đà điểu", 360, 420, { size: 38, accent: "#ffd84d" }); }],
    [24, (c, lt, d, W2) => { bg(c, "b02", lt, d, { z0: 1.04, z1: 1.16 });
      act(c, lt, [[0, { p: "sol_6", x: 230, y: GY, s: K.s, popin: 1 }]], 1);
      act(c, lt, [[0.15, { p: "emu_5", x: 520, y: GY, s: K.e * 0.95, popin: 1 }]], 4);
      stampTxt(c, lt, W2(25), "MẤT MÙA!", 340, 340, "#e0332a", -0.12, 92); }],
  ]);
} };

S.army = { sfx: (w) => [[w[2], "pop", 0.25], [w[4], "door", 0.3], [w[8], "swell", 0.3], [w[10], "bow", 0.3], [w[13], "footsteps", 0.3, 1], [w[16], "safe_close", 0.3], [w[21], "coins", 0.3, 1]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "b03", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "sol_5", x: 210, y: GY, s: K.s, popin: 1 }]], 1);
      act(c, lt, [[W2(4) - 0.1, { p: "sol_7", x: 530, y: GY, s: K.s, popin: 1 }]], 5);
      chip(c, lt, W2(2), "Cầu cứu!", 210, 420, { size: 34, accent: "#ff6b6b" });
      chip(c, lt, W2(4), "Bộ trưởng Quốc phòng", 360, 220, { size: 36, accent: "#ffd84d" }); }],
    [8, (c, lt, d, W2) => { bg(c, "b04", lt, d, { z0: 1.05, z1: 1.16 });
      bust(c, lt, "mer_1", 360, 2.1);
      chip(c, lt, W2(10), "Thiếu tá Meredith", 360, 220, { size: 40, accent: "#ffd84d" }); }],
    [13, (c, lt, d, W2) => { bg(c, "b04", lt, d, { z0: 1.18, z1: 1.28 });
      act(c, lt, [[0, { p: "lineup_2", x: 150, y: GY, s: K.p * 0.95, popin: 1 }]], 2); act(c, lt, [[0.12, { p: "lineup_2", x: 310, y: GY, s: K.p * 0.95, popin: 1, flip: 1 }]], 3);
      prop(c, lt, "props1_1", 520, 640, 0.7, { t0: W2(16), amp: 4 }); prop(c, lt, "props1_1", 560, 820, 0.7, { t0: W2(16) + 0.15, amp: 4, seed: 3 });
      if (lt > W2(20)) { prop(c, lt, "props1_3", 360, 560, 0.75, { t0: W2(20), amp: 3 }); }
      bigNum(c, lt, W2(13), "2 LÍNH", 200, 300, "#ffd84d", 90); bigNum(c, lt, W2(16), "2 SÚNG", 530, 300, "#ffd84d", 90);
      bigNum(c, lt, W2(21), "10.000 VIÊN", 360, 440, "#7dffa8", 100); }],
  ]);
} };

S.battle = { sfx: (w) => [[w[1], "pop", 0.3], [w[5], "typing", 0.45, 1.5], [w[7], "whoosh", 0.3], [w[10], "rumble", 0.3, 2], [w[17], "slide", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "b05", lt, d, { z0: 1.02, z1: 1.12 }); dust(c, lt);
      for (let i = 0; i < 5; i++) spr(c, "emu_2", 470 + i * 50, 840 + (i % 2) * 20, 0.35, { flip: 1 });
      act(c, lt, [[0, { p: "sol_1", x: 230, y: GY, s: K.g, popin: 1, shake: lt > W2(5) ? 1.4 : 0 }]], 2);
      if (lt > W2(5)) flash(c, lt, 430, GY - 330);
      bigNum(c, lt, W2(1), "2/11/1932", 360, 300, "#ffd84d", 120); }],
    [7, (c, lt, d, W2) => { bg(c, "b05", lt, d, { z0: 1.15, z1: 1.25 }); dust(c, lt, 0.35);
      const sp = lt > W2(10) ? (lt - W2(10)) : 0;
      for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2 + 0.3; const r = 40 + sp * 380; const x = 360 + Math.cos(a) * r, y = 900 + Math.sin(a) * r * 0.35;
        spr(c, sp > 0 ? "emu_1" : "emu_2", x, y, 0.55, { flip: Math.cos(a) < 0 }); }
      chip(c, lt, W2(12), "Tản ra từng nhóm nhỏ", 360, 220, { size: 34, accent: "#ffd84d" });
      if (lt > W2(17)) stampTxt(c, lt, W2(17), "NGOÀI TẦM BẮN", 360, 380, "#e0332a", -0.12, 80); }],
  ]);
} };

S.dam = { sfx: (w) => [[0.02, "birds", 0.2, 2], [w[4], "low_drone", 0.3, 3], [w[7], "pop", 0.35], [w[12], "typing", 0.45, 1.2], [w[17], "board", 0.4], [w[18], "thud", 0.45]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "b06", lt, d, { z0: 1.02, z1: 1.14 });
      if (lt > W2(6)) for (let i = 0; i < 22; i++) { const x = 60 + ((i * 97) % 600), y = 700 + ((i * 53) % 120); spr(c, i % 3 ? "emu_2" : "emu_5", x, y, 0.22 + (y - 700) / 900, { flip: i % 2, alpha: clamp((lt - W2(6) - i * 0.02) / 0.2) }); }
      bust(c, lt, "mer_4", 360, 2.0);
      bigNum(c, lt, W2(7), "1.000+", 360, 300, "#ffd84d", 160); chip(c, lt, W2(10), "bên hồ nước", 360, 390, { size: 36, accent: "#5fd3ff" }); }],
    [12, (c, lt, d, W2) => { bg(c, "b06", lt, d, { z0: 1.2, z1: 1.3 });
      const jam = lt > W2(17);
      if (!jam) { act(c, lt, [[0, { p: "sol_1", x: 330, y: GY, s: K.g, popin: 1, shake: 1.4 }]], 2); flash(c, lt, 530, GY - 330); }
      else { spr(c, "sol_2", 220, GY, K.s); spr(c, "sol_3", 500, GY, 1.4); particles(c, lt, { n: 20, color: "rgba(200,200,200,0.5)", vy: -80, size: 8, y0: 700, y1: 900 }); }
      bigNum(c, lt, W2(14), "12", 360, 330, "#ffd84d", 170);
      if (jam) stampTxt(c, lt, W2(18), "SÚNG KẸT!", 360, 520, "#e0332a", -0.15, 100); }],
  ]);
} };

S.truck = { sfx: (w) => [[0.02, "train", 0.25, 5], [w[1], "safe_close", 0.3], [w[7], "whoosh", 0.3], [w[10], "rocks", 0.4, 2], [w[15], "rocks", 0.45, 2], [w[20], "typing", 0.35, 1]], draw(ctx, t, s) {
  const truck = (c, lt, x, y, sh) => { c.save(); c.translate(x, y); c.rotate(Math.sin(lt * (sh ? 21 : 7)) * (sh ? 0.07 : 0.015)); c.translate(0, sh ? Math.abs(Math.sin(lt * 17)) * -26 : 0);
    spr(c, "props1_1", 20, -195, 0.55); spr(c, "props1_2", 0, 0, 1.2); c.restore(); };
  const runners = (c, lt, sp) => { for (let i = 0; i < 4; i++) { const x = 450 + i * 80 + lt * 30 * sp + Math.sin(lt * 2 + i) * 15; if (x > W + 150) continue;
    spr(c, "emu_1", x, 870 + (i % 2) * 45 + Math.abs(Math.sin(lt * 12 + i)) * -12, 0.6 + (i % 2) * 0.08); } };
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "b07", lt, d, { z0: 1.05, z1: 1.18 }); dust(c, lt, 0.4);
      runners(c, lt, 1);
      truck(c, lt, lerp(-120, 230, ss(lt / d)), 1270, 0);
      chip(c, lt, W2(4), "Súng + xe tải", 360, 220, { size: 38, accent: "#ffd84d" }); }],
    [9, (c, lt, d, W2) => { bg(c, "b07", lt, d, { z0: 1.15, z1: 1.25, x0: 0, x1: -40 }); dust(c, lt, 0.45);
      runners(c, lt, 3.5);
      truck(c, lt, 230 + Math.sin(lt * 3) * 10, 1270, lt > W2(15) - 0.2);
      chip(c, lt, W2(12), "Không đuổi kịp", 360, 220, { size: 36, accent: "#ff6b6b" });
      if (lt > W2(20)) stampTxt(c, lt, W2(20), "TRƯỢT HẾT!", 360, 400, "#e0332a", -0.14, 100); }],
  ]);
} };

S.retreat = { sfx: (w) => [[w[2], "pop", 0.3], [w[4], "footsteps", 0.35, 1.5], [w[8], "paper_drop", 0.4], [w[10], "zz", 0.0]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "b04", lt, d, { z0: 1.02, z1: 1.14 });
      bigNum(c, lt, W2(2), "6 NGÀY", 360, 300, "#ffd84d", 150);
      act(c, lt, [[0, { p: "sol_4", x: 560, y: GY, s: K.s, flip: 1, walk: 1 }], [W2(4), { x: -200, move: 1.6 }]], 2);
      prop(c, lt, "props1_7", 280, 640, 0.75, { t0: W2(6), amp: 5, rot: 0.1 });
      if (lt > W2(6)) stampTxt(c, lt, W2(6), "RÚT LUI", 360, 470, "#ffffff", -0.12, 90); }],
    [8, (c, lt, d, W2) => { bg(c, "b08", lt, d, { z0: 1.05, z1: 1.16 });
      const k = clamp(lt / 0.5); spr(c, "props1_5", 280, 620, lerp(0.2, 1.2, ss(k)), { anchor: "c", rot: (1 - ss(k)) * 6 - 0.12 });
      act(c, lt, [[W2(9), { p: "emu_3", x: 540, y: GY, s: K.e, popin: 1 }]], 4);
      if (lt > W2(10)) { c.save(); c.font = "70px Archivo"; c.fillStyle = "#ffd84d"; c.strokeStyle = "#000"; c.lineWidth = 10; c.textAlign = "center";
        for (let i = 0; i < 3; i++) { const y = 470 - ((lt * 60 + i * 60) % 180); c.globalAlpha = 0.9; c.strokeText("HA", 560 + i * 40 - 40, y); c.fillText("HA", 560 + i * 40 - 40, y); } c.restore(); }
      chip(c, lt, W2(12), "Báo chí chế giễu", 360, 220, { size: 36, accent: "#ffd84d" }); }],
  ]);
} };

S.round2 = { sfx: (w) => [[w[0], "whoosh", 0.3], [w[2], "typing", 0.4, 1.2], [w[5], "clock_fast", 0.25, 1], [w[13], "pop", 0.35], [w[17], "coins", 0.35, 1.2], [w[20], "pop", 0.2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "b10", lt, d, { z0: 1.05, z1: 1.16 }); dust(c, lt);
      act(c, lt, [[0, { p: "mer_8", x: 220, y: GY, s: K.m, popin: 1 }]], 1);
      act(c, lt, [[0.15, { p: "sol_1", x: 500, y: GY, s: K.g, popin: 1, shake: 1.3 }]], 2); if (lt > 0.4) flash(c, lt, 690, GY - 330);
      bigNum(c, lt, W2(1), "LẦN 2", 360, 300, "#ff6b6b", 140); }],
    [5, (c, lt, d, W2) => { bg(c, "b09", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "mer_6", x: 360, y: GY, s: K.m, popin: 1 }]], 1);
      chip(c, lt, 0.05, "1 tháng sau", 360, 220, { size: 36, accent: "#ffd84d" });
      bigNum(c, lt, W2(13), "986", 360, 350, "#ffd84d", 170);
      if (lt > W2(17)) { prop(c, lt, "props1_3", 590, 760, 0.55, { t0: W2(17), amp: 3 }); chip(c, lt, W2(17), "gần 10.000 viên đạn", 360, 440, { size: 34, accent: "#7dffa8" }); } }],
    [20, (c, lt, d, W2) => { bg(c, "b05", lt, d, { z0: 1.1, z1: 1.18, filter: "brightness(0.85)" });
      for (let i = 0; i < 10; i++) { const t0 = W2(21) + i * 0.08; if (lt < t0) continue; spr(c, "props1_4", 90 + (i % 5) * 70, (i < 5 ? 470 : 640), 0.75 * easeOutBack(clamp((lt - t0) / 0.25)), { anchor: "c" }); }
      if (lt > W2(25)) { bigNum(c, lt, W2(25), "=", 440, 600, "#fff", 120); }
      act(c, lt, [[W2(26), { p: "emu_2", x: 590, y: GY - 120, s: K.e * 0.9, popin: 1 }]], 4);
      bigNum(c, lt, W2(22), "10 VIÊN / 1 CON", 360, 300, "#ffd84d", 92); }],
  ]);
} };

S.tank = { sfx: (w) => [[w[0], "swell", 0.3], [w[7], "typing", 0.4, 1.4], [w[9], "glass", 0.25], [w[14], "thud", 0.5], [w[14] + 0.1, "rumble", 0.4, 1.5]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "b10", lt, d, { z0: 1.05, z1: 1.18, filter: "contrast(1.1)" }); dust(c, lt);
      act(c, lt, [[0, { p: "emu_7", x: 470, y: GY, s: K.e * 1.05, popin: 1 }]], 4);
      if (lt > W2(7)) { for (let i = 0; i < 6; i++) { const k = ((lt - W2(7)) * 2.2 + i / 6) % 1; const x = k < 0.6 ? lerp(-40, 400, k / 0.6) : lerp(400, 250, (k - 0.6) / 0.4); const y = k < 0.6 ? 700 + i * 25 : lerp(700 + i * 25, 380, (k - 0.6) / 0.4);
        spr(c, "props1_4", x, y, 0.22, { anchor: "c", rot: k < 0.6 ? 1.57 : 1.57 + (k - 0.6) * 20 }); if (k > 0.58 && k < 0.66) sparkles(c, 400, 700 + i * 25, lt, { r: 30, n: 4 }); } }
      if (lt > W2(14)) { spr(c, "props1_8", lerp(-300, 170, ss((lt - W2(14)) / 0.5)), 1150, 1.0); stampTxt(c, lt, W2(14), "NHƯ XE TĂNG", 360, 330, "#2ecc71", -0.12, 100); }
      chip(c, lt, W2(0), "Thiếu tá Meredith:", 360, 220, { size: 34, accent: "#ffd84d" }); }],
  ]);
} };

S.ending = { sfx: (w) => [[0.02, "warm_pad", 0.3, 5], [w[4], "chime", 0.3], [w[13], "pop", 0.3], [w[19], "gasp", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "b11", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "emu_6", x: lerp(200, 420, ss(lt / d)), y: GY - 40, s: 1.2, popin: 1 }]], 4);
      act(c, lt, [[0.2, { p: "emu_5", x: 560, y: GY + 20, s: K.e * 0.8, popin: 1 }]], 5);
      if (lt > W2(4)) stampTxt(c, lt, W2(4), "ĐÀ ĐIỂU THẮNG", 360, 330, "#ffd84d", -0.1, 96);
      chip(c, lt, W2(8), "Cánh đồng vẫn bị phá", 360, 440, { size: 34, accent: "#ff6b6b" }); }],
    [13, (c, lt, d, W2) => { bg(c, "b11", lt, d, { z0: 1.15, z1: 1.25 });
      act(c, lt, [[0, { p: "mer_5", x: 220, y: GY, s: K.m, popin: 1, shake: 1 }]], 1);
      act(c, lt, [[0.15, { p: "emu_3", x: 510, y: GY, s: K.e, popin: 1 }]], 4);
      bigNum(c, lt, W2(14), "BẠN CÓ TIN?", 360, 330, "#ffd84d", 110);
      fadeOut(c, lt, d, 0.6); }],
  ]);
} };
