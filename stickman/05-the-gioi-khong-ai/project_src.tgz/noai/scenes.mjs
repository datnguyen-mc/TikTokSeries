import { W, H, clamp, lerp, ss, ease, easeOutBack, plate, spr, act, prop, glow, shade, vignette, sparkles, particles, twinkle, chip } from "./lib.mjs";
export const S = {};
const GY = 1110;
function shots(ctx, t, s, list) {
  const st = list.map(([wi]) => wi === 0 ? 0 : s.w[wi] - 0.08);
  let i = 0; while (i + 1 < list.length && t >= st[i + 1]) i++;
  const t0 = st[i], t1 = i + 1 < list.length ? st[i + 1] : s.d; const lt = t - t0;
  ctx.save(); list[i][1](ctx, lt, t1 - t0, (k) => s.w[k] - t0); ctx.restore();
  if (lt < 0.1 && i > 0) { ctx.fillStyle = `rgba(255,255,255,${0.25 * (1 - lt / 0.1)})`; ctx.fillRect(0, 0, W, H); }
}
const bg = (ctx, name, t, d, { z0 = 1.04, z1 = 1.14, x0 = 0, x1 = 0, y0 = 0, y1 = 0, rot = 0, filter } = {}) => {
  const u = ss(t / Math.max(d, 0.01)); const z = lerp(z0, z1, u);
  ctx.save(); ctx.translate(W / 2 + lerp(x0, x1, u), H / 2 + lerp(y0, y1, u)); if (rot) ctx.rotate(rot * t); ctx.scale(z, z); ctx.translate(-W / 2, -H / 2); plate(ctx, name, { filter }); ctx.restore();
};
const stampTxt = (ctx, t, t0, s, x, y, color = "#d23a2a", rot = -0.18, size = 110) => {
  if (t < t0) return; const k = clamp((t - t0) / 0.18); const sc = lerp(2.2, 1, ss(k));
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc); ctx.globalAlpha = k;
  ctx.font = `${size}px Archivo`; const w = ctx.measureText(s).width; ctx.lineWidth = 10; ctx.strokeStyle = color; ctx.strokeRect(-w / 2 - 24, -size * 0.92, w + 48, size * 1.2);
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.fillText(s, 0, 0); ctx.restore();
};
const bigNum = (ctx, t, t0, s, x, y, color = "#ffd84d", size = 120) => { if (t < t0) return; const k = easeOutBack(clamp((t - t0) / 0.3)); ctx.save(); ctx.translate(x, y); ctx.scale(k, k); ctx.font = `${size}px Archivo`; ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 16; ctx.strokeStyle = "#000"; ctx.strokeText(s, 0, 0); ctx.fillStyle = color; ctx.fillText(s, 0, 0); ctx.restore(); };
const fadeOut = (c, lt, d, len = 0.8) => { if (lt > d - len) { c.fillStyle = `rgba(0,0,0,${ease(lt, d - len, d)})`; c.fillRect(0, 0, W, H); } };

// ---- Thế giới không AI (VI) ----
const K = { l: 1.23, m: 1.27, o: 1.26 };
const bust = (c, lt, name, x = 360, s = 2.4, t0 = 0, o = {}) => act(c, lt, [[t0, { p: name, x, y: H + 20, s, popin: 1, ...o }]], 3);
const rainOf = (ctx, t, name, n = 14, s = 0.22, seed = 3, sp = 260) => { for (let i = 0; i < n; i++) { const x = ((i * 97 + seed * 31) % 680) + 20; const y = ((t * sp + i * 140) % 1500) - 200; spr(ctx, name, x, y, s, { anchor: "c", rot: Math.sin(t * 3 + i) * 0.6 }); } };
const ghost = (c, x, y, r) => { c.save(); c.setLineDash([18, 12]); c.lineWidth = 6; c.strokeStyle = "rgba(255,120,60,0.9)"; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.stroke(); c.restore(); };
const OFF = "grayscale(1) brightness(0.8)";

S.hook = { sfx: (w) => [[0.02, "warm_pad", 0.3, 3], [w[3], "yawn", 0.3], [w[8], "battery_down", 0.35], [w[12], "low_drone", 0.3, 2], [w[15], "thud", 0.4], [w[19], "pop", 0.25], [w[26], "whoosh", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "c01", lt, d, { z0: 1.0, z1: 1.12 });
      act(c, lt, [[0, { p: "mai_3", x: 260, y: GY, s: K.m, popin: 1 }]], 1);
      const off = lt > W2(8) ? ss((lt - W2(8)) / 0.6) : 0;
      if (off < 1) { spr(c, "lineup_5", 540, GY, K.l * 1.1, { alpha: 1 - off, filter: off > 0 ? OFF : undefined }); if (off > 0) particles(c, lt, { n: 25, color: "rgba(255,140,60,0.7)", vy: -120, y0: 700, y1: 1100, a: 1 - off }); }
      if (off > 0) ghost(c, 540, GY - 200, 150);
      bigNum(c, lt, W2(5), "THẾ GIỚI", 360, 260, "#ffffff", 100); bigNum(c, lt, W2(7), "KHÔNG AI", 360, 380, "#ff8a3d", 120); }],
    [12, (c, lt, d, W2) => { bg(c, "c11", lt, d, { z0: 1.05, z1: 1.16 });
      act(c, lt, [[0, { p: "lineup_5", x: 360, y: GY, s: K.l * 1.5, popin: 1, float: 6 }]], 5);
      if (lt > W2(15)) stampTxt(c, lt, W2(15), "KHÔNG NỔI LOẠN", 360, 420, "#e0332a", -0.12, 84); }],
    [17, (c, lt, d, W2) => { bg(c, "c11", lt, d, { z0: 1.2, z1: 1.3, filter: "brightness(0.8)" });
      const items = ["props1_1", "props1_2", "props1_3", "props1_4", "props1_5", "props1_6"];
      items.forEach((n, i) => { const t0 = 0.05 + i * 0.12; if (lt < t0) return; const gone = lt > W2(24) + i * 0.12 ? clamp((lt - W2(24) - i * 0.12) / 0.4) : 0; if (gone >= 1) return;
        const x = 190 + (i % 2) * 340, y = 420 + Math.floor(i / 2) * 200; spr(c, n, x, y - gone * 80, 0.62 * easeOutBack(clamp((lt - t0) / 0.3)), { anchor: "c", alpha: 1 - gone }); });
      bigNum(c, lt, W2(19), "HÀNG TRĂM THỨ", 360, 260, "#ffd84d", 92); }],
  ]);
} };

S.phone = { sfx: (w) => [[w[2], "beep", 0.35], [w[3], "beep", 0.35], [w[7], "notify", 0.3], [w[9], "paper", 0.35, 1.5], [w[13], "pop", 0.35], [w[23], "whoosh", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "c01", lt, d, { z0: 1.2, z1: 1.3 });
      prop(c, lt, "props1_1", 360, 440, 1.1, { t0: 0.05, amp: 4 }); if (lt > W2(2)) ghost(c, 360, 420, 190);
      bust(c, lt, "mai_1", 360, 2.3);
      if (lt > W2(3)) stampTxt(c, lt, W2(3), "KHÔNG NHẬN RA", 360, 230, "#e0332a", -0.08, 76); }],
    [7, (c, lt, d, W2) => { bg(c, "c06", lt, d, { z0: 1.02, z1: 1.14 });
      rainOf(c, lt, "props1_2", lt > W2(9) ? 22 : 8, 0.32, 3, 320);
      bust(c, lt, "mai_frus", 360, 2.5);
      bigNum(c, lt, W2(13), "50-70%", 360, 300, "#ff6b6b", 150); chip(c, lt, W2(16), "thư gửi tới Gmail là rác", 360, 390, { size: 34, accent: "#ff6b6b" }); }],
    [22, (c, lt, d, W2) => { bg(c, "c06", lt, d, { z0: 1.15, z1: 1.22 });
      spr(c, "lineup_5", 360, GY, K.l * 1.3, { alpha: 0.45, filter: OFF }); ghost(c, 360, 760, 260);
      rainOf(c, lt, "props1_2", 16, 0.3, 5, 360);
      chip(c, lt, W2(23), "AI của Gmail chặn 99,9%", 360, 230, { size: 34, accent: "#ff8a3d" });
      if (lt > W2(25)) stampTxt(c, lt, W2(25), "ĐÃ BIẾN MẤT", 360, 380, "#ff8a3d", -0.1, 84); }],
  ]);
} };

S.map = { sfx: (w) => [[0.02, "street", 0.35, 3.5], [w[5], "horn", 0.3], [w[7], "paper", 0.3], [w[11], "footsteps", 0.4, 1.5], [w[13], "thud", 0.4]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "c02", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "mai_4", x: 360, y: GY, s: K.m, popin: 1 }]], 1);
      chip(c, lt, W2(4), "Không còn dự đoán kẹt xe", 360, 230, { size: 34, accent: "#ff8a3d" }); }],
    [7, (c, lt, d, W2) => { bg(c, "c12", lt, d, { z0: 1.05, z1: 1.18, x0: 30, x1: -30 }); rain(c, lt, { a: 0.3, n: 60 });
      act(c, lt, [[0, { p: "mai_run", x: -150, y: GY, s: K.m, walk: 1 }], [0.01, { x: 400, move: 1.1 }]], 1);
      if (lt > W2(13)) stampTxt(c, lt, W2(13), "MUỘN RỒI!", 360, 360, "#e0332a", -0.14, 110); }],
  ]);
} };

S.bank = { sfx: (w) => [[w[3], "alarm", 0.2], [w[8], "footsteps", 0.35, 1.5], [w[11], "coins", 0.3, 1]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "c03", lt, d, { z0: 1.02, z1: 1.14 });
      prop(c, lt, "props1_4", 360, 420, 1.0, { t0: W2(2), amp: 5 });
      act(c, lt, [[0, { p: "lineup_4", x: 150, y: GY, s: K.l, popin: 1 }], [W2(5), { x: 260, move: 1.0 }]], 4);
      chip(c, lt, W2(3), "Giao dịch lạ? Không ai báo", 360, 230, { size: 32, accent: "#ff6b6b" }); }],
    [8, (c, lt, d, W2) => { bg(c, "c03", lt, d, { z0: 1.2, z1: 1.3 });
      act(c, lt, [[0, { p: "oth_4", x: -150, y: GY, s: K.o, walk: 1 }], [0.01, { x: 820, move: d - 0.1 }]], 4);
      bigNum(c, lt, W2(10), "DỄ HƠN", 360, 330, "#ff6b6b", 130); }],
  ]);
} };

S.hospital = { sfx: (w) => [[0.02, "beep", 0.25], [w[1], "pop", 0.35], [w[10], "chime", 0.25], [w[16], "paper", 0.3], [w[19], "low_drone", 0.3, 3], [w[26], "paper", 0.35, 1.2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "c04", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "lineup_2", x: 230, y: GY, s: K.l, popin: 1 }]], 2);
      bigNum(c, lt, W2(1), "1.000+", 360, 300, "#7df9ff", 160);
      chip(c, lt, W2(2), "thiết bị y tế dùng AI (FDA)", 360, 390, { size: 32, accent: "#7df9ff" });
      prop(c, lt, "props1_5", 520, 650, 0.9, { t0: W2(16), amp: 5 }); }],
    [19, (c, lt, d, W2) => { bg(c, "c04", lt, d, { z0: 1.2, z1: 1.3, filter: "brightness(0.8)" });
      for (let i = 0; i < 7; i++) { const t0 = W2(26) + i * 0.12; if (lt < t0) continue; spr(c, "props1_5", 120 + (i * 97) % 500, 380 + (i % 3) * 140, 0.55 * easeOutBack(clamp((lt - t0) / 0.3)), { anchor: "c", rot: (i % 2 ? 1 : -1) * 0.12 }); }
      act(c, lt, [[0, { p: "oth_2", x: 380, y: GY, s: K.o * 1.05, popin: 1 }]], 2);
      chip(c, lt, W2(22), "Bác sĩ tự soi từng tấm", 360, 230, { size: 34, accent: "#ffd84d" }); }],
  ]);
} };

S.protein = { sfx: (w) => [[0.02, "low_drone", 0.25, 3], [w[7], "clock_fast", 0.25, 1.2], [w[14], "swell", 0.35], [w[25], "thud", 0.4]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "c05", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "oth_3", x: 250, y: GY, s: K.o, popin: 1 }]], 3);
      prop(c, lt, "props1_6", 520, 560, 0.9, { t0: 0.1, amp: 8, spin: 0.4 });
      bigNum(c, lt, W2(7), "50 NĂM", 360, 300, "#ffd84d", 150); }],
    [13, (c, lt, d, W2) => { bg(c, "c05", lt, d, { z0: 1.2, z1: 1.32 });
      const dark = lt > W2(25) ? ss((lt - W2(25)) / 0.4) : 0;
      for (let i = 0; i < 18; i++) { const t0 = 0.05 + i * 0.06; if (lt < t0) continue; spr(c, "props1_6", 90 + (i % 4) * 180, 470 + Math.floor(i / 4) * 150, 0.4 * easeOutBack(clamp((lt - t0) / 0.3)), { anchor: "c", rot: lt * 0.5 + i, filter: dark > 0.5 ? OFF : undefined }); }
      shade(c, 0.45 * dark);
      bigNum(c, lt, W2(14), "200 TRIỆU", 360, 300, "#7dffa8", 140); chip(c, lt, W2(16), "cấu trúc protein AI dự đoán", 360, 390, { size: 32, accent: "#7dffa8" });
      if (lt > W2(25)) stampTxt(c, lt, W2(25), "BÍ ẨN", 360, 640, "#ffffff", -0.12, 130); }],
  ]);
} };

S.access = { sfx: (w) => [[0.02, "street", 0.2, 2], [w[3], "battery_down", 0.3], [w[8], "tap", 0.35], [w[11], "battery_down", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "c10", lt, d, { z0: 1.05, z1: 1.16 });
      act(c, lt, [[0, { p: "lineup_1", x: 300, y: GY, s: K.l, popin: 1 }]], 1);
      c.save(); c.setLineDash([16, 10]); c.lineWidth = 6; c.strokeStyle = "rgba(255,120,60,0.95)"; rrect2(c, 120, 330, 480, 90, 20); c.stroke(); c.restore();
      chip(c, lt, W2(4), "Phụ đề tự động: TẮT", 360, 230, { size: 36, accent: "#ff8a3d" }); }],
    [8, (c, lt, d, W2) => { bg(c, "c12", lt, d, { z0: 1.1, z1: 1.2 }); rain(c, lt, { a: 0.25, n: 50 });
      act(c, lt, [[0, { p: "oth_1", x: -120, y: GY, s: K.o, walk: 1 }], [0.01, { x: 330, move: 1.6 }]], 6);
      if (lt > W2(12)) ghost(c, 360, 420, 120);
      chip(c, lt, W2(12), "Giọng đọc mô tả ảnh: TẮT", 360, 230, { size: 32, accent: "#ff8a3d" }); }],
  ]);
} };
function rrect2(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
import { rain } from "./lib.mjs";

S.plus = { sfx: (w) => [[w[0], "chime", 0.3], [w[6], "pop", 0.3], [w[10], "low_drone", 0.25, 3], [w[23], "battery_down", 0.25], [w[23] + 0.3, "chime", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "c08", lt, d, { z0: 1.02, z1: 1.14 });
      chip(c, lt, 0.05, "Mặt tích cực", 360, 230, { size: 38, accent: "#2ecc71" });
      prop(c, lt, "props1_7", 360, 600, 1.4, { t0: 0.1, amp: 6 });
      if (lt > W2(6)) stampTxt(c, lt, W2(6), "ÍT VIDEO GIẢ", 360, 400, "#2ecc71", -0.12, 96); }],
    [10, (c, lt, d, W2) => { bg(c, "c07", lt, d, { z0: 1.02, z1: 1.16 });
      const dim = lt > W2(23) ? ss((lt - W2(23)) / 0.5) : 0;
      glow(c, 360, 620, 260, "rgba(255,220,60,0.9)", 0.55 * (1 - dim * 0.7));
      prop(c, lt, "props1_8", 360, 620, 1.3, { t0: 0.05, amp: 6 });
      chip(c, lt, W2(16), "AI: phần tăng nhanh nhất", 360, 230, { size: 34, accent: "#ffd84d" });
      if (lt > W2(23)) stampTxt(c, lt, W2(23), "BỚT NGỐN ĐIỆN", 360, 380, "#2ecc71", -0.1, 90); }],
  ]);
} };

S.ending = { sfx: (w) => [[0.02, "warm_pad", 0.3, 5], [w[3], "chime", 0.3], [w[6], "low_drone", 0.25, 1.5], [w[13], "swell", 0.35], [w[22], "pop", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "c09", lt, d, { z0: 1.02, z1: 1.12 });
      act(c, lt, [[0, { p: "mai_5", x: 230, y: GY, s: K.m, popin: 1 }]], 1);
      act(c, lt, [[0.15, { p: "lineup_5", x: 520, y: GY, s: K.l * 1.2, popin: 1, float: 6 }]], 5);
      bigNum(c, lt, W2(3), "PHÉP MÀU", 360, 260, "#7dffa8", 110); bigNum(c, lt, W2(6), "HAY MỐI NGUY?", 360, 380, "#ff6b6b", 96); }],
    [8, (c, lt, d, W2) => { bg(c, "c09", lt, d, { z0: 1.15, z1: 1.24 });
      glow(c, 360, 800, 280, "rgba(255,150,60,0.9)", 0.4);
      act(c, lt, [[0, { p: "lineup_5", x: 360, y: GY, s: K.l * 1.5, popin: 1, float: 8 }]], 5);
      if (lt > W2(13)) stampTxt(c, lt, W2(13), "CÔNG CỤ", 360, 330, "#ffd84d", -0.1, 120);
      chip(c, lt, W2(15), "Quan trọng là cách ta dùng", 360, 460, { size: 34, accent: "#ffd84d" }); }],
    [22, (c, lt, d, W2) => { bg(c, "c09", lt, d, { z0: 1.05, z1: 1.15 });
      act(c, lt, [[0, { p: "lineup_1", x: 230, y: GY, s: K.l, popin: 1 }]], 1);
      act(c, lt, [[0.12, { p: "lineup_5", x: 500, y: GY, s: K.l * 1.15, popin: 1, float: 6 }]], 5);
      bigNum(c, lt, W2(23), "BẠN CHỌN?", 360, 330, "#ffd84d", 130);
      fadeOut(c, lt, d, 0.6); }],
  ]);
} };
