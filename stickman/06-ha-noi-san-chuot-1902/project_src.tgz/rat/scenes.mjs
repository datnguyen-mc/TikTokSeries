import { W, H, clamp, lerp, ss, ease, easeOutBack, plate, spr, act, prop, glow, shade, vignette, sparkles, particles, twinkle, chip } from "./lib.mjs";
export const S = {};
const GY = 1110;
function shots(ctx, t, s, list) {
  const st = list.map(([wi]) => wi === 0 ? 0 : s.w[wi] - 0.08);
  let i = 0; while (i + 1 < list.length && t >= st[i + 1]) i++;
  const t0 = st[i], t1 = i + 1 < list.length ? st[i + 1] : s.d; const lt = t - t0;
  ctx.save(); list[i][1](ctx, lt, t1 - t0, (k) => s.w[k] - t0); ctx.restore();
  if (lt < 0.1 && i > 0) { ctx.fillStyle = `rgba(255,255,255,${0.25 * (1 - lt / 0.1)})`; ctx.fillRect(0, 0, W, H); }
}
const bg = (ctx, name, t, d, { z0 = 1.04, z1 = 1.14, x0 = 0, x1 = 0, y0 = 0, y1 = 0, rot = 0, filter } = {}) => {
  const u = ss(t / Math.max(d, 0.01)); const z = lerp(z0, z1, u);
  ctx.save(); ctx.translate(W / 2 + lerp(x0, x1, u), H / 2 + lerp(y0, y1, u)); if (rot) ctx.rotate(rot * t); ctx.scale(z, z); ctx.translate(-W / 2, -H / 2); plate(ctx, name, { filter }); ctx.restore();
};
const stampTxt = (ctx, t, t0, s, x, y, color = "#d23a2a", rot = -0.18, size = 110) => {
  if (t < t0) return; const k = clamp((t - t0) / 0.18); const sc = lerp(2.2, 1, ss(k));
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc); ctx.globalAlpha = k;
  ctx.font = `${size}px Archivo`; const w = ctx.measureText(s).width; ctx.lineWidth = 10; ctx.strokeStyle = color; ctx.strokeRect(-w / 2 - 24, -size * 0.92, w + 48, size * 1.2);
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.fillText(s, 0, 0); ctx.restore();
};
const bigNum = (ctx, t, t0, s, x, y, color = "#ffd84d", size = 120) => { if (t < t0) return; const k = easeOutBack(clamp((t - t0) / 0.3)); ctx.save(); ctx.translate(x, y); ctx.scale(k, k); ctx.font = `${size}px Archivo`; ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 16; ctx.strokeStyle = "#000"; ctx.strokeText(s, 0, 0); ctx.fillStyle = color; ctx.fillText(s, 0, 0); ctx.restore(); };
const fadeOut = (c, lt, d, len = 0.8) => { if (lt > d - len) { c.fillStyle = `rgba(0,0,0,${ease(lt, d - len, d)})`; c.fillRect(0, 0, W, H); } };

// ---- Hà Nội săn chuột 1902 ----
import { rain } from "./lib.mjs";
const K = { l: 0.95, v: 1.65, r: 0.65 };
const bust = (c, lt, name, x = 360, s = 2.1, t0 = 0, o = {}) => act(c, lt, [[t0, { p: name, x, y: H + 20, s, popin: 1, ...o }]], 3);
const run = (c, lt, t0, n, { dir = 1, y0 = 760, y1 = 900, speed = 520, name = "rats_1", s = 0.5, seed = 1 } = {}) => {
  if (lt < t0) return; const tt = lt - t0;
  for (let i = 0; i < n; i++) { const r = ((i * 73 + seed * 37) % 100) / 100; const y = lerp(y0, y1, ((i * 41 + seed * 13) % 100) / 100);
    const x0 = dir > 0 ? -150 - r * 600 : W + 150 + r * 600; const x = x0 + dir * speed * (1 + r * 0.4) * tt;
    spr(c, name, x, y + Math.abs(Math.sin(tt * 14 + i)) * -8, s * (0.8 + 0.4 * (y - y0) / Math.max(1, y1 - y0)), { flip: dir < 0 }); }
};
const counter = (c, lt, t0, t1, v0, v1, x, y, color, size, suffix = "") => { if (lt < t0) return; const u = ss((lt - t0) / Math.max(0.01, t1 - t0)); const v = Math.round(lerp(v0, v1, u));
  bigNum(c, 1, 0, v.toLocaleString("de-DE") + suffix, x, y, color, size); };

S.hook = { sfx: (w) => [[0.02, "street", 0.3, 3], [w[1], "thud", 0.35], [w[8], "coins", 0.35, 0.8], [w[12], "pop", 0.3], [w[15], "whoosh", 0.3], [w[17], "rocks", 0.3, 2], [w[19], "gasp", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "r01", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "lineup_1", x: 300, y: GY, s: K.l, popin: 1 }], [W2(7), { p: "fr_4" }]], 1);
      prop(c, lt, "props1_2", 470, 560, 0.45, { t0: W2(8), amp: 5, spin: 0.5 });
      act(c, lt, [[W2(12), { p: "rats_2", x: 580, y: GY, s: K.r, popin: 1 }]], 4);
      bigNum(c, lt, W2(1), "1902", 360, 270, "#ffd84d", 170); chip(c, lt, W2(5), "Hà Nội", 360, 360, { size: 38, accent: "#ffd84d" }); }],
    [15, (c, lt, d, W2) => { bg(c, "r03", lt, d, { z0: 1.05, z1: 1.16 });
      run(c, lt, 0, 10, { dir: 1, y0: 720, y1: 860, speed: 420, s: 0.42 }); run(c, lt, 0.3, 10, { dir: -1, y0: 760, y1: 900, speed: 420, s: 0.42, seed: 3 });
      bust(c, lt, "fr_1", 360, 2.0);
      if (lt > W2(19)) stampTxt(c, lt, W2(19), "NHIỀU HƠN!", 360, 330, "#e0332a", -0.12, 120); }],
  ]);
} };

S.sewer = { sfx: (w) => [[0.02, "drip", 0.3, 2], [w[3], "pop", 0.3], [w[12], "low_drone", 0.3, 3], [w[17], "chime", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "r09", lt, d, { z0: 1.02, z1: 1.16 }); particles(c, lt, { n: 25, color: "rgba(230,230,230,0.35)", vy: -60, size: 10, y0: 600, y1: 1000 });
      bigNum(c, lt, W2(3), "19 KM", 360, 300, "#ffd84d", 170); chip(c, lt, W2(6), "cống ngầm dưới phố Tây", 360, 400, { size: 34, accent: "#ffd84d" }); }],
    [12, (c, lt, d, W2) => { bg(c, "r02", lt, d, { z0: 1.05, z1: 1.18 });
      act(c, lt, [[0, { p: "rats_7", x: 230, y: GY, s: K.r * 1.2, popin: 1 }]], 4); act(c, lt, [[0.2, { p: "rats_4", x: 510, y: GY, s: K.r * 1.2, popin: 1 }]], 5);
      act(c, lt, [[0.4, { p: "rats_6", x: 380, y: GY - 230, s: K.r, popin: 1 }]], 6);
      chip(c, lt, W2(13), "Tối · ấm · đầy rác", 360, 230, { size: 36, accent: "#7dffa8" });
      if (lt > W2(17)) { stampTxt(c, lt, W2(17), "THIÊN ĐƯỜNG", 360, 380, "#7dffa8", -0.1, 100); sparkles(c, 360, 700, lt, { r: 220, n: 9 }); } }],
  ]);
} };

S.plague = { sfx: (w) => [[0.02, "low_drone", 0.35, 4], [w[2], "thud", 0.45], [w[9], "heartbeat", 0.3, 2], [w[12], "pop", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "r08", lt, d, { z0: 1.02, z1: 1.12, filter: "brightness(0.85)" });
      act(c, lt, [[0, { p: "vn_6", x: 470, y: GY, s: K.v, popin: 1 }]], 2);
      if (lt > W2(2)) stampTxt(c, lt, W2(2), "DỊCH HẠCH", 360, 330, "#e0332a", -0.12, 120);
      chip(c, lt, W2(6), "lan khắp châu Á", 360, 450, { size: 34, accent: "#ff6b6b" }); }],
    [9, (c, lt, d, W2) => { bg(c, "r08", lt, d, { z0: 1.2, z1: 1.3, filter: "brightness(0.7)" });
      act(c, lt, [[0, { p: "rats_2", x: 360, y: GY, s: K.r * 2, popin: 1, shake: 1 }]], 4);
      if (lt > W2(12)) for (let i = 0; i < 5; i++) { const a = lt * 3 + i * 1.3; spr(c, "props1_5", 360 + Math.cos(a) * 230, 640 + Math.sin(a * 1.4) * 140 - Math.abs(Math.sin(lt * 8 + i)) * 40, 0.3, { anchor: "c" }); }
      chip(c, lt, W2(12), "Bọ chét truyền bệnh", 360, 230, { size: 36, accent: "#ff6b6b" }); }],
  ]);
} };

S.hunters = { sfx: (w) => [[w[0], "pop", 0.25], [w[3], "footsteps", 0.35, 1.5], [w[9], "slide", 0.35], [w[12], "coins", 0.35, 0.8]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "r09", lt, d, { z0: 1.1, z1: 1.2 });
      chip(c, lt, 0.05, "Tháng 4/1902", 360, 230, { size: 38, accent: "#ffd84d" });
      const down = lt > W2(9) ? ss((lt - W2(9)) / 0.7) : 0;
      act(c, lt, [[0, { p: "lineup_2", x: -120, y: GY, s: K.l, walk: 1 }], [0.01, { x: 360, move: 1.2 }]], 2);
      chip(c, lt, W2(4), "Thợ bắt chuột người Việt", 360, 320, { size: 34, accent: "#ffd84d" });
      if (down > 0) { c.fillStyle = `rgba(0,0,0,${0.6 * down})`; c.fillRect(0, 0, W, H); } }],
    [12, (c, lt, d, W2) => { bg(c, "r02", lt, d, { z0: 1.15, z1: 1.25 });
      act(c, lt, [[0, { p: "vn_1", x: 300, y: GY, s: K.v, popin: 1 }]], 2);
      prop(c, lt, "props1_2", 540, 560, 0.5, { t0: 0.2, amp: 5, spin: 0.6 });
      chip(c, lt, W2(12), "Trả tiền theo từng con", 360, 230, { size: 36, accent: "#ffd84d" }); }],
  ]);
} };

S.numbers = { sfx: (w) => [[0.02, "clock_fast", 0.3, 2.5], [w[5], "pop", 0.3], [w[8], "swell", 0.35], [w[8] + 0.3, "coins", 0.3, 1.2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "r04", lt, d, { z0: 1.02, z1: 1.14 });
      prop(c, lt, "props1_7", 360, 640, 1.2, { t0: 0.05, amp: 3 });
      counter(c, lt, 0.1, W2(4), 0, 4000, 360, 330, "#ffd84d", 150); chip(c, lt, W2(1), "con / ngày", 360, 420, { size: 36, accent: "#ffd84d" }); }],
    [5, (c, lt, d, W2) => { bg(c, "r04", lt, d, { z0: 1.2, z1: 1.3 });
      act(c, lt, [[0, { p: "fr_3", x: 220, y: GY, s: K.l, popin: 1 }]], 1); act(c, lt, [[0.15, { p: "vn_2", x: 520, y: GY, s: K.v, popin: 1 }]], 2);
      chip(c, lt, W2(6), "21/6/1902", 360, 230, { size: 38, accent: "#ffd84d" });
      counter(c, lt, W2(7), W2(9) + 0.3, 4000, 20000, 360, 360, "#ff6b6b", 150, "+"); if (lt > W2(10)) chip(c, lt, W2(10), "chỉ trong 1 ngày", 360, 450, { size: 34, accent: "#ff6b6b" }); }],
  ]);
} };

S.bounty = { sfx: (w) => [[w[2], "whoosh", 0.3], [w[8], "coins", 0.4, 0.8], [w[14], "pop", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "r01", lt, d, { z0: 1.1, z1: 1.2 });
      act(c, lt, [[0, { p: "fr_4", x: 230, y: GY, s: K.l, popin: 1 }]], 1);
      prop(c, lt, "props1_2", 500, 620, 0.85, { t0: W2(8), amp: 6, spin: 0.4 });
      chip(c, lt, W2(4), "Ai cũng được thưởng", 360, 230, { size: 36, accent: "#ffd84d" });
      bigNum(c, lt, W2(8), "1 XU / CON", 360, 350, "#ffd84d", 120); }],
    [12, (c, lt, d, W2) => { bg(c, "r04", lt, d, { z0: 1.05, z1: 1.15 });
      prop(c, lt, "props1_7", 360, 760, 1.1, { t0: 0.05, amp: 2 });
      prop(c, lt, "props1_1", 360, 620, 1.3, { t0: W2(15), amp: 6, rot: 0.3 });
      if (lt > W2(14)) stampTxt(c, lt, W2(14), "CHỈ CẦN ĐUÔI", 360, 330, "#e0332a", -0.1, 100); }],
  ]);
} };

S.trick = { sfx: (w) => [[w[3], "chime", 0.3], [w[6], "zipper", 0.4], [w[9], "whoosh", 0.3], [w[12], "pop", 0.3], [w[14], "pop", 0.3], [w[16], "pop", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "r11", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "lineup_3", x: 230, y: GY, s: K.l, popin: 1 }], [W2(5), { p: "vn_3", s: K.v }]], 2);
      if (lt > W2(3) && lt < W2(6)) sparkles(c, 230, 520, lt, { r: 70, n: 6 });
      const cut = lt > W2(6); const free = lt > W2(9) ? (lt - W2(9)) : 0;
      if (!cut) spr(c, "rats_2", 520, GY, K.r * 1.2); else spr(c, "rats_3", 520 + free * 500, GY - Math.abs(Math.sin(free * 14)) * 12, K.r * 1.2);
      if (cut) { const k = clamp((lt - W2(6)) / 0.8); spr(c, "props1_1", lerp(560, 420, k), lerp(980, 640, Math.sin(k * 3.14) * 0.6 + k * 0.4), 0.6, { anchor: "c", rot: k * 6 }); }
      bigNum(c, lt, W2(5), "MẸO!", 360, 300, "#7dffa8", 150); }],
    [12, (c, lt, d, W2) => { bg(c, "r05", lt, d, { z0: 1.05, z1: 1.16 });
      act(c, lt, [[0, { p: "rats_4", x: 360, y: GY, s: K.r * 1.6, popin: 1 }]], 4);
      for (let i = 0; i < 8; i++) { const t0 = W2(14) + i * 0.15; if (lt < t0) continue; spr(c, "rats_2", 120 + (i * 83) % 500, 820 + (i % 3) * 30, 0.3 * easeOutBack(clamp((lt - t0) / 0.3))); }
      bigNum(c, lt, W2(14), "ĐẺ THÊM", 360, 330, "#ffd84d", 130); chip(c, lt, W2(16), "chuột có đuôi = thêm tiền", 360, 430, { size: 32, accent: "#ffd84d" }); }],
  ]);
} };

S.farm = { sfx: (w) => [[w[4], "gasp", 0.3], [w[5], "rocks", 0.3, 2], [w[11], "creak", 0.3], [w[17], "thud", 0.4]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "r01", lt, d, { z0: 1.15, z1: 1.25, x0: 20, x1: -20 });
      run(c, lt, W2(4), 9, { dir: 1, y0: 500, y1: 640, speed: 480, name: "rats_3", s: 0.42 });
      bust(c, lt, "fr_1", 360, 2.0);
      chip(c, lt, W2(6), "Chuột cụt đuôi?!", 360, 230, { size: 38, accent: "#ff6b6b" }); }],
    [11, (c, lt, d, W2) => { bg(c, "r10", lt, d, { z0: 1.02, z1: 1.14 });
      for (let i = 0; i < 4; i++) prop(c, lt, "props1_3", 150 + (i % 2) * 420, 560 + Math.floor(i / 2) * 200, 0.7, { t0: 0.05 + i * 0.1, amp: 0 });
      act(c, lt, [[0.3, { p: "rats_6", x: 360, y: 760, s: K.r * 0.9, popin: 1 }]], 4);
      act(c, lt, [[0.2, { p: "vn_5", x: 520, y: GY, s: K.v, popin: 1 }]], 2);
      if (lt > W2(17)) stampTxt(c, lt, W2(17), "TRẠI NUÔI CHUỘT", 360, 330, "#e0332a", -0.1, 88); }],
  ]);
} };

S.end = { sfx: (w) => [[w[2], "thud", 0.45], [w[4], "low_drone", 0.35, 3], [w[15], "pop", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "r04", lt, d, { z0: 1.05, z1: 1.15 });
      bust(c, lt, "fr_2", 360, 2.1, 0, { shake: 1.2 });
      if (lt > W2(2)) stampTxt(c, lt, W2(2), "HỦY!", 360, 330, "#e0332a", -0.14, 150); }],
    [4, (c, lt, d, W2) => { bg(c, "r08", lt, d, { z0: 1.05, z1: 1.15, filter: "brightness(0.6) saturate(0.7)" });
      act(c, lt, [[0, { p: "vn_6", x: 360, y: GY, s: K.v, popin: 1, filter: "saturate(0.6)" }]], 2);
      bigNum(c, lt, W2(5), "1903", 360, 300, "#ffffff", 150); chip(c, lt, W2(11), "Hơn 100 người chết", 360, 400, { size: 36, accent: "#ff6b6b" }); }],
    [15, (c, lt, d, W2) => { bg(c, "r06", lt, d, { z0: 1.05, z1: 1.15 });
      act(c, lt, [[0, { p: "rats_7", x: 250, y: GY, s: K.r * 1.3, popin: 1 }]], 4); act(c, lt, [[0.2, { p: "rats_5", x: 510, y: GY, s: K.r * 1.3, popin: 1 }]], 5);
      chip(c, lt, W2(16), "Chuột vẫn ở đó", 360, 230, { size: 38, accent: "#ffd84d" }); }],
  ]);
} };

S.ending = { sfx: (w) => [[0.02, "warm_pad", 0.3, 5], [w[6], "pop", 0.35], [w[13], "swell", 0.35], [w[19], "pop", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "r12", lt, d, { z0: 1.02, z1: 1.12 });
      act(c, lt, [[0, { p: "fr_5", x: 220, y: GY + 10, s: 1.6, popin: 1 }]], 1); act(c, lt, [[0.15, { p: "vn_5", x: 520, y: GY, s: K.v, popin: 1 }]], 2);
      chip(c, lt, 0.1, "Thưởng sai cách", 360, 230, { size: 38, accent: "#ffd84d" });
      bigNum(c, lt, W2(6), "NGƯỢC ĐỜI", 360, 350, "#ff6b6b", 130); }],
    [8, (c, lt, d, W2) => { bg(c, "r12", lt, d, { z0: 1.15, z1: 1.25 });
      chip(c, lt, 0.05, "Người ta gọi đó là", 360, 300, { size: 36, accent: "#ffd84d" });
      bigNum(c, lt, W2(13), "HIỆU ỨNG", 360, 450, "#ffd84d", 120); bigNum(c, lt, W2(15), "RẮN HỔ MANG", 360, 580, "#7dffa8", 110); }],
    [18, (c, lt, d, W2) => { bg(c, "r12", lt, d, { z0: 1.05, z1: 1.15 });
      act(c, lt, [[0, { p: "vn_3", x: 230, y: GY, s: K.v, popin: 1 }]], 2); act(c, lt, [[0.15, { p: "rats_5", x: 520, y: GY, s: K.r * 1.3, popin: 1 }]], 4);
      bigNum(c, lt, W2(19), "BẠN BIẾT KHÔNG?", 360, 330, "#ffd84d", 100);
      fadeOut(c, lt, d, 0.6); }],
  ]);
} };
