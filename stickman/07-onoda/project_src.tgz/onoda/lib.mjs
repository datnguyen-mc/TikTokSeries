// "Con người 1000 năm nữa" — Flow art (Nano Banana) + keyed local motion, 1280x720.
import fs from "node:fs";
import { createRequire } from "node:module";
const require = createRequire("/home/claude/repo/stickman-video-director/skills/directing-stickman-videos/package.json");
export const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
const F = "/home/claude/repo/stickman-video-director/skills/directing-stickman-videos/assets/fonts";
GlobalFonts.registerFromPath(`${F}/NotoSans.ttf`, "NotoSans");
GlobalFonts.registerFromPath(`${F}/Anton.ttf`, "Anton");
GlobalFonts.registerFromPath(`${F}/Nunito.ttf`, "Nunito");

export const W = 720, H = 1280, FPS = 30, G = 1040;
export const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
export const lerp = (a, b, u) => a + (b - a) * u;
export const ss = (u) => { u = clamp(u); return u * u * (3 - 2 * u); };
export const ease = (t, t0, t1) => ss((t - t0) / Math.max(1e-6, t1 - t0));
export const easeOutBack = (u) => { u = clamp(u); const c = 1.7; return 1 + (c + 1) * Math.pow(u - 1, 3) + c * Math.pow(u - 1, 2); };
const hash = (n) => { const x = Math.sin(n * 127.1) * 43758.5453; return x - Math.floor(x); };
export const rnd = (seed, i) => hash(seed * 31.7 + i * 7.13);

const A = "/home/claude/onoda/assets";
export const IMG = {};
export const ALIAS = JSON.parse(fs.readFileSync(`${A}/alias.json`, "utf8"));
export async function loadAll() {
  for (const f of fs.readdirSync(`${A}/sprites`)) IMG[f.replace(/\.\w+$/, "")] = await loadImage(`${A}/sprites/${f}`);
  for (const f of fs.readdirSync(`${A}/bg`)) IMG[f.replace(/\.\w+$/, "")] = await loadImage(`${A}/bg/${f}`);
}
export const img = (n) => { const im = IMG[ALIAS[n] ?? n]; if (!im) throw new Error("missing " + n); return im; };

// background plate, cover-fit
export function plate(ctx, name, o = {}) {
  const im = img(name); const sc = Math.max(W / im.width, H / im.height) * (o.z ?? 1);
  ctx.save(); ctx.globalAlpha *= o.alpha ?? 1; if (o.filter) ctx.filter = o.filter;
  ctx.drawImage(im, (W - im.width * sc) / 2 + (o.dx ?? 0), (H - im.height * sc) / 2 + (o.dy ?? 0), im.width * sc, im.height * sc);
  ctx.restore();
}
// camera move across the whole segment
export function cam(ctx, t, d, { z0 = 1, z1 = 1.06, x0 = 0, x1 = 0, y0 = 0, y1 = 0, cx = W / 2, cy = 700, shake = 0, rot = 0 } = {}) {
  const u = ss(t / d); const z = lerp(z0, z1, u);
  ctx.translate(cx + lerp(x0, x1, u) + Math.sin(t * 53) * shake, cy + lerp(y0, y1, u) + Math.cos(t * 47) * shake);
  if (rot) ctx.rotate(rot); ctx.scale(z, z); ctx.translate(-cx, -cy);
}
// sprite, anchored bottom-centre (or centre with anchor:"c")
export function spr(ctx, name, x, y, s = 0.55, o = {}) {
  const im = img(name); const w = im.width * s, h = im.height * s;
  ctx.save(); ctx.globalAlpha *= o.alpha ?? 1; if (o.filter) ctx.filter = o.filter;
  ctx.translate(x, y); if (o.rot) ctx.rotate(o.rot);
  ctx.scale((o.flip ? -1 : 1) * (o.sx ?? 1), o.sy ?? 1);
  if (o.anchor === "c") ctx.drawImage(im, -w / 2, -h / 2, w, h); else ctx.drawImage(im, -w / 2, -h, w, h);
  ctx.restore(); return { w, h, top: y - h };
}
// keyed actor with pose crossfade + pop + breathing + walk bob + float
export function act(ctx, t, keys, seed = 1) {
  const full = []; let acc = { s: 0.56, rot: 0, alpha: 1, move: 0.5 };
  for (const [kt, k] of keys) { acc = { ...acc, ...k }; full.push([kt, acc]); }
  if (t < full[0][0]) return null;
  let i = 0; while (i + 1 < full.length && t >= full[i + 1][0]) i++;
  const [t0, cur] = full[i]; const prev = i > 0 ? full[i - 1][1] : cur;
  const u = i > 0 ? ss((t - t0) / cur.move) : 1;
  const x = lerp(prev.x, cur.x, u), y = lerp(prev.y, cur.y, u), s = lerp(prev.s, cur.s, u), rot = lerp(prev.rot, cur.rot, u);
  const since = t - t0, switched = i > 0 && prev.p !== cur.p;
  const fadeIn = i === 0 && cur.fade ? clamp((t - t0) / cur.fade) : 1;
  const alpha = lerp(prev.alpha, cur.alpha, i > 0 ? ss((t - t0) / 0.35) : 1) * fadeIn;
  const pop = switched ? lerp(0.93, 1, easeOutBack(clamp(since / 0.22))) : (i === 0 && cur.popin ? easeOutBack(clamp(since / 0.35)) : 1);
  const br = Math.sin(t * 2.3 + seed * 1.7);
  const moving = u < 1 && Math.abs(cur.x - prev.x) > 6;
  const bob = cur.walk && moving ? -Math.abs(Math.sin(t * 9 + seed)) * 8 : 0;
  const fl = cur.float ? Math.sin(t * 1.8 + seed) * cur.float : 0;
  const shake = cur.shake ? Math.sin(t * 47 + seed) * cur.shake : 0;
  const o = { flip: cur.flip, rot: rot + (cur.wob ? Math.sin(t * cur.wob * 6.28 + seed) * 0.05 : 0), sx: pop * (1 - 0.006 * br), sy: pop * (1 + 0.012 * br), filter: cur.filter };
  if (switched && since < 0.14) spr(ctx, prev.p, x + shake, y + bob + fl, s, { flip: prev.flip, rot, alpha: alpha * (1 - since / 0.14), filter: prev.filter });
  return spr(ctx, cur.p, x + shake, y + bob + fl, s, { ...o, alpha: alpha * (switched ? clamp(since / 0.14) : 1) });
}
// prop that pops in at t0 and floats
export function prop(ctx, t, name, x, y, s, { t0 = 0, t1 = 1e9, amp = 6, rate = 1.6, rot = 0, spin = 0, seed = 1, anchor = "c", fade = 0.3, filter } = {}) {
  if (t < t0 || t > t1 + fade) return;
  const k = easeOutBack(clamp((t - t0) / 0.35)); const out = t > t1 ? 1 - (t - t1) / fade : 1;
  spr(ctx, name, x, y + Math.sin(t * rate + seed) * amp, s * k, { anchor, rot: rot + spin * t + Math.sin(t * 1.3 + seed) * 0.03, alpha: clamp(out), filter });
}
export function glow(ctx, x, y, r, color, a) {
  if (a <= 0) return; ctx.save(); ctx.globalAlpha = clamp(a); ctx.globalCompositeOperation = "lighter";
  const g = ctx.createRadialGradient(x, y, 1, x, y, r); g.addColorStop(0, color); g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g; ctx.fillRect(x - r, y - r, 2 * r, 2 * r); ctx.restore();
}
export function shade(ctx, a, color = "0,0,0") { if (a <= 0) return; ctx.save(); ctx.fillStyle = `rgba(${color},${clamp(a)})`; ctx.fillRect(-50, -50, W + 100, H + 100); ctx.restore(); }
export function vignette(ctx, a = 0.45) {
  ctx.save(); const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, H * 0.95);
  g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, `rgba(0,0,0,${a})`); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.restore();
}
export function sparkles(ctx, x, y, t, { color = "#ffe9a0", n = 7, r = 70, a = 1, seed = 1 } = {}) {
  for (let i = 0; i < n; i++) {
    const ang = i / n * 6.283 + t * 1.2 + seed; const k = (Math.sin(t * 4 + i * 1.7 + seed) + 1) / 2;
    ctx.save(); ctx.globalAlpha = a * (0.35 + 0.65 * k); ctx.fillStyle = color;
    ctx.translate(x + Math.cos(ang) * r * (0.7 + 0.3 * rnd(seed, i)), y + Math.sin(ang) * r * 0.75); ctx.rotate(t + i);
    const s = 4 + 7 * k; ctx.beginPath(); for (let j = 0; j < 8; j++) { const rr = j % 2 ? s * 0.32 : s; const aa = j * Math.PI / 4; ctx.lineTo(Math.cos(aa) * rr, Math.sin(aa) * rr); } ctx.fill(); ctx.restore();
  }
}
export function twinkle(ctx, t, { n = 60, y0 = 0, y1 = 300, a = 1, seed = 3, color = "#ffffff" } = {}) {
  for (let i = 0; i < n; i++) {
    const x = rnd(seed, i) * W, y = y0 + rnd(seed + 1, i) * (y1 - y0); const k = (Math.sin(t * (1.5 + rnd(seed + 2, i) * 3) + i) + 1) / 2;
    ctx.save(); ctx.globalAlpha = a * k * 0.9; ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, 1 + 1.6 * k, 0, 6.283); ctx.fill(); ctx.restore();
  }
}
export function particles(ctx, t, { n = 40, color = "rgba(255,255,255,0.6)", vy = -30, vx = 0, size = 3, seed = 5, y0 = 0, y1 = H, a = 1 } = {}) {
  ctx.save(); ctx.globalAlpha = a; ctx.fillStyle = color;
  for (let i = 0; i < n; i++) {
    const span = y1 - y0; const x = ((rnd(seed, i) * W + vx * t) % W + W) % W; const y = y0 + (((rnd(seed + 1, i) * span + vy * t) % span) + span) % span;
    ctx.beginPath(); ctx.arc(x + Math.sin(t + i) * 6, y, size * (0.5 + rnd(seed + 2, i)), 0, 6.283); ctx.fill();
  }
  ctx.restore();
}
export function rain(ctx, t, { n = 110, a = 0.5, seed = 9 } = {}) {
  ctx.save(); ctx.strokeStyle = `rgba(200,220,255,${a})`; ctx.lineWidth = 1.6;
  for (let i = 0; i < n; i++) { const x = rnd(seed, i) * (W + 200) - 100 + ((t * 120) % 60); const y = ((rnd(seed + 1, i) * H + t * 900) % (H + 40)) - 20; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 6, y + 22); ctx.stroke(); }
  ctx.restore();
}
// ---- typography ----
export function txt(ctx, s, x, y, { size = 40, font = "Anton", color = "#fff", stroke = "#14161c", sw = 8, align = "center", alpha = 1, weight = "", base = "alphabetic", maxW = 0 } = {}) {
  if (alpha <= 0 || !s) return 0;
  ctx.save(); ctx.globalAlpha *= clamp(alpha); ctx.textAlign = align; ctx.textBaseline = base; ctx.lineJoin = "round";
  let sz = size; ctx.font = `${weight} ${sz}px ${font}`.trim();
  if (maxW) while (ctx.measureText(s).width > maxW && sz > 14) { sz -= 2; ctx.font = `${weight} ${sz}px ${font}`.trim(); }
  if (sw) { ctx.lineWidth = sw; ctx.strokeStyle = stroke; ctx.strokeText(s, x, y); }
  ctx.fillStyle = color; ctx.fillText(s, x, y); const w = ctx.measureText(s).width; ctx.restore(); return w;
}
export function rrect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
// pill chip that pops in at t0
export function chip(ctx, t, t0, s, x, y, { size = 26, bg = "rgba(16,20,32,0.82)", color = "#fff", accent = "#5fd3ff", t1 = 1e9, align = "center" } = {}) {
  if (t < t0 || t > t1 + 0.3) return;
  const k = easeOutBack(clamp((t - t0) / 0.32)); const out = t > t1 ? 1 - (t - t1) / 0.3 : 1;
  ctx.save(); ctx.globalAlpha = clamp(out) * clamp((t - t0) / 0.15); ctx.font = `600 ${size}px NotoSans`;
  const w = ctx.measureText(s).width + size * 1.4, h = size * 1.75;
  const cx = align === "left" ? x + w / 2 : x;
  ctx.translate(cx, y); ctx.scale(k, k);
  rrect(ctx, -w / 2, -h / 2, w, h, h / 2); ctx.fillStyle = bg; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = accent; ctx.stroke();
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(s, 0, 2);
  ctx.restore();
}
// big stat card: number + label
export function stat(ctx, t, t0, big, small, x, y, { color = "#ffd84d", size = 86, t1 = 1e9, w = 0 } = {}) {
  if (t < t0 || t > t1 + 0.3) return;
  const k = easeOutBack(clamp((t - t0) / 0.38)); const out = t > t1 ? 1 - (t - t1) / 0.3 : 1;
  ctx.save(); ctx.globalAlpha = clamp(out) * clamp((t - t0) / 0.15); ctx.translate(x, y); ctx.scale(k, k);
  ctx.font = `${size}px Anton`; const bw = Math.max(w, ctx.measureText(big).width + 70); ctx.font = `600 ${Math.round(size * 0.3)}px NotoSans`; const sw = ctx.measureText(small).width + 50; const ww = Math.max(bw, sw);
  rrect(ctx, -ww / 2, -size * 0.95, ww, size * 1.55, 22); ctx.fillStyle = "rgba(14,18,30,0.84)"; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = color; ctx.stroke();
  ctx.restore();
  ctx.save(); ctx.globalAlpha = clamp(out) * clamp((t - t0) / 0.15); ctx.translate(x, y); ctx.scale(k, k);
  txt(ctx, big, 0, 0, { size, color, sw: 0 }); txt(ctx, small, 0, size * 0.42, { size: Math.round(size * 0.3), font: "NotoSans", weight: "600", color: "#e8ecf4", sw: 0 });
  ctx.restore();
}
// year badge (top-left)
export function badge(ctx, t, t0, s, { t1 = 1e9 } = {}) {
  if (t < t0 || t > t1 + 0.4) return;
  const u = ss((t - t0) / 0.45), out = t > t1 ? 1 - (t - t1) / 0.4 : 1;
  ctx.save(); ctx.globalAlpha = clamp(out); ctx.translate(lerp(-240, 0, u), 0);
  ctx.font = "44px Anton"; const w = ctx.measureText(s).width + 56;
  rrect(ctx, 34, 30, w, 66, 16); ctx.fillStyle = "rgba(14,18,30,0.85)"; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = "#ffd84d"; ctx.stroke();
  txt(ctx, s, 34 + w / 2, 80, { size: 44, color: "#ffd84d", sw: 0 }); ctx.restore();
}
// name plate under a character
export function plateName(ctx, t, t0, s, x, y, color = "#5fd3ff") { chip(ctx, t, t0, s, x, y > 560 ? 236 : y, { size: 22, accent: color, t1: t0 + 4.5 }); }
// speech bubble
export function bubble(ctx, t, t0, t1, x, y, draw, { w = 200, h = 110, tail = "left" } = {}) {
  if (t < t0 || t > t1 + 0.25) return;
  const k = easeOutBack(clamp((t - t0) / 0.3)), out = t > t1 ? 1 - (t - t1) / 0.25 : 1;
  ctx.save(); ctx.globalAlpha = clamp(out); ctx.translate(x, y); ctx.scale(k, k);
  ctx.fillStyle = "#fff"; ctx.strokeStyle = "#1b1d22"; ctx.lineWidth = 4;
  rrect(ctx, -w / 2, -h / 2, w, h, 26); ctx.fill(); ctx.stroke();
  const tx = tail === "left" ? -w / 4 : w / 4; ctx.beginPath(); ctx.moveTo(tx - 14, h / 2 - 2); ctx.lineTo(tx + (tail === "left" ? -30 : 30), h / 2 + 34); ctx.lineTo(tx + 16, h / 2 - 2); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.fillStyle = "#fff"; ctx.fillRect(tx - 12, h / 2 - 6, 26, 8);
  draw(ctx); ctx.restore();
}
// chapter card
export function chapter(ctx, t, d, num, title, bg, year) {
  ctx.save(); cam(ctx, t, d, { z0: 1.08, z1: 1.22 }); plate(ctx, bg); ctx.restore();
  shade(ctx, 0.55); vignette(ctx, 0.6);
  const u = easeOutBack(clamp(t / 0.4));
  ctx.save(); ctx.translate(W / 2, 330); ctx.scale(u, u);
  txt(ctx, num, 0, -70, { size: 46, color: "#ffd84d", sw: 6 });
  txt(ctx, title.toUpperCase(), 0, 30, { size: 84, sw: 10, maxW: 1150 });
  ctx.restore();
  if (year) chip(ctx, t, 0.5, year, W / 2, 440, { size: 30, accent: "#ffd84d" });
  ctx.save(); ctx.globalAlpha = 0.9; ctx.fillStyle = "#ffd84d"; ctx.fillRect(W / 2 - 160 * ease(t, 0.2, 0.8), 395, 320 * ease(t, 0.2, 0.8), 5); ctx.restore();
}
// captions
export function caption(ctx, text, alpha = 1) {
  if (!text) return;
  ctx.save(); ctx.globalAlpha = alpha;
  let size = 34; ctx.font = `600 ${size}px NotoSans`;
  while (ctx.measureText(text).width > W - 120 && size > 24) { size -= 2; ctx.font = `600 ${size}px NotoSans`; }
  const w = ctx.measureText(text).width;
  rrect(ctx, W / 2 - w / 2 - 22, 652 - size + 2, w + 44, size + 22, 12); ctx.fillStyle = "rgba(8,10,16,0.62)"; ctx.fill();
  ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 5; ctx.strokeStyle = "#0b0c10"; ctx.strokeText(text, W / 2, 662);
  ctx.fillStyle = "#ffffff"; ctx.fillText(text, W / 2, 662); ctx.restore();
}
