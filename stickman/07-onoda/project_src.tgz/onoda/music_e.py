import numpy as np, sys
sys.path.insert(0,'/home/claude/k1000')
from music import mtof, lp, SR, bell
def pl(f,d=0.22,bright=2400):
    t=np.arange(int(d*SR))/SR; x=(np.sin(2*np.pi*f*t)+0.5*np.sin(2*np.pi*2*f*t)+0.2*np.sin(2*np.pi*3*f*t))*np.exp(-t*9)
    return lp(x,bright)
def bass(f,d=0.3):
    t=np.arange(int(d*SR))/SR; return lp(np.sin(2*np.pi*f*t)+0.3*np.sin(2*np.pi*2*f*t),600)*np.exp(-t*5)
def brush(d=0.08):
    n=np.random.default_rng(1).standard_normal(int(d*SR)); t=np.arange(len(n))/SR; return lp(n,6000)*np.exp(-t*40)*0.25
def heist(dur, bpm=112):
    beat=60/bpm; out=np.zeros(int((dur+2)*SR))
    prog=[(45,[0,3,7,10]),(50,[0,3,7,10]),(52,[0,4,7,10]),(45,[0,3,7,10])]  # Am7 Dm7 E7 Am7
    i=0; t=0.0
    while t<dur:
        root,ch=prog[(i//4)%4]; b=i%4
        p=int(t*SR)
        walk=[0,7,12,7][b]; x=bass(mtof(root-12+walk))*0.5; out[p:p+len(x)]+=x
        if b in (1,3):
            for iv in ch: y=pl(mtof(root+12+iv),0.18)*0.08; out[p:p+len(y)]+=y
        # swung off-beat brush
        y=brush(); q=int((t+beat*0.66)*SR); out[q:q+len(y)]+=y
        if b==0 and (i//4)%2==1:
            m=root+24+ch[(i//8)%4]; y=bell(mtof(m),1.0)*0.04; out[p:p+len(y)]+=y
        t+=beat; i+=1
    return out[:int(dur*SR)].astype(np.float32)

def kick():
    t=np.arange(int(0.35*SR))/SR; f=55+90*np.exp(-t*30); return np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*9)
def future(dur, bpm=100):
    from music import music
    beat=60/bpm; pad=music('cosmic',dur+1)[:int(dur*SR)]*0.9
    out=np.zeros(int((dur+2)*SR)); out[:len(pad)]+=pad
    prog=[(45,[0,3,7,12]),(41,[0,4,7,12]),(48,[0,4,7,12]),(43,[0,4,7,12])]  # Am F C G
    i=0; t=0.0
    while t<dur:
        root,ch=prog[(i//16)%4]; p=int(t*SR)
        if t>1.0:
            y=pl(mtof(root+24+ch[i%4]),0.16,3200)*0.05; out[p:p+len(y)]+=y
        if i%4==0 and t>3.0: y=kick()*0.35; out[p:p+len(y)]+=y
        if i%4==2 and t>3.0: y=brush(0.05)*0.6; out[p:p+len(y)]+=y
        if i%16==0: y=bass(mtof(root-12),beat*3.5)*0.4; out[p:p+len(y)]+=y
        t+=beat/4; i+=1
    return out[:int(dur*SR)].astype(np.float32)

def war(dur):
    from music import music
    a=music('tense',dur+1)[:int(dur*SR)]; b=music('ancient',dur+1,offset=2.0)[:int(dur*SR)]
    out=a*0.8+b*0.5; t=np.arange(len(out))/SR
    # slow taiko-like pulse
    for bt in np.arange(2.0,dur-1,1.25):
        p=int(bt*SR); n=int(0.4*SR); tt=np.arange(n)/SR; k=np.sin(2*np.pi*(60+40*np.exp(-tt*25))*tt)*np.exp(-tt*7)*0.35
        out[p:p+n]+=k[:len(out)-p]
    return out.astype(np.float32)
