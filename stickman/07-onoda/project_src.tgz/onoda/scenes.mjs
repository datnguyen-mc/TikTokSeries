import { W, H, clamp, lerp, ss, ease, easeOutBack, plate, spr, act, prop, glow, shade, vignette, sparkles, particles, twinkle, chip } from "./lib.mjs";
export const S = {};
const GY = 1110;
function shots(ctx, t, s, list) {
  const st = list.map(([wi]) => wi === 0 ? 0 : s.w[wi] - 0.08);
  let i = 0; while (i + 1 < list.length && t >= st[i + 1]) i++;
  const t0 = st[i], t1 = i + 1 < list.length ? st[i + 1] : s.d; const lt = t - t0;
  ctx.save(); list[i][1](ctx, lt, t1 - t0, (k) => s.w[k] - t0); ctx.restore();
  if (lt < 0.1 && i > 0) { ctx.fillStyle = `rgba(255,255,255,${0.25 * (1 - lt / 0.1)})`; ctx.fillRect(0, 0, W, H); }
}
const bg = (ctx, name, t, d, { z0 = 1.04, z1 = 1.14, x0 = 0, x1 = 0, y0 = 0, y1 = 0, rot = 0, filter } = {}) => {
  const u = ss(t / Math.max(d, 0.01)); const z = lerp(z0, z1, u);
  ctx.save(); ctx.translate(W / 2 + lerp(x0, x1, u), H / 2 + lerp(y0, y1, u)); if (rot) ctx.rotate(rot * t); ctx.scale(z, z); ctx.translate(-W / 2, -H / 2); plate(ctx, name, { filter }); ctx.restore();
};
const stampTxt = (ctx, t, t0, s, x, y, color = "#d23a2a", rot = -0.18, size = 110) => {
  if (t < t0) return; const k = clamp((t - t0) / 0.18); const sc = lerp(2.2, 1, ss(k));
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc); ctx.globalAlpha = k;
  ctx.font = `${size}px Archivo`; const w = ctx.measureText(s).width; ctx.lineWidth = 10; ctx.strokeStyle = color; ctx.strokeRect(-w / 2 - 24, -size * 0.92, w + 48, size * 1.2);
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.fillText(s, 0, 0); ctx.restore();
};
const bigNum = (ctx, t, t0, s, x, y, color = "#ffd84d", size = 120) => { if (t < t0) return; const k = easeOutBack(clamp((t - t0) / 0.3)); ctx.save(); ctx.translate(x, y); ctx.scale(k, k); ctx.font = `${size}px Archivo`; ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 16; ctx.strokeStyle = "#000"; ctx.strokeText(s, 0, 0); ctx.fillStyle = color; ctx.fillText(s, 0, 0); ctx.restore(); };
const fadeOut = (c, lt, d, len = 0.8) => { if (lt > d - len) { c.fillStyle = `rgba(0,0,0,${ease(lt, d - len, d)})`; c.fillRect(0, 0, W, H); } };

// ---- Onoda ----
import { rain } from "./lib.mjs";
const K = { f: 1.08, c: 1.1 };
const rainOf = (ctx, t, name, n = 14, s = 0.22, seed = 3, sp = 160) => { for (let i = 0; i < n; i++) { const x = ((i * 97 + seed * 31) % 680) + 20; const y = ((t * sp + i * 140) % 1500) - 200; spr(ctx, name, x + Math.sin(t * 1.5 + i) * 30, y, s, { anchor: "c", rot: Math.sin(t * 2 + i) * 0.9 }); } };
const leaves = (c, lt, a = 0.5) => particles(c, lt, { n: 22, color: `rgba(40,70,30,${a})`, vy: 40, vx: -15, size: 7 });
const somber = "saturate(0.55) brightness(0.8)";

S.hook = { sfx: (w) => [[0.02, "wind", 0.3, 7], [w[1], "thud", 0.45], [w[7], "low_drone", 0.3, 3], [w[13], "rocks", 0.25, 1], [w[19], "thud", 0.5]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "j01", lt, d, { z0: 1.0, z1: 1.15 }); leaves(c, lt);
      bigNum(c, lt, W2(1), "1974", 360, 300, "#ffd84d", 180); chip(c, lt, W2(7), "Thế chiến II đã kết thúc từ năm 1945", 360, 400, { size: 30, accent: "#ffd84d" }); }],
    [13, (c, lt, d, W2) => { bg(c, "j01", lt, d, { z0: 1.2, z1: 1.32 }); leaves(c, lt, 0.6);
      act(c, lt, [[0, { p: "late_1", x: 760, y: GY, s: K.f, walk: 1 }], [0.01, { x: 380, move: 1.4 }]], 1);
      if (lt > W2(19)) stampTxt(c, lt, W2(19), "VẪN CHIẾN ĐẤU", 360, 360, "#e0332a", -0.1, 96); }],
  ]);
} };

S.order = { sfx: (w) => [[0.02, "waves", 0.3, 4], [w[1], "pop", 0.3], [w[9], "chime", 0.2], [w[13], "low_drone", 0.3, 3], [w[15], "thud", 0.45], [w[19], "thud", 0.45]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "j02", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "lineup_1", x: -120, y: GY, s: K.f, walk: 1 }], [0.01, { x: 330, move: 1.6 }]], 1);
      bigNum(c, lt, W2(1), "12/1944", 360, 290, "#ffd84d", 140); chip(c, lt, W2(2), "Trung úy Hiroo Onoda", 360, 380, { size: 36, accent: "#ffd84d" });
      chip(c, lt, W2(9), "Đảo Lubang · Philippines", 360, 450, { size: 32, accent: "#5fd3ff" }); }],
    [13, (c, lt, d, W2) => { bg(c, "j03", lt, d, { z0: 1.05, z1: 1.16 });
      act(c, lt, [[0, { p: "lineup_2", x: 220, y: GY, s: K.f, popin: 1 }]], 2); act(c, lt, [[0.15, { p: "ono_2", x: 510, y: GY, s: K.f, popin: 1 }]], 1);
      chip(c, lt, 0.05, "Mệnh lệnh", 360, 220, { size: 38, accent: "#ff6b6b" });
      if (lt > W2(15)) stampTxt(c, lt, W2(15), "KHÔNG ĐẦU HÀNG", 360, 350, "#e0332a", -0.1, 84);
      if (lt > W2(19)) stampTxt(c, lt, W2(19), "KHÔNG TỰ SÁT", 360, 490, "#e0332a", 0.08, 84); }],
  ]);
} };

S.promise = { sfx: (w) => [[w[3], "pop", 0.3], [w[5], "pop", 0.3], [w[10], "chime", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "j03", lt, d, { z0: 1.15, z1: 1.25 });
      act(c, lt, [[0, { p: "oth_5", x: 230, y: GY, s: K.f, popin: 1 }]], 2); act(c, lt, [[0.15, { p: "oth_6", x: 500, y: GY, s: K.f, popin: 1 }]], 1);
      bigNum(c, lt, W2(3), "3 NĂM?", 240, 330, "#ffd84d", 110); bigNum(c, lt, W2(5), "5 NĂM?", 480, 450, "#ffd84d", 110);
      chip(c, lt, W2(10), "\"Chúng tôi sẽ quay lại đón cậu\"", 360, 220, { size: 30, accent: "#ffd84d" }); }],
  ]);
} };

S.leaflets = { sfx: (w) => [[w[1], "thud", 0.4], [w[6], "paper", 0.35, 2], [w[12], "low_drone", 0.3, 3], [w[18], "thud", 0.45]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "j04", lt, d, { z0: 1.02, z1: 1.14 });
      if (lt > W2(6)) rainOf(c, lt - W2(6), "props1_3", 14, 0.3, 3, 220);
      bigNum(c, lt, W2(1), "1945", 360, 300, "#ffd84d", 170); chip(c, lt, W2(2), "Chiến tranh kết thúc", 360, 400, { size: 36, accent: "#7dffa8" }); }],
    [12, (c, lt, d, W2) => { bg(c, "j04", lt, d, { z0: 1.2, z1: 1.3, filter: "brightness(0.85)" }); rainOf(c, lt + 3, "props1_3", 8, 0.25, 5, 160);
      act(c, lt, [[0, { p: "ono_5", x: 360, y: GY, s: K.f * 1.1, popin: 1 }]], 1);
      if (lt > W2(18)) stampTxt(c, lt, W2(18), "MƯU CỦA ĐỊCH!", 360, 350, "#e0332a", -0.12, 96); }],
  ]);
} };

S.jungle = { sfx: (w) => [[0.02, "birds", 0.25, 3], [w[7], "pop", 0.3], [w[8], "pop", 0.3], [w[9], "low_drone", 0.3, 3], [w[15], "low_drone", 0.35, 3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "j06", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "oth_1", x: 240, y: GY, s: K.f, walk: 1 }], [0.01, { x: 270, move: 3 }]], 2); act(c, lt, [[0.1, { p: "lineup_1", x: 520, y: GY, s: K.f, popin: 1 }]], 1);
      chip(c, lt, W2(1), "4 người lính", 360, 220, { size: 38, accent: "#ffd84d" });
      prop(c, lt, "props1_4", 230, 520, 0.6, { t0: W2(7), amp: 5 }); prop(c, lt, "props1_5", 500, 500, 0.5, { t0: W2(8), amp: 5 }); }],
    [9, (c, lt, d, W2) => { bg(c, "j01", lt, d, { z0: 1.25, z1: 1.35, filter: "brightness(0.75)" }); leaves(c, lt, 0.6);
      act(c, lt, [[0, { p: "ono_1", x: 330, y: GY, s: K.c * 1.2, popin: 1 }]], 1);
      chip(c, lt, W2(12), "Đánh du kích", 360, 230, { size: 38, accent: "#ff6b6b" }); }],
    [15, (c, lt, d, W2) => { bg(c, "j07", lt, d, { z0: 1.05, z1: 1.14, filter: somber });
      act(c, lt, [[0, { p: "oth_3", x: 600, y: GY, s: 1.45, walk: 1, filter: somber }], [0.01, { x: 200, move: d }]], 4);
      chip(c, lt, 0.1, "Nhiều người dân trên đảo thiệt mạng", 360, 230, { size: 30, accent: "#ff6b6b" }); shade(c, 0.2); }],
  ]);
} };

S.alone = { sfx: (w) => [[0.02, "crickets", 0.3, 6], [w[4], "footsteps", 0.3, 1.5], [w[8], "thud", 0.35], [w[13], "low_drone", 0.35, 4]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "j05", lt, d, { z0: 1.05, z1: 1.14 });
      const gone = lt > W2(8) ? ss((lt - W2(8)) / 0.8) : 0;
      spr(c, "oth_1", 230, GY, K.f, { alpha: 1 - gone, filter: gone > 0 ? somber : undefined });
      act(c, lt, [[W2(4), { p: "oth_2", x: 140, y: GY, s: K.f, walk: 1, fade: 0.3 }], [W2(4) + 0.01, { x: -220, move: 2.0 }]], 3);
      act(c, lt, [[0, { p: "lineup_1", x: 530, y: GY, s: K.f, popin: 1 }]], 1);
      chip(c, lt, W2(5), "1950 · đầu hàng", 360, 220, { size: 32, accent: "#ffd84d" }); chip(c, lt, W2(9), "1954 · 1972 · bị bắn chết", 360, 290, { size: 32, accent: "#ff6b6b" }); }],
    [13, (c, lt, d, W2) => { bg(c, "j07", lt, d, { z0: 1.05, z1: 1.18 });
      act(c, lt, [[0, { p: "ono_4", x: 360, y: GY, s: K.c * 1.2, popin: 1 }]], 1);
      bigNum(c, lt, W2(14), "1972", 360, 300, "#ffd84d", 160); chip(c, lt, W2(19), "Chỉ còn một mình", 360, 400, { size: 36, accent: "#ffd84d" }); }],
  ]);
} };

S.suzuki = { sfx: (w) => [[0.02, "street", 0.3, 3], [w[1], "pop", 0.3], [w[11], "birds", 0.2, 3], [w[15], "pop", 0.3], [w[18], "pop", 0.3], [w[21], "pop", 0.3], [w[23], "swell", 0.35], [w[25], "chime", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "j08", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "lineup_3", x: -120, y: GY, s: K.f, walk: 1 }], [0.01, { x: 360, move: 1.5 }]], 3);
      bigNum(c, lt, W2(1), "1974", 360, 300, "#ffd84d", 160); chip(c, lt, W2(7), "Norio Suzuki", 360, 400, { size: 38, accent: "#ff6b6b" }); }],
    [11, (c, lt, d, W2) => { bg(c, "j09", lt, d, { z0: 1.05, z1: 1.15 });
      act(c, lt, [[0, { p: "late_3", x: 360, y: GY, s: K.f, popin: 1 }]], 3);
      chip(c, lt, 0.05, "Danh sách cần tìm", 360, 220, { size: 34, accent: "#ffd84d" });
      prop(c, lt, "lineup_1", 140, 420, 0.42, { t0: W2(15), amp: 4 }); prop(c, lt, "props1_7", 360, 420, 0.75, { t0: W2(18), amp: 4 }); prop(c, lt, "props1_8", 580, 420, 0.7, { t0: W2(21), amp: 4 }); }],
    [23, (c, lt, d, W2) => { bg(c, "j01", lt, d, { z0: 1.1, z1: 1.2 }); leaves(c, lt, 0.4);
      act(c, lt, [[0, { p: "late_3", x: 210, y: GY, s: K.f, popin: 1 }]], 3); act(c, lt, [[0.3, { p: "late_1", x: 520, y: GY, s: K.f, fade: 0.6 }]], 1);
      bigNum(c, lt, W2(25), "4 NGÀY", 360, 330, "#7dffa8", 140); if (lt > W2(28)) sparkles(c, 360, 650, lt, { r: 200, n: 8 }); }],
  ]);
} };

S.major = { sfx: (w) => [[w[5], "pop", 0.3], [w[11], "waves", 0.3, 3], [w[16], "whoosh", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "j10", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "late_1", x: 360, y: GY, s: K.f, popin: 1 }]], 1);
      chip(c, lt, W2(5), "Chỉ nghe lệnh cấp trên", 360, 230, { size: 36, accent: "#ffd84d" }); }],
    [11, (c, lt, d, W2) => { bg(c, "j02", lt, d, { z0: 1.1, z1: 1.2 });
      act(c, lt, [[0, { p: "late_5", x: 820, y: GY, s: K.f, walk: 1 }], [0.01, { x: 400, move: 1.6 }]], 2);
      chip(c, lt, 0.1, "Cựu chỉ huy · Thiếu tá Taniguchi", 360, 230, { size: 30, accent: "#ffd84d" }); }],
  ]);
} };

S.surrender = { sfx: (w) => [[w[1], "thud", 0.4], [w[3], "paper", 0.3], [w[6], "swell", 0.35], [w[8], "glass", 0.25], [w[14], "chime", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "j10", lt, d, { z0: 1.12, z1: 1.22 });
      act(c, lt, [[0, { p: "late_5", x: 220, y: GY, s: K.f, popin: 1 }]], 2); act(c, lt, [[0.1, { p: "late_1", x: 510, y: GY, s: K.f, popin: 1 }]], 1);
      bigNum(c, lt, W2(1), "9/3/1974", 360, 300, "#ffd84d", 130); }],
    [5, (c, lt, d, W2) => { bg(c, "j11", lt, d, { z0: 1.02, z1: 1.14 });
      glow(c, 360, 760, 260, "rgba(255,210,120,0.9)", 0.35);
      act(c, lt, [[0, { p: "late_2", x: 360, y: GY, s: K.f * 1.15, popin: 1 }]], 1);
      chip(c, lt, W2(6), "Trao lại thanh kiếm", 360, 230, { size: 36, accent: "#ffd84d" });
      bigNum(c, lt, W2(14), "52 TUỔI", 360, 360, "#ffffff", 130); }],
  ]);
} };

S.ending = { sfx: (w) => [[0.02, "warm_pad", 0.3, 6], [w[1], "thud", 0.4], [w[16], "chime", 0.3], [w[20], "low_drone", 0.3, 2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "j12", lt, d, { z0: 1.02, z1: 1.12 });
      act(c, lt, [[0, { p: "late_1", x: 360, y: GY, s: K.f, fade: 0.6, filter: "brightness(0.85)" }]], 1);
      bigNum(c, lt, W2(1), "GẦN 30 NĂM", 360, 300, "#ffd84d", 120); chip(c, lt, W2(6), "cho một cuộc chiến đã kết thúc", 360, 400, { size: 32, accent: "#ffd84d" }); }],
    [12, (c, lt, d, W2) => { bg(c, "j12", lt, d, { z0: 1.15, z1: 1.25 });
      act(c, lt, [[0, { p: "ono_2", x: 360, y: GY, s: K.f, popin: 1 }]], 1);
      bigNum(c, lt, W2(16), "TRUNG THÀNH?", 360, 300, "#ffd84d", 110); bigNum(c, lt, W2(20), "BI KỊCH?", 360, 430, "#ff6b6b", 120);
      fadeOut(c, lt, d, 0.7); }],
  ]);
} };
