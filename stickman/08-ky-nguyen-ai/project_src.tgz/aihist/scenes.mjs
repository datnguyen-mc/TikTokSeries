import { W, H, clamp, lerp, ss, ease, easeOutBack, plate, spr, act, prop, glow, shade, vignette, sparkles, particles, twinkle, chip } from "./lib.mjs";
export const S = {};
const GY = 1110;
function shots(ctx, t, s, list) {
  const st = list.map(([wi]) => wi === 0 ? 0 : s.w[wi] - 0.08);
  let i = 0; while (i + 1 < list.length && t >= st[i + 1]) i++;
  const t0 = st[i], t1 = i + 1 < list.length ? st[i + 1] : s.d; const lt = t - t0;
  ctx.save(); list[i][1](ctx, lt, t1 - t0, (k) => s.w[k] - t0); ctx.restore();
  if (lt < 0.1 && i > 0) { ctx.fillStyle = `rgba(255,255,255,${0.25 * (1 - lt / 0.1)})`; ctx.fillRect(0, 0, W, H); }
}
const bg = (ctx, name, t, d, { z0 = 1.04, z1 = 1.14, x0 = 0, x1 = 0, y0 = 0, y1 = 0, rot = 0, filter } = {}) => {
  const u = ss(t / Math.max(d, 0.01)); const z = lerp(z0, z1, u);
  ctx.save(); ctx.translate(W / 2 + lerp(x0, x1, u), H / 2 + lerp(y0, y1, u)); if (rot) ctx.rotate(rot * t); ctx.scale(z, z); ctx.translate(-W / 2, -H / 2); plate(ctx, name, { filter }); ctx.restore();
};
const stampTxt = (ctx, t, t0, s, x, y, color = "#d23a2a", rot = -0.18, size = 110) => {
  if (t < t0) return; const k = clamp((t - t0) / 0.18); const sc = lerp(2.2, 1, ss(k));
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc); ctx.globalAlpha = k;
  ctx.font = `${size}px Archivo`; const w = ctx.measureText(s).width; ctx.lineWidth = 10; ctx.strokeStyle = color; ctx.strokeRect(-w / 2 - 24, -size * 0.92, w + 48, size * 1.2);
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.fillText(s, 0, 0); ctx.restore();
};
const bigNum = (ctx, t, t0, s, x, y, color = "#ffd84d", size = 120) => { if (t < t0) return; const k = easeOutBack(clamp((t - t0) / 0.3)); ctx.save(); ctx.translate(x, y); ctx.scale(k, k); ctx.font = `${size}px Archivo`; ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 16; ctx.strokeStyle = "#000"; ctx.strokeText(s, 0, 0); ctx.fillStyle = color; ctx.fillText(s, 0, 0); ctx.restore(); };
const fadeOut = (c, lt, d, len = 0.8) => { if (lt > d - len) { c.fillStyle = `rgba(0,0,0,${ease(lt, d - len, d)})`; c.fillRect(0, 0, W, H); } };

// ---- Kỷ nguyên AI ----
const K = { f: 1.25, pc: 1.5 };
const bust = (c, lt, name, x = 360, s = 2.0, t0 = 0, o = {}) => act(c, lt, [[t0, { p: name, x, y: H + 20, s, popin: 1, ...o }]], 3);
const rainOf = (ctx, t, name, n = 14, s = 0.22, seed = 3, sp = 160) => { for (let i = 0; i < n; i++) { const x = ((i * 97 + seed * 31) % 680) + 20; const y = ((t * sp + i * 140) % 1500) - 200; spr(ctx, name, x + Math.sin(t * 1.5 + i) * 30, y, s, { anchor: "c", rot: Math.sin(t * 2 + i) * 0.9 }); } };
const counter = (c, lt, t0, t1, v0, v1, x, y, color, size, suffix = "") => { if (lt < t0) return; const u = ss((lt - t0) / Math.max(0.01, t1 - t0)); bigNum(c, 1, 0, Math.round(lerp(v0, v1, u)).toLocaleString("de-DE") + suffix, x, y, color, size); };

S.hook = { sfx: (w) => [[0.02, "tick_loop", 0.2, 5], [w[1], "thud", 0.4], [w[10], "pop", 0.3], [w[12], "swell", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k01", lt, d, { z0: 1.0, z1: 1.14 });
      act(c, lt, [[0, { p: "lineup_1", x: 360, y: GY, s: K.f, popin: 1 }], [W2(10), { p: "tur_think" }]], 1);
      bigNum(c, lt, W2(1), "1950", 360, 200, "#ffd84d", 120);
      bigNum(c, lt, W2(12), "MÁY CÓ THỂ", 360, 340, "#ffffff", 84); bigNum(c, lt, W2(15), "SUY NGHĨ?", 360, 450, "#7df9ff", 100); }],
  ]);
} };

S.turing = { sfx: (w) => [[w[2], "chime", 0.3], [w[7], "typing", 0.35, 2.5], [w[17], "notify", 0.3], [w[25], "pop", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k01", lt, d, { z0: 1.15, z1: 1.25 });
      act(c, lt, [[0, { p: "tur_4", x: 360, y: GY, s: K.f * 1.05, popin: 1 }]], 1);
      chip(c, lt, W2(2), "Alan Turing (1912–1954)", 360, 230, { size: 36, accent: "#ffd84d" }); }],
    [7, (c, lt, d, W2) => { bg(c, "k02", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "tur_2", x: 210, y: GY, s: K.f, popin: 1 }]], 1); act(c, lt, [[0.15, { p: "lineup_5", x: 530, y: GY, s: K.pc, popin: 1 }]], 5);
      c.save(); c.setLineDash([16, 12]); c.strokeStyle = "rgba(255,255,255,0.8)"; c.lineWidth = 5; c.beginPath(); c.moveTo(370, 560); c.lineTo(370, GY); c.stroke(); c.restore();
      prop(c, lt, "props1_8", 230, 500, 0.45, { t0: W2(11), amp: 4 }); prop(c, lt, "props1_8", 520, 560, 0.45, { t0: W2(13), amp: 4, seed: 3 });
      bigNum(c, lt, W2(8), "PHÉP THỬ TURING", 360, 300, "#ffd84d", 80);
      if (lt > W2(25)) stampTxt(c, lt, W2(25), "ĐỦ THÔNG MINH", 360, 420, "#2ecc71", -0.1, 78); }],
  ]);
} };

S.dartmouth = { sfx: (w) => [[0.02, "birds", 0.25, 3], [w[1], "pop", 0.3], [w[10], "swell", 0.35], [w[17], "chime", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k03", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "sci_1", x: 360, y: GY, s: 1.05, popin: 1 }]], 2);
      bigNum(c, lt, W2(1), "1956", 360, 280, "#ffd84d", 160); chip(c, lt, W2(3), "Đại học Dartmouth · Mỹ", 360, 380, { size: 34, accent: "#ffd84d" }); }],
    [10, (c, lt, d, W2) => { bg(c, "k03", lt, d, { z0: 1.18, z1: 1.28 });
      act(c, lt, [[0, { p: "misc_1", x: 360, y: GY, s: K.pc * 1.2, popin: 1 }]], 5);
      chip(c, lt, 0.05, "Lần đầu có tên gọi", 360, 220, { size: 34, accent: "#7df9ff" });
      bigNum(c, lt, W2(17), "TRÍ TUỆ", 360, 340, "#7df9ff", 120); bigNum(c, lt, W2(19), "NHÂN TẠO", 360, 470, "#7df9ff", 120);
      if (lt > W2(19)) sparkles(c, 360, 420, lt, { r: 250, n: 10 }); }],
  ]);
} };

S.perceptron = { sfx: (w) => [[w[3], "typing", 0.3, 1.5], [w[11], "paper_drop", 0.4], [w[17], "pop", 0.3], [w[19], "pop", 0.3], [w[22], "pop", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k02", lt, d, { z0: 1.12, z1: 1.22 });
      prop(c, lt, "props1_4", 360, 520, 1.6, { t0: W2(3), amp: 5, rot: -0.08 });
      bust(c, lt, "sci_3", 360, 2.0);
      bigNum(c, lt, 0.05, "1958", 360, 260, "#ffd84d", 140); chip(c, lt, W2(4), "Máy Perceptron", 360, 350, { size: 36, accent: "#ffd84d" }); }],
    [11, (c, lt, d, W2) => { bg(c, "k04", lt, d, { z0: 1.02, z1: 1.14 });
      const k = clamp(lt / 0.5); spr(c, "props1_5", 360, 640, lerp(0.2, 1.6, ss(k)), { anchor: "c", rot: (1 - ss(k)) * 6 - 0.08 });
      chip(c, lt, W2(17), "Máy sẽ biết đi", 360, 230, { size: 34, accent: "#ffd84d" }); chip(c, lt, W2(19), "biết nói", 360, 300, { size: 34, accent: "#ffd84d" });
      chip(c, lt, W2(22), "và TỰ NHẬN THỨC!", 360, 370, { size: 38, accent: "#ff6b6b" }); }],
  ]);
} };

S.winter = { sfx: (w) => [[0.02, "wind", 0.4, 4], [w[5], "thud", 0.45], [w[10], "battery_down", 0.35], [w[14], "low_drone", 0.3, 2]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k05", lt, d, { z0: 1.02, z1: 1.14 }); rainOf(c, lt, "props1_6", 16, 0.12, 4, 120);
      act(c, lt, [[0, { p: "misc_5", x: 360, y: GY, s: K.pc * 1.2, popin: 1 }], [W2(10), { p: "misc_2", shake: 1 }]], 5);
      if (lt > W2(5)) stampTxt(c, lt, W2(5), "CẮT TÀI TRỢ", 360, 300, "#e0332a", -0.12, 90);
      bigNum(c, lt, W2(14), "MÙA ĐÔNG AI", 360, 450, "#9fe8ff", 100); }],
  ]);
} };

S.chess = { sfx: (w) => [[0.02, "low_drone", 0.25, 3], [w[1], "thud", 0.4], [w[4], "notify", 0.3], [w[6], "thud", 0.5], [w[6] + 0.2, "gasp", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k06", lt, d, { z0: 1.05, z1: 1.16 });
      act(c, lt, [[0, { p: "lineup_3", x: 200, y: GY, s: K.f, popin: 1 }]], 3); act(c, lt, [[0.15, { p: "lineup_5", x: 540, y: GY, s: K.pc, popin: 1 }]], 5);
      prop(c, lt, "props1_1", 370, 820, 0.5, { t0: 0.3, amp: 3 });
      bigNum(c, lt, W2(1), "1997", 360, 280, "#ffd84d", 150); chip(c, lt, W2(4), "Deep Blue", 540, 380, { size: 36, accent: "#5fd3ff" }); }],
    [6, (c, lt, d, W2) => { bg(c, "k06", lt, d, { z0: 1.2, z1: 1.3 });
      act(c, lt, [[0, { p: "misc_1", x: 560, y: GY - 120, s: K.pc, popin: 1 }]], 5);
      bust(c, lt, "sci_4", 260, 2.0, 0, { shake: 1.2 });
      bigNum(c, lt, W2(6), "MÁY THẮNG", 360, 300, "#ff6b6b", 120); chip(c, lt, W2(15), "Garry Kasparov · vô địch thế giới", 360, 400, { size: 30, accent: "#ffd84d" }); }],
  ]);
} };

S.deep = { sfx: (w) => [[0.02, "low_drone", 0.3, 4], [w[4], "rumble", 0.3, 1.5], [w[7], "pop", 0.3], [w[16], "swell", 0.35], [w[21], "chime", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k10", lt, d, { z0: 1.02, z1: 1.16 }); particles(c, lt, { n: 70, color: "rgba(140,200,255,0.8)", vy: 90, size: 4 });
      chip(c, lt, W2(1), "Internet: núi dữ liệu", 360, 230, { size: 34, accent: "#7df9ff" });
      prop(c, lt, "props1_7", 360, 640, 1.4, { t0: W2(7), amp: 6 }); chip(c, lt, W2(8), "Card đồ họa = sức mạnh tính toán", 360, 300, { size: 30, accent: "#7dffa8" }); }],
    [15, (c, lt, d, W2) => { bg(c, "k07", lt, d, { z0: 1.02, z1: 1.14 });
      glow(c, 360, 480, 260, "rgba(80,255,200,0.9)", 0.45); prop(c, lt, "props1_9", 360, 480, 1.2, { t0: 0.05, amp: 6 });
      act(c, lt, [[W2(20), { p: "misc_4", x: 360, y: GY, s: K.pc * 1.1, popin: 1 }]], 5);
      bigNum(c, lt, W2(16), "2012", 360, 240, "#7dffa8", 140); chip(c, lt, W2(17), "Học sâu · Deep learning", 360, 760, { size: 32, accent: "#7dffa8" }); }],
  ]);
} };

S.go = { sfx: (w) => [[0.02, "low_drone", 0.25, 3], [w[1], "thud", 0.4], [w[2], "tap", 0.35], [w[8], "tap", 0.35], [w[10], "thud", 0.5]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k08", lt, d, { z0: 1.05, z1: 1.18 });
      act(c, lt, [[0, { p: "misc_3", x: 210, y: GY, s: K.f, popin: 1 }]], 4); act(c, lt, [[0.15, { p: "lineup_5", x: 540, y: GY, s: K.pc, popin: 1 }]], 5);
      prop(c, lt, "props1_2", 380, 860, 0.45, { t0: 0.3, amp: 3 });
      bigNum(c, lt, W2(1), "2016", 360, 270, "#ffd84d", 140); chip(c, lt, W2(2), "AlphaGo", 540, 360, { size: 36, accent: "#5fd3ff" }); chip(c, lt, W2(8), "Lee Sedol", 210, 360, { size: 36, accent: "#ffd84d" });
      bigNum(c, lt, W2(10), "4 - 1", 360, 520, "#7dffa8", 150); }],
  ]);
} };

S.chat = { sfx: (w) => [[w[2], "pop", 0.3], [w[3], "notify", 0.35], [w[6], "clock_fast", 0.25, 1.2], [w[13], "swell", 0.4]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k09", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "misc_6", x: 360, y: GY, s: K.f, popin: 1 }]], 1);
      prop(c, lt, "props1_8", 500, 520, 0.6, { t0: W2(3), amp: 5 });
      bigNum(c, lt, W2(2), "2022", 360, 270, "#ffd84d", 150); chip(c, lt, W2(3), "ChatGPT ra mắt", 360, 370, { size: 36, accent: "#7dffa8" }); }],
    [6, (c, lt, d, W2) => { bg(c, "k09", lt, d, { z0: 1.2, z1: 1.3, filter: "brightness(0.7)" });
      for (let i = 0; i < 6; i++) { const t0 = 0.1 + i * 0.25; if (lt < t0) continue; spr(c, "misc_7", 130 + (i % 3) * 230, 760 + Math.floor(i / 3) * 260, 0.6 * easeOutBack(clamp((lt - t0) / 0.3))); }
      chip(c, lt, W2(7), "chỉ khoảng 2 tháng", 360, 200, { size: 34, accent: "#ffd84d" });
      counter(c, lt, W2(10), W2(14), 0, 100, 360, 420, "#7dffa8", 150, " TRIỆU"); }],
  ]);
} };

S.ending = { sfx: (w) => [[0.02, "warm_pad", 0.3, 7], [w[5], "chime", 0.3], [w[13], "swell", 0.35], [w[21], "pop", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "k12", lt, d, { z0: 1.02, z1: 1.12 });
      act(c, lt, [[0, { p: "tur_think", x: 200, y: GY, s: K.f, popin: 1 }]], 1); act(c, lt, [[W2(6), { p: "misc_1", x: 540, y: GY, s: K.pc, popin: 1 }]], 5);
      bigNum(c, lt, W2(5), "1950  →  NAY", 360, 300, "#ffd84d", 110); }],
    [13, (c, lt, d, W2) => { bg(c, "k11", lt, d, { z0: 1.05, z1: 1.15 });
      act(c, lt, [[0, { p: "misc_6", x: 230, y: GY, s: K.f, popin: 1 }]], 1); act(c, lt, [[0.15, { p: "lineup_5", x: 520, y: GY, s: K.pc, popin: 1 }]], 5);
      chip(c, lt, 0.1, "Câu hỏi tiếp theo", 360, 230, { size: 36, accent: "#ffd84d" });
      bigNum(c, lt, W2(18), "CHÚNG TA SẼ", 360, 360, "#ffffff", 90); bigNum(c, lt, W2(21), "LÀM GÌ VỚI NÓ?", 360, 470, "#7df9ff", 96);
      fadeOut(c, lt, d, 0.7); }],
  ]);
} };
