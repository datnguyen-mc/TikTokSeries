import { W, H, clamp, lerp, ss, ease, easeOutBack, plate, spr, act, prop, glow, shade, vignette, sparkles, particles, twinkle, chip } from "./lib.mjs";
export const S = {};
const GY = 1110;
function shots(ctx, t, s, list) {
  const st = list.map(([wi]) => wi === 0 ? 0 : s.w[wi] - 0.08);
  let i = 0; while (i + 1 < list.length && t >= st[i + 1]) i++;
  const t0 = st[i], t1 = i + 1 < list.length ? st[i + 1] : s.d; const lt = t - t0;
  ctx.save(); list[i][1](ctx, lt, t1 - t0, (k) => s.w[k] - t0); ctx.restore();
  if (lt < 0.1 && i > 0) { ctx.fillStyle = `rgba(255,255,255,${0.25 * (1 - lt / 0.1)})`; ctx.fillRect(0, 0, W, H); }
}
const bg = (ctx, name, t, d, { z0 = 1.04, z1 = 1.14, x0 = 0, x1 = 0, y0 = 0, y1 = 0, rot = 0, filter } = {}) => {
  const u = ss(t / Math.max(d, 0.01)); const z = lerp(z0, z1, u);
  ctx.save(); ctx.translate(W / 2 + lerp(x0, x1, u), H / 2 + lerp(y0, y1, u)); if (rot) ctx.rotate(rot * t); ctx.scale(z, z); ctx.translate(-W / 2, -H / 2); plate(ctx, name, { filter }); ctx.restore();
};
const stampTxt = (ctx, t, t0, s, x, y, color = "#d23a2a", rot = -0.18, size = 110) => {
  if (t < t0) return; const k = clamp((t - t0) / 0.18); const sc = lerp(2.2, 1, ss(k));
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc); ctx.globalAlpha = k;
  ctx.font = `${size}px Archivo`; const w = ctx.measureText(s).width; ctx.lineWidth = 10; ctx.strokeStyle = color; ctx.strokeRect(-w / 2 - 24, -size * 0.92, w + 48, size * 1.2);
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.fillText(s, 0, 0); ctx.restore();
};
const bigNum = (ctx, t, t0, s, x, y, color = "#ffd84d", size = 120) => { if (t < t0) return; const k = easeOutBack(clamp((t - t0) / 0.3)); ctx.save(); ctx.translate(x, y); ctx.scale(k, k); ctx.font = `${size}px Archivo`; ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 16; ctx.strokeStyle = "#000"; ctx.strokeText(s, 0, 0); ctx.fillStyle = color; ctx.fillText(s, 0, 0); ctx.restore(); };
const fadeOut = (c, lt, d, len = 0.8) => { if (lt > d - len) { c.fillStyle = `rgba(0,0,0,${ease(lt, d - len, d)})`; c.fillRect(0, 0, W, H); } };

// ---- Mùa thu 1945 ----
const K = { f: 1.02 };
const bust = (c, lt, name, x = 360, s = 1.9, t0 = 0, o = {}) => act(c, lt, [[t0, { p: name, x, y: H + 20, s, popin: 1, ...o }]], 3);
const leavesY = (c, lt) => particles(c, lt, { n: 26, color: "rgba(230,170,60,0.75)", vy: 55, vx: -20, size: 6 });
const somber = "saturate(0.45) brightness(0.8)";
const flag = (c, lt, x, y, s, seed = 1, t0 = 0) => { if (lt < t0) return; const k = easeOutBack(clamp((lt - t0) / 0.35)); spr(c, "props1_1", x, y, s * k, { anchor: "c", rot: Math.sin(lt * 3 + seed) * 0.06 }); };

S.hook = { sfx: (w) => [[0.02, "wind", 0.3, 6], [w[3], "thud", 0.4], [w[7], "chime", 0.25], [w[17], "swell", 0.4]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "q01", lt, d, { z0: 1.0, z1: 1.15 }); leavesY(c, lt);
      bigNum(c, lt, W2(3), "15 NGÀY", 360, 300, "#ffd84d", 150); chip(c, lt, W2(7), "Mùa thu 1945", 360, 400, { size: 38, accent: "#ffd84d" });
      if (lt > W2(17)) { glow(c, 360, 660, 220, "rgba(255,80,60,0.9)", 0.4); flag(c, lt, 360, 660, 1.2, 1, W2(17)); } }],
  ]);
} };

S.march = { sfx: (w) => [[0.02, "low_drone", 0.3, 5], [w[1], "thud", 0.4], [w[3], "footsteps", 0.35, 1.5], [w[6], "thud", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "q02", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "lineup_4", x: 250, y: GY, s: K.f, popin: 1 }], [W2(3), { x: -220, move: 1.2, alpha: 0.2 }]], 4);
      act(c, lt, [[0, { p: "lineup_3", x: 900, y: GY, s: K.f }], [W2(3), { x: 400, move: 1.2 }]], 3);
      bigNum(c, lt, W2(1), "3/1945", 360, 300, "#ffd84d", 150); chip(c, lt, W2(3), "Nhật đảo chính Pháp", 360, 400, { size: 36, accent: "#ff6b6b" }); chip(c, lt, W2(8), "Đông Dương", 360, 470, { size: 32, accent: "#ffd84d" }); }],
  ]);
} };

S.famine = { sfx: (w) => [[0.02, "wind", 0.35, 6], [w[3], "low_drone", 0.35, 5]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "q03", lt, d, { z0: 1.02, z1: 1.12, filter: somber });
      act(c, lt, [[0, { p: "ppl_4", x: 230, y: GY, s: K.f, fade: 0.8, filter: somber }]], 1); act(c, lt, [[0.4, { p: "crowd_6", x: 520, y: GY, s: 1.4, fade: 0.8, filter: somber }]], 2);
      chip(c, lt, W2(3), "Nạn đói Ất Dậu", 360, 230, { size: 38, accent: "#ff6b6b" });
      chip(c, lt, W2(11), "Hàng trăm nghìn người chết", 360, 310, { size: 34, accent: "#ff6b6b" }); chip(c, lt, W2(16), "có ước tính tới 2 triệu", 360, 380, { size: 32, accent: "#ff6b6b" });
      shade(c, 0.2); }],
  ]);
} };

S.surrender = { sfx: (w) => [[w[1], "thud", 0.4], [w[2], "low_drone", 0.3, 2], [w[7], "whoosh", 0.35], [w[11], "swell", 0.4]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "q04", lt, d, { z0: 1.05, z1: 1.15 });
      prop(c, lt, "props1_4", 200, 600, 0.75, { t0: 0.05, amp: 3 });
      bust(c, lt, "rulers_2", 575, 1.35);
      bigNum(c, lt, W2(1), "15/8/1945", 360, 280, "#ffd84d", 120); chip(c, lt, W2(2), "Nhật đầu hàng Đồng minh", 360, 380, { size: 34, accent: "#ffd84d" }); }],
    [7, (c, lt, d, W2) => { bg(c, "q09", lt, d, { z0: 1.05, z1: 1.16 });
      act(c, lt, [[0, { p: "ppl_2", x: 360, y: GY, s: K.f * 1.05, popin: 1 }]], 1);
      prop(c, lt, "props1_6", 580, 640, 0.6, { t0: W2(9), amp: 5, rot: -0.2 });
      chip(c, lt, 0.05, "Việt Minh", 360, 230, { size: 38, accent: "#ff6b6b" });
      bigNum(c, lt, W2(11), "TỔNG KHỞI NGHĨA", 360, 360, "#ffd84d", 92); }],
  ]);
} };

S.hanoi = { sfx: (w) => [[0.02, "street", 0.35, 5], [w[1], "thud", 0.35], [w[2], "footsteps", 0.4, 3], [w[11], "whoosh", 0.3], [w[15], "swell", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "q05", lt, d, { z0: 1.02, z1: 1.14 });
      act(c, lt, [[0, { p: "ppl_1", x: 240, y: GY, s: K.f, popin: 1 }]], 1); act(c, lt, [[0.15, { p: "ppl_3", x: 550, y: GY, s: K.f, popin: 1 }]], 2);
      bigNum(c, lt, W2(1), "19/8/1945", 360, 290, "#ffd84d", 120); chip(c, lt, W2(9), "Hà Nội", 360, 380, { size: 38, accent: "#ff6b6b" }); }],
    [11, (c, lt, d, W2) => { bg(c, "q05", lt, d, { z0: 1.18, z1: 1.28 });
      [[120, 380, 0.55], [600, 330, 0.6], [180, 600, 0.5], [560, 620, 0.55], [360, 250, 0.65]].forEach(([x, y, sc], i) => flag(c, lt, x, y, sc, i, i * 0.12));
      act(c, lt, [[0.3, { p: "lineup_2", x: 360, y: GY, s: K.f, popin: 1 }]], 2); if (lt > 0.6) sparkles(c, 360, 500, lt, { r: 260, n: 10 }); }],
  ]);
} };

S.wave = { sfx: (w) => [[w[1], "whoosh", 0.35], [w[3], "whoosh", 0.35], [w[8], "swell", 0.4], [w[13], "chime", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "q06", lt, d, { z0: 1.05, z1: 1.15 }); chip(c, lt, W2(1), "Huế · 23/8", 360, 260, { size: 40, accent: "#ffd84d" }); }],
    [2, (c, lt, d, W2) => { bg(c, "q07", lt, d, { z0: 1.05, z1: 1.15 }); chip(c, lt, W2(3), "Sài Gòn · 25/8", 360, 260, { size: 40, accent: "#ffd84d" }); }],
    [5, (c, lt, d, W2) => { bg(c, "q05", lt, d, { z0: 1.05, z1: 1.18 });
      act(c, lt, [[0, { p: "crowd_2", x: 360, y: GY, s: 1.45, popin: 1 }]], 3);
      bigNum(c, lt, W2(8), "15 NGÀY", 360, 300, "#ffd84d", 150); chip(c, lt, W2(13), "Việt Minh giành chính quyền cả nước", 360, 400, { size: 30, accent: "#ff6b6b" }); }],
  ]);
} };

S.baodai = { sfx: (w) => [[0.02, "warm_pad", 0.3, 5], [w[1], "thud", 0.35], [w[9], "chime", 0.3], [w[13], "glass", 0.25], [w[16], "thud", 0.4]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "q06", lt, d, { z0: 1.12, z1: 1.22 });
      act(c, lt, [[0, { p: "lineup_5", x: 360, y: GY, s: K.f, popin: 1 }]], 5);
      bigNum(c, lt, W2(1), "30/8/1945", 360, 280, "#ffd84d", 120); chip(c, lt, W2(3), "Ngọ Môn · Huế", 360, 370, { size: 34, accent: "#ffd84d" }); chip(c, lt, W2(6), "Vua Bảo Đại thoái vị", 360, 440, { size: 34, accent: "#ffd84d" }); }],
    [11, (c, lt, d, W2) => { bg(c, "q12", lt, d, { z0: 1.05, z1: 1.15 });
      glow(c, 360, 560, 240, "rgba(255,210,100,0.9)", 0.35);
      act(c, lt, [[0, { p: "rulers_9", x: 330, y: GY, s: 1.6, popin: 1 }]], 5);
      prop(c, lt, "props1_2", 250, 520, 0.6, { t0: W2(13), amp: 4 }); prop(c, lt, "props1_3", 500, 500, 0.6, { t0: W2(15), amp: 4, rot: 0.4 });
      chip(c, lt, W2(16), "Chế độ quân chủ chấm dứt", 360, 230, { size: 34, accent: "#ffd84d" }); }],
  ]);
} };

S.badinh = { sfx: (w) => [[0.02, "birds", 0.2, 3], [w[1], "thud", 0.4], [w[7], "street", 0.35, 4], [w[12], "swell", 0.35], [w[17], "chime", 0.3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "q08", lt, d, { z0: 1.02, z1: 1.12 });
      act(c, lt, [[W2(7), { p: "crowd_2", x: 360, y: GY + 30, s: 1.45, popin: 1 }]], 3);
      bigNum(c, lt, W2(1), "2/9/1945", 360, 280, "#ffd84d", 130); chip(c, lt, W2(3), "Quảng trường Ba Đình", 360, 380, { size: 36, accent: "#ffd84d" }); chip(c, lt, W2(8), "Hàng trăm nghìn người", 360, 450, { size: 34, accent: "#ff6b6b" }); }],
    [12, (c, lt, d, W2) => { bg(c, "q08", lt, d, { z0: 1.25, z1: 1.35 });
      prop(c, lt, "props1_7", 360, 560, 0.9, { t0: 0.05, amp: 2 }); flag(c, lt, 160, 470, 0.7, 1, 0.1); flag(c, lt, 560, 470, 0.7, 2, 0.2);
      act(c, lt, [[0, { p: "crowd_2", x: 360, y: GY + 40, s: 1.6 }]], 3);
      chip(c, lt, 0.1, "Chủ tịch Hồ Chí Minh", 360, 230, { size: 36, accent: "#ffd84d" }); chip(c, lt, W2(17), "đọc Tuyên ngôn độc lập", 360, 300, { size: 36, accent: "#ff6b6b" }); }],
  ]);
} };

S.quote = { sfx: (w) => [[0.02, "paper", 0.3], [w[4], "pop", 0.25], [w[12], "swell", 0.35], [w[21], "chime", 0.35]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "q11", lt, d, { z0: 1.05, z1: 1.15, filter: "brightness(0.85)" });
      prop(c, lt, "props1_6", 360, 640, 1.3, { t0: 0.05, amp: 4, rot: -0.1 });
      chip(c, lt, W2(4), "Trích Tuyên ngôn độc lập Mỹ, 1776", 360, 230, { size: 32, accent: "#ffd84d" });
      bigNum(c, lt, W2(12), "MỌI NGƯỜI SINH RA", 360, 360, "#ffffff", 76); bigNum(c, lt, W2(19), "ĐỀU BÌNH ĐẲNG", 360, 460, "#ffd84d", 96); }],
  ]);
} };

S.ending = { sfx: (w) => [[0.02, "warm_pad", 0.3, 3], [w[5], "low_drone", 0.35, 4], [w[10], "thud", 0.5], [w[10] + 0.4, "rumble", 0.4, 2], [w[16], "low_drone", 0.3, 3]], draw(ctx, t, s) {
  shots(ctx, t, s, [
    [0, (c, lt, d, W2) => { bg(c, "q11", lt, d, { z0: 1.02, z1: 1.1 });
      act(c, lt, [[0, { p: "crowd_3", x: 360, y: GY, s: 1.4, popin: 1 }]], 2);
      chip(c, lt, W2(1), "Hòa bình rất ngắn", 360, 230, { size: 38, accent: "#ffd84d" }); }],
    [5, (c, lt, d, W2) => { bg(c, "q10", lt, d, { z0: 1.05, z1: 1.15 });
      act(c, lt, [[0, { p: "rulers_6", x: 820, y: GY, s: 1.6, walk: 1 }], [0.01, { x: 470, move: 2.2 }]], 4); act(c, lt, [[0.3, { p: "rulers_7", x: 920, y: GY, s: 1.6, walk: 1 }], [0.31, { x: 620, move: 2.2 }]], 5);
      if (lt > W2(10)) glow(c, 200, 500, 260, "rgba(255,120,40,0.9)", 0.4 + 0.2 * Math.sin(lt * 20));
      chip(c, lt, W2(6), "3 tuần sau · Sài Gòn", 360, 230, { size: 36, accent: "#ff6b6b" }); }],
    [16, (c, lt, d, W2) => { bg(c, "q10", lt, d, { z0: 1.2, z1: 1.3, filter: "brightness(0.7)" });
      bigNum(c, lt, W2(16), "MỘT CUỘC CHIẾN DÀI", 360, 330, "#ffffff", 80); bigNum(c, lt, W2(20), "BẮT ĐẦU", 360, 440, "#ff6b6b", 120);
      chip(c, lt, W2(22), "Bạn muốn nghe tiếp chương nào?", 360, 560, { size: 32, accent: "#ffd84d" });
      fadeOut(c, lt, d, 0.7); }],
  ]);
} };
