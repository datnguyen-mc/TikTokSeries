"""Mix all chapters, build shorts and the full film. usage: python3 assemble.py [mix] [shorts] [film]"""
import json, os, subprocess, sys, unicodedata, re
import numpy as np, soundfile as sf
R = '/home/claude/ww2'; OUT = f'{R}/deliver'; os.makedirs(f'{OUT}/phim_16x9', exist_ok=True); os.makedirs(f'{OUT}/shorts_9x16', exist_ok=True)
meta = {m['no']: m for m in json.load(open(f'{R}/chapters.json'))}
CH = [f'{i:02d}' for i in range(14)]
def run(cmd): r = subprocess.run(cmd, shell=True, capture_output=True, text=True); assert r.returncode == 0, r.stderr[-800:]; return r.stdout
def slug(s): s = unicodedata.normalize('NFD', s.replace('Đ', 'D').replace('đ', 'd')); s = ''.join(c for c in s if unicodedata.category(c) != 'Mn'); return re.sub(r'[^A-Za-z0-9]+', '_', s).strip('_').title()
def dur(f): return float(run(f'ffprobe -v error -show_entries format=duration -of csv=p=0 "{f}"'))
args = set(sys.argv[1:]) or {'mix', 'shorts', 'film'}
if 'mix' in args:
    for c in CH:
        run(f'cd {R} && python3 mixw.py {c} film ch{c}/out/film_mix.wav')
        if c not in ('00', '13'): run(f'cd {R} && python3 mixw.py {c} short ch{c}/out/short_mix.wav')
        print('mixed', c, flush=True)
if 'shorts' in args:
    for c in CH[1:13]:
        name = f'WW2_P{int(c):02d}_{slug(meta[c]["title"])}.mp4'
        run(f'ffmpeg -y -loglevel error -i {R}/ch{c}/out/short.mp4 -i {R}/ch{c}/out/short_mix.wav -map 0:v -map 1:a -c:v copy -af loudnorm=I=-14:TP=-1.5:LRA=11 -ar 48000 -c:a aac -b:a 192k -shortest -movflags +faststart "{OUT}/shorts_9x16/{name}"')
        print('short', name, round(dur(f'{OUT}/shorts_9x16/{name}'), 1), flush=True)
if 'film' in args:
    lst = f'{R}/out_concat.txt'; open(lst, 'w').write(''.join(f"file '{R}/ch{c}/out/film.mp4'\n" for c in CH))
    run(f'ffmpeg -y -loglevel error -f concat -safe 0 -i {lst} -c copy {R}/film_video.mp4')
    # audio: concat chapter mixes, each padded/trimmed to its video length
    parts = []; offs = []; t = 0.0
    for c in CH:
        v = dur(f'{R}/ch{c}/out/film.mp4'); a, sr = sf.read(f'{R}/ch{c}/out/film_mix.wav', dtype='float32'); n = int(round(v * sr))
        a = np.pad(a, ((0, max(0, n - len(a))), (0, 0)))[:n]; parts.append(a); offs.append(t); t += v
    sf.write(f'{R}/film_mix.wav', np.concatenate(parts), sr, subtype='PCM_16')
    run(f'ffmpeg -y -loglevel error -i {R}/film_video.mp4 -i {R}/film_mix.wav -map 0:v -map 1:a -c:v copy -af loudnorm=I=-14:TP=-1.5:LRA=11 -ar 48000 -c:a aac -b:a 256k -shortest -movflags +faststart "{OUT}/phim_16x9/THE_CHIEN_II_Phim_16x9.mp4"')
    # SRT + YouTube chapters
    def ts(x): h = int(x // 3600); m = int(x % 3600 // 60); s = x % 60; return f'{h:02d}:{m:02d}:{int(s):02d},{int(round((s - int(s)) * 1000)) % 1000:03d}'
    srt = []; k = 1
    for c, o in zip(CH, offs):
        for g in json.load(open(f'{R}/ch{c}/subs.json')): srt.append(f"{k}\n{ts(o + g['s'])} --> {ts(o + g['e'])}\n{g['text']}\n"); k += 1
    open(f'{OUT}/phim_16x9/THE_CHIEN_II_Phim_16x9.srt', 'w').write('\n'.join(srt))
    chap = [f"{int(o // 60)}:{int(o % 60):02d} {('Mở đầu' if c == '00' else 'Lời kết' if c == '13' else 'Chương ' + str(int(c)) + ' – ' + meta[c]['title'].title())}" for c, o in zip(CH, offs)]
    json.dump({'offsets': offs, 'chapters': chap, 'total': t}, open(f'{R}/film_index.json', 'w'), ensure_ascii=False, indent=1)
    print('film', round(t, 1), '\n'.join(chap))
