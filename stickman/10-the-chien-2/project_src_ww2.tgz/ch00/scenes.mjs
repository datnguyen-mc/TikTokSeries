import { W, H, bg, shots, stick, big, tag, glow, shade, explosion, column, ss, lerp, clamp, preloadClip, clip, plane, tank } from "../common.mjs";
export const S = {}; S.__card = 0; S.__cardSfx = []; S.__tailFilm = 1.0;
await preloadClip("k1");
S.c00_1 = { pad: 2.5, sfx: (w) => [[0.02, "veo_k1", 0.8, 8], [w[0], "boom_far", 0.6], [w[2], "boom_far", 0.6], [w[7], "boom", 0.7]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    if (!clip(c, "k1", lt)) bg(c, "w50", lt, d);
    if (lt < 0.6) shade(c, 1 - lt / 0.6);
    big(c, lt, W2(0), "6 NĂM", 960, 200, { size: 130, color: "#fff", t1: W2(2) - 0.1 });
    big(c, lt, W2(2), "> 30 QUỐC GIA", 960, 200, { size: 130, color: "#fff", t1: W2(7) - 0.1 });
    big(c, lt, W2(7), "> 100 TRIỆU NGƯỜI CẦM SÚNG", 960, 200, { size: 100, color: "#ffd84d" });
  }]]);
} };
S.c00_2 = { pad: 3.0, sfx: (w) => [[0.02, "planepass", 0.5, 2.6], [w[5], "boom", 0.9], [w[5] + 0.1, "swell", 0.6], [w[13], "drum_roll", 0.4, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w50", lt, d, { z0: 1.0, z1: 1.12 });
    for (let i = 0; i < 3; i++) plane(c, { x: lerp(-300 - i * 200, 2200, lt / 3), y: 150 + i * 60, s: 0.5, t: lt, fac: ["uk", "us", "su"][i] });
    tank(c, { x: lerp(2200, 1300, ss(lt / 4)), y: 1000, s: 0.85, t: lt, fac: "de", dir: -1, speed: 120, fire: 2.5 });
    const kits = ["uk", "us", "su", "fr", "pl"]; for (let i = 0; i < 5; i++) stick(c, { x: lerp(-200 - i * 200, 1100 - i * 200, lt / 5), y: 1005, s: 1.2, pose: "runcarry", t: lt + i * 0.2, kit: kits[i], seed: i + 3 });
    explosion(c, 1500, 980, lt - W2(5), 1.6, 7);
    const k = clamp((lt - W2(5)) / 0.5); if (k > 0) { glow(c, 960, 420, 700, "rgba(255,120,60,0.6)", 0.6 * k); big(c, lt, W2(5), "THẾ CHIẾN II", 960, 470, { size: 230, color: "#f2efe6", stroke: 22 }); big(c, lt, W2(7) + 0.2, "1939 – 1945", 960, 600, { size: 90, color: "#ff5a3a" }); }
    tag(c, lt, W2(13), "Kể bằng những người que", 960, 720, { accent: "#ffd84d" });
  }]]);
} };
