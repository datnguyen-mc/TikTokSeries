import { W, H, bg, camera, shots, focus, stick, actor, crowd, big, tag, stamp, chip, glow, shade, vignette, darken, tint, table, wheelbarrow, moneyRain, particles, searchlights, tank, column, drawMap, arrow, pin, poster, explosion, smokeCol, flame, ss, lerp, clamp, rnd, TAU, mic, paperStack } from "../common.mjs";
export const S = {};
const G = 1005;
S.c01_1 = { pad: 1.2, sfx: (w) => [[0.02, "murmur", 0.35, 5], [w[1], "thud", 0.45], [w[11], "scribble", 0.4], [w[14], "chime", 0.3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w01", lt, d, { z0: 1.0, z1: 1.08 });
    table(c, 960, G - 10, 420, 120, "#5a3a22", "#2f5a3a");
    paperStack(c, 960, G - 130, 3, 1);
    actor(c, lt, [[0, { x: 1180, y: G, pose: "sit", kit: "suit", dir: -1, expr: "sad" }], [W2(9), { pose: "type", expr: "sad" }]]);
    actor(c, lt, [[0, { x: 560, y: G, pose: "talk", kit: "diplomat", seed: 2 }], [W2(10), { pose: "point", expr: "angry" }]]);
    actor(c, lt, [[0, { x: 400, y: G + 10, pose: "idle", kit: "uk_off", seed: 4 }], [W2(4), { pose: "point", expr: "angry" }]]);
    actor(c, lt, [[0, { x: 1500, y: G + 10, pose: "talk", kit: "fr", seed: 5, dir: -1 }]]);
    big(c, lt, W2(1), "1919", 960, 210, { size: 150 });
    tag(c, lt, W2(12), "Hiệp ước Versailles", 960, 320);
  }]]);
} };
S.c01_2 = { sfx: (w) => [[w[0], "thud", 0.4], [w[2], "thud", 0.4], [w[7], "coins", 0.5, 1.5], [w[12], "low_drone", 0.3, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w39", lt, d, { z0: 1.06, z1: 1.14, filter: "saturate(0.5) brightness(0.75)" });
    actor(c, lt, [[0, { x: 960, y: G, pose: "sad", kit: "de", s: 1.6 }], [W2(7), { pose: "facepalm" }]]);
    tag(c, lt, W2(0), "Mất ~13% lãnh thổ", 960, 190, { accent: "#e0463a" });
    tag(c, lt, W2(2), "Quân đội tối đa 100.000 người", 960, 275, { accent: "#e0463a" });
    tag(c, lt, W2(7), "Bồi thường 132 tỷ mác vàng", 960, 360, { accent: "#ffd84d" });
    if (lt > W2(7)) moneyRain(c, lt - W2(7), { n: 14, seed: 3 });
  }]]);
} };
S.c01_3 = { pad: 1.0, sfx: (w) => [[0.02, "street", 0.3, 6], [w[1], "thud", 0.4], [w[5], "whoosh", 0.4], [w[9], "wheel", 0.4, 3], [w[17], "gasp", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w02", lt, d, { z0: 1.02, z1: 1.1 });
    moneyRain(c, lt, { n: 26, seed: 1 });
    big(c, lt, W2(1), "1923", 960, 200, { size: 140 });
    // exchange counter
    if (lt > W2(4)) { const u = ss((lt - W2(4)) / 2.2); const v = Math.round(Math.pow(10, lerp(0.6, 12.62, u))); big(c, lt, W2(4), "1$ = " + v.toLocaleString("vi-VN") + " MÁC", 960, 330, { size: 74, color: "#ff8a6a" }); }
    actor(c, lt, [[0, { x: 760, y: G, pose: "shock", kit: "civ", seed: 2 }], [0.01, { pose: "shrug" }]]);
    actor(c, lt, [[0, { x: 1180, y: G, pose: "shout", kit: "woman", dir: -1, seed: 3 }]]);
  }], [9, (c, lt, d, W2) => {
    bg(c, "w02", lt, d, { z0: 1.14, z1: 1.2, x0: -120, x1: -60 });
    wheelbarrow(c, lerp(500, 820, ss(lt / d)), G, 1.1, 1, lt);
    actor(c, lt, [[0, { x: 330, y: G, pose: "wheel", kit: "civ2", seed: 4 }], [0.01, { x: 650, move: d, lin: 1 }]]);
    actor(c, lt, [[0, { x: 1350, y: G, pose: "hold", kit: "woman2", dir: -1, prop: "bread", seed: 5 }]]);
    big(c, lt, W2(9), "NỬA CÂN BÁNH MÌ", 960, 200, { size: 80, color: "#fff" });
    big(c, lt, W2(15), "> 100 TỶ MÁC", 960, 320, { size: 120, color: "#ff5a3a" });
  }]]);
} };
S.c01_4 = { sfx: (w) => [[0.02, "wheel", 0.4, 2.5], [w[10], "paper", 0.45], [w[13], "paper", 0.4], [w[15], "paper", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w02", lt, d, { z0: 1.05, z1: 1.12, x0: 60, x1: -40 });
    wheelbarrow(c, lerp(-100, 1500, lt / 5) + 0, G, 1.1, 1, lt);
    actor(c, lt, [[0, { x: -420, y: G, pose: "wheel", kit: "worker", seed: 6 }], [0.01, { x: 1180, move: 5, lin: 1 }]]);
    crowd(c, lt, { n: 3, x0: 1300, x1: 1700, y: G + 10, s: 1.23, pose: "point", kits: ["civ", "woman", "kid"], dir: -1, seed: 7, expr: "shock" });
  }], [10, (c, lt, d, W2) => {
    bg(c, "w02", lt, d, { z0: 1.25, z1: 1.3, x0: -250, x1: -230 });
    // money wallpaper on wall
    const n = Math.floor(clamp(lt / (d * 0.8)) * 24);
    for (let i = 0; i < n; i++) { const x = 520 + (i % 6) * 120, y = 330 + Math.floor(i / 6) * 70; c.save(); c.translate(x, y); c.rotate((rnd(2, i) - 0.5) * 0.15); c.fillStyle = "#b9c99a"; c.strokeStyle = "#3a4a2a"; c.lineWidth = 3; c.fillRect(-56, -30, 112, 60); c.strokeRect(-56, -30, 112, 60); c.beginPath(); c.arc(0, 0, 14, 0, TAU); c.stroke(); c.restore(); }
    actor(c, lt, [[0, { x: 1300, y: G, pose: "holdup", kit: "civ", dir: -1, prop: "money", seed: 8 }]]);
    actor(c, lt, [[0, { x: 560, y: G, pose: "shrug", kit: "woman", seed: 9 }]]);
    tag(c, lt, 0.1, "Tiền rẻ hơn giấy dán tường", 960, 200);
  }]]);
} };
S.c01_5 = { pad: 1.0, sfx: (w) => [[0.02, "wind", 0.35, 6], [w[2], "thud", 0.45], [w[3], "low_drone", 0.35, 4], [w[9], "footsteps", 0.3, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w03", lt, d, { z0: 1.02, z1: 1.1, filter: "saturate(0.6)" });
    for (let i = 0; i < 9; i++) { const x = 1750 - i * 210 + Math.min(lt, d) * 12; stick(c, { x, y: G + (i % 2) * 8, s: 1.3, dir: 1, pose: i % 3 === 0 ? "sad" : "coldwalk", t: lt + i * 0.4, kit: ["worker", "civ", "civ2", "civ3"][i % 4], seed: 20 + i, freq: 0.5 }); }
    big(c, lt, W2(2), "1929", 960, 200, { size: 140 });
    tag(c, lt, W2(3), "Khủng hoảng kinh tế thế giới", 960, 310, { accent: "#e0463a" });
    tag(c, lt, W2(9), "Hàng triệu người Đức mất việc", 960, 395);
    particles(c, lt, { n: 30, color: "rgba(200,200,200,0.4)", vx: -60, vy: 20, size: 3 });
  }]]);
} };
S.c01_6 = { sfx: (w) => [[0.02, "crowd", 0.35, 4.5], [w[3], "cheer", 0.45, 3], [w[10], "drum_roll", 0.35, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w04", lt, d, { z0: 1.0, z1: 1.12, y0: 0, y1: -30 });
    searchlights(c, lt, [300, 800, 1200, 1650], { a: 0.12 });
    // silhouette speaker at podium
    c.save(); c.fillStyle = "#151518"; c.fillRect(890, 600, 140, 190); c.restore();
    stick(c, { x: 960, y: 640, s: 0.8, pose: "shout", t: lt, kit: "suit", seed: 3, filter: "brightness(0)" });
    crowd(c, lt, { n: 14, x0: 120, x1: 1800, y: 1110, s: 1.52, pose: "cheer", kits: ["civ", "worker", "civ2", "civ3"], seed: 5, filter: "brightness(0.25)" });
    tag(c, lt, W2(7), "“Làm nước Đức vĩ đại trở lại”", 960, 220, { accent: "#e0463a" });
    vignette(c, 0.6);
  }]]);
} };
S.c01_7 = { pad: 1.6, sfx: (w) => [[w[3], "thud", 0.5], [w[4], "crowd", 0.3, 2], [w[9], "tank", 0.45, 4], [w[13], "march", 0.45, 3.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w04", lt, d, { z0: 1.14, z1: 1.2 }); searchlights(c, lt, [500, 1400], { a: 0.1 });
    stick(c, { x: 960, y: 1000, s: 1.5, pose: "shout", t: lt, kit: "suit", seed: 3, filter: "brightness(0)" });
    big(c, lt, W2(1), "1/1933", 960, 200, { size: 130 });
    tag(c, lt, W2(4), "Adolf Hitler lên nắm quyền", 960, 315, { accent: "#e0463a" });
    vignette(c, 0.6);
  }], [9, (c, lt, d, W2) => {
    bg(c, "w03", lt, d, { z0: 1.02, z1: 1.1, filter: "saturate(0.7) brightness(0.85)" });
    tank(c, { x: lerp(-300, 700, lt / 4), y: G, s: 0.9, t: lt, fac: "de", speed: 150 });
    tank(c, { x: lerp(-800, 200, lt / 4), y: G + 30, s: 0.9, t: lt, fac: "de", speed: 150, seed: 3 });
    column(c, lt, { n: 7, x0: 1000, gap: 188, y: G + 20, s: 1.23, kit: "de", speed: 70 });
    stamp(c, lt, W2(13), "TÁI VŨ TRANG", 960, 260, { size: 110 });
  }]]);
} };
S.c01_8 = { sfx: (w) => [[w[1], "thud", 0.4], [w[3], "whoosh", 0.5], [w[8], "whoosh", 0.5], [w[13], "murmur", 0.3, 2.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    c.save(); const z = lerp(1, 1.06, ss(lt / d)); c.translate(W / 2, H / 2); c.scale(z, z); c.translate(-W / 2, -H / 2);
    const pr = drawMap(c, { lon0: -12, lon1: 32, lat0: 40, lat1: 60 });
    const B = pr(13.4, 52.5), V = pr(16.37, 48.2), Pr = pr(14.42, 50.08), L = pr(-0.12, 51.5), Pa = pr(2.35, 48.85);
    pin(c, ...B, "BERLIN", lt, 0); pin(c, ...L, "LONDON", lt, 0, { color: "#3a6ac8" }); pin(c, ...Pa, "PARIS", lt, 0, { color: "#3a6ac8" });
    arrow(c, [B, [B[0] + 40, (B[1] + V[1]) / 2], V], ss((lt - W2(3)) / 0.8)); pin(c, ...V, "ÁO", lt, W2(5));
    arrow(c, [B, [B[0] - 30, (B[1] + Pr[1]) / 2 + 10], Pr], ss((lt - W2(8)) / 0.8), { color: "#ff7a3a" }); pin(c, ...Pr, "TIỆP KHẮC", lt, W2(11));
    c.restore();
    big(c, lt, W2(1), "1938", 960, 160, { size: 120 });
    if (lt > W2(13)) { actor(c, lt, [[W2(13), { x: 760, y: 1060, pose: "shrug", kit: "suit", popin: 1, seed: 2 }], [W2(16), { pose: "idle", expr: "worried" }]]); actor(c, lt, [[W2(14), { x: 1160, y: 1060, pose: "shrug", kit: "fr", dir: -1, popin: 1, seed: 6 }]]); }
  }]]);
} };
S.c01_9 = { sfx: (w) => [[0.02, "plane", 0.25, 2], [w[5], "paper", 0.5], [w[10], "cheer", 0.45, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w05", lt, d, { z0: 1.04, z1: 1.12 });
    actor(c, lt, [[0, { x: 1300, y: G, pose: "walk", kit: "suit", dir: -1, seed: 1 }], [0.01, { x: 980, move: W2(5), lin: 1 }], [W2(5), { pose: "holdup", prop: "paper", expr: "happy" }]]);
    crowd(c, lt, { n: 6, x0: 300, x1: 720, y: G + 30, s: 1.3, pose: (i) => i % 2 ? "cheer" : "wave", kits: ["civ", "civ2", "woman", "civ3"], seed: 9 });
    tag(c, lt, W2(0), "Thủ tướng Anh trở về từ Munich", 960, 200);
    big(c, lt, W2(12), "“HÒA BÌNH CHO THỜI ĐẠI CHÚNG TA”", 960, 320, { size: 70, color: "#fff" });
  }]]);
} };
S.c01_10 = { pad: 0.8, sfx: (w) => [[w[0], "low_drone", 0.35, 3], [w[11], "thud", 0.6], [w[11], "wind", 0.4, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w05", lt, d, { z0: 1.12, z1: 1.2, filter: `brightness(${lerp(1, 0.55, ss(lt / d))}) saturate(${lerp(1, 0.4, ss(lt / d))})` });
    const fly = lt > W2(11); actor(c, lt, [[0, { x: 980, y: G, pose: "holdup", prop: fly ? null : "paper", kit: "suit", dir: -1, expr: "happy" }], [W2(11), { pose: "shock", expr: "shock" }]]);
    if (fly) { const u = lt - W2(11); c.save(); c.translate(980 + u * 600, 560 - u * 300); c.rotate(u * 6); c.fillStyle = "#f4efe0"; c.fillRect(-20, -26, 40, 52); c.restore(); }
    tag(c, lt, W2(2), "Chính sách nhân nhượng", 960, 200);
    stamp(c, lt, W2(11), "HỌ ĐÃ NHẦM", 960, 360, { size: 120 });
  }]]);
} };
S.c01_11 = { pad: 1.8, sfx: (w) => [[0.02, "battle", 0.45, 6], [w[7], "boom", 0.6], [w[11], "shell", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w50", lt, d, { z0: 1.0, z1: 1.12 });
    for (let i = 0; i < 4; i++) explosion(c, 300 + i * 450, 900, (lt - i * 1.3) % 3.5, 0.9, i + 2);
    column(c, lt, { n: 8, x0: 1200, gap: 232, y: G + 20, s: 1.23, kit: "de", pose: "runcarry", speed: 140, seed: 3 });
    big(c, lt, W2(2), "1939", 960, 220, { size: 170, color: "#ff5a3a" });
    tag(c, lt, W2(11), "Cuộc chiến đẫm máu nhất lịch sử", 960, 340, { accent: "#e0463a" });
  }]]);
} };
