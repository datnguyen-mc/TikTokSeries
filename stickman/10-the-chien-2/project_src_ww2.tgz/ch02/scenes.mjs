import { W, H, bg, shots, stick, actor, crowd, big, tag, stamp, glow, darken, tank, plane, bomb, explosion, smokeCol, column, drawMap, arrow, pin, drawFlag, table, chair, ss, lerp, clamp, rnd, preloadClip, clip, hasClip, particles, truck } from "../common.mjs";
export const S = {};
await preloadClip("k2");
const G = 1005;
S.c02_1 = { pad: 1.0, sfx: (w) => [[0.02, "birds", 0.3, 3], [w[3], "thud", 0.4], [w[4], "tank", 0.5, 4], [w[6], "boom_far", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w06", lt, d, { z0: 1.0, z1: 1.08 });
    // barrier lifts
    actor(c, lt, [[0, { x: 1450, y: G, pose: "idle", kit: "pl", dir: -1, rifle: true, seed: 3 }], [W2(4), { pose: "shock" }], [W2(6), { pose: "run", x: 1950, dir: 1, move: 2.2, lin: 1 }]]);
    tank(c, { x: lerp(-400, 820, ss((lt - W2(4) * 0.6) / 3.2)), y: G + 10, s: 1.0, t: lt, fac: "de", speed: 160, head: "de" });
    big(c, lt, W2(3), "1/9/1939", 960, 210, { size: 140 });
    tag(c, lt, W2(10), "Đức tấn công Ba Lan", 960, 320, { accent: "#e0463a" });
  }]]);
} };
S.c02_2 = { pad: 2.0, sfx: (w) => [[0.02, "tank", 0.55, 4], [w[5], "stuka", 0.55, 2.4], [w[8], "bombfall", 0.4, 1.4], [w[9], "boom", 0.7], [w[13], "boom", 0.5], [w[18], "whoosh", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    if (!clip(c, "k2", lt * 0.9)) { bg(c, "w07", lt, d, { z0: 1.02, z1: 1.12 }); for (let i = 0; i < 3; i++) tank(c, { x: lerp(-300 - i * 420, 1600 - i * 420, lt / 6), y: G + i * 15, s: 1.15, t: lt, fac: "de", speed: 150, seed: i }); }
  }], [5, (c, lt, d, W2) => {
    bg(c, "w07", lt, d, { z0: 1.06, z1: 1.14 });
    for (let i = 0; i < 2; i++) tank(c, { x: lerp(-200 - i * 500, 1500 - i * 500, lt / 6), y: G + i * 20, s: 1.15, t: lt, fac: "de", speed: 150, seed: i, fire: 2.2 });
    const px = lerp(1900, 300, ss(lt / 2.6)), py = lerp(140, 380, ss(lt / 2.6));
    plane(c, { x: px, y: py, s: 0.9, t: lt, fac: "de", kind: "dive", dir: -1, rot: 0.35 });
    if (lt > 1.2) bomb(c, 1100 - (lt - 1.2) * 120, 400 + (lt - 1.2) * 600, 1.2, 0.2);
    explosion(c, 950, 960, lt - 2.2, 1.3, 4); explosion(c, 1400, 970, lt - 3.0, 1.0, 7);
    big(c, lt, W2(18), "BLITZKRIEG", 960, 210, { size: 150, color: "#ff5a3a" });
    tag(c, lt, W2(19), "Chiến tranh chớp nhoáng", 960, 320);
  }]]);
} };
S.c02_3 = { sfx: (w) => [[w[0], "thud", 0.4], [w[3], "radio_voice", 0.4, 2], [w[10], "boom", 0.55], [w[14], "swell", 0.45]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w18", lt, d, { z0: 1.05, z1: 1.12 });
    actor(c, lt, [[0, { x: 640, y: G, pose: "radio", kit: "uk_off", seed: 1 }], [W2(6), { pose: "shout" }]]);
    actor(c, lt, [[0, { x: 1280, y: G, pose: "talk", kit: "fr", dir: -1, seed: 2 }], [W2(6), { pose: "point" }]]);
    drawFlag(c, 380, 300, 160, 100, lt, "uk"); drawFlag(c, 1380, 300, 160, 100, lt, "fr");
    tag(c, lt, W2(0), "3/9/1939", 960, 200);
    big(c, lt, W2(6), "TUYÊN CHIẾN!", 960, 340, { size: 120, color: "#ff5a3a" });
    big(c, lt, W2(10), "THẾ CHIẾN II BẮT ĐẦU", 960, 470, { size: 84, color: "#fff" });
  }]]);
} };
S.c02_4 = { pad: 1.0, sfx: (w) => [[w[2], "whoosh", 0.45], [w[5], "tank", 0.35, 3], [w[12], "battle", 0.35, 3], [w[27], "boom_far", 0.6]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: 4, lon1: 36, lat0: 46, lat1: 58 });
    const B = pr(13.4, 52.5), Wa = pr(21.0, 52.2), M = pr(30.5, 53.5);
    pin(c, ...Wa, "VACSAVA", lt, 0);
    arrow(c, [pr(13, 54), pr(18, 53), [Wa[0] - 30, Wa[1] - 10]], ss(lt / 1.2), { color: "#4a4a4a" });
    arrow(c, [pr(14, 51), pr(18, 51.6), [Wa[0] - 30, Wa[1] + 20]], ss(lt / 1.2), { color: "#4a4a4a" });
    arrow(c, [pr(31, 53), pr(26, 52.6), [Wa[0] + 40, Wa[1] + 10]], ss((lt - W2(2)) / 1.2), { color: "#d42a2a" });
    big(c, lt, W2(1), "17/9: LIÊN XÔ", 960, 180, { size: 100, color: "#ff5a3a" });
    tag(c, lt, 0.2, "Đức", 520, 470, { accent: "#9a9a9a" }); tag(c, lt, W2(2), "Liên Xô", 1500, 470, { accent: "#d42a2a" });
  }], [12, (c, lt, d, W2) => {
    bg(c, "w07", lt, d, { z0: 1.08, z1: 1.16, filter: "brightness(0.8)" });
    smokeCol(c, 400, 700, lt, 1.2, 2); smokeCol(c, 1500, 680, lt, 1.0, 5);
    column(c, lt, { n: 4, x0: 760, gap: 210, y: G, s: 1.3, kit: "pl", pose: "aim", speed: 0, dir: 1, seed: 3 });
    actor(c, lt, [[0, { x: 1150, y: G, pose: "aim", kit: "pl", fire: 1.1, seed: 9 }], [W2(18), { pose: "sad" }]]);
    explosion(c, 1500, 980, (lt % 2.4) - 0.2, 1.0, 3);
    tag(c, lt, W2(2), "Ba Lan chiến đấu dũng cảm", 960, 200);
    big(c, lt, W2(20), "~5 TUẦN", 960, 440, { size: 130, color: "#ff5a3a" });
  }]]);
} };
S.c02_5 = { sfx: (w) => [[0.02, "wind", 0.3, 5], [w[4], "clock_fast", 0.3, 3], [w[13], "paper", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w08", lt, d, { z0: 1.04, z1: 1.1 });
    chair(c, 700, G, 1.3); actor(c, lt, [[0, { x: 720, y: G, pose: "sit", kit: "fr", seed: 1, expr: "neutral" }]]);
    actor(c, lt, [[0, { x: 1220, y: G, pose: "sit", kit: "uk", dir: -1, seed: 2 }], [W2(9), { pose: "shrug" }]]);
    actor(c, lt, [[0, { x: 960, y: G, pose: "read", kit: "fr", prop: "paper", seed: 4, expr: "neutral" }]]);
    const yawn = Math.sin(lt * 1.3) > 0.7; if (yawn) tag(c, lt, 0, "zzz", 720, 560, { size: 30 });
    tag(c, lt, W2(2), "Mặt trận phía Tây", 960, 200);
    big(c, lt, W2(18), "CHIẾN TRANH KỲ QUẶC", 960, 330, { size: 100, color: "#ffd84d" });
  }]]);
} };
S.c02_6 = { pad: 1.5, sfx: (w) => [[0.02, "birds", 0.25, 3], [w[4], "tank", 0.55, 5], [w[14], "march", 0.3, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w09", lt, d, { z0: 1.04, z1: 1.14, x0: 30, x1: -30 });
    for (let i = 0; i < 4; i++) tank(c, { x: lerp(-500 - i * 520, 2100 - i * 520, lt / 7), y: G + 10 - i * 4, s: 1.1, t: lt, fac: "de", speed: 120, seed: i, head: i === 0 ? "de_off" : null });
    big(c, lt, W2(1), "5/1940", 960, 200, { size: 130 });
    tag(c, lt, W2(8), "Rừng Ardennes", 960, 310);
    tag(c, lt, W2(13), "“Xe tăng không thể qua đây”... sai rồi", 960, 400, { accent: "#e0463a" });
  }]]);
} };
S.c02_7 = { pad: 1.2, sfx: (w) => [[w[0], "boom_far", 0.5], [w[2], "boom_far", 0.5], [w[7], "march", 0.55, 5], [w[11], "drum_roll", 0.3, 2.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: -6, lon1: 16, lat0: 43, lat1: 55 });
    const A = pr(4.9, 52.4), Bx = pr(4.35, 50.85), P = pr(2.35, 48.85);
    pin(c, ...A, "HÀ LAN", lt, W2(0)); pin(c, ...Bx, "BỈ", lt, W2(2)); pin(c, ...P, "PARIS", lt, 0, { color: "#3a6ac8" });
    arrow(c, [pr(9, 52.6), [A[0] + 30, A[1]]], ss(lt / 0.8), { color: "#4a4a4a" }); arrow(c, [pr(8, 50.6), [Bx[0] + 30, Bx[1]]], ss((lt - W2(2)) / 0.8), { color: "#4a4a4a" });
    arrow(c, [pr(7, 49.8), pr(4.5, 49.4), [P[0] + 30, P[1] - 10]], ss((lt - W2(4)) / 1.0), { color: "#4a4a4a" });
  }], [7, (c, lt, d, W2) => {
    bg(c, "w10", lt, d, { z0: 1.03, z1: 1.1, filter: "saturate(0.6)" });
    column(c, lt, { n: 8, x0: 200, gap: 200, y: G, s: 1.3, kit: "de", speed: 120, seed: 4 });
    actor(c, lt, [[0, { x: 1650, y: G, pose: "sad", kit: "civ", dir: -1, seed: 6 }]]); actor(c, lt, [[0, { x: 1800, y: G + 10, pose: "mourn", kit: "woman", dir: -1, seed: 7 }]]);
    big(c, lt, W2(8), "14/6/1940", 960, 200, { size: 130 });
    tag(c, lt, W2(11), "Quân Đức vào Paris", 960, 310, { accent: "#e0463a" });
  }]]);
} };
S.c02_8 = { pad: 1.5, sfx: (w) => [[0.02, "low_drone", 0.4, 4], [w[10], "thud", 0.6], [w[14], "boom_far", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w10", lt, d, { z0: 1.12, z1: 1.22, filter: `saturate(${lerp(0.6, 0.15, ss(lt / d))}) brightness(0.8)` });
    drawFlag(c, 1180, 380, 220, 140, lt * 0.4, "fr");
    actor(c, lt, [[0, { x: 900, y: G, pose: "sad", kit: "fr", seed: 2 }], [W2(10), { pose: "mourn", expr: "sad" }]]);
    big(c, lt, W2(12), "CHỈ 6 TUẦN", 960, 230, { size: 140, color: "#ff5a3a" });
    tag(c, lt, W2(2), "Cường quốc quân sự hàng đầu châu Âu", 960, 350);
  }]]);
} };
