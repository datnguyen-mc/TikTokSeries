import { W, H, bg, shots, stick, actor, crowd, big, tag, stamp, glow, darken, tank, truck, plane, bomb, explosion, smokeCol, column, drawMap, arrow, pin, drawFlag, ship, water, splash, ss, lerp, clamp, rnd, preloadClip, clip, sandbags } from "../common.mjs";
export const S = {};
await preloadClip("k3");
const G = 1005;
// beach crowd of waiting soldiers
function beach(c, lt, n = 10, y = 990, s = 1.1, pose = "sad", seed = 1) { for (let i = 0; i < n; i++) stick(c, { x: 120 + i * 175 + rnd(seed, i) * 40, y: y + (i % 2) * 14, s, pose: i % 3 === 0 ? "idle" : pose, t: lt + i * 0.37, kit: i % 4 === 3 ? "fr" : "uk", seed: seed + i, rifle: true, dir: i % 2 ? 1 : -1 }); }
S.c03_1 = { pad: 1.2, sfx: (w) => [[0.02, "waves", 0.45, 6], [w[4], "thud", 0.4], [w[5], "battle", 0.3, 4], [w[16], "boom_far", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w11", lt, d, { z0: 1.0, z1: 1.1 });
    beach(c, lt, 10, 1000, 1.05);
    big(c, lt, W2(1), "5/1940", 960, 200, { size: 130 });
    tag(c, lt, W2(5), "> 300.000 lính Anh & Pháp bị dồn ra biển", 960, 310, { accent: "#e0463a" });
    tag(c, lt, W2(16), "Dunkirk", 960, 395);
  }]]);
} };
S.c03_2 = { sfx: (w) => [[w[0], "tank", 0.45, 2], [w[3], "boom", 0.5], [w[5], "waves", 0.5, 2], [w[9], "low_drone", 0.4, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: -4, lon1: 6, lat0: 49.6, lat1: 52.6 });
    const D = pr(2.37, 51.03); pin(c, ...D, "DUNKIRK", lt, 0, { color: "#3a6ac8" });
    glow(c, D[0], D[1], 260, "rgba(80,140,255,0.5)", 0.5);
    for (let i = 0; i < 4; i++) { const a = -0.9 + i * 0.6; arrow(c, [[D[0] + 520 * Math.cos(a) * 1.3, D[1] + 520 * Math.sin(a) * 0.4 + 260], [D[0] + 170 * Math.cos(a), D[1] + 130 + 60 * Math.sin(a)]], ss((lt - 0.2 - i * 0.12) / 0.9), { color: "#4a4a4a" }); }
    tag(c, lt, W2(0), "Phía sau: quân Đức", 1250, 880, { accent: "#9a9a9a" }); tag(c, lt, W2(5), "Phía trước: biển", 700, 300, { accent: "#3a6ac8" });
    big(c, lt, W2(9), "KHÔNG CÒN ĐƯỜNG LUI", 960, 160, { size: 92, color: "#ff5a3a" });
  }]]);
} };
S.c03_3 = { pad: 1.0, sfx: (w) => [[0.02, "tank", 0.5, 3], [w[9], "radio_voice", 0.4, 1.5], [w[13], "thud", 0.5], [w[15], "tank", 0.3, 1]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w07", lt, d, { z0: 1.04, z1: 1.1 });
    const stop = W2(15); const u = lt < stop ? lt : stop + (1 - Math.exp(-(lt - stop) * 4)) * 0.25;
    for (let i = 0; i < 3; i++) tank(c, { x: lerp(-300 - i * 560, 1400 - i * 560, u / 5), y: G - i * 6, s: 0.85, t: lt, fac: "de", speed: lt < stop ? 140 : 0, seed: i, head: i === 0 ? "de" : null });
    big(c, lt, W2(7), "24/5", 960, 200, { size: 130 });
    stamp(c, lt, W2(13), "DỪNG LẠI!", 960, 340, { size: 120 });
    tag(c, lt, W2(1), "Một điều khó hiểu...", 960, 450);
  }]]);
} };
S.c03_4 = { sfx: (w) => [[0.02, "radio_voice", 0.45, 3], [w[10], "shiphorn", 0.5, 2], [w[13], "waves", 0.4, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w13", lt, d, { z0: 1.03, z1: 1.1 });
    water(c, 830, lt, { color: "rgba(60,90,120,0.55)", amp: 6, foam: false });
    for (let i = 0; i < 3; i++) ship(c, { x: 420 + i * 520 + Math.sin(lt * 0.5 + i) * 10, y: 880, s: 1.15, t: lt, kind: ["fishing", "yacht", "boat"][i], seed: i + 1, flag: "uk" });
    water(c, 888, lt, { color: "rgba(40,80,110,0.75)", amp: 7 });
    c.fillStyle = "#6b5236"; c.fillRect(0, 960, W, 140); c.fillStyle = "#3a2a1a"; for (let x = 0; x < W; x += 60) c.fillRect(x, 960, 6, 140);
    actor(c, lt, [[0, { x: 1600, y: 1040, pose: "shout", kit: "navy_off", dir: -1, seed: 2 }]]);
    actor(c, lt, [[0, { x: 300, y: 1040, pose: "walk", kit: "civ", seed: 3 }], [0.01, { x: 900, move: 4, lin: 1 }]]);
    tag(c, lt, W2(10), "“Mọi con thuyền có thể ra khơi”", 960, 220);
  }]]);
} };
S.c03_5 = { pad: 2.5, sfx: (w) => [[0.02, "veo_k3", 0.8, 8], [w[6], "shiphorn", 0.4, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    if (!clip(c, "k3", lt)) { bg(c, "w12", lt, d); for (let i = 0; i < 7; i++) ship(c, { x: (i * 330 + lt * 40) % 2200 - 100, y: 760 + (i % 3) * 60, s: 0.5, t: lt, kind: "fishing", seed: i }); water(c, 820, lt); }
    tag(c, lt, W2(0), "Thuyền đánh cá · phà · du thuyền", 960, 110);
    big(c, lt, W2(7), "800 – 1.200 THUYỀN", 960, 290, { size: 110 });
  }]]);
} };
S.c03_6 = { pad: 1.0, sfx: (w) => [[0.02, "waves", 0.5, 5], [w[9], "stuka", 0.45, 1.8], [w[10], "boom", 0.6], [w[11], "splash", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w11", lt, d, { z0: 1.15, z1: 1.22, y0: -60, y1: -60 });
    for (let i = 0; i < 7; i++) stick(c, { x: 360 + i * 200, y: 1060 + (i % 2) * 10, s: 1.25, pose: "wade", t: lt + i * 0.3, kit: i === 3 ? "fr" : "uk", seed: i + 4, freq: 0.15 });
    water(c, 880, lt, { color: "rgba(70,95,110,0.82)", amp: 9, len: 120 });
    explosion(c, 1500, 900, lt - W2(10), 1.0, 4); for (let k = 0; k < 2; k++) { const a = lt - W2(10) - k * 0.9; if (a > 0) G_splash(c, 300 + k * 900, 880, a); }
    plane(c, { x: lerp(2100, -300, (lt - W2(8)) / 2.4), y: 200, s: 0.7, t: lt, fac: "de", kind: "dive", dir: -1 });
    tag(c, lt, W2(6), "Nước ngập đến ngực", 960, 200);
  }]]);
} };
function G_splash(c, x, y, a) { splash(c, x, y, a, 1.1); }
S.c03_7 = { sfx: (w) => [[0.02, "wind", 0.35, 4], [w[0], "thud", 0.4], [w[2], "thud", 0.4], [w[4], "thud", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w11", lt, d, { z0: 1.05, z1: 1.12, filter: "saturate(0.6)" });
    tank(c, { x: 420, y: G - 20, s: 0.8, t: 0, fac: "uk", alpha: lt > W2(0) ? 1 : 0 }); truck(c, { x: 1450, y: G - 10, s: 0.95, t: 0, col: "#6b6a42" });
    if (lt > W2(2)) { c.save(); c.translate(950, G - 20); c.fillStyle = "#3a3a2a"; c.strokeStyle = "#111"; c.lineWidth = 5; c.beginPath(); c.arc(-40, 0, 34, 0, 6.28); c.arc(60, 0, 34, 0, 6.28); c.fill(); c.stroke(); c.fillRect(-60, -60, 120, 30); c.strokeRect(-60, -60, 120, 30); c.fillRect(30, -90, 200, 18); c.restore(); }
    smokeCol(c, 420, 760, lt, 0.9, 3); smokeCol(c, 1450, 760, lt, 0.8, 6);
    actor(c, lt, [[0, { x: 760, y: G, pose: "walk", kit: "uk", dir: -1, seed: 5, rifle: true }], [0.01, { x: 200, move: 4, lin: 1 }]]);
    tag(c, lt, W2(6), "Gần như tất cả bị bỏ lại", 960, 220, { accent: "#e0463a" });
  }]]);
} };
S.c03_8 = { pad: 1.6, sfx: (w) => [[w[0], "waves", 0.35, 3], [w[3], "swell", 0.5], [w[11], "cheer", 0.5, 2.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w13", lt, d, { z0: 1.05, z1: 1.12 });
    for (let i = 0; i < 9; i++) stick(c, { x: 220 + i * 190, y: G + (i % 2) * 12, s: 1.15, pose: i % 3 === 1 ? "cheer" : i % 3 === 2 ? "hug" : "wave", t: lt + i * 0.2, kit: ["uk", "fr", "uk", "civ", "woman", "uk"][i % 6], seed: 30 + i, dir: i % 2 ? -1 : 1 });
    big(c, lt, W2(1), "9 NGÀY", 960, 180, { size: 110, color: "#fff" });
    big(c, lt, W2(3), "~338.000 NGƯỜI", 960, 320, { size: 140 });
    tag(c, lt, W2(11), "được cứu", 960, 430, { accent: "#5fd36a" });
  }]]);
} };
S.c03_9 = { pad: 1.8, sfx: (w) => [[0.02, "warm_pad", 0.35, 6], [w[3], "thud", 0.4], [w[13], "swell", 0.45]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w18", lt, d, { z0: 1.06, z1: 1.14 });
    actor(c, lt, [[0, { x: 900, y: G, pose: "talk", kit: "suit", seed: 7 }], [W2(13), { pose: "point", expr: "determined" }]]);
    drawFlag(c, 1200, 330, 200, 125, lt, "uk");
    tag(c, lt, W2(0), "Thủ tướng Churchill · 4/6/1940", 960, 200);
    big(c, lt, W2(3), "“Chiến tranh không thể thắng", 960, 330, { size: 70, color: "#fff" }); big(c, lt, W2(7), "bằng những cuộc rút lui”", 960, 420, { size: 70, color: "#fff" });
  }]]);
} };
