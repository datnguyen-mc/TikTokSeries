import { W, H, bg, shots, stick, actor, crowd, big, tag, stamp, glow, darken, plane, bomb, explosion, smokeCol, flame, drawMap, arrow, pin, drawFlag, radarRings, searchlights, flak, tracers, table, ss, lerp, clamp, rnd, preloadClip, clip, particles } from "../common.mjs";
export const S = {};
await preloadClip("k4");
const G = 1005;
const sky = (c, lt, d) => bg(c, "w16", lt, d, { z0: 1.05, z1: 1.12, x0: 40, x1: -40 });
S.c04_1 = { pad: 1.0, sfx: (w) => [[0.02, "wind", 0.3, 5], [w[2], "thud", 0.4], [w[11], "bombers", 0.45, 4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w13", lt, d, { z0: 1.04, z1: 1.1 });
    actor(c, lt, [[0, { x: 960, y: G, pose: "binoc", kit: "uk", seed: 2, rifle: true }]]);
    drawFlag(c, 1250, 420, 170, 105, lt, "uk");
    big(c, lt, W2(2), "HÈ 1940", 960, 200, { size: 130 });
    tag(c, lt, W2(3), "Nước Anh đứng một mình", 960, 310);
    for (let i = 0; i < 5; i++) plane(c, { x: lerp(2200 + i * 160, 1300 + i * 160, ss((lt - W2(11)) / 2.5)), y: 120 + i * 50, s: 0.35, t: lt, fac: "de", kind: "bomber", dir: -1 });
  }]]);
} };
S.c04_2 = { pad: 1.0, sfx: (w) => [[0.02, "bombers", 0.55, 4.5], [w[9], "ping", 0.5], [w[17], "ping", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    sky(c, lt, d);
    for (let i = 0; i < 9; i++) plane(c, { x: ((i * 260 - lt * 140) % 2600 + 2600) % 2600 - 300, y: 160 + (i % 3) * 140 + Math.sin(lt + i) * 6, s: 0.45, t: lt, fac: "de", kind: "bomber", dir: -1, seed: i });
    big(c, lt, W2(0), "HÀNG NGHÌN MÁY BAY ĐỨC", 960, 860, { size: 80, color: "#fff" });
  }], [9, (c, lt, d, W2) => {
    bg(c, "w15", lt, d, { z0: 1.05, z1: 1.12 });
    radarRings(c, 1400, 330, lt, { r: 900 });
    actor(c, lt, [[0, { x: 700, y: G, pose: "point", kit: "waaf", seed: 3, expr: "happy" }]]);
    big(c, lt, W2(18), "RADAR", 960, 220, { size: 150, color: "#7dff9a" });
  }]]);
} };
S.c04_3 = { pad: 1.0, sfx: (w) => [[0.02, "ping", 0.4], [w[7], "ping", 0.4], [w[15], "whistle_blow", 0.4], [w[16], "footsteps", 0.4, 2], [w[19], "planepass", 0.6, 2.6]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w18", lt, d, { z0: 1.05, z1: 1.1 });
    actor(c, lt, [[0, { x: 600, y: G, pose: "desk", kit: "waaf", seed: 4 }]]); actor(c, lt, [[0, { x: 1300, y: G, pose: "desk", kit: "waaf", dir: -1, seed: 5 }]]);
    actor(c, lt, [[0, { x: 960, y: G, pose: "point", kit: "uk_off", seed: 6 }]]);
    tag(c, lt, W2(1), "Chain Home: phát hiện địch từ xa", 960, 200, { accent: "#7dff9a" });
  }], [15, (c, lt, d, W2) => {
    bg(c, "w14", lt, d, { z0: 1.03, z1: 1.1 });
    for (let i = 0; i < 4; i++) actor(c, lt, [[0, { x: 200 + i * 180, y: G, pose: "run", kit: "pilot_uk", seed: 10 + i }], [0.01, { x: 900 + i * 180, move: 2.5, lin: 1 }]]);
    const u = clamp((lt - 0.8) / 2.5); plane(c, { x: lerp(500, 2100, u), y: lerp(900, 350, u * u), s: 0.8, t: lt, fac: "uk", rot: -0.25 * u });
    tag(c, lt, W2(18), "Cất cánh đón đầu", 960, 200);
  }]]);
} };
S.c04_4 = { pad: 0.6, sfx: (w) => [[0.02, "plane", 0.3, 5], [w[0], "thud", 0.45], [w[11], "pop", 0.4], [w[14], "pop", 0.4], [w[20], "pop", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w14", lt, d, { z0: 1.1, z1: 1.16 });
    const kits = ["pilot_uk", "pilot_uk", "pilot_uk", "pilot_uk", "pilot_uk", "pilot_uk", "pilot_uk"];
    for (let i = 0; i < 7; i++) stick(c, { x: 260 + i * 230, y: G, s: 1.2, pose: i % 2 ? "salute" : "idle", t: lt + i * 0.3, kit: kits[i], seed: 50 + i });
    big(c, lt, W2(0), "> 2.900 PHI CÔNG", 960, 200, { size: 120 });
    const fl = [["uk", W2(11)], ["us", W2(14)], ["pl", W2(20)], ["fr", W2(21)]]; fl.forEach(([k, t0], i) => { if (lt > t0) drawFlag(c, 520 + i * 240, 300, 150, 92, lt, k); });
    tag(c, lt, W2(12), "Khối Thịnh vượng chung · Ba Lan · Séc · Pháp...", 960, 470, { size: 36 });
  }]]);
} };
S.c04_5 = { pad: 3.0, sfx: (w) => [[0.02, "veo_k4", 0.8, 8], [w[1], "thud", 0.4], [w[13], "dogfight", 0.4, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    if (!clip(c, "k4", lt)) { sky(c, lt, d); plane(c, { x: 900 + Math.sin(lt) * 300, y: 400, s: 0.9, t: lt, fac: "uk" }); }
    big(c, lt, W2(1), "15/9/1940", 960, 160, { size: 110 });
    tag(c, lt, W2(3), "Đợt tấn công lớn nhất", 960, 270, { accent: "#e0463a" });
    big(c, lt, W2(15), "~60 MÁY BAY ĐỨC BỊ BẮN RƠI", 960, 900, { size: 70, color: "#fff" });
  }]]);
} };
S.c04_6 = { pad: 1.5, sfx: (w) => [[0.02, "airraid", 0.5, 4.5], [w[5], "bombfall", 0.45, 1.6], [w[7], "boom", 0.6], [w[10], "flak", 0.45, 3], [w[17], "boom", 0.6]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w17", lt, d, { z0: 1.02, z1: 1.1 });
    searchlights(c, lt, [300, 900, 1500], { a: 0.1 }); flak(c, lt, { n: 6 });
    for (let i = 0; i < 4; i++) plane(c, { x: ((i * 520 - lt * 120) % 2400 + 2400) % 2400 - 200, y: 140 + i * 60, s: 0.35, t: lt, fac: "de", kind: "bomber", dir: -1 });
    for (let i = 0; i < 3; i++) explosion(c, 400 + i * 550, 820, ((lt + i * 1.1) % 3) - 0.3, 1.0, i + 1);
    stick(c, { x: 820, y: G, s: 1.25, pose: "duck", t: lt, kit: "woman", seed: 3 }); stick(c, { x: 1080, y: G, s: 0.9, pose: "duck", t: lt, kit: "kid", seed: 4 });
    stick(c, { x: 1380, y: G, s: 1.25, pose: "point", t: lt, kit: "civ", seed: 5, dir: -1, expr: "shout" });
    big(c, lt, W2(15), "THE BLITZ", 960, 220, { size: 140, color: "#ff5a3a" });
    tag(c, lt, W2(7), "London bị ném bom ban đêm", 960, 340);
  }]]);
} };
S.c04_7 = { sfx: (w) => [[0.02, "planepass", 0.5, 2.6], [w[7], "boom_far", 0.5], [w[9], "swell", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    sky(c, lt, d);
    plane(c, { x: lerp(-300, 2200, lt / 3.5), y: 420 + Math.sin(lt * 2) * 40, s: 0.95, t: lt, fac: "uk", rot: Math.sin(lt * 2) * 0.1 });
    for (let i = 0; i < 3; i++) { const a = clamp((lt - 0.8 - i * 0.6) / 2.4); plane(c, { x: 1400 - i * 300, y: 200 + a * 900, s: 0.6, t: lt, fac: "de", dir: -1, rot: -0.6 - a, smoke: 1 }); }
    big(c, lt, W2(7), "ĐỨC MẤT > 1.700 MÁY BAY", 960, 200, { size: 92, color: "#fff" });
  }]]);
} };
S.c04_8 = { pad: 1.2, sfx: (w) => [[0.02, "warm_pad", 0.4, 4], [w[2], "swell", 0.45]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w14", lt, d, { z0: 1.06, z1: 1.14, filter: "sepia(0.25)" });
    actor(c, lt, [[0, { x: 1350, y: G, pose: "talk", kit: "suit", dir: -1, seed: 8 }]]);
    for (let i = 0; i < 4; i++) stick(c, { x: 300 + i * 190, y: G, s: 1.2, pose: "salute", t: lt + i * 0.4, kit: "pilot_uk", seed: 60 + i });
    big(c, lt, W2(2), "“Chưa bao giờ có nhiều người", 960, 220, { size: 66, color: "#fff" }); big(c, lt, W2(8), "mang ơn một số ít người đến vậy”", 960, 310, { size: 66, color: "#ffd84d" });
    tag(c, lt, 0.1, "Churchill · 20/8/1940", 960, 410);
  }]]);
} };
S.c04_9 = { pad: 1.8, sfx: (w) => [[w[0], "paper", 0.5], [w[5], "thud", 0.6], [w[12], "swell", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w35", lt, d, { z0: 1.04, z1: 1.1, filter: "brightness(0.85)" });
    actor(c, lt, [[0, { x: 960, y: G, pose: "desk", kit: "de_off", seed: 3 }], [W2(4), { pose: "facepalm" }]]);
    stamp(c, lt, W2(5), "HOÃN VÔ THỜI HẠN", 960, 230, { size: 96 });
    tag(c, lt, W2(9), "Lần đầu tiên Hitler bị chặn lại", 960, 380, { accent: "#5fd36a" });
  }]]);
} };
