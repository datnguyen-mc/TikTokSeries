import { W, H, bg, shots, stick, actor, crowd, big, tag, stamp, glow, darken, tint, tank, truck, plane, explosion, smokeCol, column, drawMap, arrow, pin, drawFlag, snow, rain, ss, lerp, clamp, rnd } from "../common.mjs";
export const S = {};
const G = 1005;
S.c05_1 = { pad: 1.5, sfx: (w) => [[0.02, "birds", 0.25, 2], [w[1], "thud", 0.5], [w[3], "paper", 0.5], [w[8], "battle", 0.5, 5], [w[16], "boom", 0.6]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w19", lt, d, { z0: 1.0, z1: 1.08 });
    actor(c, lt, [[0, { x: 960, y: G, pose: "read", kit: "de_off", prop: "paper", seed: 2 }], [W2(3), { pose: "throw", prop: null }]]);
    if (lt > W2(3)) { const u = lt - W2(3); c.save(); c.translate(1050 + u * 300, 650 - u * 200 + u * u * 300); c.rotate(u * 7); c.fillStyle = "#f4efe0"; c.fillRect(-25, -18, 22, 36); c.fillRect(3, -18, 22, 36); c.restore(); }
    big(c, lt, W2(1), "22/6/1941", 960, 200, { size: 130 });
    tag(c, lt, W2(3), "Xé bỏ hiệp ước với Liên Xô", 960, 310, { accent: "#e0463a" });
  }], [8, (c, lt, d, W2) => {
    bg(c, "w19", lt, d, { z0: 1.1, z1: 1.18, x0: -60, x1: 60 });
    for (let i = 0; i < 3; i++) tank(c, { x: lerp(-400 - i * 560, 1700 - i * 560, lt / 6), y: G - i * 8, s: 0.85, t: lt, fac: "de", speed: 150, seed: i, fire: i === 1 ? 2.5 : 0 });
    for (let i = 0; i < 3; i++) plane(c, { x: lerp(-200 - i * 300, 2200, lt / 4), y: 150 + i * 70, s: 0.45, t: lt, fac: "de", seed: i });
    big(c, lt, W2(14), "CHIẾN DỊCH BARBAROSSA", 960, 220, { size: 96, color: "#ff5a3a" });
  }]]);
} };
S.c05_2 = { pad: 0.8, sfx: (w) => [[0.02, "march", 0.4, 4], [w[0], "thud", 0.5], [w[9], "whoosh", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: 8, lon1: 48, lat0: 42, lat1: 62 });
    pin(c, ...pr(37.6, 55.75), "MOSCOW", lt, 0); pin(c, ...pr(30.3, 59.9), "LENINGRAD", lt, 0.2); pin(c, ...pr(30.5, 50.45), "KIEV", lt, 0.4);
    const front = [[22, 59.5], [23.5, 56], [23.5, 53], [23.8, 50.5], [26, 48], [28, 45.6]].map(p => pr(...p));
    for (let i = 0; i < 3; i++) arrow(c, [front[i * 2], [front[i * 2][0] + 380, front[i * 2][1] - 40 + i * 30]], ss((lt - 0.3 - i * 0.2) / 1.2), { color: "#4a4a4a" });
    c.save(); c.strokeStyle = "#d42a2a"; c.lineWidth = 10; c.setLineDash([22, 14]); c.beginPath(); front.forEach((p, i) => i ? c.lineTo(...p) : c.moveTo(...p)); c.stroke(); c.restore();
    big(c, lt, W2(0), "> 3 TRIỆU QUÂN", 960, 140, { size: 110 });
    tag(c, lt, W2(4), "Mặt trận dài ~2.900 km", 960, 250, { accent: "#e0463a" });
  }]]);
} };
S.c05_3 = { pad: 1.0, sfx: (w) => [[0.02, "stuka", 0.5, 2], [w[5], "boom", 0.6], [w[8], "boom", 0.5], [w[12], "boom", 0.6]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w14", lt, d, { z0: 1.06, z1: 1.14, filter: "saturate(0.7) brightness(0.9)" });
    for (let i = 0; i < 4; i++) plane(c, { x: 260 + i * 420, y: 930, s: 0.55, t: 0, fac: "su", pilot: false, alpha: 1 });
    for (let i = 0; i < 4; i++) explosion(c, 260 + i * 420, 950, lt - 0.6 - i * 0.55, 1.2, i + 3);
    plane(c, { x: lerp(2100, -300, lt / 2.6), y: 260, s: 0.8, t: lt, fac: "de", kind: "dive", dir: -1, rot: 0.15 });
    big(c, lt, W2(5), "> 1.000 MÁY BAY", 960, 200, { size: 120, color: "#ff5a3a" });
    tag(c, lt, W2(0), "Chỉ riêng ngày đầu tiên", 960, 320);
  }]]);
} };
S.c05_4 = { pad: 1.0, sfx: (w) => [[0.02, "tank", 0.45, 4], [w[6], "wind", 0.3, 2], [w[12], "thud", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w19", lt, d, { z0: 1.05, z1: 1.12, filter: "sepia(0.35)" });
    column(c, lt, { n: 8, x0: 400, gap: 210, y: G, s: 1.25, kit: "de", pose: "walk", speed: 160, seed: 6, freq: 2 });
    big(c, lt, W2(7), "11/1941", 960, 200, { size: 120 });
    big(c, lt, W2(12), "CÁCH MOSCOW ~20 KM", 960, 320, { size: 90, color: "#ff5a3a" });
  }]]);
} };
S.c05_5 = { pad: 1.2, sfx: (w) => [[0.02, "rain_soft", 0.5, 5], [w[9], "tank", 0.4, 3], [w[13], "strain", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w20", lt, d, { z0: 1.03, z1: 1.1 }); rain(c, lt, { n: 180, a: 0.35 });
    tank(c, { x: 1250, y: G + 40, s: 0.9, t: lt, fac: "de", speed: 260, seed: 2 }); // spinning, stuck
    c.fillStyle = "rgba(70,52,34,0.85)"; c.fillRect(0, G + 20, W, 120);
    actor(c, lt, [[0, { x: 520, y: G + 30, pose: "push", kit: "de", seed: 3 }]]); actor(c, lt, [[0, { x: 360, y: G + 30, pose: "push", kit: "de", seed: 4 }]]);
    stick(c, { x: 760, y: G + 30, s: 1.25, pose: "pull", t: lt, kit: "de", seed: 5, dir: -1 });
    tag(c, lt, W2(2), "Biển bùn", 960, 220); tag(c, lt, W2(9), "Xe tăng sa lầy", 960, 310, { accent: "#e0463a" });
  }]]);
} };
S.c05_6 = { pad: 1.5, sfx: (w) => [[0.02, "wind", 0.55, 8], [w[8], "rumble", 0.3, 2], [w[19], "crack", 0.5], [w[24], "low_drone", 0.4, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w21", lt, d, { z0: 1.0, z1: 1.1 }); snow(c, lt, { n: 220, wind: 160, speed: 160 });
    for (let i = 0; i < 6; i++) stick(c, { x: 1700 - i * 270 + lt * 15, y: G + (i % 2) * 10, s: 1.25, pose: i % 2 ? "coldwalk" : "shiver", t: lt + i * 0.2, kit: "de_winter", seed: 70 + i, dir: -1, rifle: true });
    big(c, lt, W2(2), "MÙA ĐÔNG NƯỚC NGA", 960, 200, { size: 110, color: "#cfe8ff" });
    tag(c, lt, W2(11), "Vẫn mặc quân phục mùa hè", 960, 310);
  }], [16, (c, lt, d, W2) => {
    bg(c, "w21", lt, d, { z0: 1.12, z1: 1.2 }); snow(c, lt, { n: 260, wind: 180, speed: 180 });
    tank(c, { x: 700, y: G, s: 0.9, t: lt, fac: "de", color: "#9aa4ad" });
    c.save(); c.globalAlpha = 0.6; c.fillStyle = "#e8f2ff"; c.fillRect(400, 820, 700, 30); c.restore();
    stick(c, { x: 1350, y: G, s: 1.3, pose: "shiver", t: lt, kit: "de_winter", seed: 3, rifle: true });
    big(c, lt, W2(30), "-30°C", 960, 260, { size: 200, color: "#9fd6ff" });
    tag(c, lt, W2(4), "Súng không bắn được", 960, 400);
  }]]);
} };
S.c05_7 = { pad: 1.5, sfx: (w) => [[0.02, "battle", 0.5, 4], [w[3], "cheer", 0.45, 2.5], [w[5], "mg", 0.4, 1.2], [w[13], "march", 0.3, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w21", lt, d, { z0: 1.05, z1: 1.12, x0: 40, x1: -40 }); snow(c, lt, { n: 150, wind: 80 });
    for (let i = 0; i < 6; i++) stick(c, { x: lerp(-200 - i * 220, 1300 - i * 220, lt / 4.5), y: G + (i % 2) * 12, s: 1.25, pose: i === 0 ? "runaim" : "runcarry", t: lt + i * 0.2, kit: "su_winter", seed: 80 + i });
    for (let i = 0; i < 3; i++) stick(c, { x: 1500 + i * 160 + lt * 60, y: G, s: 1.15, pose: "run", t: lt + i * 0.3, kit: "de_winter", seed: 90 + i, expr: "scared" });
    big(c, lt, W2(3), "HỒNG QUÂN PHẢN CÔNG", 960, 200, { size: 100, color: "#ff5a3a" });
    tag(c, lt, W2(7), "Lần đầu tiên quân Đức rút lui", 960, 310);
  }]]);
} };
S.c05_8 = { pad: 1.8, sfx: (w) => [[0.02, "clock_fast", 0.3, 3], [w[7], "boom_far", 0.5], [w[14], "low_drone", 0.4, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w30", lt, d, { z0: 1.03, z1: 1.12 }); snow(c, lt, { n: 100, wind: 40 });
    tag(c, lt, W2(1), "Kế hoạch: vài tháng", 960, 200, { accent: "#9a9a9a" });
    big(c, lt, W2(12), "THỰC TẾ: GẦN 4 NĂM", 960, 330, { size: 100, color: "#ff5a3a" });
    stick(c, { x: 960, y: G, s: 1.35, pose: "sad", t: lt, kit: "de_winter", seed: 4, rifle: true });
  }]]);
} };
