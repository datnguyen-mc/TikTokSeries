import { W, H, bg, shots, stick, actor, crowd, big, tag, stamp, glow, darken, plane, bomb, explosion, smokeCol, flame, drawMap, arrow, pin, drawFlag, ship, water, radioSet, radarRings, mic, ss, lerp, clamp, rnd, preloadClip, clip } from "../common.mjs";
export const S = {};
await preloadClip("k5");
const G = 1005;
S.c06_1 = { pad: 1.0, sfx: (w) => [[0.02, "march", 0.35, 3], [w[1], "thud", 0.45], [w[12], "whoosh", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: 90, lon1: 150, lat0: -10, lat1: 30 });
    pin(c, ...pr(105.85, 21.03), "ĐÔNG DƯƠNG", lt, W2(5)); pin(c, ...pr(139.7, 35.7), "NHẬT", lt, 0, { color: "#c8201e" });
    arrow(c, [pr(121, 25), pr(112, 22), pr(106.5, 20.5)], ss((lt - W2(2)) / 1.0), { color: "#c8201e" });
    arrow(c, [pr(110, 15), pr(104, 6), pr(102, 2)], ss((lt - W2(10)) / 1.0), { color: "#c8201e" }); arrow(c, [pr(112, 12), pr(115, 3), pr(110, -4)], ss((lt - W2(11)) / 1.0), { color: "#c8201e" });
    big(c, lt, W2(1), "1940", 960, 160, { size: 120 });
    if (lt > W2(16)) { tag(c, lt, W2(17), "Dầu mỏ", 760, 900, { accent: "#2a2a2a" }); tag(c, lt, W2(20), "Cao su", 1160, 900, { accent: "#5fd36a" }); }
  }]]);
} };
S.c06_2 = { pad: 0.8, sfx: (w) => [[0.02, "shiphorn", 0.4, 2], [w[3], "thud", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w35", lt, d, { z0: 1.04, z1: 1.1, filter: "brightness(0.9)" });
    actor(c, lt, [[0, { x: 780, y: G, pose: "desk", kit: "jp_off", seed: 1 }], [W2(3), { pose: "point", expr: "angry" }]]);
    actor(c, lt, [[0, { x: 1200, y: G, pose: "salute", kit: "jp", dir: -1, seed: 2 }]]);
    big(c, lt, W2(3), "MỘT ĐÒN QUYẾT ĐỊNH", 960, 220, { size: 100, color: "#ff5a3a" });
    tag(c, lt, W2(5), "Mục tiêu: hạm đội Mỹ ở Thái Bình Dương", 960, 330);
  }]]);
} };
S.c06_3 = { pad: 1.2, sfx: (w) => [[0.02, "waves", 0.4, 5], [0.3, "birds", 0.4, 4], [w[5], "guitar", 0.2, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w22", lt, d, { z0: 1.0, z1: 1.08 });
    actor(c, lt, [[0, { x: 700, y: G, pose: "idle", kit: "sailor_us", seed: 1, prop: "cup" }]]); actor(c, lt, [[0, { x: 1150, y: G, pose: "talk", kit: "sailor_us", dir: -1, seed: 2 }]]);
    actor(c, lt, [[0, { x: 1500, y: G, pose: "dance", kit: "sailor_us", seed: 3 }]]);
    big(c, lt, W2(4), "7/12/1941", 960, 200, { size: 130 });
    tag(c, lt, W2(5), "Hawaii · sáng Chủ nhật", 960, 310, { accent: "#5fd3ff" });
  }]]);
} };
S.c06_4 = { pad: 1.0, sfx: (w) => [[0.02, "ping", 0.5], [w[3], "ping", 0.5], [w[5], "ping", 0.55], [w[19], "paper", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w23", lt, d, { z0: 1.04, z1: 1.1 });
    radarRings(c, 1240, 380, lt, { r: 700 });
    actor(c, lt, [[0, { x: 760, y: G, pose: "radio", kit: "us", seed: 4 }], [W2(5), { pose: "point", expr: "shock" }]]);
    actor(c, lt, [[0, { x: 1150, y: G, pose: "idle", kit: "us_off", dir: -1, seed: 5 }], [W2(11), { pose: "shrug", expr: "neutral" }]]);
    tag(c, lt, W2(6), "Một đàn máy bay rất lớn!", 960, 200, { accent: "#e0463a" });
    tag(c, lt, W2(12), "“Chắc là máy bay Mỹ”", 960, 300);
  }]]);
} };
S.c06_5 = { pad: 2.4, sfx: (w) => [[0.02, "veo_k5", 0.85, 8], [w[0], "clock_fast", 0.3, 1]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    if (!clip(c, "k5", lt)) { bg(c, "w22", lt, d); for (let i = 0; i < 4; i++) plane(c, { x: lerp(2100, -200, (lt - i * 0.4) / 3), y: 200 + i * 60, s: 0.6, t: lt, fac: "jp", dir: -1, rot: 0.3 }); }
    big(c, lt, W2(0), "7:55", 960, 190, { size: 150, color: "#ff5a3a" });
  }]]);
} };
S.c06_6 = { pad: 1.2, sfx: (w) => [[0.02, "planepass", 0.5, 2.6], [w[1], "boom", 0.6], [w[4], "bombfall", 0.4], [w[11], "boom", 0.9], [w[14], "boom", 0.7]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w22", lt, d, { z0: 1.08, z1: 1.16, filter: "brightness(0.85)" });
    for (let i = 0; i < 6; i++) plane(c, { x: ((i * 380 - lt * 300) % 2400 + 2400) % 2400 - 200, y: 120 + (i % 3) * 80, s: 0.5, t: lt, fac: "jp", dir: -1, rot: 0.2, seed: i });
    for (let i = 0; i < 3; i++) explosion(c, 400 + i * 600, 760, ((lt + i * 0.9) % 2.8) - 0.3, 1.2, i + 2);
    big(c, lt, W2(0), "2 ĐỢT · > 350 MÁY BAY", 960, 200, { size: 92 });
  }], [11, (c, lt, d, W2) => {
    bg(c, "w22", lt, d, { z0: 1.2, z1: 1.26, filter: "brightness(0.75)" });
    water(c, 760, lt, { color: "rgba(30,80,120,0.5)", foam: false });
    ship(c, { x: 960, y: 800, s: 1.1, t: lt, kind: "battleship", fac: "us", list: clamp((lt - 1) / 3) * 0.12, fire: 1, flag: "us" });
    explosion(c, 960, 700, lt - 0.1, 2.2, 9);
    water(c, 820, lt, { color: "rgba(30,80,120,0.85)" });
    big(c, lt, W2(13), "USS ARIZONA", 960, 180, { size: 110, color: "#fff" });
    tag(c, lt, W2(16), "> 1.100 thủy thủ thiệt mạng", 960, 290, { accent: "#e0463a" });
  }]]);
} };
S.c06_7 = { sfx: (w) => [[0.02, "flame", 0.0], [0.02, "low_drone", 0.4, 4], [w[6], "boom_far", 0.5], [w[16], "boom_far", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w22", lt, d, { z0: 1.04, z1: 1.1, filter: "brightness(0.65) saturate(0.7)" });
    smokeCol(c, 500, 700, lt, 1.4, 1); smokeCol(c, 1100, 720, lt, 1.6, 2); smokeCol(c, 1600, 700, lt, 1.2, 3);
    for (let i = 0; i < 3; i++) flame(c, 500 + i * 550, 730, lt + i, 1.6);
    actor(c, lt, [[0, { x: 960, y: G, pose: "mourn", kit: "sailor_us", seed: 3 }]]);
    tag(c, lt, W2(0), "~20 tàu chiến chìm hoặc hư hại", 960, 200, { accent: "#e0463a" });
    tag(c, lt, W2(11), "~200 máy bay bị phá hủy", 960, 290, { accent: "#e0463a" });
  }]]);
} };
S.c06_8 = { pad: 1.6, sfx: (w) => [[0.02, "low_drone", 0.45, 4], [w[2], "bell_loop", 0.0]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w48", lt, d, { z0: 1.04, z1: 1.1, filter: "saturate(0.6)" });
    for (let i = 0; i < 4; i++) stick(c, { x: 560 + i * 260, y: G, s: 1.2, pose: "salute", t: lt + i * 0.3, kit: i === 1 ? "us_off" : "sailor_us", seed: 40 + i });
    big(c, lt, W2(2), "2.403", 960, 230, { size: 190, color: "#fff" });
    tag(c, lt, W2(8), "người Mỹ thiệt mạng", 960, 350);
  }]]);
} };
S.c06_9 = { pad: 1.0, sfx: (w) => [[0.02, "waves", 0.4, 4], [w[7], "shiphorn", 0.6, 2.2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w27", lt, d, { z0: 1.02, z1: 1.08 });
    for (let i = 0; i < 3; i++) ship(c, { x: lerp(-500, 400, ss(lt / d)) + i * 620, y: 800 + i * 40, s: 0.55 + i * 0.12, t: lt, kind: "carrier", fac: "us", planes: 4, seed: i });
    water(c, 870, lt, { color: "rgba(30,80,140,0.6)", foam: false });
    big(c, lt, W2(7), "3 TÀU SÂN BAY MỸ", 960, 200, { size: 110 });
    tag(c, lt, W2(14), "không có mặt ở cảng", 960, 310, { accent: "#5fd36a" });
  }]]);
} };
S.c06_10 = { pad: 1.8, sfx: (w) => [[0.02, "radio_voice", 0.4, 2], [w[3], "thud", 0.6], [w[6], "rumble", 0.5, 2], [w[15], "swell", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w18", lt, d, { z0: 1.05, z1: 1.12 });
    mic(c, 900, G, 1.2); actor(c, lt, [[0, { x: 760, y: G, pose: "shout", kit: "suit", seed: 3 }]]);
    drawFlag(c, 1180, 320, 220, 136, lt, "us");
    big(c, lt, W2(3), "8/12: MỸ TUYÊN CHIẾN", 960, 200, { size: 100, color: "#ff5a3a" });
  }], [6, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: -130, lon1: 160, lat0: -45, lat1: 72, wrap: false });
    glow(c, W / 2, H / 2, 900, "rgba(255,80,40,0.35)", 0.25 + 0.15 * Math.sin(lt * 4));
    const pts = [[-0.1, 51.5], [2.35, 48.85], [37.6, 55.75], [139.7, 35.7], [-77, 38.9], [151, -33], [31, 30], [106, 21]];
    pts.forEach(([lo, la], i) => { const p = pr(lo, la); if (lt > 0.2 + i * 0.25) explosionDot(c, p, lt - 0.2 - i * 0.25); });
    big(c, lt, W2(15), "CHIẾN TRANH TOÀN CẦU", 960, 180, { size: 110, color: "#ff5a3a" });
  }]]);
} };
function explosionDot(c, p, a) { const k = Math.min(1, a * 3); c.save(); c.globalAlpha = k; c.fillStyle = "#ff5a3a"; c.beginPath(); c.arc(p[0], p[1], 14 + 6 * Math.sin(a * 8), 0, 6.28); c.fill(); c.strokeStyle = "rgba(255,90,58,0.6)"; c.lineWidth = 4; c.beginPath(); c.arc(p[0], p[1], 20 + (a * 60) % 60, 0, 6.28); c.stroke(); c.restore(); }
