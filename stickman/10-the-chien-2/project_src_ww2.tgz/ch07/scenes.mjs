import { W, H, bg, shots, stick, actor, crowd, big, tag, stamp, glow, darken, plane, bomb, explosion, smokeCol, flame, drawMap, arrow, pin, drawFlag, ship, water, radioSet, table, paperStack, ss, lerp, clamp, rnd, preloadClip, clip, rrect } from "../common.mjs";
export const S = {};
await preloadClip("k6");
const G = 1005;
const telegram = (c, lt, t0, text, x, y, col = "#f4efe0") => { if (lt < t0) return; const k = ss((lt - t0) / 0.3); c.save(); c.translate(x, y); c.rotate(-0.04); c.globalAlpha = k; c.fillStyle = col; c.strokeStyle = "#222"; c.lineWidth = 4; c.fillRect(-330, -70, 660, 140); c.strokeRect(-330, -70, 660, 140);
  c.fillStyle = "#222"; c.font = "44px NotoSans"; c.textAlign = "center"; c.textBaseline = "middle"; const n = Math.floor(clamp((lt - t0) / 1.4) * text.length); c.fillText(text.slice(0, n), 0, 4); c.restore(); };
S.c07_1 = { pad: 0.8, sfx: (w) => [[0.02, "waves", 0.4, 3], [w[6], "shiphorn", 0.5, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w27", lt, d, { z0: 1.02, z1: 1.08 });
    for (let i = 0; i < 3; i++) ship(c, { x: lerp(1900, 900, ss(lt / d)) + i * 420 - 300, y: 760 + i * 50, s: 0.5 + i * 0.12, t: lt, kind: i === 1 ? "carrier" : "battleship", fac: "jp", planes: 5, seed: i });
    water(c, 830, lt, { color: "rgba(20,70,130,0.6)", foam: false });
    big(c, lt, W2(6), "HẢI QUÂN NHẬT", 960, 200, { size: 110 }); tag(c, lt, W2(10), "vẫn bất bại", 960, 310, { accent: "#e0463a" });
  }]]);
} };
S.c07_2 = { pad: 0.8, sfx: (w) => [[w[1], "thud", 0.4], [w[11], "morse", 0.5, 2.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w35", lt, d, { z0: 1.04, z1: 1.1, filter: "brightness(0.85)" });
    actor(c, lt, [[0, { x: 960, y: G, pose: "point", kit: "jp_off", seed: 2, expr: "determined" }]]);
    big(c, lt, W2(0), "6/1942", 960, 200, { size: 120 });
    big(c, lt, W2(14), "MỤC TIÊU: “AF”", 960, 340, { size: 120, color: "#ff5a3a" });
  }]]);
} };
S.c07_3 = { sfx: (w) => [[0.02, "typewriter", 0.4, 4], [w[7], "morse", 0.35, 2], [w[13], "pop", 0.4], [w[17], "pop", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w24", lt, d, { z0: 1.04, z1: 1.1 });
    actor(c, lt, [[0, { x: 640, y: G, pose: "type", kit: "codeus", seed: 2 }]]); actor(c, lt, [[0, { x: 1260, y: G, pose: "think", kit: "us_off", dir: -1, seed: 3 }], [W2(14), { pose: "pointup", expr: "happy" }]]);
    tag(c, lt, W2(0), "Đội giải mã Mỹ ở Hawaii", 960, 200);
    big(c, lt, W2(14), "AF = MIDWAY?", 960, 330, { size: 130, color: "#ffd84d" });
  }]]);
} };
S.c07_4 = { pad: 0.8, sfx: (w) => [[w[1], "drip", 0.4], [w[6], "morse", 0.5, 2.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w25", lt, d, { z0: 1.03, z1: 1.1 });
    actor(c, lt, [[0, { x: 760, y: G, pose: "radio", kit: "us", seed: 4 }]]); radioSet(c, 960, G - 40, 0.9, lt);
    actor(c, lt, [[0, { x: 1280, y: G, pose: "shrug", kit: "us_off", dir: -1, seed: 5, expr: "happy" }]]);
    tag(c, lt, W2(1), "Cái bẫy", 960, 170, { accent: "#ffd84d" });
    telegram(c, lt, W2(9), "“Máy lọc nước bị hỏng”", 960, 330);
  }]]);
} };
S.c07_5 = { pad: 1.2, sfx: (w) => [[0.02, "morse", 0.45, 2], [w[6], "typewriter", 0.4, 1.4], [w[10], "cheer", 0.5, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w24", lt, d, { z0: 1.08, z1: 1.14 });
    telegram(c, lt, W2(3), "“AF đang thiếu nước”", 960, 260, "#ffe9b0");
    actor(c, lt, [[0, { x: 700, y: G, pose: "read", kit: "codeus", prop: "paper", seed: 6 }], [W2(10), { pose: "cheer" }]]);
    actor(c, lt, [[0, { x: 1240, y: G, pose: "think", kit: "us_off", dir: -1, seed: 7 }], [W2(10), { pose: "dance" }]]);
    big(c, lt, W2(10), "BẮT ĐƯỢC RỒI!", 960, 430, { size: 120, color: "#5fd36a" });
  }]]);
} };
S.c07_6 = { pad: 1.0, sfx: (w) => [[0.02, "planepass", 0.5, 2.6], [w[5], "mg", 0.4, 1.5], [w[13], "boom_far", 0.5], [w[19], "planepass", 0.5, 2.6]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w27", lt, d, { z0: 1.04, z1: 1.1 });
    for (let i = 0; i < 4; i++) { const down = lt > W2(13) + i * 0.4; plane(c, { x: lerp(-200 - i * 250, 1500 - i * 250, lt / 4), y: 720 + i * 35 + (down ? (lt - W2(13) - i * 0.4) * 300 : 0), s: 0.5, t: lt, fac: "us", seed: i, rot: down ? 0.5 : 0, smoke: down ? 1 : 0 }); }
    for (let i = 0; i < 3; i++) plane(c, { x: lerp(2200 + i * 200, 1000 + i * 200, ss((lt - 0.5) / 2)), y: lerp(150, 620, ss((lt - 0.8) / 2)) + i * 40, s: 0.55, t: lt, fac: "jp", dir: -1, rot: 0.3, seed: i + 5 });
    water(c, 900, lt, { color: "rgba(20,70,130,0.55)", foam: false });
    big(c, lt, W2(1), "4/6/1942", 960, 180, { size: 110 });
    tag(c, lt, W2(16), "…nhưng kéo tiêm kích Nhật xuống thấp", 960, 290);
  }]]);
} };
S.c07_7 = { pad: 3.0, sfx: (w) => [[0.02, "veo_k6", 0.85, 8]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    if (!clip(c, "k6", lt)) { bg(c, "w26", lt, d); for (let i = 0; i < 3; i++) plane(c, { x: 700 + i * 200, y: lerp(100, 700, lt / 3), s: 0.6, t: lt, fac: "us", kind: "dive", rot: 1.1 }); }
    tag(c, lt, W2(3), "Máy bay ném bom bổ nhào Mỹ", 960, 120);
    tag(c, lt, W2(18), "Đúng lúc Nhật đang nạp nhiên liệu & bom", 960, 890, { accent: "#e0463a" });
  }]]);
} };
S.c07_8 = { pad: 1.2, sfx: (w) => [[0.02, "boom", 0.7], [w[3], "boom", 0.7], [w[6], "boom", 0.7], [w[12], "bombfall", 0.4, 1.4], [w[16], "boom", 0.7]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w27", lt, d, { z0: 1.06, z1: 1.12, filter: "brightness(0.85)" });
    for (let i = 0; i < 3; i++) { ship(c, { x: 360 + i * 600, y: 790 + (i % 2) * 40, s: 0.55, t: lt, kind: "carrier", fac: "jp", planes: 4, fire: lt > i * 0.9 ? 1 : 0, seed: i }); explosion(c, 360 + i * 600, 750, lt - i * 0.9, 1.4, i + 1); }
    water(c, 860, lt, { color: "rgba(20,70,130,0.7)" });
    big(c, lt, W2(3), "~10 PHÚT", 960, 200, { size: 150, color: "#ff5a3a" });
    tag(c, lt, W2(5), "3 tàu sân bay Nhật bốc cháy", 960, 320);
  }]]);
} };
S.c07_9 = { pad: 1.8, sfx: (w) => [[w[0], "thud", 0.5], [w[6], "swell", 0.5], [w[15], "cheer", 0.35, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: 120, lon1: 220, lat0: 0, lat1: 45, wrap: true });
    const M = pr(-177.4, 28.2), Hi = pr(-157.9, 21.3), J = pr(139.7, 35.7);
    pin(c, ...M, "MIDWAY", lt, 0, { color: "#3a6ac8" }); pin(c, ...Hi, "HAWAII", lt, 0.2, { color: "#3a6ac8" }); pin(c, ...J, "TOKYO", lt, 0.4);
    arrow(c, [Hi, [(Hi[0] + J[0]) / 2, Hi[1] - 120], [J[0] + 120, J[1] + 40]], ss((lt - W2(8)) / 1.6), { color: "#3a6ac8" });
    big(c, lt, W2(0), "NHẬT MẤT 4 TÀU SÂN BAY", 960, 160, { size: 96, color: "#ff5a3a" });
    tag(c, lt, W2(8), "Thế chủ động thuộc về Mỹ", 960, 270, { accent: "#5fd3ff" });
  }]]);
} };
