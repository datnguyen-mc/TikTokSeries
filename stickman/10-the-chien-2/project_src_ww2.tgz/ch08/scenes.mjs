import { W, H, bg, shots, stick, actor, crowd, big, tag, stamp, glow, darken, tank, plane, bomb, explosion, smokeCol, flame, drawMap, arrow, pin, drawFlag, rubble, sandbags, snow, tracers, ss, lerp, clamp, rnd, particles } from "../common.mjs";
export const S = {};
const G = 1005;
S.c08_1 = { pad: 1.0, sfx: (w) => [[0.02, "tank", 0.4, 4], [w[5], "battle", 0.4, 4], [w[7], "boom", 0.6]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: 28, lon1: 52, lat0: 42, lat1: 56 });
    const St = pr(44.5, 48.7); pin(c, ...St, "STALINGRAD", lt, 0); pin(c, ...pr(37.6, 55.75), "MOSCOW", lt, 0.2, { color: "#c8201e" });
    arrow(c, [pr(31, 49.5), pr(38, 49.5), [St[0] - 40, St[1]]], ss((lt - W2(3)) / 1.4), { color: "#4a4a4a" });
    big(c, lt, W2(0), "HÈ 1942", 960, 160, { size: 120 });
    tag(c, lt, W2(8), "Thành phố mang tên Stalin", 960, 270, { accent: "#e0463a" });
  }]]);
} };
S.c08_2 = { pad: 1.2, sfx: (w) => [[0.02, "bombers", 0.5, 3], [w[0], "bombfall", 0.4, 1.2], [w[1], "boom", 0.8], [w[6], "boom", 0.6], [w[16], "mg", 0.35, 1.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w28", lt, d, { z0: 1.0, z1: 1.1 });
    for (let i = 0; i < 4; i++) plane(c, { x: ((i * 520 - lt * 160) % 2400 + 2400) % 2400 - 200, y: 120 + i * 50, s: 0.38, t: lt, fac: "de", kind: "bomber", dir: -1 });
    for (let i = 0; i < 4; i++) explosion(c, 300 + i * 450, 860, ((lt + i * 0.8) % 2.8) - 0.3, 1.4, i + 3);
  }], [8, (c, lt, d, W2) => {
    bg(c, "w29", lt, d, { z0: 1.04, z1: 1.1 });
    sandbags(c, 520, G, 7, 2, 1.1); rubble(c, 1400, G + 20, 500, 3);
    stick(c, { x: 720, y: G - 30, s: 1.25, pose: "aim", t: lt, kit: "su_cap", seed: 3, fire: 1.3 }); stick(c, { x: 980, y: G - 30, s: 1.25, pose: "aim", t: lt + 0.4, kit: "su", seed: 4, fire: 1.7 });
    tag(c, lt, W2(14), "Đống đổ nát thành pháo đài", 960, 220, { accent: "#e0463a" });
  }]]);
} };
S.c08_3 = { pad: 1.0, sfx: (w) => [[w[0], "thud", 0.5], [w[5], "drum_roll", 0.4, 1.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w28", lt, d, { z0: 1.12, z1: 1.18, filter: "brightness(0.8)" });
    for (let i = 0; i < 5; i++) stick(c, { x: 560 + i * 200, y: G, s: 1.25, pose: "salute", t: lt + i * 0.2, kit: i === 2 ? "su_cap" : "su", seed: 20 + i, expr: "determined" });
    drawFlag(c, 1500, 330, 200, 125, lt, "su");
    big(c, lt, W2(5), "“KHÔNG LÙI MỘT BƯỚC”", 960, 230, { size: 110, color: "#ff5a3a" });
  }]]);
} };
S.c08_4 = { pad: 1.5, sfx: (w) => [[0.02, "battle", 0.55, 8], [w[4], "mg", 0.4, 1.2], [w[7], "boom", 0.5], [w[10], "rifle", 0.5], [w[18], "drip", 0.4], [w[27], "drip", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w29", lt, d, { z0: 1.0, z1: 1.08, x0: -40, x1: 40 });
    rubble(c, 960, G + 20, 600, 5);
    actor(c, lt, [[0, { x: 520, y: G, pose: "kneel", kit: "su", seed: 5, fire: 1.2 }]]); actor(c, lt, [[0, { x: 1420, y: G, pose: "kneel", kit: "de", dir: -1, seed: 6, fire: 1.5 }]]);
    tracers(c, lt, { x0: 640, y0: 760, x1: 1300, y1: 760, n: 4, rate: 2 }); tracers(c, lt, { x0: 1300, y0: 770, x1: 640, y1: 770, n: 4, rate: 2.3, seed: 4 });
    explosion(c, 960, 960, (lt % 3) - 0.4, 1.0, 3);
    tag(c, lt, W2(4), "Từng con phố · từng tòa nhà · từng tầng lầu", 960, 200, { size: 40 });
  }], [13, (c, lt, d, W2) => {
    darken(c, 1); c.fillStyle = "#2a2622"; c.fillRect(0, 0, W, H);
    c.save(); c.fillStyle = "#3d3630"; c.beginPath(); c.ellipse(960, 640, 900, 360, 0, 0, 6.28); c.fill(); c.strokeStyle = "#5a5048"; c.lineWidth = 30; c.stroke(); c.restore();
    c.fillStyle = "rgba(60,90,80,0.5)"; c.fillRect(0, 900, W, 180);
    for (let i = 0; i < 4; i++) stick(c, { x: lerp(-200, 1100, lt / 6) - i * 180, y: 940, s: 1.15, pose: "crawl", t: lt + i * 0.3, kit: i % 2 ? "su" : "su_cap", seed: 30 + i });
    glow(c, 1500, 600, 300, "rgba(255,200,120,0.5)", 0.5 + 0.2 * Math.sin(lt * 9));
    big(c, lt, W2(18), "“CHIẾN TRANH CHUỘT”", 960, 200, { size: 110, color: "#ffd84d" });
    tag(c, lt, W2(26), "Cống ngầm · tầng hầm", 960, 320);
  }]]);
} };
S.c08_5 = { pad: 1.5, sfx: (w) => [[0.02, "mg", 0.35, 1.5], [w[11], "clock_fast", 0.3, 2], [w[23], "swell", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w28", lt, d, { z0: 1.2, z1: 1.28, x0: -150, x1: -150 });
    // the building
    c.save(); c.fillStyle = "#8a7a68"; c.strokeStyle = "#1a1a1a"; c.lineWidth = 6; c.fillRect(560, 300, 800, 640); c.strokeRect(560, 300, 800, 640);
    for (let r = 0; r < 4; r++) for (let k = 0; k < 6; k++) { const x = 600 + k * 125, y = 340 + r * 145; c.fillStyle = "#1e1a16"; c.fillRect(x, y, 80, 95);
      if ((r * 6 + k) % 3 === 0) { stick(c, { x: x + 40, y: y + 140, s: 0.55, pose: "aim", t: lt + k, kit: "su", seed: r * 6 + k, fire: 1.4 + k * 0.2 }); } } c.restore();
    sandbags(c, 560, 945, 13, 2, 1.0);
    tracers(c, lt, { x0: 1900, y0: 700, x1: 1300, y1: 600, n: 5, rate: 2.6 });
    tag(c, lt, W2(11), "Gần 2 tháng", 960, 200, { accent: "#e0463a" });
    big(c, lt, W2(23), "NHÀ PAVLOV", 960, 150, { size: 120, color: "#ffd84d" });
  }]]);
} };
S.c08_6 = { pad: 1.5, sfx: (w) => [[w[2], "cannon", 0.6], [w[5], "battle", 0.4, 3], [w[10], "whoosh", 0.5], [w[12], "boom", 0.6]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: 38, lon1: 50, lat0: 46, lat1: 52 });
    const St = pr(44.5, 48.7); pin(c, ...St, "STALINGRAD", lt, 0);
    c.save(); c.fillStyle = "rgba(90,90,90,0.55)"; c.beginPath(); c.ellipse(St[0] - 120, St[1] + 20, 320, 200, 0, 0, 6.28); c.fill(); c.restore();
    const u = ss((lt - W2(4)) / 1.8);
    arrow(c, [pr(41, 51), pr(43, 50), [St[0] - 200, St[1] - 170]], u, { color: "#d42a2a" }); arrow(c, [pr(46.5, 46.6), pr(44, 47.2), [St[0] - 220, St[1] + 210]], u, { color: "#d42a2a" });
    big(c, lt, W2(0), "11/1942: SAO THIÊN VƯƠNG", 960, 150, { size: 90, color: "#ff5a3a" });
    tag(c, lt, W2(12), "Bao vây ~300.000 quân Đức & đồng minh", 960, 890);
  }]]);
} };
S.c08_7 = { pad: 1.8, sfx: (w) => [[0.02, "wind", 0.55, 6], [w[11], "thud", 0.6], [w[13], "footsteps", 0.3, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w30", lt, d, { z0: 1.02, z1: 1.1 }); snow(c, lt, { n: 220, wind: 120, speed: 140 });
    for (let i = 0; i < 6; i++) stick(c, { x: 380 + i * 230, y: G, s: 1.25, pose: lt > W2(11) ? "handsup" : "shiver", t: lt + i * 0.3, kit: "de_winter", seed: 50 + i, noGun: lt > W2(11) });
    stick(c, { x: 1700, y: G, s: 1.3, pose: "aim", t: lt, kit: "su_winter", seed: 9, dir: -1 });
    big(c, lt, W2(5), "2/1943", 960, 200, { size: 130 });
    tag(c, lt, W2(9), "Quân Đức đầu hàng", 960, 310, { accent: "#5fd36a" });
    tag(c, lt, W2(13), "~100.000 người bị bắt", 960, 400);
  }]]);
} };
S.c08_8 = { pad: 2.0, sfx: (w) => [[0.02, "low_drone", 0.45, 4], [w[6], "swell", 0.6]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w30", lt, d, { z0: 1.1, z1: 1.2, filter: "saturate(0.5) brightness(0.8)" }); snow(c, lt, { n: 90, wind: 30, speed: 60 });
    stick(c, { x: 960, y: G, s: 1.35, pose: "mourn", t: lt, kit: "su_winter", seed: 3 });
    big(c, lt, W2(0), "~2 TRIỆU THƯƠNG VONG", 960, 210, { size: 100, color: "#fff" });
    big(c, lt, W2(9), "BƯỚC NGOẶT", 960, 350, { size: 140, color: "#ff5a3a" });
  }]]);
} };
