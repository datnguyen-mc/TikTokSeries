import { W, H, bg, shots, stick, actor, crowd, big, tag, stamp, glow, darken, enigma, bombe, ship, water, drawMap, arrow, pin, drawFlag, table, chair, paperStack, radioSet, ss, lerp, clamp, rnd, particles } from "../common.mjs";
export const S = {};
const G = 1005;
const AL = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
function letters(c, lt, x, y, plain, cipher, t0, size = 90) { const n = Math.floor(clamp((lt - t0) / 2.2) * plain.length);
  c.save(); c.font = `${size}px Archivo`; c.textAlign = "center"; c.lineWidth = 10; c.strokeStyle = "#000";
  for (let i = 0; i < plain.length; i++) { const px = x + (i - plain.length / 2 + 0.5) * size * 0.8; c.fillStyle = "#fff"; c.strokeText(plain[i], px, y); c.fillText(plain[i], px, y);
    if (i < n) { c.fillStyle = "#ff5a3a"; c.strokeText(cipher[i], px, y + size * 1.2); c.fillText(cipher[i], px, y + size * 1.2); } } c.restore(); }
S.c09_1 = { pad: 1.0, sfx: (w) => [[0.02, "typewriter", 0.4, 4.5], [w[19], "chime", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w35", lt, d, { z0: 1.04, z1: 1.1, filter: "brightness(0.85)" });
    table(c, 960, G, 520, 130, "#4a3020");
    enigma(c, 960, G - 130, 1.0, lt, { lit: Math.floor(lt * 3) % 26 });
    actor(c, lt, [[0, { x: 620, y: G, pose: "type", kit: "de", seed: 3, expr: "happy" }]]);
    actor(c, lt, [[0, { x: 1330, y: G, pose: "idle", kit: "de_off", dir: -1, seed: 4, expr: "happy" }], [W2(4), { pose: "talk" }]]);
    tag(c, lt, W2(2), "“Không ai đọc được”", 960, 200);
    big(c, lt, W2(19), "ENIGMA", 960, 330, { size: 150, color: "#ffd84d" });
  }]]);
} };
S.c09_2 = { pad: 1.0, sfx: (w) => [[0.02, "typewriter", 0.5, 4.5], [w[5], "rotor", 0.4, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    c.fillStyle = "#1b1712"; c.fillRect(0, 0, W, H);
    enigma(c, 960, 1000, 2.2, lt, { lit: Math.floor(lt * 4) % 26 });
    letters(c, lt, 960, 170, "HELLO", "ZQBVR", W2(10), 90);
    tag(c, lt, W2(5), "Bánh xoay chuyển động mỗi lần gõ", 960, 430);
  }]]);
} };
S.c09_3 = { pad: 1.0, sfx: (w) => [[w[0], "paper", 0.4], [w[5], "clock_fast", 0.4, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w32", lt, d, { z0: 1.04, z1: 1.1 });
    actor(c, lt, [[0, { x: 960, y: G, pose: "think", kit: "tweed", seed: 3 }], [W2(16), { pose: "facepalm" }]]);
    const n = Math.min(26, Math.floor(lt * 7)); c.save(); c.font = "40px Archivo"; c.fillStyle = "rgba(255,255,255,0.35)"; for (let i = 0; i < n * 3; i++) c.fillText(AL[(i * 7) % 26] + AL[(i * 11) % 26] + AL[(i * 3) % 26], 80 + (i * 173) % 1760, 120 + ((i * 97) % 520)); c.restore();
    tag(c, lt, W2(0), "Mã đổi mỗi ngày", 960, 200, { accent: "#e0463a" });
    big(c, lt, W2(9), "~159 TỶ TỶ CÁCH CÀI ĐẶT", 960, 330, { size: 84, color: "#ffd84d" });
  }]]);
} };
S.c09_4 = { pad: 1.0, sfx: (w) => [[w[4], "whoosh", 0.4], [w[7], "chime", 0.5], [w[15], "paper", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: -8, lon1: 28, lat0: 46, lat1: 58 });
    const Wa = pr(21, 52.2), L = pr(-0.7, 52); pin(c, ...Wa, "BA LAN", lt, 0, { color: "#d42a3a" }); pin(c, ...L, "ANH", lt, 0.2, { color: "#3a6ac8" });
    arrow(c, [Wa, [(Wa[0] + L[0]) / 2, Wa[1] - 180], [L[0] + 40, L[1]]], ss((lt - W2(14)) / 1.2), { color: "#ffd84d" });
    for (let i = 0; i < 3; i++) stick(c, { x: Wa[0] - 120 + i * 120, y: Wa[1] + 330, s: 0.95, pose: i === 1 ? "point" : "think", t: lt + i, kit: "tweed", seed: 40 + i });
    big(c, lt, W2(6), "1932: BA LAN PHÁ ENIGMA", 960, 150, { size: 84 });
    tag(c, lt, W2(15), "7/1939: trao bí mật cho Anh & Pháp", 960, 260);
  }]]);
} };
S.c09_5 = { pad: 1.0, sfx: (w) => [[0.02, "birds", 0.3, 3], [w[10], "typewriter", 0.4, 2.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w31", lt, d, { z0: 1.02, z1: 1.1 });
    for (let i = 0; i < 5; i++) actor(c, lt, [[0, { x: -100 - i * 160, y: G, pose: "walk", kit: ["tweed", "waaf", "codeus", "woman", "tweed"][i], seed: 10 + i }], [0.01, { x: 1900 - i * 160, move: 6, lin: 1 }]]);
    big(c, lt, W2(8), "BLETCHLEY PARK", 960, 200, { size: 120, color: "#ffd84d" });
    tag(c, lt, W2(10), "Hàng nghìn người · làm việc ngày đêm", 960, 310);
  }]]);
} };
S.c09_6 = { pad: 1.5, sfx: (w) => [[0.02, "rotor", 0.5, 4], [w[15], "chime", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w32", lt, d, { z0: 1.06, z1: 1.12, filter: "brightness(0.8)" });
    bombe(c, 1220, G, 1.05, lt);
    actor(c, lt, [[0, { x: 620, y: G, pose: "think", kit: "tweed", seed: 5 }], [W2(9), { pose: "point", expr: "happy" }]]);
    tag(c, lt, W2(4), "Alan Turing", 620, 200, { accent: "#ffd84d" });
    big(c, lt, W2(15), "BOMBE", 1220, 200, { size: 130, color: "#ff5a3a" });
  }]]);
} };
S.c09_7 = { pad: 1.0, sfx: (w) => [[0.02, "rotor", 0.5, 6], [w[8], "coins", 0.3], [w[16], "ping", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w32", lt, d, { z0: 1.0, z1: 1.06, filter: "brightness(0.7)" });
    for (let i = 0; i < 3; i++) bombe(c, 420 + i * 540, G, 0.75, lt + i);
    for (let i = 0; i < 18; i++) { const a = ((lt * 0.7 + i / 18) % 1); c.save(); c.globalAlpha = 1 - a; c.translate(200 + (i * 97) % 1500, 1000 - a * 900); c.rotate(i); c.fillStyle = "#f4efe0"; c.fillRect(-26, -18, 52, 36); c.restore(); }
    big(c, lt, W2(1), "1943", 960, 150, { size: 100 });
    big(c, lt, W2(8), "~84.000 TIN / THÁNG", 960, 280, { size: 100, color: "#ffd84d" });
    tag(c, lt, W2(16), "~2 tin mỗi phút", 960, 390);
  }]]);
} };
S.c09_8 = { pad: 1.5, sfx: (w) => [[0.02, "waves", 0.5, 5], [w[8], "ping", 0.5], [w[14], "shiphorn", 0.4, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w33", lt, d, { z0: 1.02, z1: 1.08 });
    for (let i = 0; i < 4; i++) ship(c, { x: lerp(-300, 900, lt / d) + i * 330 - (i % 2) * 80, y: 800 + (i % 2) * 60, s: 0.42, t: lt, kind: i % 2 ? "liner" : "destroyer", fac: "us", seed: i });
    water(c, 870, lt, { color: "rgba(40,60,80,0.75)", amp: 12 });
    const ux = 1550, uy = 980; c.save(); c.globalAlpha = 0.85; ship(c, { x: ux, y: uy, s: 0.5, t: lt, kind: "uboat", dir: -1 }); c.restore();
    c.save(); c.strokeStyle = "#ff5a3a"; c.lineWidth = 6; c.setLineDash([16, 12]); c.beginPath(); c.arc(ux, uy - 20, 200 + 10 * Math.sin(lt * 4), 0, 6.28); c.stroke(); c.restore();
    tag(c, lt, W2(7), "Biết tàu ngầm Đức nằm ở đâu", 960, 200, { accent: "#5fd36a" });
  }]]);
} };
S.c09_9 = { pad: 2.0, sfx: (w) => [[0.02, "warm_pad", 0.4, 7], [w[11], "swell", 0.5], [w[24], "door", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w31", lt, d, { z0: 1.06, z1: 1.14, filter: "sepia(0.2)" });
    for (let i = 0; i < 4; i++) stick(c, { x: 520 + i * 290, y: G, s: 1.2, pose: i % 2 ? "idle" : "think", t: lt + i * 0.4, kit: ["tweed", "waaf", "codeus", "woman"][i], seed: 60 + i });
    big(c, lt, W2(11), "RÚT NGẮN 2 – 4 NĂM", 960, 200, { size: 110, color: "#ffd84d" });
    stamp(c, lt, W2(25), "TUYỆT MẬT", 960, 370, { size: 110 });
  }]]);
} };
