import { W, H, bg, shots, stick, actor, crowd, big, tag, stamp, glow, darken, tank, plane, bomb, explosion, smokeCol, drawMap, arrow, pin, drawFlag, ship, water, radioSet, dummy, parachute, hedgehog, table, ss, lerp, clamp, rnd, preloadClip, clip, particles, truck } from "../common.mjs";
export const S = {};
await preloadClip("k7");
const G = 1005;
S.c10_1 = { pad: 1.0, sfx: (w) => [[w[1], "thud", 0.45], [w[10], "drum_roll", 0.35, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: -8, lon1: 12, lat0: 45, lat1: 54.5 });
    const N = pr(-0.6, 49.3), Ca = pr(1.86, 50.95), Lo = pr(-0.12, 51.5); pin(c, ...Lo, "ANH", lt, 0, { color: "#3a6ac8" });
    if (lt > W2(14)) { pin(c, ...N, "NORMANDY?", lt, W2(15), { color: "#ffd84d" }); pin(c, ...Ca, "CALAIS?", lt, W2(15) + 0.2, { color: "#ffd84d" }); }
    big(c, lt, W2(1), "1944", 960, 160, { size: 120 });
    big(c, lt, W2(15), "Ở ĐÂU?", 960, 880, { size: 130, color: "#ff5a3a" });
  }]]);
} };
S.c10_2 = { pad: 0.8, sfx: (w) => [[w[1], "whoosh", 0.4], [w[9], "pop", 0.5], [w[11], "pop", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w34", lt, d, { z0: 1.03, z1: 1.1 });
    actor(c, lt, [[0, { x: 760, y: G, pose: "think", kit: "us_off", seed: 2 }], [W2(4), { pose: "pointup", expr: "happy" }]]);
    actor(c, lt, [[0, { x: 1200, y: G, pose: "shrug", kit: "artist", dir: -1, seed: 3, expr: "happy" }]]);
    big(c, lt, W2(8), "ĐẠO QUÂN “MA”", 960, 220, { size: 120, color: "#ffd84d" });
    tag(c, lt, W2(11), "không có thật", 960, 330, { accent: "#e0463a" });
  }]]);
} };
S.c10_3 = { pad: 1.5, sfx: (w) => [[0.02, "zipper", 0.0], [w[0], "strain", 0.4], [w[2], "whoosh", 0.4, 1], [w[10], "radio_voice", 0.4, 2], [w[14], "morse", 0.4, 2], [w[20], "thud", 0.45]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w34", lt, d, { z0: 1.05, z1: 1.12 });
    // inflatable tank inflating, then a soldier lifts it
    const inf = ss(clamp((lt - 0.2) / 1.6)); c.save(); c.translate(1150, G); c.scale(1, Math.max(0.05, inf)); c.translate(-1150, -G); tank(c, { x: 1150, y: G, s: 0.85, t: lt, fac: "us", fake: true }); c.restore();
    actor(c, lt, [[0, { x: 720, y: G, pose: "push", kit: "artist", seed: 4, freq: 3 }], [2.0, { pose: "holdup", expr: "happy" }]]);
    tag(c, lt, W2(0), "Xe tăng bơm hơi", 960, 200, { accent: "#ffd84d" });
    if (lt > 2.4) { c.save(); c.translate(720, 640); c.fillStyle = "#5f7a3f"; c.strokeStyle = "#111"; c.lineWidth = 4; c.beginPath(); c.ellipse(0, -40, 90, 34, 0.1, 0, 6.28); c.fill(); c.stroke(); c.restore(); }
  }], [4, (c, lt, d, W2) => {
    bg(c, "w14", lt, d, { z0: 1.04, z1: 1.1 });
    c.save(); c.globalAlpha = 0.95; for (let i = 0; i < 2; i++) { c.save(); c.translate(620 + i * 700, 860); c.scale(0.9, 0.9); c.fillStyle = "#c9b48a"; c.strokeStyle = "#5a4a3a"; c.lineWidth = 4; c.fillRect(-200, -30, 400, 50); c.strokeRect(-200, -30, 400, 50); c.fillRect(-40, -60, 80, 120); c.strokeRect(-40, -60, 80, 120); c.restore(); } c.restore();
    stick(c, { x: 960, y: G, s: 1.25, pose: "type", t: lt, kit: "artist", seed: 5 }); radioSet(c, 1150, G - 50, 0.8, lt);
    tag(c, lt, W2(4), "Máy bay gỗ & vải", 620, 200); tag(c, lt, W2(10), "Radio giả", 1300, 200); tag(c, lt, W2(14), "Gián điệp hai mang", 960, 290, { accent: "#e0463a" });
  }], [18, (c, lt, d, W2) => {
    bg(c, "w34", lt, d, { z0: 1.14, z1: 1.2 });
    for (let i = 0; i < 4; i++) tank(c, { x: 300 + i * 450, y: G - 40, s: 0.6, t: lt + i, fac: "us", fake: true, seed: i });
    actor(c, lt, [[0, { x: 960, y: G + 40, pose: "point", kit: "us_off", seed: 6, expr: "determined" }]]);
    tag(c, lt, W2(19), "Tướng Patton chỉ huy… đạo quân ma", 960, 200, { accent: "#ffd84d" });
  }]]);
} };
S.c10_4 = { pad: 1.5, sfx: (w) => [[0.02, "bombers", 0.45, 5], [w[7], "flap", 0.4], [w[12], "flap", 0.4], [w[17], "rifle_far", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w37", lt, d, { z0: 1.03, z1: 1.1 });
    for (let i = 0; i < 3; i++) plane(c, { x: lerp(-300 - i * 300, 2200, lt / 5), y: 120 + i * 40, s: 0.4, t: lt, fac: "us", kind: "bomber" });
    for (let i = 0; i < 6; i++) { const t0 = 0.6 + i * 0.5; if (lt > t0) dummy(c, 300 + i * 270, lerp(150, 800, (lt - t0) / 5), lt + i, 0.8); }
    actor(c, lt, [[0, { x: 1650, y: G, pose: "binoc", kit: "de", dir: -1, seed: 7 }], [W2(17), { pose: "shout", expr: "shock" }]]);
    tag(c, lt, W2(10), "Hình nộm nhảy dù", 960, 200, { accent: "#ffd84d" });
  }]]);
} };
S.c10_5 = { pad: 0.8, sfx: (w) => [[0.02, "clock_fast", 0.3, 2], [w[11], "thud", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w35", lt, d, { z0: 1.04, z1: 1.1 });
    actor(c, lt, [[0, { x: 960, y: G, pose: "desk", kit: "de_off", seed: 8, expr: "happy" }], [W2(10), { pose: "point", expr: "determined" }]]);
    big(c, lt, W2(10), "“CALAIS!”", 960, 230, { size: 140, color: "#ffd84d" });
    tag(c, lt, W2(0), "Bộ chỉ huy Đức tin như vậy", 960, 350);
  }]]);
} };
S.c10_6 = { pad: 3.0, sfx: (w) => [[0.02, "veo_k7", 0.85, 8], [w[3], "shiphorn", 0.4, 2], [w[19], "boom_far", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    if (!clip(c, "k7", lt)) { bg(c, "w36", lt, d); for (let i = 0; i < 4; i++) ship(c, { x: 300 + i * 420, y: 860, s: 0.6, t: lt, kind: "lcvp" }); water(c, 880, lt); }
    big(c, lt, W2(2), "6/6/1944 · D-DAY", 960, 150, { size: 110 });
    tag(c, lt, W2(3), "> 5.000 tàu · ~156.000 quân · 5 bãi biển", 960, 890, { size: 40 });
  }]]);
} };
S.c10_7 = { pad: 1.2, sfx: (w) => [[0.02, "battle", 0.55, 4], [w[2], "mg", 0.4, 1.5], [w[5], "swell", 0.4], [w[11], "cheer", 0.35, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w36", lt, d, { z0: 1.06, z1: 1.12, filter: lt < W2(5) ? "brightness(0.75)" : "none" });
    for (let i = 0; i < 4; i++) hedgehog(c, 300 + i * 450, G + 10, 1.3);
    for (let i = 0; i < 5; i++) stick(c, { x: lerp(-200 - i * 250, 1500 - i * 250, lt / 4.2), y: G + (i % 2) * 15, s: 1.2, pose: "runcarry", t: lt + i * 0.3, kit: "us", seed: 20 + i });
    if (lt < W2(5)) explosion(c, 1300, 990, (lt % 1.8) - 0.2, 1.0, 5);
    big(c, lt, W2(1), "OMAHA", 960, 200, { size: 130, color: "#ff5a3a" });
    tag(c, lt, W2(7), "Đến tối: Đồng minh đã lên bờ", 960, 320, { accent: "#5fd36a" });
  }]]);
} };
S.c10_8 = { pad: 1.8, sfx: (w) => [[0.02, "warm_pad", 0.35, 8], [w[1], "pop", 0.4], [w[16], "scribble", 0.4], [w[32], "swell", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w34", lt, d, { z0: 1.02, z1: 1.1 });
    for (let i = 0; i < 3; i++) tank(c, { x: 360 + i * 600, y: G - 60, s: 0.55, t: lt + i, fac: "us", fake: true, seed: i });
    for (let i = 0; i < 5; i++) stick(c, { x: 280 + i * 340, y: G + 30, s: 1.2, pose: i % 2 ? "type" : "think", t: lt + i * 0.4, kit: "artist", seed: 40 + i });
    tag(c, lt, W2(7), "~1.100 người · nhiều họa sĩ", 960, 200);
    tag(c, lt, W2(22), "> 20 lần đánh lừa", 960, 290, { accent: "#ffd84d" });
    big(c, lt, W2(32), "ĐỘI QUÂN MA", 960, 480, { size: 130, color: "#ffd84d" });
  }]]);
} };
