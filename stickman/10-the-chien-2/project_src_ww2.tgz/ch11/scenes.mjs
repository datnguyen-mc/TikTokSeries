import { W, H, bg, shots, stick, actor, crowd, big, tag, stamp, glow, darken, tank, plane, explosion, smokeCol, drawMap, arrow, pin, drawFlag, snow, wire, confetti, rubble, ss, lerp, clamp, rnd, particles } from "../common.mjs";
export const S = {};
const G = 1005;
S.c11_1 = { pad: 1.0, sfx: (w) => [[0.02, "cheer", 0.5, 3.5], [w[4], "bells", 0.35, 3], [w[11], "tank", 0.4, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w38", lt, d, { z0: 1.02, z1: 1.1 }); confetti(c, lt, { n: 90 });
    for (let i = 0; i < 7; i++) stick(c, { x: 260 + i * 230, y: G + (i % 2) * 10, s: 1.15, pose: i % 3 === 0 ? "dance" : i % 3 === 1 ? "cheer" : "holdup", prop: i % 3 === 2 ? "flag_fr" : null, t: lt + i * 0.3, kit: ["civ", "woman", "civ2", "us", "woman2", "civ3", "fr"][i], seed: 10 + i });
    big(c, lt, W2(0), "8/1944", 960, 180, { size: 120 });
    tag(c, lt, W2(4), "Paris được giải phóng", 960, 290, { accent: "#5fd36a" });
  }], [8, (c, lt, d, W2) => {
    const pr = drawMap(c, { lon0: 0, lon1: 40, lat0: 44, lat1: 58 });
    const B = pr(13.4, 52.5); pin(c, ...B, "BERLIN", lt, 0);
    arrow(c, [pr(37, 55), pr(28, 53.5), pr(20, 52.6), [B[0] + 50, B[1]]], ss(lt / 2.2), { color: "#d42a2a" });
    arrow(c, [pr(2.3, 48.8), pr(7, 50.3), [B[0] - 50, B[1] + 20]], ss((lt - 0.5) / 2.2), { color: "#3a6ac8" });
    tag(c, lt, W2(11), "Hồng quân tiến về Berlin", 960, 180, { accent: "#d42a2a" });
  }]]);
} };
S.c11_2 = { pad: 1.2, sfx: (w) => [[0.02, "wind", 0.45, 5], [w[5], "tank", 0.45, 3], [w[12], "boom", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w39", lt, d, { z0: 1.03, z1: 1.1 }); snow(c, lt, { n: 160, wind: 60 });
    tank(c, { x: lerp(1900, 1200, ss(lt / 3)), y: G, s: 0.85, t: lt, fac: "de", dir: -1, speed: lt < 3 ? 120 : 0, color: "#c9ccc8" });
    for (let i = 0; i < 3; i++) stick(c, { x: 420 + i * 220, y: G, s: 1.25, pose: "kneel", t: lt + i * 0.3, kit: "us", seed: 30 + i, fire: 1.3 + i * 0.2 });
    explosion(c, 1200, 980, lt - 3.2, 1.2, 4);
    tag(c, lt, W2(0), "Mùa đông 1944 · Ardennes", 960, 200);
    stamp(c, lt, W2(13), "THẤT BẠI", 960, 340, { size: 110 });
  }]]);
} };
S.c11_3 = { pad: 1.5, sfx: (w) => [[0.02, "low_drone", 0.4, 6], [w[11], "wind", 0.35, 4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w44", lt, d, { z0: 1.04, z1: 1.1, filter: "grayscale(1) brightness(0.7)" });
    wire(c, -40, W + 80, 900, lt);
    for (let i = 0; i < 3; i++) stick(c, { x: 640 + i * 320, y: G + 40, s: 1.2, pose: "sad", t: lt + i * 0.5, kit: i === 1 ? "us_off" : "us", seed: 40 + i, rifle: true, filter: "grayscale(0.6)" });
    tag(c, lt, W2(11), "Các trại tập trung", 960, 200, { accent: "#9a9a9a" });
  }]]);
} };
S.c11_4 = { pad: 2.5, sfx: (w) => [[0.02, "warm_pad", 0.35, 7]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    c.fillStyle = "#0c0c0e"; c.fillRect(0, 0, W, H);
    for (let i = 0; i < 9; i++) { const x = 360 + i * 150, y = 880; c.fillStyle = "#e8e2d0"; c.fillRect(x - 8, y - 70, 16, 70); glow(c, x, y - 82, 70, "rgba(255,200,110,0.9)", 0.6 + 0.2 * Math.sin(lt * 7 + i)); c.fillStyle = "#ffcf70"; c.beginPath(); c.ellipse(x, y - 84, 6, 12 + Math.sin(lt * 9 + i) * 2, 0, 0, 6.28); c.fill(); }
    big(c, lt, W2(0), "~6.000.000", 960, 330, { size: 170, color: "#f2efe6" });
    tag(c, lt, W2(3), "người Do Thái bị sát hại", 960, 450, { accent: "#9a9a9a" });
    big(c, lt, W2(19), "HOLOCAUST", 960, 620, { size: 110, color: "#c9c2b0" });
  }]]);
} };
S.c11_5 = { pad: 1.5, sfx: (w) => [[0.02, "waves", 0.3, 5], [w[1], "thud", 0.4], [w[14], "cheer", 0.45, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w40", lt, d, { z0: 1.03, z1: 1.1 });
    actor(c, lt, [[0, { x: 300, y: G, pose: "walk", kit: "us", seed: 2, rifle: true }], [0.01, { x: 840, move: W2(13), lin: 1 }], [W2(13), { pose: "handshake" }]]);
    actor(c, lt, [[0, { x: 1620, y: G, pose: "walk", kit: "su_cap", dir: -1, seed: 3, rifle: true }], [0.01, { x: 1080, move: W2(13), lin: 1 }], [W2(13), { pose: "handshake" }]]);
    if (lt > W2(14)) { drawFlag(c, 520, 380, 160, 100, lt, "us"); drawFlag(c, 1250, 380, 160, 100, lt, "su"); }
    big(c, lt, W2(1), "25/4/1945", 960, 200, { size: 120 });
    tag(c, lt, W2(11), "Sông Elbe", 960, 310, { accent: "#5fd3ff" });
  }]]);
} };
S.c11_6 = { pad: 1.8, sfx: (w) => [[0.02, "battle", 0.5, 4], [w[5], "low_drone", 0.4, 3], [w[13], "swell", 0.5], [w[17], "cheer", 0.4, 2]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w41", lt, d, { z0: 1.0, z1: 1.08 });
    for (let i = 0; i < 2; i++) tank(c, { x: lerp(-400 - i * 600, 900 - i * 600, ss(lt / 4)), y: G, s: 0.8, t: lt, fac: "su", speed: lt < 4 ? 120 : 0, seed: i });
    big(c, lt, W2(5), "30/4/1945", 960, 200, { size: 120 });
    tag(c, lt, W2(7), "Hitler tự sát trong hầm ngầm", 960, 310, { accent: "#9a9a9a" });
  }], [13, (c, lt, d, W2) => {
    bg(c, "w41", lt, d, { z0: 1.35, z1: 1.45, y0: 150, y1: 150 });
    rubble(c, 960, 640, 700, 6);
    actor(c, lt, [[0, { x: 960, y: 640, pose: "holdup", kit: "su_cap", prop: "flag_su", seed: 4 }]]);
    tag(c, lt, W2(20), "Nóc tòa nhà Quốc hội Đức", 960, 890);
  }]]);
} };
S.c11_7 = { pad: 2.0, sfx: (w) => [[w[1], "thud", 0.5], [w[5], "cheer", 0.6, 4], [w[5], "bells", 0.4, 4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w42", lt, d, { z0: 1.0, z1: 1.08 }); confetti(c, lt, { n: 140 });
    for (let i = 0; i < 8; i++) stick(c, { x: 200 + i * 220, y: G + (i % 2) * 12, s: 1.15, pose: ["dance", "cheer", "hug", "holdup"][i % 4], prop: i % 4 === 3 ? ["flag_uk", "flag_us", "flag_fr", "flag_su"][(i >> 2) % 4] : null, t: lt + i * 0.25, kit: ["uk", "woman", "us", "civ", "fr", "woman2", "su_cap", "kid"][i], seed: 60 + i });
    big(c, lt, W2(0), "8/5/1945", 960, 180, { size: 120 });
    big(c, lt, W2(2), "ĐỨC ĐẦU HÀNG", 960, 310, { size: 120, color: "#5fd36a" });
  }]]);
} };
S.c11_8 = { pad: 1.5, sfx: (w) => [[0.02, "low_drone", 0.5, 3], [w[4], "boom_far", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w50", lt, d, { z0: 1.06, z1: 1.14, filter: "hue-rotate(-10deg)" });
    for (let i = 0; i < 3; i++) stick(c, { x: 640 + i * 320, y: G, s: 1.2, pose: "aim", t: lt + i * 0.4, kit: "jp", seed: 70 + i, fire: 1.4 + i * 0.3, dir: -1 });
    big(c, lt, W2(1), "CHÂU Á", 960, 200, { size: 130, color: "#ff5a3a" });
    tag(c, lt, W2(6), "Chiến tranh vẫn chưa kết thúc", 960, 310);
  }]]);
} };
