import { W, H, bg, shots, stick, actor, crowd, big, tag, stamp, glow, darken, shade, plane, explosion, drawMap, arrow, pin, drawFlag, ship, water, radioSet, table, mic, shock, ss, lerp, clamp, rnd, particles, preloadClip, clip } from "../common.mjs";
export const S = {};
await preloadClip("k8");
const G = 1005;
S.c12_1 = { pad: 1.0, sfx: (w) => [[0.02, "low_drone", 0.45, 5], [w[8], "thud", 0.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w35", lt, d, { z0: 1.04, z1: 1.1, filter: "brightness(0.75)" });
    actor(c, lt, [[0, { x: 760, y: G, pose: "desk", kit: "us_off", seed: 2 }], [W2(8), { pose: "talk" }]]); actor(c, lt, [[0, { x: 1200, y: G, pose: "sad", kit: "suit", dir: -1, seed: 3 }]]);
    big(c, lt, W2(2), "HÈ 1945", 960, 200, { size: 120 });
    tag(c, lt, W2(11), "Một loại vũ khí mới", 960, 310, { accent: "#e0463a" });
  }]]);
} };
S.c12_2 = { pad: 2.5, sfx: (w) => [[0.02, "birds", 0.35, 5], [w[12], "boom", 1.0], [w[12] + 0.2, "ring", 0.4, 4], [w[12] + 1.0, "rumble", 0.6, 4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    const fl = W2(12);
    if (lt < fl) { bg(c, "w43", lt, d, { z0: 1.0, z1: 1.06 }); big(c, lt, W2(0), "8:15", 960, 190, { size: 150 }); tag(c, lt, W2(5), "6/8/1945 · Hiroshima", 960, 310); plane(c, { x: lerp(-300, 2200, lt / 6), y: 120, s: 0.35, t: lt, fac: "us", kind: "bomber" }); }
    else { const a = lt - fl; bg(c, "w44", lt, d, { z0: 1.06, z1: 1.1, filter: "grayscale(0.6)" }); shock(c, 960, 700, a, 1300);
      c.save(); c.globalAlpha = clamp(1 - a / 2.5); c.fillStyle = "#fff"; c.fillRect(0, 0, W, H); c.restore();
      if (a > 2.0) tag(c, lt, fl + 2.0, "Hiroshima", 960, 200, { accent: "#9a9a9a" }); }
  }]]);
} };
S.c12_3 = { pad: 2.0, sfx: (w) => [[0.02, "wind", 0.4, 8], [w[8], "boom_far", 0.6]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w44", lt, d, { z0: 1.06, z1: 1.14, filter: "grayscale(0.8) brightness(0.85)" });
    particles(c, lt, { n: 60, color: "rgba(200,200,200,0.5)", vy: 25, vx: 10, size: 3 });
    big(c, lt, W2(1), "9/8: NAGASAKI", 960, 200, { size: 110, color: "#f2efe6" });
    big(c, lt, W2(15), "~110.000 NGƯỜI", 960, 380, { size: 120, color: "#fff" });
    tag(c, lt, W2(21), "chưa kể người chết vì phóng xạ sau đó", 960, 490, { accent: "#9a9a9a" });
  }]]);
} };
S.c12_4 = { pad: 1.2, sfx: (w) => [[0.02, "static", 0.4, 3.5], [w[2], "radio_voice", 0.45, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w45", lt, d, { z0: 1.04, z1: 1.1 });
    radioSet(c, 960, 760, 1.2, lt);
    for (let i = 0; i < 4; i++) stick(c, { x: 480 + i * 320 + (i > 1 ? 160 : 0), y: G, s: i === 3 ? 0.9 : 1.2, pose: i === 0 ? "mourn" : "sad", t: lt + i * 0.3, kit: ["jpciv2", "jpciv", "jp", "kid"][i], seed: 20 + i, dir: i < 2 ? 1 : -1 });
    big(c, lt, W2(0), "15/8/1945", 960, 200, { size: 120 });
    tag(c, lt, W2(2), "Nhật hoàng tuyên bố đầu hàng qua radio", 960, 310);
  }]]);
} };
S.c12_5 = { pad: 1.8, sfx: (w) => [[0.02, "waves", 0.35, 6], [w[10], "scribble", 0.5], [w[15], "swell", 0.6]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w46", lt, d, { z0: 1.03, z1: 1.1 });
    table(c, 960, G, 360, 120, "#5a3a22", "#2f5a3a");
    actor(c, lt, [[0, { x: 780, y: G, pose: "desk", kit: "diplomat", seed: 2, expr: "sad" }], [W2(10), { pose: "type", expr: "sad" }]]);
    for (let i = 0; i < 4; i++) stick(c, { x: 1250 + i * 160, y: G, s: 1.15, pose: "salute", t: lt + i * 0.3, kit: i === 0 ? "us_off" : "sailor_us", seed: 30 + i, dir: -1 });
    big(c, lt, W2(1), "2/9/1945", 960, 180, { size: 120 });
    tag(c, lt, W2(3), "Chiến hạm Missouri · vịnh Tokyo", 960, 290);
    big(c, lt, W2(15), "THẾ CHIẾN II KẾT THÚC", 960, 460, { size: 92, color: "#5fd36a" });
  }]]);
} };
S.c12_6 = { pad: 1.5, sfx: (w) => [[0.02, "crowd", 0.45, 4], [w[12], "cheer", 0.5, 2.5]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w47", lt, d, { z0: 1.02, z1: 1.1 });
    for (let i = 0; i < 9; i++) stick(c, { x: 160 + i * 200, y: G + (i % 2) * 12, s: 1.1, pose: i % 3 === 0 ? "holdup" : "cheer", prop: i % 3 === 0 ? "flag_vn" : null, t: lt + i * 0.3, kit: ["viet", "civ3", "worker", "viet", "civ", "kid", "viet", "civ3", "worker"][i], seed: 50 + i });
    tag(c, lt, W2(0), "Cùng ngày · Hà Nội", 960, 200, { accent: "#ffd84d" });
    big(c, lt, W2(12), "VIỆT NAM TUYÊN BỐ ĐỘC LẬP", 960, 320, { size: 84, color: "#ffd84d" });
  }]]);
} };
S.c12_7 = { pad: 2.0, sfx: (w) => [[0.02, "warm_pad", 0.4, 6], [w[2], "low_drone", 0.4, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w48", lt, d, { z0: 1.0, z1: 1.1 });
    big(c, lt, W2(0), "6 NĂM", 960, 180, { size: 120, color: "#fff" });
    big(c, lt, W2(2), "70 – 85 TRIỆU NGƯỜI CHẾT", 960, 310, { size: 92, color: "#ff5a3a" });
    tag(c, lt, W2(12), "Phần lớn là dân thường", 960, 420);
    stick(c, { x: 1450, y: G, s: 1.2, pose: "mourn", t: lt, kit: "woman", seed: 5, dir: -1 });
  }]]);
} };
S.c12_8 = { pad: 1.5, sfx: (w) => [[0.02, "warm_pad", 0.35, 5], [w[4], "footsteps", 0.3, 3]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w49", lt, d, { z0: 1.04, z1: 1.1 });
    for (let i = 0; i < 3; i++) actor(c, lt, [[0, { x: -150 - i * 260, y: G, pose: "walk", kit: ["uk", "us", "su_cap"][i], seed: 70 + i, freq: 1.2, rifle: true }], [0.01, { x: 700 - i * 260, move: 3.5, lin: 1 }], [3.6, { pose: "sad" }]]);
    actor(c, lt, [[0, { x: 1350, y: G, pose: "wave", kit: "woman", dir: -1, seed: 80 }], [3.0, { pose: "hug" }]]); stick(c, { x: 1500, y: G, s: 0.95, pose: "cheer", t: lt, kit: "kid", seed: 81, dir: -1 });
    tag(c, lt, W2(7), "Những vết thương không ai nhìn thấy", 960, 200);
  }]]);
} };
S.c12_9 = { pad: 3.0, sfx: (w) => [[0.02, "veo_k8", 0.7, 8], [w[0], "swell", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    if (!clip(c, "k8", lt)) bg(c, "w49", lt, d);
    if (lt > W2(0)) drawFlag(c, 1500, 160, 220, 140, lt, "un");
    big(c, lt, W2(0), "LIÊN HỢP QUỐC · 1945", 960, 160, { size: 92, color: "#fff" });
    tag(c, lt, W2(9), "“Không bao giờ để chuyện này lặp lại”", 960, 890, { accent: "#5fd3ff" });
  }]]);
} };
