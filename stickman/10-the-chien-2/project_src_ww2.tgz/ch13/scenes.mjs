import { W, H, bg, shots, stick, big, tag, glow, shade, ss, lerp, clamp, drawFlag } from "../common.mjs";
export const S = {}; S.__card = 0; S.__cardSfx = []; S.__tailFilm = 1.0;
const CR = ["Kịch bản & dựng phim: Claude", "Nền & cảnh Veo: Google Flow (Nano Banana, Veo 3.1)", "Giọng đọc: Piper vi_VN · Nhạc & SFX: tổng hợp gốc", "Nguồn: History.com · IWM · RAF · Smithsonian · HistoryNet", "Thực hiện cho: Dat Nguyen · Metacrew"];
S.c13_1 = { pad: 9.0, sfx: (w) => [[0.02, "warm_pad", 0.45, 12], [w[7], "chime", 0.4]], draw(c, t, s) {
  shots(c, t, s, [[0, (c, lt, d, W2) => {
    bg(c, "w49", lt, d, { z0: 1.0, z1: 1.12 });
    const kits = ["uk", "us", "su_cap", "fr", "pl", "civ", "woman", "kid", "viet"]; for (let i = 0; i < 9; i++) stick(c, { x: 200 + i * 190, y: 1010, s: 1.0, pose: i % 2 ? "wave" : "idle", t: lt + i * 0.3, kit: kits[i], seed: i + 1 });
    big(c, lt, W2(0), "CẢM ƠN BẠN ĐÃ XEM", 960, 200, { size: 110, color: "#fff" });
    tag(c, lt, W2(7), "Bạn muốn nghe tiếp câu chuyện nào? Bình luận nhé!", 960, 320, { accent: "#ffd84d" });
    const u = clamp((lt - 5.5) / 8); if (u > 0) { c.save(); c.fillStyle = "rgba(0,0,0,0.55)"; c.fillRect(0, 380, W, 380); c.font = "600 38px NotoSans"; c.textAlign = "center"; c.fillStyle = "#f2efe6"; CR.forEach((l, i) => { const y = 860 - u * 520 + i * 70; if (y > 390 && y < 750) c.fillText(l, 960, y); }); c.restore(); }
    if (lt > d - 1.2) shade(c, (lt - (d - 1.2)) / 1.2);
  }]]);
} };
