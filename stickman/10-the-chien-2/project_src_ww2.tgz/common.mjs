// shared imports + helpers for chapter scene files
export * from "./core.mjs";
export * from "./rig.mjs";
export * from "./gear.mjs";
export { shots, focus, FOCUS, GY } from "./stage.mjs";
import { W, H, clamp, ss, lerp, rnd, IMG, loadImage, bigText as BT, chip as CP } from "./core.mjs";
import { stick } from "./rig.mjs";
import fs from "node:fs";
import { PENDING } from "./stage.mjs";
// text defaults sized for the 1080-wide short crop
export const big = (c, t, t0, s, x = 960, y = 230, o = {}) => BT(c, t, t0, s, x, y, { maxW: 980, ...o });
export const tag = (c, t, t0, s, x = 960, y = 330, o = {}) => CP(c, t, t0, s, x, y, { size: 46, ...o });
// marching column: n soldiers walking from xa to xb over time (looping), kits
export function column(c, t, { n = 6, x0 = -200, gap = 170, y = 960, s = 0.9, kit = "uk", pose = "march", speed = 90, dir = 1, seed = 1, freq } = {}) {
  for (let i = 0; i < n; i++) { const x = x0 + (dir > 0 ? 1 : -1) * (t * speed) - i * gap * dir; stick(c, { x, y: y + (i % 2) * 6, s, dir, pose, t: t + i * 0.21, kit: typeof kit === "function" ? kit(i) : kit, seed: seed + i, freq, rifle: pose !== "march" }); }
}
// video frames (Veo clips extracted to jpg sequences), decoded lazily + synchronously
const require_ = (await import("node:module")).createRequire("/home/claude/repo/stickman-video-director/skills/directing-stickman-videos/package.json");
const { Image } = require_("@napi-rs/canvas");
const VF = {}, CACHE = new Map();
export async function preloadClip(name) { const dir = `/home/claude/ww2/assets/veo/${name}`; if (!fs.existsSync(dir)) return false; VF[name] = fs.readdirSync(dir).filter(f => f.endsWith(".jpg")).sort().map(f => `${dir}/${f}`); return true; }
export const hasClip = (name) => !!VF[name]?.length;
function frameImg(path) { if (CACHE.has(path)) return CACHE.get(path); const im = new Image(); const p = new Promise(res => { im.onload = () => { im._ok = true; res(); }; im.onerror = res; }); PENDING.add(p); p.then(() => PENDING.delete(p)); im.src = fs.readFileSync(path); CACHE.set(path, im); if (CACHE.size > 16) CACHE.delete(CACHE.keys().next().value); return im; }
export function clip(c, name, t, { fps = 24, z = 1, alpha = 1, x = 0, y = 0 } = {}) {
  const fr = VF[name]; if (!fr?.length) return false; const k = Math.min(fr.length - 1, Math.max(0, Math.floor(t * fps))); const im = frameImg(fr[k]); for (let j = 1; j <= 3; j++) if (k + j < fr.length) frameImg(fr[k + j]);
  if (!im._ok) return true;
  const sc = Math.max(W / im.width, H / im.height) * z; c.save(); c.globalAlpha *= alpha; c.drawImage(im, (W - im.width * sc) / 2 + x, (H - im.height * sc) / 2 + y, im.width * sc, im.height * sc); c.restore(); return true;
}
export const darken = (c, a) => { c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.fillStyle = `rgba(0,0,0,${a})`; c.fillRect(0, 0, W, H); c.restore(); };
export const tint = (c, color, a) => { c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = a; c.fillStyle = color; c.fillRect(0, 0, W, H); c.restore(); };
