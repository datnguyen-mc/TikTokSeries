// core helpers for the WW2 film (1920x1080 world)
import fs from "node:fs";
import { createRequire } from "node:module";
const require = createRequire("/home/claude/repo/stickman-video-director/skills/directing-stickman-videos/package.json");
export const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
const F = "/home/claude/repo/stickman-video-director/skills/directing-stickman-videos/assets/fonts";
GlobalFonts.registerFromPath(`${F}/NotoSans.ttf`, "NotoSans");
GlobalFonts.registerFromPath(`${F}/Anton.ttf`, "Archivo");
export const W = 1920, H = 1080, FPS = 30;
export const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
export const lerp = (a, b, u) => a + (b - a) * u;
export const ss = (u) => { u = clamp(u); return u * u * (3 - 2 * u); };
export const ease = (t, t0, t1) => ss((t - t0) / Math.max(1e-6, t1 - t0));
export const easeOutBack = (u) => { u = clamp(u); const c = 1.7; return 1 + (c + 1) * Math.pow(u - 1, 3) + c * Math.pow(u - 1, 2); };
const hash = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
export const rnd = (seed, i = 0) => hash(seed * 31.7 + i * 7.13);
export const TAU = Math.PI * 2;

export const IMG = {};
export async function loadDir(dir) {
  if (!fs.existsSync(dir)) return;
  for (const f of fs.readdirSync(dir)) if (/\.(jpg|png|jpeg|webp)$/i.test(f)) IMG[f.replace(/\.\w+$/, "")] = await loadImage(`${dir}/${f}`);
}
export const img = (n) => { const im = IMG[n]; if (!im) throw new Error("missing image " + n); return im; };

// background plate with slow camera move. o: z0,z1,x0,x1,y0,y1,filter,alpha
export function bg(ctx, name, t, d, o = {}) {
  const { z0 = 1.03, z1 = 1.1, x0 = 0, x1 = 0, y0 = 0, y1 = 0, filter, alpha = 1 } = o;
  const u = ss(t / Math.max(d, 0.01)); const z = lerp(z0, z1, u);
  const im = img(name); const sc = Math.max(W / im.width, H / im.height) * z;
  ctx.save(); ctx.globalAlpha *= alpha; if (filter) ctx.filter = filter;
  ctx.drawImage(im, (W - im.width * sc) / 2 + lerp(x0, x1, u), (H - im.height * sc) / 2 + lerp(y0, y1, u), im.width * sc, im.height * sc);
  ctx.restore();
}
// world camera: call cam(ctx, ...) then draw world things, restore after
export function camera(ctx, t, d, { z0 = 1, z1 = 1.04, cx = W / 2, cy = H * 0.6, x0 = 0, x1 = 0, y0 = 0, y1 = 0, shake = 0 } = {}) {
  const u = ss(t / Math.max(d, 0.01)); const z = lerp(z0, z1, u);
  ctx.translate(cx + lerp(x0, x1, u) + Math.sin(t * 53) * shake, cy + lerp(y0, y1, u) + Math.cos(t * 47) * shake);
  ctx.scale(z, z); ctx.translate(-cx, -cy);
}
export function shade(ctx, a, color = "0,0,0") { if (a <= 0) return; ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = `rgba(${color},${clamp(a)})`; ctx.fillRect(0, 0, W, H); ctx.restore(); }
export function vignette(ctx, a = 0.5) {
  ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
  const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, H * 0.95);
  g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, `rgba(0,0,0,${a})`); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.restore();
}
export function glow(ctx, x, y, r, color, a) {
  if (a <= 0) return; ctx.save(); ctx.globalAlpha *= clamp(a);
  const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, color); g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g; ctx.fillRect(x - r, y - r, 2 * r, 2 * r); ctx.restore();
}
// ---------- text ----------
export function bigText(ctx, t, t0, s, x, y, { color = "#ffd84d", size = 110, t1 = 1e9, stroke = 14, align = "center", maxW = 1700 } = {}) {
  if (t < t0 || t > t1 + 0.3) return; const k = easeOutBack(clamp((t - t0) / 0.3)); const out = t > t1 ? 1 - (t - t1) / 0.3 : 1;
  ctx.save(); ctx.globalAlpha *= clamp(out); ctx.translate(x, y); ctx.scale(k, k);
  let sz = size; ctx.font = `${sz}px Archivo`; while (ctx.measureText(s).width > maxW && sz > 30) { sz -= 4; ctx.font = `${sz}px Archivo`; }
  ctx.textAlign = align; ctx.lineJoin = "round"; ctx.lineWidth = stroke; ctx.strokeStyle = "#000"; ctx.strokeText(s, 0, 0); ctx.fillStyle = color; ctx.fillText(s, 0, 0); ctx.restore();
}
export function rrect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
export function chip(ctx, t, t0, s, x, y, { size = 34, bg = "rgba(14,16,24,0.85)", color = "#fff", accent = "#ffd84d", t1 = 1e9, align = "center" } = {}) {
  if (t < t0 || t > t1 + 0.3) return; const k = easeOutBack(clamp((t - t0) / 0.32)); const out = t > t1 ? 1 - (t - t1) / 0.3 : 1;
  ctx.save(); ctx.globalAlpha *= clamp(out); ctx.font = `600 ${size}px NotoSans`; const w = ctx.measureText(s).width + size * 1.2, h = size * 1.6;
  const ox = align === "left" ? 0 : align === "right" ? -w : -w / 2;
  ctx.translate(x, y); ctx.scale(k, k); rrect(ctx, ox, -h / 2, w, h, h / 2); ctx.fillStyle = bg; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = accent; ctx.stroke();
  ctx.fillStyle = color; ctx.textAlign = "left"; ctx.textBaseline = "middle"; ctx.fillText(s, ox + size * 0.6, 2); ctx.restore();
}
export function stamp(ctx, t, t0, s, x, y, { color = "#d23a2a", rot = -0.12, size = 100 } = {}) {
  if (t < t0) return; const k = clamp((t - t0) / 0.18); const sc = lerp(2.2, 1, ss(k));
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc); ctx.globalAlpha *= k;
  ctx.font = `${size}px Archivo`; const w = ctx.measureText(s).width; ctx.lineWidth = 9; ctx.strokeStyle = color; ctx.strokeRect(-w / 2 - 22, -size * 0.92, w + 44, size * 1.18);
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.fillText(s, 0, 0); ctx.restore();
}
export function fadeIO(ctx, lt, d, fi = 0.4, fo = 0.4) {
  let a = 0; if (fi > 0 && lt < fi) a = 1 - lt / fi; if (fo > 0 && lt > d - fo) a = Math.max(a, (lt - (d - fo)) / fo);
  shade(ctx, a);
}
