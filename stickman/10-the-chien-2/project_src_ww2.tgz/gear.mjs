// Vehicles, props and effects (procedural, 1920x1080 world)
import fs from "node:fs";
import { W, H, clamp, lerp, ss, rnd, TAU, rrect, glow } from "./core.mjs";
import { drawFlag, stick } from "./rig.mjs";
const { sin, cos, PI, abs, max, min, hypot, atan2, exp } = Math;

const outline = (ctx, fill, lw = 5) => { ctx.fillStyle = fill; ctx.fill(); ctx.lineWidth = lw; ctx.strokeStyle = "#141414"; ctx.stroke(); };
function starPath(ctx, x, y, r) { ctx.beginPath(); for (let i = 0; i < 10; i++) { const a = -PI / 2 + i * PI / 5, rr = i % 2 ? r * 0.45 : r; ctx.lineTo(x + cos(a) * rr, y + sin(a) * rr); } ctx.closePath(); }
export function insignia(ctx, fac, x, y, r) {
  ctx.save(); ctx.lineWidth = 3;
  if (fac === "de") { ctx.fillStyle = "#fff"; ctx.fillRect(x - r, y - r * 0.32, 2 * r, r * 0.64); ctx.fillRect(x - r * 0.32, y - r, r * 0.64, 2 * r); ctx.fillStyle = "#111"; ctx.fillRect(x - r * 0.78, y - r * 0.16, r * 1.56, r * 0.32); ctx.fillRect(x - r * 0.16, y - r * 0.78, r * 0.32, r * 1.56); }
  else if (fac === "su") { ctx.fillStyle = "#d42a2a"; starPath(ctx, x, y, r); ctx.fill(); ctx.strokeStyle = "#111"; ctx.stroke(); }
  else if (fac === "us") { ctx.fillStyle = "#24357a"; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); ctx.fillStyle = "#fff"; starPath(ctx, x, y, r * 0.85); ctx.fill(); }
  else if (fac === "uk") { for (const [rr, c] of [[1, "#e8c840"], [0.86, "#24357a"], [0.6, "#fff"], [0.32, "#c8201e"]]) { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, y, r * rr, 0, TAU); ctx.fill(); } }
  else if (fac === "jp") { ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); ctx.fillStyle = "#c8201e"; ctx.beginPath(); ctx.arc(x, y, r * 0.8, 0, TAU); ctx.fill(); }
  else if (fac === "fr") { for (const [rr, c] of [[1, "#24357a"], [0.66, "#fff"], [0.33, "#c8201e"]]) { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, y, r * rr, 0, TAU); ctx.fill(); } }
  else if (fac === "pl") { ctx.fillStyle = "#fff"; ctx.fillRect(x - r, y - r, r, r); ctx.fillRect(x, y, r, r); ctx.fillStyle = "#c8201e"; ctx.fillRect(x, y - r, r, r); ctx.fillRect(x - r, y, r, r); }
  ctx.restore();
}
const TANKC = { de: "#6a6e5c", su: "#4f6233", us: "#59663a", uk: "#6f6d4b", fr: "#7a7a5a", pl: "#6e6f4f", jp: "#7a7448", fake: "#5f7a3f" };
// ---------------- tank ----------------
export function tank(ctx, o) {
  const { x, y, dir = 1, t = 0, fac = "de", speed = 0, fire = 0, seed = 1, turret = 0, head = null, fake = false, alpha = 1 } = o; const s = (o.s ?? 1) * 1.45;
  ctx.save(); ctx.translate(x, y); ctx.scale(dir * s, s); ctx.globalAlpha *= alpha;
  if (fake) { const wb = 1 + 0.03 * sin(t * 3 + seed); ctx.scale(wb, 2 - wb); }
  const col = o.color ?? (fake ? TANKC.fake : TANKC[fac] ?? TANKC.de);
  const bump = speed ? 1.6 * sin(t * 20 + seed) : 0; ctx.translate(0, bump);
  // exhaust
  if (speed) for (let i = 0; i < 4; i++) { const a = ((t * 1.3 + i / 4 + seed) % 1); ctx.fillStyle = `rgba(90,90,90,${0.4 * (1 - a)})`; ctx.beginPath(); ctx.arc(-175 - a * 70, -100 - a * 40, 10 + a * 24, 0, TAU); ctx.fill(); }
  // tracks
  rrect(ctx, -175, -62, 350, 62, 30); outline(ctx, "#2b2b2b");
  for (let i = 0; i < 6; i++) { const wx = -138 + i * 55; ctx.save(); ctx.translate(wx, -31); ctx.rotate((speed ? -t * speed / 22 : 0) * 1); ctx.beginPath(); ctx.arc(0, 0, 22, 0, TAU); outline(ctx, "#4a4a4a", 4);
    ctx.strokeStyle = "#222"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-14, 0); ctx.lineTo(14, 0); ctx.moveTo(0, -14); ctx.lineTo(0, 14); ctx.stroke(); ctx.restore(); }
  ctx.fillStyle = "#1a1a1a"; const off = speed ? (t * speed) % 20 : 0; for (let i = -9; i < 9; i++) { ctx.fillRect(i * 20 + off - 2, -64, 6, 6); ctx.fillRect(i * 20 - off - 2, -3, 6, 6); }
  if (head) stick(ctx, { x: -20, y: -50, s: 0.72, pose: "binoc", t, kit: head, seed, noGun: true });
  // hull
  ctx.beginPath(); ctx.moveTo(-170, -58); ctx.lineTo(178, -58); ctx.lineTo(150, -112); ctx.lineTo(-160, -112); ctx.closePath(); outline(ctx, col);
  ctx.fillStyle = "rgba(0,0,0,0.15)"; ctx.fillRect(-165, -72, 330, 12);
  if (fake) { ctx.fillStyle = "#4a6a32"; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(-90 + i * 80, -86, 10, 0, TAU); ctx.fill(); } }
  // turret
  const rec = fire ? (((t + seed * 0.3) % fire) < 0.2 ? exp(-(((t + seed * 0.3) % fire)) * 18) : 0) : 0;
  ctx.save(); ctx.translate(-10, -112); ctx.rotate(turret);
  ctx.beginPath(); ctx.moveTo(-80, 0); ctx.lineTo(-70, -54); ctx.lineTo(60, -54); ctx.lineTo(82, 0); ctx.closePath(); outline(ctx, col);
  ctx.save(); ctx.translate(76 - rec * 18, -30); rrect(ctx, 0, -8, 150, 16, 6); outline(ctx, col, 4); rrect(ctx, 140, -11, 18, 22, 4); outline(ctx, "#3a3a3a", 4); ctx.restore();
  ctx.restore();
  insignia(ctx, fac === "fake" ? "us" : fac, 30, -85, 18);
  ctx.restore();
  if (rec > 0.25) { const mx = x + dir * s * (-10 + 76 + 160), my = y - 142 * s + bump * s; ctx.save(); ctx.globalAlpha *= rec; ctx.fillStyle = "#fff4b0"; ctx.beginPath(); ctx.arc(mx, my, 40 * s * rec, 0, TAU); ctx.fill(); ctx.fillStyle = "#ffae3a"; ctx.beginPath(); ctx.arc(mx + dir * 30 * s, my, 26 * s, 0, TAU); ctx.fill(); ctx.restore(); }
}
// ---------------- planes ----------------
const PLANEC = { uk: ["#5c6b45", "#8a7a55"], de: ["#7d8590", "#e8c840"], us: ["#3e5a7a", "#c8c8c8"], jp: ["#d6d2bf", "#2a2a2a"], su: ["#5a6b3a", "#c8201e"] };
export function plane(ctx, o) {
  const { x, y, s = 1, dir = 1, t = 0, fac = "uk", kind = "fighter", rot = 0, seed = 1, pilot = true, smoke = 0, alpha = 1 } = o;
  const [c1, c2] = PLANEC[fac] ?? PLANEC.uk;
  ctx.save(); ctx.translate(x, y); ctx.scale(dir * s, s); ctx.rotate(rot + 0.02 * sin(t * 2 + seed)); ctx.globalAlpha *= alpha;
  if (smoke) for (let i = 0; i < 10; i++) { const a = ((t * 2 + i / 10) % 1); ctx.fillStyle = `rgba(40,40,40,${0.5 * (1 - a) * smoke})`; ctx.beginPath(); ctx.arc(-120 - a * 260, -10 + sin(i) * 8, 14 + a * 30, 0, TAU); ctx.fill(); }
  if (kind === "bomber") {
    ctx.beginPath(); ctx.moveTo(220, 0); ctx.quadraticCurveTo(210, -36, 150, -40); ctx.lineTo(-180, -26); ctx.lineTo(-250, -18); ctx.lineTo(-250, 6); ctx.lineTo(-170, 14); ctx.lineTo(150, 30); ctx.quadraticCurveTo(212, 26, 220, 0); outline(ctx, c1);
    ctx.beginPath(); ctx.moveTo(-200, -24); ctx.lineTo(-250, -100); ctx.lineTo(-215, -100); ctx.lineTo(-160, -26); outline(ctx, c1);
    ctx.beginPath(); ctx.ellipse(10, 18, 120, 14, 0, 0, TAU); outline(ctx, c1, 4);
    for (const ex of [-20, 60]) { ctx.beginPath(); ctx.ellipse(ex + 30, 8, 34, 14, 0, 0, TAU); outline(ctx, "#4a4a4a", 4); propeller(ctx, ex + 66, 8, t, 34); }
    ctx.fillStyle = "#9cc3d8"; for (let i = 0; i < 6; i++) { ctx.fillRect(100 - i * 40, -20, 18, 12); }
    ctx.beginPath(); ctx.ellipse(180, -8, 26, 20, 0, 0, TAU); ctx.fillStyle = "rgba(160,200,220,0.9)"; ctx.fill(); ctx.stroke();
    insignia(ctx, fac, -100, -2, 18);
  } else {
    // fighter / dive bomber / zero
    const L = kind === "dive" ? 1.1 : 1;
    ctx.beginPath(); ctx.moveTo(130 * L, 0); ctx.quadraticCurveTo(122 * L, -26, 80, -26); ctx.lineTo(-90, -14); ctx.lineTo(-150, -8); ctx.lineTo(-150, 8); ctx.lineTo(-90, 12); ctx.lineTo(80, 22); ctx.quadraticCurveTo(122 * L, 20, 130 * L, 0); outline(ctx, c1);
    if (fac === "de") { ctx.beginPath(); ctx.moveTo(130, 0); ctx.quadraticCurveTo(122, -26, 100, -25); ctx.lineTo(100, 21); ctx.quadraticCurveTo(122, 20, 130, 0); ctx.fillStyle = c2; ctx.fill(); ctx.stroke(); }
    if (fac === "uk") { ctx.fillStyle = c2; ctx.beginPath(); ctx.ellipse(10, -6, 50, 9, 0.1, 0, TAU); ctx.fill(); }
    ctx.beginPath(); ctx.moveTo(-120, -10); ctx.lineTo(-160, -66); ctx.lineTo(-136, -68); ctx.lineTo(-96, -12); outline(ctx, c1); // tail fin
    ctx.beginPath(); ctx.ellipse(20, 14, 82, 11, 0.04, 0, TAU); outline(ctx, c1, 4); // wing
    // canopy + pilot
    ctx.save(); ctx.beginPath(); ctx.ellipse(20, -28, 34, 20, 0, PI, TAU); ctx.closePath(); ctx.fillStyle = "rgba(170,210,230,0.85)"; ctx.fill(); ctx.lineWidth = 4; ctx.strokeStyle = "#141414"; ctx.stroke(); ctx.clip();
    if (pilot) { ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(22, -30, 14, 0, TAU); ctx.fill(); ctx.stroke(); ctx.fillStyle = "#5a3a22"; ctx.beginPath(); ctx.arc(20, -34, 14, PI, TAU); ctx.fill(); ctx.fillStyle = "#111"; ctx.beginPath(); ctx.arc(29, -30, 2.2, 0, TAU); ctx.fill(); }
    ctx.restore();
    propeller(ctx, 132 * L, 0, t, 42);
    if (kind === "dive") { ctx.fillStyle = "#222"; ctx.beginPath(); ctx.ellipse(20, 34, 30, 8, 0, 0, TAU); ctx.fill(); }
    insignia(ctx, fac, -60, 0, 14); if (fac !== "de") insignia(ctx, fac, 30, 14, 9);
  }
  ctx.restore();
}
function propeller(ctx, x, y, t, r) { ctx.save(); ctx.translate(x, y); ctx.fillStyle = "rgba(60,60,60,0.25)"; ctx.beginPath(); ctx.ellipse(0, 0, 6, r, 0, 0, TAU); ctx.fill();
  ctx.strokeStyle = "rgba(30,30,30,0.7)"; ctx.lineWidth = 5; const a = t * 60; ctx.beginPath(); ctx.moveTo(0, -r * cos(a)); ctx.lineTo(0, r * cos(a)); ctx.stroke(); ctx.fillStyle = "#222"; ctx.beginPath(); ctx.arc(2, 0, 7, 0, TAU); ctx.fill(); ctx.restore(); }
// ---------------- ships ----------------
export function ship(ctx, o) {
  const { x, y, s = 1, dir = 1, t = 0, kind = "battleship", seed = 1, list = 0, sink = 0, fire = 0, fac = "us", crew = 0, alpha = 1 } = o;
  const bob = sin(t * 1.4 + seed) * 4, roll = sin(t * 1.1 + seed) * 0.015;
  ctx.save(); ctx.translate(x, y + bob + sink * 120); ctx.scale(dir * s, s); ctx.rotate(roll + list); ctx.globalAlpha *= alpha;
  const grey = o.color ?? (fac === "jp" ? "#7c8084" : "#8a9298");
  if (kind === "battleship" || kind === "destroyer" || kind === "cruiser") {
    const L = kind === "destroyer" ? 0.7 : 1;
    ctx.beginPath(); ctx.moveTo(-380 * L, -40); ctx.lineTo(420 * L, -46); ctx.lineTo(380 * L, 10); ctx.lineTo(-350 * L, 10); ctx.closePath(); outline(ctx, grey);
    ctx.fillStyle = "#7a3a2a"; ctx.fillRect(-350 * L, 0, 730 * L, 10);
    ctx.beginPath(); ctx.rect(-120 * L, -110, 200 * L, 70); outline(ctx, grey); ctx.beginPath(); ctx.rect(-60 * L, -170, 90 * L, 62); outline(ctx, grey);
    ctx.beginPath(); ctx.moveTo(-20 * L, -170); ctx.lineTo(-10 * L, -260); ctx.lineTo(0, -170); outline(ctx, "#555", 4);
    ctx.beginPath(); ctx.rect(-170 * L, -150, 34, 44); outline(ctx, "#5a5a5a"); // funnel
    for (const tx of [200, 300, -260]) { ctx.beginPath(); ctx.ellipse(tx * L, -52, 40 * L, 16, 0, PI, TAU); ctx.closePath(); outline(ctx, grey, 4); ctx.beginPath(); ctx.rect(tx * L + (tx > 0 ? 20 : -100) * L, -60, 80 * L, 8); outline(ctx, "#666", 3); }
    ctx.fillStyle = "#222"; for (let i = 0; i < 8; i++) ctx.fillRect(-100 * L + i * 22 * L, -90, 10, 8);
    if (o.flag) drawFlag(ctx, -10 * L, -258, 50, 32, t, o.flag);
    for (let i = 0; i < 3; i++) { const a = ((t * 0.6 + i / 3 + seed) % 1); ctx.fillStyle = `rgba(80,80,80,${0.35 * (1 - a)})`; ctx.beginPath(); ctx.arc(-153 * L - a * 60, -160 - a * 90, 14 + a * 26, 0, TAU); ctx.fill(); }
  } else if (kind === "carrier") {
    ctx.beginPath(); ctx.moveTo(-430, -36); ctx.lineTo(440, -40); ctx.lineTo(400, 12); ctx.lineTo(-400, 12); ctx.closePath(); outline(ctx, grey);
    ctx.beginPath(); ctx.rect(-470, -58, 950, 22); outline(ctx, "#8a7a62");
    ctx.strokeStyle = "rgba(255,255,255,0.6)"; ctx.lineWidth = 3; ctx.setLineDash([24, 18]); ctx.beginPath(); ctx.moveTo(-440, -47); ctx.lineTo(450, -47); ctx.stroke(); ctx.setLineDash([]);
    ctx.beginPath(); ctx.rect(150, -150, 70, 92); outline(ctx, grey); ctx.beginPath(); ctx.rect(175, -190, 26, 42); outline(ctx, "#5a5a5a");
    if (o.planes) for (let i = 0; i < o.planes; i++) plane(ctx, { x: -360 + i * 110, y: -76, s: 0.32, t, fac, pilot: false });
    if (fac === "jp") { ctx.fillStyle = "#c8201e"; ctx.beginPath(); ctx.arc(-300, -47, 14, 0, TAU); ctx.fill(); }
  } else if (kind === "boat" || kind === "fishing" || kind === "yacht" || kind === "ferry") {
    const col = o.color ?? ["#c84a3a", "#3a6ac8", "#e8e0c8", "#4a8a5a", "#d9a040"][seed % 5];
    const L = kind === "ferry" ? 1.5 : 1;
    ctx.beginPath(); ctx.moveTo(-120 * L, -36); ctx.lineTo(140 * L, -44); ctx.quadraticCurveTo(120 * L, 10, 70 * L, 12); ctx.lineTo(-100 * L, 12); ctx.closePath(); outline(ctx, col);
    ctx.fillStyle = "#f2efe6"; ctx.fillRect(-110 * L, -36, 240 * L, 6);
    ctx.beginPath(); ctx.rect(-50 * L, -96, 90 * L, 58); outline(ctx, "#f2efe6"); ctx.fillStyle = "#8fc0d8"; ctx.fillRect(-36 * L, -84, 22, 18); ctx.fillRect(0, -84, 22, 18);
    if (kind === "fishing" || kind === "yacht") { ctx.strokeStyle = "#3a2a1a"; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(70, -40); ctx.lineTo(70, -170); ctx.stroke(); }
    if (kind === "yacht") { ctx.beginPath(); ctx.moveTo(74, -165); ctx.lineTo(74, -50); ctx.lineTo(150, -50); ctx.closePath(); outline(ctx, "#f4f0e0", 4); }
    if (o.flag) drawFlag(ctx, 70, -170, 44, 28, t, o.flag);
  } else if (kind === "lcvp") {
    ctx.beginPath(); ctx.moveTo(-140, -50); ctx.lineTo(120, -54); ctx.lineTo(126, 10); ctx.lineTo(-120, 10); ctx.closePath(); outline(ctx, "#6b7258");
    ctx.beginPath(); ctx.rect(108, -64, 26, 72); outline(ctx, "#5f664c");
  } else if (kind === "uboat") {
    ctx.beginPath(); ctx.ellipse(0, -6, 330, 26, 0, 0, TAU); outline(ctx, "#6a7076"); ctx.beginPath(); ctx.moveTo(-50, -26); ctx.lineTo(-40, -86); ctx.lineTo(40, -86); ctx.lineTo(60, -26); outline(ctx, "#6a7076");
    ctx.strokeStyle = "#333"; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(10, -86); ctx.lineTo(10, -130); ctx.lineTo(24, -130); ctx.stroke();
  } else if (kind === "liner") {
    ctx.beginPath(); ctx.moveTo(-400, -60); ctx.lineTo(420, -66); ctx.lineTo(380, 12); ctx.lineTo(-360, 12); ctx.closePath(); outline(ctx, "#2a2a2a");
    ctx.beginPath(); ctx.rect(-320, -120, 600, 60); outline(ctx, "#f2efe6");
    for (const fx of [-160, -40, 80]) { ctx.beginPath(); ctx.rect(fx, -190, 50, 72); outline(ctx, "#d48a3a"); }
  }
  if (crew) for (let i = 0; i < crew; i++) stick(ctx, { x: -60 + i * 40, y: kind === "carrier" ? -58 : -40, s: 0.42, pose: o.crewPose ?? "idle", t: t + i, kit: o.crewKit ?? "sailor_us", seed: seed + i });
  if (fire) { for (let i = 0; i < 3; i++) flame(ctx, -60 + i * 60, -60, t + i, 1.2 * fire); smokeCol(ctx, 0, -80, t, 1.4 * fire, seed); }
  ctx.restore();
}
// water band drawn over hulls (waves)
export function water(ctx, y, t, { color = "rgba(40,90,130,0.85)", amp = 8, len = 140, speed = 40, h = 400, foam = true, x0 = -40, x1 = W + 40 } = {}) {
  ctx.save(); ctx.beginPath(); ctx.moveTo(x0, y + h);
  for (let x = x0; x <= x1; x += 12) ctx.lineTo(x, y + sin((x + t * speed) / len * TAU) * amp + sin((x * 0.37 - t * speed * 0.6) / len * TAU) * amp * 0.5);
  ctx.lineTo(x1, y + h); ctx.closePath(); ctx.fillStyle = color; ctx.fill();
  if (foam) { ctx.strokeStyle = "rgba(255,255,255,0.55)"; ctx.lineWidth = 3; ctx.beginPath(); for (let x = x0; x <= x1; x += 12) ctx.lineTo(x, y + sin((x + t * speed) / len * TAU) * amp + sin((x * 0.37 - t * speed * 0.6) / len * TAU) * amp * 0.5); ctx.stroke(); }
  ctx.restore();
}
// ---------------- effects ----------------
export function explosion(ctx, x, y, age, size = 1, seed = 1) {
  if (age < 0 || age > 3) return; const s = size;
  ctx.save();
  if (age < 0.12) glow(ctx, x, y - 40 * s, 300 * s, "rgba(255,240,200,0.95)", 1 - age / 0.12);
  // smoke puffs
  for (let i = 0; i < 9; i++) { const r = rnd(seed, i), a = clamp((age - 0.05) / 2.6), px = x + (r - 0.5) * 140 * s * (0.4 + a), py = y - 30 * s - a * (120 + 140 * r) * s;
    ctx.fillStyle = `rgba(${70 + 30 * r},${68 + 25 * r},${65 + 20 * r},${0.75 * (1 - a)})`; ctx.beginPath(); ctx.arc(px, py, (30 + 50 * a + 20 * r) * s, 0, TAU); ctx.fill(); }
  // fireball
  if (age < 0.6) { const a = age / 0.6; for (let i = 0; i < 7; i++) { const r = rnd(seed + 3, i), ang = r * TAU, d = 50 * s * ss(a * 1.6) * (0.5 + r);
      ctx.fillStyle = i % 2 ? `rgba(255,${160 + 60 * r},60,${1 - a})` : `rgba(255,230,120,${1 - a})`; ctx.beginPath(); ctx.arc(x + cos(ang) * d, y - 40 * s + sin(ang) * d * 0.7, (34 + 40 * a) * s * (0.7 + r * 0.5), 0, TAU); ctx.fill(); } }
  // debris
  for (let i = 0; i < 10; i++) { const r = rnd(seed + 7, i), vx = (r - 0.5) * 600 * s, vy = -(300 + 400 * rnd(seed + 9, i)) * s, a = min(age, 1.4);
    const px = x + vx * a, py = y - 20 * s + vy * a + 900 * s * a * a; if (py > y + 10) continue; ctx.fillStyle = "#2a2622"; ctx.fillRect(px, py, 7 * s, 7 * s); }
  ctx.restore();
}
export function smokeCol(ctx, x, y, t, s = 1, seed = 1, dark = 0.6) {
  for (let i = 0; i < 10; i++) { const a = ((t * 0.18 + i / 10 + rnd(seed, i) * 0.05) % 1); ctx.fillStyle = `rgba(30,30,32,${dark * (1 - a) * min(1, a * 6)})`;
    ctx.beginPath(); ctx.arc(x + sin(a * 4 + seed) * 30 * s + a * 80 * s, y - a * 420 * s, (26 + a * 70) * s, 0, TAU); ctx.fill(); }
}
export function flame(ctx, x, y, t, s = 1) {
  for (let i = 0; i < 5; i++) { const f = 0.7 + 0.3 * sin(t * 13 + i * 2.1); ctx.fillStyle = i % 2 ? "rgba(255,120,30,0.85)" : "rgba(255,210,80,0.9)";
    ctx.beginPath(); ctx.ellipse(x + (i - 2) * 9 * s, y - 20 * s * f, 12 * s, 30 * s * f, 0, 0, TAU); ctx.fill(); }
}
export function tracers(ctx, t, { x0, y0, x1, y1, n = 6, rate = 3, color = "rgba(255,230,140,0.9)", seed = 1 }) {
  ctx.save(); ctx.strokeStyle = color; ctx.lineWidth = 4; ctx.lineCap = "round";
  for (let i = 0; i < n; i++) { const a = ((t * rate + i / n + rnd(seed, i) * 0.3) % 1); const jx = (rnd(seed + 2, i) - 0.5) * 120, jy = (rnd(seed + 4, i) - 0.5) * 80;
    const px = lerp(x0, x1 + jx, a), py = lerp(y0, y1 + jy, a), qx = lerp(x0, x1 + jx, max(0, a - 0.07)), qy = lerp(y0, y1 + jy, max(0, a - 0.07));
    ctx.beginPath(); ctx.moveTo(qx, qy); ctx.lineTo(px, py); ctx.stroke(); }
  ctx.restore();
}
export function flak(ctx, t, { x0 = 0, x1 = W, y0 = 80, y1 = 450, n = 8, seed = 5 } = {}) {
  for (let i = 0; i < n; i++) { const per = 1.6 + rnd(seed, i), a = ((t + rnd(seed + 1, i) * per) % per) / per; const px = lerp(x0, x1, rnd(seed + 2, i + Math.floor((t + rnd(seed + 1, i) * per) / per) * 7)), py = lerp(y0, y1, rnd(seed + 3, i + Math.floor((t + rnd(seed + 1, i) * per) / per) * 5));
    if (a < 0.08) glow(ctx, px, py, 60, "rgba(255,220,140,0.9)", 1 - a / 0.08); ctx.fillStyle = `rgba(40,40,40,${0.7 * (1 - a)})`; ctx.beginPath(); ctx.arc(px, py, 14 + 30 * a, 0, TAU); ctx.fill(); }
}
export function bomb(ctx, x, y, s = 1, rot = 0) { ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s); ctx.beginPath(); ctx.ellipse(0, 0, 9, 22, 0, 0, TAU); outline(ctx, "#3a3a3a", 3);
  ctx.beginPath(); ctx.moveTo(-9, -18); ctx.lineTo(-12, -32); ctx.lineTo(12, -32); ctx.lineTo(9, -18); outline(ctx, "#3a3a3a", 3); ctx.restore(); }
export function searchlights(ctx, t, xs, { y = H, len = 1300, a = 0.16 } = {}) {
  ctx.save(); ctx.globalCompositeOperation = "lighter";
  xs.forEach((x, i) => { const ang = -PI / 2 + 0.5 * sin(t * 0.35 + i * 1.9); ctx.save(); ctx.translate(x, y); ctx.rotate(ang); const g = ctx.createLinearGradient(0, 0, len, 0); g.addColorStop(0, `rgba(230,240,255,${a * 2})`); g.addColorStop(1, "rgba(230,240,255,0)");
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(0, -8); ctx.lineTo(len, -90); ctx.lineTo(len, 90); ctx.lineTo(0, 8); ctx.closePath(); ctx.fill(); ctx.restore(); });
  ctx.restore();
}
export function snow(ctx, t, { n = 160, a = 0.85, wind = 60, seed = 2, speed = 120 } = {}) {
  ctx.save(); ctx.fillStyle = `rgba(255,255,255,${a})`;
  for (let i = 0; i < n; i++) { const r = rnd(seed, i), z = 0.4 + rnd(seed + 1, i), y = ((r * H + t * speed * z) % (H + 20)) - 10, x = ((rnd(seed + 2, i) * W + t * wind * z + sin(t + i) * 20) % (W + 20) + W + 20) % (W + 20) - 10;
    ctx.beginPath(); ctx.arc(x, y, 2.2 * z + 1, 0, TAU); ctx.fill(); }
  ctx.restore();
}
export function rain(ctx, t, { n = 200, a = 0.35, seed = 9 } = {}) {
  ctx.save(); ctx.strokeStyle = `rgba(200,210,230,${a})`; ctx.lineWidth = 2;
  for (let i = 0; i < n; i++) { const x = (rnd(seed, i) * W + t * 140) % W, y = (rnd(seed + 1, i) * H + t * 1400) % H; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 8, y - 30); ctx.stroke(); }
  ctx.restore();
}
export function particles(ctx, t, { n = 40, color = "rgba(255,255,255,0.6)", vy = -30, vx = 0, size = 3, seed = 5, y0 = 0, y1 = H, a = 1 } = {}) {
  ctx.save(); ctx.globalAlpha *= a; ctx.fillStyle = color;
  for (let i = 0; i < n; i++) { const x = ((rnd(seed, i) * W + vx * t) % W + W) % W, y = y0 + (((rnd(seed + 1, i) * (y1 - y0) + vy * t) % (y1 - y0)) + (y1 - y0)) % (y1 - y0); ctx.beginPath(); ctx.arc(x, y, size * (0.6 + rnd(seed + 2, i)), 0, TAU); ctx.fill(); }
  ctx.restore();
}
export function confetti(ctx, t, { n = 120, seed = 4 } = {}) {
  const cols = ["#e84a4a", "#ffd84d", "#4ab0e8", "#6ad06a", "#f2f2f2", "#e88ad0"];
  for (let i = 0; i < n; i++) { const x = (rnd(seed, i) * W + sin(t * 2 + i) * 40), y = ((rnd(seed + 1, i) * H + t * (120 + 80 * rnd(seed + 3, i))) % (H + 40)) - 20;
    ctx.save(); ctx.translate(x, y); ctx.rotate(t * 4 + i); ctx.fillStyle = cols[i % cols.length]; ctx.fillRect(-6, -3, 12, 6 * abs(cos(t * 5 + i))); ctx.restore(); }
}
export function moneyRain(ctx, t, { n = 40, seed = 6, y0 = -100 } = {}) {
  for (let i = 0; i < n; i++) { const x = rnd(seed, i) * W + sin(t * 1.5 + i) * 60, y = ((rnd(seed + 1, i) * (H + 200) + t * (90 + 60 * rnd(seed + 2, i))) % (H + 200)) + y0;
    ctx.save(); ctx.translate(x, y); ctx.rotate(sin(t * 2 + i) * 0.8); ctx.fillStyle = "#b9c99a"; ctx.strokeStyle = "#3a4a2a"; ctx.lineWidth = 2; ctx.fillRect(-26, -12, 52, 24); ctx.strokeRect(-26, -12, 52, 24);
    ctx.beginPath(); ctx.arc(0, 0, 7, 0, TAU); ctx.stroke(); ctx.restore(); }
}
export function radarRings(ctx, x, y, t, { n = 4, r = 600, color = "120,255,160" } = {}) {
  ctx.save(); ctx.lineWidth = 4; for (let i = 0; i < n; i++) { const a = ((t * 0.5 + i / n) % 1); ctx.strokeStyle = `rgba(${color},${0.7 * (1 - a)})`; ctx.beginPath(); ctx.arc(x, y, a * r, PI * 1.05, PI * 1.95); ctx.stroke(); } ctx.restore();
}
export function splash(ctx, x, y, age, s = 1) { if (age < 0 || age > 1.2) return; const a = age / 1.2;
  ctx.fillStyle = `rgba(230,240,255,${0.9 * (1 - a)})`; for (let i = 0; i < 9; i++) { const ang = -PI / 2 + (i - 4) * 0.18, d = 220 * s * ss(a * 1.5); ctx.beginPath(); ctx.arc(x + cos(ang) * d * 0.5, y + sin(ang) * d - 0 + 300 * s * a * a, 16 * s * (1 - a * 0.5), 0, TAU); ctx.fill(); } }
export function shock(ctx, x, y, age, r = 900) { if (age < 0 || age > 1.5) return; const a = age / 1.5; ctx.save(); ctx.strokeStyle = `rgba(255,255,255,${0.8 * (1 - a)})`; ctx.lineWidth = 30 * (1 - a) + 2; ctx.beginPath(); ctx.ellipse(x, y, r * ss(a), r * ss(a) * 0.35, 0, 0, TAU); ctx.stroke(); ctx.restore(); }
// animated arrow along polyline
export function arrow(ctx, pts, u, { color = "#d42a2a", w = 30, head = 64, outline: ol = true } = {}) {
  if (u <= 0) return; let L = 0; const seg = []; for (let i = 1; i < pts.length; i++) { const l = hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); seg.push(l); L += l; }
  const target = L * clamp(u); let acc = 0; const path = [pts[0]]; let end = pts[0], ang = 0;
  for (let i = 1; i < pts.length; i++) { const l = seg[i - 1]; if (acc + l >= target) { const k = (target - acc) / l; end = [lerp(pts[i - 1][0], pts[i][0], k), lerp(pts[i - 1][1], pts[i][1], k)]; path.push(end); ang = atan2(pts[i][1] - pts[i - 1][1], pts[i][0] - pts[i - 1][0]); break; } path.push(pts[i]); acc += l; end = pts[i]; ang = atan2(pts[i][1] - pts[i - 1][1], pts[i][0] - pts[i - 1][0]); }
  ctx.save(); ctx.lineCap = "round"; ctx.lineJoin = "round";
  const stroke = (c, lw) => { ctx.strokeStyle = c; ctx.lineWidth = lw; ctx.beginPath(); path.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.stroke(); };
  if (ol) stroke("#111", w + 8); stroke(color, w);
  ctx.translate(end[0], end[1]); ctx.rotate(ang); ctx.beginPath(); ctx.moveTo(head * 0.8, 0); ctx.lineTo(-head * 0.4, -head * 0.6); ctx.lineTo(-head * 0.4, head * 0.6); ctx.closePath(); ctx.fillStyle = color; ctx.fill(); ctx.lineWidth = 4; ctx.strokeStyle = "#111"; ctx.stroke();
  ctx.restore();
}
// ---------------- map ----------------
const LAND = JSON.parse(fs.readFileSync("/home/claude/ww2/land.json", "utf8"));
export function mapView(view) { // view: {lon0, lon1, lat0, lat1} -> projection (mercator-ish)
  const my = (lat) => Math.log(Math.tan(PI / 4 + lat * PI / 360));
  const y0 = my(view.lat1), y1 = my(view.lat0);
  return (lon, lat) => { let L = lon; if (view.wrap && L < 0) L += 360; return [(L - view.lon0) / (view.lon1 - view.lon0) * W, (my(lat) - y0) / (y1 - y0) * H]; };
}
export function drawMap(ctx, view, { sea = "#20384f", land = "#d9c9a0", edge = "#6b5a3a", grid = true, t = 0 } = {}) {
  const pr = mapView(view); ctx.save(); ctx.fillStyle = sea; ctx.fillRect(0, 0, W, H);
  if (grid) { ctx.strokeStyle = "rgba(255,255,255,0.06)"; ctx.lineWidth = 1; for (let lo = -180; lo <= 360; lo += 10) { const a = pr(lo, 0)[0]; ctx.beginPath(); ctx.moveTo(a, 0); ctx.lineTo(a, H); ctx.stroke(); } for (let la = -80; la <= 80; la += 10) { const b = pr(view.lon0, la)[1]; ctx.beginPath(); ctx.moveTo(0, b); ctx.lineTo(W, b); ctx.stroke(); } }
  const draw = (shift) => { for (const poly of LAND) { ctx.beginPath(); poly.forEach(([lo, la], i) => { const p = pr(lo + shift, la); i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]); }); ctx.closePath(); ctx.fillStyle = land; ctx.fill(); ctx.strokeStyle = edge; ctx.lineWidth = 3; ctx.stroke(); } };
  draw(0); if (view.wrap) draw(360);
  ctx.restore(); return pr;
}
export function pin(ctx, x, y, label, t, t0, { color = "#d42a2a", size = 46 } = {}) {
  if (t < t0) return; const k = clamp((t - t0) / 0.3); ctx.save(); ctx.globalAlpha *= k;
  ctx.fillStyle = color; ctx.strokeStyle = "#111"; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, 10 + 4 * sin(t * 5), 0, TAU); ctx.fill(); ctx.stroke();
  if (label) { ctx.font = `${size}px Archivo`; ctx.lineWidth = 8; ctx.strokeStyle = "#111"; ctx.textAlign = "left"; ctx.strokeText(label, x + 18, y + 10); ctx.fillStyle = "#fff"; ctx.fillText(label, x + 18, y + 10); }
  ctx.restore();
}
// ---------------- furniture & props ----------------
export function table(ctx, x, y, w = 360, h = 110, col = "#6b4a2a", cloth) { ctx.save(); ctx.translate(x, y); ctx.beginPath(); ctx.rect(-w / 2, -h, w, 18); outline(ctx, cloth ?? col, 4);
  for (const lx of [-w / 2 + 20, w / 2 - 30]) { ctx.beginPath(); ctx.rect(lx, -h + 18, 12, h - 18); outline(ctx, col, 4); } ctx.restore(); }
export function chair(ctx, x, y, s = 1, dir = 1) { ctx.save(); ctx.translate(x, y); ctx.scale(dir * s, s); ctx.strokeStyle = "#3a2a1a"; ctx.lineWidth = 8; ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(-34, -60); ctx.lineTo(30, -60); ctx.moveTo(-30, -60); ctx.lineTo(-30, 0); ctx.moveTo(26, -60); ctx.lineTo(26, 0); ctx.moveTo(-34, -60); ctx.lineTo(-40, -140); ctx.stroke(); ctx.restore(); }
export function radioSet(ctx, x, y, s = 1, t = 0, on = true) { ctx.save(); ctx.translate(x, y); ctx.scale(s, s); rrect(ctx, -70, -110, 140, 110, 22); outline(ctx, "#7a4a2a");
  ctx.beginPath(); ctx.arc(-24, -56, 30, 0, TAU); outline(ctx, "#c9a66b", 4); ctx.strokeStyle = "#5a3a1a"; ctx.lineWidth = 2; for (let i = -3; i <= 3; i++) { ctx.beginPath(); ctx.moveTo(-50, -56 + i * 7); ctx.lineTo(2, -56 + i * 7); ctx.stroke(); }
  ctx.beginPath(); ctx.arc(36, -76, 12, 0, TAU); outline(ctx, "#222", 3); ctx.beginPath(); ctx.arc(36, -36, 12, 0, TAU); outline(ctx, "#222", 3);
  if (on) { for (let i = 0; i < 3; i++) { const a = ((t * 0.8 + i / 3) % 1); ctx.strokeStyle = `rgba(255,255,255,${0.8 * (1 - a)})`; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(0, -60, 90 + a * 120, -PI * 0.35, PI * 0.35); ctx.stroke(); } }
  ctx.restore(); }
export function mic(ctx, x, y, s = 1) { ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.strokeStyle = "#222"; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -150); ctx.stroke(); rrect(ctx, -14, -196, 28, 50, 12); outline(ctx, "#8a8a8a", 4); ctx.fillStyle = "#222"; ctx.fillRect(-30, -4, 60, 8); ctx.restore(); }
export function sandbags(ctx, x, y, n = 6, rows = 2, s = 1) { ctx.save(); ctx.translate(x, y); ctx.scale(s, s); for (let r = 0; r < rows; r++) for (let i = 0; i < n - r; i++) { ctx.beginPath(); ctx.ellipse(i * 62 + r * 31, -22 - r * 36, 34, 20, 0, 0, TAU); outline(ctx, "#b9a77a", 4); } ctx.restore(); }
export function wire(ctx, x0, x1, y, t = 0) { ctx.save(); ctx.strokeStyle = "#333"; ctx.lineWidth = 3; for (let x = x0; x < x1; x += 40) { ctx.beginPath(); ctx.ellipse(x, y - 24, 22, 24, 0, 0, TAU); ctx.stroke(); } ctx.lineWidth = 6; ctx.strokeStyle = "#4a3a2a"; for (let x = x0; x < x1; x += 160) { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y - 60); ctx.stroke(); } ctx.restore(); }
export function hedgehog(ctx, x, y, s = 1) { ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.strokeStyle = "#2a2622"; ctx.lineWidth = 10; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(-40, 0); ctx.lineTo(40, -70); ctx.moveTo(40, 0); ctx.lineTo(-40, -70); ctx.moveTo(0, 5); ctx.lineTo(0, -80); ctx.stroke(); ctx.restore(); }
export function wheelbarrow(ctx, x, y, s = 1, dir = 1, t = 0, money = true) { ctx.save(); ctx.translate(x, y); ctx.scale(dir * s, s);
  ctx.beginPath(); ctx.arc(70, -26, 26, 0, TAU); outline(ctx, "#5a4a3a", 4); ctx.beginPath(); ctx.moveTo(-70, -70); ctx.lineTo(90, -70); ctx.lineTo(70, -30); ctx.lineTo(-40, -30); ctx.closePath(); outline(ctx, "#8a5a3a");
  ctx.strokeStyle = "#3a2a1a"; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(-60, -60); ctx.lineTo(-120, -40); ctx.moveTo(-30, -30); ctx.lineTo(-40, 0); ctx.stroke();
  if (money) for (let i = 0; i < 9; i++) { ctx.save(); ctx.translate(-50 + (i % 5) * 30, -82 - Math.floor(i / 5) * 16); ctx.rotate((i % 3 - 1) * 0.2); ctx.fillStyle = "#b9c99a"; ctx.strokeStyle = "#3a4a2a"; ctx.lineWidth = 2; ctx.fillRect(-20, -9, 40, 18); ctx.strokeRect(-20, -9, 40, 18); ctx.restore(); }
  ctx.restore(); }
export function enigma(ctx, x, y, s = 1, t = 0, { lit = -1, rotors = true } = {}) { ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  rrect(ctx, -170, -150, 340, 150, 14); outline(ctx, "#5a3a22"); rrect(ctx, -150, -136, 300, 126, 8); outline(ctx, "#1e1e1e", 3);
  // lampboard
  for (let r = 0; r < 3; r++) for (let i = 0; i < 9 - (r === 2 ? 1 : 0); i++) { const idx = r * 9 + i; ctx.beginPath(); ctx.arc(-128 + i * 32 + r * 8, -116 + r * 26, 11, 0, TAU); outline(ctx, idx === lit ? "#ffe680" : "#3a3a3a", 2); if (idx === lit) glow(ctx, -128 + i * 32 + r * 8, -116 + r * 26, 40, "rgba(255,230,120,0.9)", 0.8); }
  for (let r = 0; r < 2; r++) for (let i = 0; i < 9; i++) { ctx.beginPath(); ctx.arc(-128 + i * 32 + r * 8, -40 + r * 22, 10, 0, TAU); outline(ctx, "#eeeeee", 2); }
  if (rotors) for (let i = 0; i < 3; i++) { ctx.save(); ctx.translate(-36 + i * 36, -160); ctx.beginPath(); ctx.rect(-12, -20, 24, 26); outline(ctx, "#b9b9b9", 3); ctx.fillStyle = "#222"; const k = Math.floor(t * (i === 2 ? 4 : i === 1 ? 1 : 0.25)); ctx.font = "16px Archivo"; ctx.textAlign = "center"; ctx.fillText(String.fromCharCode(65 + (k % 26)), 0, -1); ctx.restore(); }
  ctx.restore(); }
export function bombe(ctx, x, y, s = 1, t = 0) { ctx.save(); ctx.translate(x, y); ctx.scale(s, s); rrect(ctx, -260, -420, 520, 420, 10); outline(ctx, "#3a3a3e");
  const cols = ["#d42a2a", "#e8e8e8", "#2a2a2a"]; for (let r = 0; r < 3; r++) for (let c = 0; c < 6; c++) for (let k = 0; k < 3; k++) { const cx = -200 + c * 80, cy = -360 + r * 120 + k * 32;
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(t * (2 + c * 0.7 + r) * (k % 2 ? -1 : 1)); ctx.beginPath(); ctx.arc(0, 0, 15, 0, TAU); outline(ctx, cols[k], 3); ctx.strokeStyle = "#111"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(13, 0); ctx.stroke(); ctx.restore(); }
  ctx.restore(); }
export function paperStack(ctx, x, y, n = 6, s = 1) { ctx.save(); ctx.translate(x, y); ctx.scale(s, s); for (let i = 0; i < n; i++) { ctx.save(); ctx.translate(0, -i * 6); ctx.rotate((rnd(3, i) - 0.5) * 0.15); ctx.fillStyle = "#f2eee0"; ctx.strokeStyle = "#333"; ctx.lineWidth = 2; ctx.fillRect(-50, -6, 100, 6); ctx.strokeRect(-50, -6, 100, 6); ctx.restore(); } ctx.restore(); }
export function poster(ctx, x, y, w, h, lines, { bg: b = "#efe6cc", color = "#222", size = 40, rot = 0 } = {}) { ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.beginPath(); ctx.rect(-w / 2, -h / 2, w, h); outline(ctx, b, 4);
  ctx.fillStyle = color; ctx.textAlign = "center"; ctx.textBaseline = "middle"; lines.forEach((l, i) => { ctx.font = `${i === 0 ? size : size * 0.6}px Archivo`; ctx.fillText(l, 0, -h / 2 + h * (i + 1) / (lines.length + 1)); }); ctx.restore(); }
export function truck(ctx, o) { const { x, y, s = 1, dir = 1, t = 0, speed = 0, col = "#5d6342", seed = 1 } = o; ctx.save(); ctx.translate(x, y + (speed ? sin(t * 18 + seed) * 1.5 : 0)); ctx.scale(dir * s, s);
  ctx.beginPath(); ctx.rect(-200, -150, 250, 110); outline(ctx, "#7a7a5a"); ctx.beginPath(); ctx.moveTo(60, -40); ctx.lineTo(60, -130); ctx.lineTo(130, -130); ctx.lineTo(160, -90); ctx.lineTo(190, -86); ctx.lineTo(190, -40); ctx.closePath(); outline(ctx, col);
  ctx.fillStyle = "#9cc3d8"; ctx.fillRect(78, -120, 40, 30); for (const wx of [-140, -60, 130]) { ctx.save(); ctx.translate(wx, -26); ctx.rotate(-t * speed / 26); ctx.beginPath(); ctx.arc(0, 0, 28, 0, TAU); outline(ctx, "#2a2a2a", 4); ctx.fillStyle = "#777"; ctx.fillRect(-4, -14, 8, 28); ctx.restore(); } ctx.restore(); }
export function rubble(ctx, x, y, w = 400, seed = 1) { ctx.save(); for (let i = 0; i < 26; i++) { const r = rnd(seed, i), px = x + (r - 0.5) * w, sz = 12 + 30 * rnd(seed + 1, i), py = y - sz * 0.4 * rnd(seed + 2, i) - (1 - abs(r - 0.5) * 2) * 40;
  ctx.save(); ctx.translate(px, py); ctx.rotate(r * 3); ctx.fillStyle = ["#6a625a", "#8a7a6a", "#4a4440", "#9a8a7a"][i % 4]; ctx.strokeStyle = "#1a1a1a"; ctx.lineWidth = 3; ctx.beginPath(); ctx.rect(-sz / 2, -sz / 3, sz, sz * 0.66); ctx.fill(); ctx.stroke(); ctx.restore(); } ctx.restore(); }
export function dummy(ctx, x, y, t, s = 1) { // paradummy under parachute
  ctx.save(); ctx.translate(x + sin(t * 1.3) * 10, y); ctx.scale(s, s); ctx.beginPath(); ctx.arc(0, -160, 90, PI, TAU); ctx.closePath(); outline(ctx, "#e8e4d8", 4);
  ctx.strokeStyle = "#555"; ctx.lineWidth = 2; for (const lx of [-88, -40, 40, 88]) { ctx.beginPath(); ctx.moveTo(lx, -160); ctx.lineTo(0, -40); ctx.stroke(); }
  ctx.beginPath(); ctx.moveTo(-14, -40); ctx.lineTo(14, -40); ctx.lineTo(10, 30); ctx.lineTo(-10, 30); ctx.closePath(); outline(ctx, "#a08a6a", 3); ctx.beginPath(); ctx.arc(0, -52, 14, 0, TAU); outline(ctx, "#c9b48a", 3);
  ctx.restore(); }
export function parachute(ctx, x, y, t, s = 1, kit = "us") { ctx.save(); ctx.translate(x + sin(t * 1.2) * 12, y); ctx.scale(s, s); ctx.beginPath(); ctx.arc(0, -230, 110, PI, TAU); ctx.closePath(); outline(ctx, "#d8d2bc", 4);
  ctx.strokeStyle = "#555"; ctx.lineWidth = 2; for (const lx of [-108, -50, 50, 108]) { ctx.beginPath(); ctx.moveTo(lx, -230); ctx.lineTo(0, -110); ctx.stroke(); } ctx.restore();
  stick(ctx, { x: x + sin(t * 1.2) * 12 * s, y: y + 150 * s, s: s * 0.9, pose: "handsup", t, kit, seed: 3, expr: "scared" }); }
