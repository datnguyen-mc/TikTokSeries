"""Mix narration + SFX + music bed for a chapter. usage: python3 mixw.py NN film|short out.wav"""
import json, sys, numpy as np, soundfile as sf
sys.path.insert(0, '/home/claude/ww2'); sys.path.insert(0, '/home/claude/k1000'); sys.path.insert(0, '/home/claude/vn45')
import sfxw
from music import music, SR
from scipy.ndimage import uniform_filter1d, maximum_filter1d
ch, mode, out = sys.argv[1], sys.argv[2], sys.argv[3]
D = f'/home/claude/ww2/ch{ch}'
meta = json.load(open('/home/claude/ww2/chapters.json')); M = next(m for m in meta if m['no'] == ch)
MOOD = {'00': 'tense', '01': 'ancient', '02': 'tense', '03': 'tense', '04': 'science', '05': 'tense', '06': 'tense', '07': 'science', '08': 'tense', '09': 'tech', '10': 'tense', '11': 'transition', '12': 'gentle', '13': 'hopeful'}[ch]
ev = json.load(open(f'{D}/events_{mode}.json')); N = int(ev['duration'] * SR)
v, _ = sf.read(f'{D}/narration.wav', dtype='float32')
vv = np.zeros(N, np.float32)
if mode == 'short': vv[:min(N, len(v))] = v[:N]
else:
    for s in ev['segs']:
        a, b = int(s['a'] * SR) if s['a'] > 0.01 else 0, int(s['b'] * SR); piece = v[a:b]; p = int(s['fStart'] * SR)
        n = min(len(piece), N - p); vv[p:p + n] = piece[:n]
L = np.zeros(N, np.float32); R = L.copy()
def place(x, t, g, pan=0.0):
    p = int(t * SR)
    if p >= N or p < 0: return
    n = min(len(x), N - p); L[p:p + n] += x[:n] * g * (1 - max(0, pan)); R[p:p + n] += x[:n] * g * (1 + min(0, pan))
bed = music(MOOD, ev['duration'] + 1)[:N]
# low war pulse for tense chapters
if MOOD == 'tense':
    for bt in np.arange(2.0, ev['duration'] - 1, 1.5):
        p = int(bt * SR); n = int(0.4 * SR); tt = np.arange(n) / SR; k = np.sin(2 * np.pi * (55 + 35 * np.exp(-tt * 25)) * tt) * np.exp(-tt * 7) * 0.3
        bed[p:p + n] += k[:max(0, len(bed) - p)]
f = int(1.2 * SR); bed[:f] *= np.linspace(0, 1, f); bed[-f:] *= np.linspace(1, 0, f)
place(bed, 0, 0.22)
for i, e in enumerate(ev['events']):
    try: x = np.asarray(sfxw.make(e['k'], e.get('dur')), np.float32)
    except Exception as ex: print('sfx', e['k'], ex); continue
    place(x, e['t'], e['gain'] * 0.7, pan=((i * 37) % 7 - 3) / 12)
env = uniform_filter1d(maximum_filter1d(np.abs(vv), int(0.08 * SR)), int(0.3 * SR)); duck = 1 - 0.55 * np.clip(env / 0.07, 0, 1)
L *= duck; R *= duck; L += vv; R += vv; o = np.stack([L, R], 1); pk = np.abs(o).max()
if pk > 0.98: o *= 0.98 / pk
sf.write(out, o, SR, subtype='PCM_16'); print('mix', ch, mode, round(ev['duration'], 2), 'peak', round(float(pk), 2))
