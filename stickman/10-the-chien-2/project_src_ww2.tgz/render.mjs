// WW2 film renderer: one pass per chapter -> film (1920x1080, with title card + pads + subtitles) and short (1080x1920 stacked).
// usage: node render.mjs ch=03 [stills=1.2,5] [stillmode=film|short] [events] [film=0] [short=0]
import fs from "node:fs";
import { spawn } from "node:child_process";
import { createCanvas, W, H, FPS, clamp, lerp, ss, easeOutBack, loadDir, rrect, shade } from "./core.mjs";
import { FOCUS, PENDING } from "./stage.mjs";
import { stick } from "./rig.mjs";
const args = Object.fromEntries(process.argv.slice(2).map(a => a.includes("=") ? a.split("=") : [a, "1"]));
const CH = args.ch; const D = `/home/claude/ww2/ch${CH}`;
const META = JSON.parse(fs.readFileSync("/home/claude/ww2/chapters.json", "utf8")).find(m => m.no === CH);
const TL = JSON.parse(fs.readFileSync(`${D}/timeline.json`, "utf8"));
const { S } = await import(`${D}/scenes.mjs`);
const CARD = args.card !== undefined ? +args.card : (S.__card ?? 3.4);
const TAIL_F = S.__tailFilm ?? 1.4, TAIL_S = 1.0;
// segments
const segs = TL.segments.map((sg, i) => {
  const start = i === 0 ? 0 : sg.start; const next = i + 1 < TL.segments.length ? TL.segments[i + 1].start : TL.duration;
  const dS = next - start + (i + 1 === TL.segments.length ? TAIL_S : 0);
  const sc = S[sg.scene] ?? {}; const pad = sc.pad ?? 0;
  const dF = next - start + pad + (i + 1 === TL.segments.length ? TAIL_F : 0);
  const w = TL.words.filter(x => x.seg === sg.id).map(x => x.s - start);
  return { ...sg, start, next, dS, dF, pad, w, wordsAbs: TL.words.filter(x => x.seg === sg.id) };
});
let acc = CARD; for (const s of segs) { s.fStart = acc; acc += s.dF; } const FILM_DUR = acc;
let acs = 0; for (const s of segs) { s.sStart = acs; acs += s.dS; } const SHORT_DUR = acs;
// caption groups (absolute narration time -> both timelines)
const toFilm = (ta) => { const s = segs.findLast(x => ta >= x.start - 1e-6) ?? segs[0]; return s.fStart + (ta - s.start); };
const toShort = (ta) => { const s = segs.findLast(x => ta >= x.start - 1e-6) ?? segs[0]; return s.sStart + (ta - s.start); };
function groupWords(maxN, maxC) { const g = []; let cur = null;
  TL.words.forEach(w => { const brk = !cur || cur.n >= maxN || /[.,?!:;]$/.test(cur.text) || cur.text.length + w.w.length > maxC || cur.seg !== w.seg;
    if (brk) { cur = { text: w.w, s: w.s, n: 1, seg: w.seg }; g.push(cur); } else { cur.text += " " + w.w; cur.n++; } });
  g.forEach((x, i) => { const nx = g[i + 1]; x.e = nx && nx.seg === x.seg ? nx.s : x.s + Math.min(2.6, 0.32 * x.n + 0.8); }); return g; }
const segOf = (ta) => segs.findLast(x => ta >= x.start - 1e-6) ?? segs[0];
const subs = groupWords(9, 46).map(g => { const sg = segOf(g.s); return { text: g.text.replace(/\.$/, ""), s: toFilm(g.s), e: Math.min(sg.fStart + (g.e - sg.start), sg.fStart + sg.dF - 0.15) }; });
const caps = groupWords(2, 13).map(g => { const sg = segOf(g.s); return { text: g.text, s: toShort(g.s), e: Math.min(sg.sStart + (g.e - sg.start), toShort(g.s) + 1.6, sg.sStart + sg.dS - 0.05) }; });
if (args.events) {
  const evF = [], evS = [];
  for (const s of segs) { const sc = S[s.scene] ?? {}; const list = sc.sfx?.(s.w, s.dF) ?? [];
    for (const [t, k, g, d] of list) { evF.push({ t: +(s.fStart + t).toFixed(3), k, gain: g, dur: d }); if (t < s.dS - 0.05) evS.push({ t: +(s.sStart + t).toFixed(3), k, gain: g, dur: d && Math.min(d, s.dS - t + 0.3) }); } }
  for (const [t, k, g, d] of (S.__cardSfx ?? [[0.05, "boom_far", 0.5], [0.3, "swell", 0.35]])) evF.push({ t, k, gain: g, dur: d });
  fs.writeFileSync(`${D}/events_film.json`, JSON.stringify({ events: evF, duration: FILM_DUR, card: CARD, segs: segs.map(s => ({ a: s.start, b: s.next, fStart: s.fStart, dF: s.dF, pad: s.pad })) }, null, 1));
  fs.writeFileSync(`${D}/events_short.json`, JSON.stringify({ events: evS, duration: SHORT_DUR }, null, 1));
  fs.writeFileSync(`${D}/subs.json`, JSON.stringify(subs, null, 1));
  console.log("events", evF.length, evS.length, "film", FILM_DUR.toFixed(2), "short", SHORT_DUR.toFixed(2)); process.exit(0);
}
await loadDir("/home/claude/ww2/assets/bg");
const cv = createCanvas(W, H), ctx = cv.getContext("2d");
const SW = 1080, SH = 1920; const sv = createCanvas(SW, SH), sx = sv.getContext("2d");
const tiny = createCanvas(64, 36), tx = tiny.getContext("2d");
// ---------- title card ----------
function card(t) {
  ctx.fillStyle = "#0d0e10"; ctx.fillRect(0, 0, W, H);
  const g = ctx.createRadialGradient(W / 2, H * 0.45, 50, W / 2, H * 0.45, 1100); g.addColorStop(0, "rgba(120,30,20,0.55)"); g.addColorStop(1, "rgba(0,0,0,0)"); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  // marching silhouettes along the bottom
  ctx.save(); ctx.globalAlpha = 0.9; for (let i = 0; i < 9; i++) { const x = ((i * 240 + t * 90) % (W + 400)) - 200; stick(ctx, { x, y: 1010, s: 0.62, pose: "march", t: t + i * 0.13, kit: "uk", seed: i, filter: "brightness(0)" }); } ctx.restore();
  const k = easeOutBack(clamp((t - 0.15) / 0.5)), a = clamp((CARD - t) / 0.35);
  ctx.save(); ctx.globalAlpha = a; ctx.textAlign = "center";
  ctx.font = "600 40px NotoSans"; ctx.fillStyle = "#d9b45a"; ctx.fillText(`CHƯƠNG ${+CH}`, W / 2, 380);
  ctx.translate(W / 2, 520); ctx.scale(k, k); let size = 150; ctx.font = `${size}px Archivo`; while (ctx.measureText(META.title).width > 1600) { size -= 6; ctx.font = `${size}px Archivo`; }
  ctx.lineWidth = 16; ctx.strokeStyle = "#000"; ctx.strokeText(META.title, 0, 0); ctx.fillStyle = "#f2efe6"; ctx.fillText(META.title, 0, 0); ctx.restore();
  ctx.save(); ctx.globalAlpha = a * clamp((t - 0.6) / 0.4); ctx.textAlign = "center"; ctx.font = "64px Archivo"; ctx.fillStyle = "#d42a2a"; ctx.fillText(META.years, W / 2, 640);
  ctx.strokeStyle = "#d9b45a"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(W / 2 - 260 * ss((t - 0.4) / 0.8), 700); ctx.lineTo(W / 2 + 260 * ss((t - 0.4) / 0.8), 700); ctx.stroke(); ctx.restore();
  if (t < 0.25) shade(ctx, 1 - t / 0.25);
}
// ---------- subtitles (film) ----------
function subtitle(T) { const g = subs.find(x => T >= x.s && T < x.e); if (!g) return;
  ctx.save(); ctx.font = "600 46px NotoSans"; ctx.textAlign = "center"; ctx.lineJoin = "round"; ctx.lineWidth = 10; ctx.strokeStyle = "rgba(0,0,0,0.92)"; ctx.strokeText(g.text, W / 2, 1030); ctx.fillStyle = "#fff"; ctx.fillText(g.text, W / 2, 1030); ctx.restore(); }
// ---------- short composition ----------
let fxs = W / 2, lastShot = "";
function composeShort(T, fx, shotId) {
  if (shotId !== lastShot || Math.abs(fx - fxs) > 260) fxs = fx; else fxs += (fx - fxs) * 0.12; lastShot = shotId;
  const cx = clamp(fxs, SW / 2, W - SW / 2);
  tx.drawImage(cv, 0, 0, 64, 36); sx.imageSmoothingEnabled = true; sx.imageSmoothingQuality = "high";
  sx.drawImage(tiny, 10, 0, 44, 36, 0, 0, SW, SH); sx.fillStyle = "rgba(8,8,10,0.62)"; sx.fillRect(0, 0, SW, SH);
  sx.drawImage(cv, cx - SW / 2, 0, SW, H, 0, 420, SW, H);
  sx.fillStyle = "rgba(0,0,0,0.5)"; sx.fillRect(0, 418, SW, 3); sx.fillRect(0, 1500, SW, 3);
  // header
  sx.save(); sx.textAlign = "center"; sx.font = "600 34px NotoSans"; sx.fillStyle = "#d9b45a"; sx.fillText(`THẾ CHIẾN II · PHẦN ${+CH}/12`, SW / 2, 190);
  let size = 96; sx.font = `${size}px Archivo`; while (sx.measureText(META.title).width > SW - 90) { size -= 4; sx.font = `${size}px Archivo`; }
  sx.lineJoin = "round"; sx.lineWidth = 12; sx.strokeStyle = "#000"; sx.strokeText(META.title, SW / 2, 300); sx.fillStyle = "#fff"; sx.fillText(META.title, SW / 2, 300);
  sx.font = "44px Archivo"; sx.fillStyle = "#e0463a"; sx.fillText(META.years, SW / 2, 370); sx.restore();
  // captions
  const g = caps.find(x => T >= x.s - 0.03 && T < x.e);
  if (g) { const k = easeOutBack(clamp((T - g.s + 0.03) / 0.14)); sx.save(); sx.translate(SW / 2, 1690); sx.scale(0.8 + 0.2 * k, 0.8 + 0.2 * k);
    let sz = 104; sx.font = `${sz}px Archivo`; while (sx.measureText(g.text).width > SW - 80 && sz > 50) { sz -= 4; sx.font = `${sz}px Archivo`; }
    sx.textAlign = "center"; sx.lineJoin = "round"; sx.lineWidth = 16; sx.strokeStyle = "#000"; sx.strokeText(g.text, 0, 0); sx.fillStyle = "#ffd84d"; sx.fillText(g.text, 0, 0); sx.restore(); }
  sx.fillStyle = "rgba(255,255,255,0.18)"; sx.fillRect(0, SH - 10, SW, 10); sx.fillStyle = "#d42a2a"; sx.fillRect(0, SH - 10, SW * clamp(T / SHORT_DUR), 10);
}
// ---------- frame ----------
function drawScene(seg, lt) {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.filter = "none"; ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H);
  FOCUS.x = W / 2; FOCUS.shot = seg.id;
  const sc = S[seg.scene]; ctx.save(); if (sc) sc.draw(ctx, lt, { id: seg.id, w: seg.w, d: seg.dF, dS: seg.dS }); ctx.restore();
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.filter = "none";
}
async function filmFrame(T) {
  if (T < CARD) { card(T); return null; }
  const seg = segs.findLast(s => T >= s.fStart) ?? segs[0]; const lt = T - seg.fStart; drawScene(seg, lt);
  if (PENDING.size) { await Promise.all([...PENDING]); drawScene(seg, lt); }
  // gentle fade at chapter end
  if (T > FILM_DUR - 0.6) shade(ctx, (T - (FILM_DUR - 0.6)) / 0.6);
  return { seg, lt };
}
if (args.stills) { const mode = args.stillmode ?? "film"; fs.mkdirSync(`${D}/stills`, { recursive: true });
  for (const v of String(args.stills).split(",")) { const T = +v;
    if (mode === "film") { await filmFrame(T); subtitle(T); fs.writeFileSync(`${D}/stills/f_${T.toFixed(1)}.jpg`, cv.toBuffer("image/jpeg", 85)); }
    else { const seg = segs.findLast(s => T >= s.sStart) ?? segs[0]; drawScene(seg, T - seg.sStart); if (PENDING.size) { await Promise.all([...PENDING]); drawScene(seg, T - seg.sStart); } composeShort(T, FOCUS.x, "x" + T); fs.writeFileSync(`${D}/stills/s_${T.toFixed(1)}.jpg`, sv.toBuffer("image/jpeg", 85)); } }
  process.exit(0); }
// ---------- encode ----------
fs.mkdirSync(`${D}/out`, { recursive: true });
const enc = (out, w, h) => { const p = spawn("ffmpeg", ["-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${w}x${h}`, "-r", String(FPS), "-i", "-", "-c:v", "libx264", "-preset", "veryfast", "-crf", "19", "-pix_fmt", "yuv420p", out + ".part.mp4"], { stdio: ["pipe", "inherit", "inherit"] });
  const done = new Promise(r => p.on("close", c => { if (c === 0) fs.renameSync(out + ".part.mp4", out); r(c); })); return { p, done }; };
const doFilm = args.film !== "0", doShort = args.short !== "0";
const EF = doFilm ? enc(`${D}/out/film.mp4`, W, H) : null, ES = doShort ? enc(`${D}/out/short.mp4`, SW, SH) : null;
const write = async (E, buf) => { if (!E.p.stdin.write(buf)) await new Promise(r => E.p.stdin.once("drain", r)); };
const NF = Math.round(FILM_DUR * FPS); let shortFrames = 0; const NS = Math.round(SHORT_DUR * FPS);
const t0 = Date.now();
for (let f = 0; f < NF; f++) {
  const T = f / FPS; const r = await filmFrame(T);
  // short frame(s): map film frame to short time if inside the non-padded part
  if (ES && r && r.lt < r.seg.dS) { const sT = r.seg.sStart + r.lt; let first = true;
    while (shortFrames < NS && shortFrames / FPS <= sT + 0.5 / FPS) { if (first) { composeShort(sT, FOCUS.x, FOCUS.shot); first = false; } await write(ES, Buffer.from(sv.data())); shortFrames++; } }
  if (EF) { subtitle(T); await write(EF, Buffer.from(cv.data())); }
  if (f % 300 === 0) console.error(`ch${CH} ${f}/${NF} ${((Date.now() - t0) / 1000).toFixed(0)}s`);
}
while (ES && shortFrames < NS) { const T = shortFrames / FPS; const seg = segs.findLast(s => T >= s.sStart) ?? segs[0]; drawScene(seg, T - seg.sStart); if (PENDING.size) { await Promise.all([...PENDING]); drawScene(seg, T - seg.sStart); } composeShort(T, FOCUS.x, FOCUS.shot); await write(ES, Buffer.from(sv.data())); shortFrames++; }
if (EF) EF.p.stdin.end(); if (ES) ES.p.stdin.end();
const codes = await Promise.all([EF?.done, ES?.done]); console.error("done", codes, ((Date.now() - t0) / 1000).toFixed(0) + "s");
