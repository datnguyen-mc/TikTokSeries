// Articulated stickman rig: continuous motion, faction kits, poses, props.
import { clamp, lerp, ss, rnd, TAU } from "./core.mjs";
const { sin, cos, PI, abs, max, min, atan2, hypot, acos } = Math;
// skeleton (s=1): total height ~ 290px
const T = 58, SH = 56, LT = 86, UA = 46, FA = 44, HR = 31, NECK = 5;
const V = (a) => [sin(a), cos(a)];           // angle from straight down; + = forward (local +x)
const add = (p, v, l) => [p[0] + v[0] * l, p[1] + v[1] * l];

// ---------------- kits ----------------
export const KITS = {
  de: { coat: "#5f6650", hat: "stahl", hatc: "#545b49", belt: "#2b2b22" },
  de_off: { coat: "#5f6650", hat: "peak", hatc: "#545b49", band: "#2a2a2a", belt: "#3a2a1a" },
  uk: { coat: "#86784a", hat: "brodie", hatc: "#6c673e", belt: "#5d5536" },
  uk_off: { coat: "#86784a", hat: "peak", hatc: "#86784a", band: "#7a2a2a", belt: "#4a3420" },
  us: { coat: "#6b6a42", hat: "m1", hatc: "#4f5a33", belt: "#8a8358" },
  us_off: { coat: "#6b6a42", hat: "peak", hatc: "#5c5a3a", band: "#3a3a2a", belt: "#4a3420" },
  su: { coat: "#7c7a4c", hat: "ssh", hatc: "#4d6136", star: 1, belt: "#4a3420" },
  su_cap: { coat: "#7c7a4c", hat: "pilotka", hatc: "#6d6b40", star: 1, belt: "#4a3420" },
  su_winter: { coat: "#e6e8ea", hat: "ushanka", hatc: "#8b7a5a", star: 1, belt: "#4a3420" },
  de_winter: { coat: "#5f6650", hat: "stahl", hatc: "#545b49", belt: "#2b2b22", scarf: "#9aa0a6" },
  jp: { coat: "#8c7d48", hat: "jph", hatc: "#7a6f40", jstar: 1, belt: "#5a4a2a" },
  jp_off: { coat: "#8c7d48", hat: "peak", hatc: "#7a6f40", band: "#b02a2a", belt: "#4a3420" },
  fr: { coat: "#7d7458", hat: "adrian", hatc: "#6d6c5c", belt: "#4a3420" },
  pl: { coat: "#6e6f4f", hat: "rogat", hatc: "#6e6f4f", belt: "#4a3420" },
  pilot_uk: { coat: "#7a5232", hat: "aviator", hatc: "#5a3a22", scarf: "#f2f2f2" },
  pilot_de: { coat: "#5a5f66", hat: "aviator", hatc: "#4a4036", scarf: "#d9d2b0" },
  pilot_us: { coat: "#7a5232", hat: "aviator", hatc: "#5a3a22", scarf: "#e8e0c0" },
  pilot_jp: { coat: "#7d7448", hat: "aviator", hatc: "#6a5a3a", scarf: "#f2f2f2", hachi: 1 },
  sailor_us: { coat: "#ffffff", hat: "dixie", hatc: "#ffffff", collar: "#1f3a6b" },
  sailor_jp: { coat: "#ffffff", hat: "sailorcap", hatc: "#1d2333", collar: "#1d2333" },
  navy_off: { coat: "#1e2a44", hat: "peak", hatc: "#1e2a44", band: "#c9a640", top: "#ffffff" },
  civ: { coat: "#4f6d8f", hat: "flatcap", hatc: "#5a4a3a" },
  civ2: { coat: "#8f4f4f", hat: "fedora", hatc: "#3a3a3a" },
  civ3: { coat: "#6d8f4f", hat: null },
  suit: { coat: "#2f3135", hat: "homburg", hatc: "#202022", tie: "#7a1f1f", shirt: 1 },
  woman: { coat: "#b0554f", hat: "hair", hatc: "#3a2a20", skirt: "#3d4f6b" },
  woman2: { coat: "#4f8fa0", hat: "scarf", hatc: "#d9a040", skirt: "#6b4f3d" },
  kid: { coat: "#d9a040", hat: "flatcap", hatc: "#6b4f3d", kid: 1 },
  worker: { coat: "#5a5f6b", hat: "flatcap", hatc: "#3a3a3a" },
  tweed: { coat: "#8a6a4a", hat: null, tie: "#2a3a6b", shirt: 1, glasses: 1 },
  waaf: { coat: "#4f6a8f", hat: "hair", hatc: "#6b4a2a", skirt: "#4f6a8f" },
  artist: { coat: "#6b6a42", hat: "beret", hatc: "#2a2a2a", belt: "#8a8358" },
  codeus: { coat: "#e8e8e0", hat: null, tie: "#1f2f5a", shirt: 1, glasses: 1 },
  jpciv: { coat: "#d8d0c0", hat: "hair", hatc: "#1a1a1a" },
  jpciv2: { coat: "#5a6b8a", hat: null },
  viet: { coat: "#e9e2d0", hat: "hair", hatc: "#1a1a1a", skirt: "#ffffff" },
  diplomat: { coat: "#24262c", hat: "tophat", hatc: "#141416", tie: "#e8e8e8", shirt: 1 },
};

// ---------------- IK ----------------
function ik2(S, P, a, b, bendSign = 1) { // returns shoulder angle (from down) and elbow bend for arm reaching P
  const dx = P[0] - S[0], dy = P[1] - S[1]; let d = clamp(hypot(dx, dy), 1, a + b - 0.5);
  const base = atan2(dx, dy); // angle from down
  const cA = clamp((a * a + d * d - b * b) / (2 * a * d), -1, 1), A = acos(cA);
  const cB = clamp((a * a + b * b - d * d) / (2 * a * b), -1, 1), B = acos(cB);
  return [base - bendSign * A, bendSign * (PI - B)];
}

// ---------------- poses ----------------
// each returns P: {lean, hip:[near,far], knee:[n,f], sh:[n,f], el:[n,f], rot, lift, tilt, expr, mouth, gun, prop, hands?}
const base = () => ({ lean: 0.03, hip: [0.07, -0.07], knee: [0.04, 0.04], sh: [0.12, -0.1], el: [0.25, 0.25], rot: 0, lift: 0, tilt: 0, dx: 0 });
const P = {};
P.idle = (t, o) => { const b = base(), br = sin(t * 1.9 + o.seed); b.lean += 0.015 * br; b.sh = [0.14 + 0.04 * br, -0.08 + 0.04 * br]; b.tilt = 0.04 * sin(t * 0.7 + o.seed); return b; };
P.stand = P.idle;
P.walk = (t, o) => { const b = base(), f = o.freq ?? 1.6, p = TAU * f * t + o.seed, A = o.amp ?? 0.5;
  b.hip = [A * sin(p), -A * sin(p)]; b.knee = [0.12 + 0.75 * max(0, cos(p)), 0.12 + 0.75 * max(0, -cos(p))];
  b.sh = [-0.5 * A * 1.6 * sin(p), 0.5 * A * 1.6 * sin(p)]; b.el = [0.35, 0.35]; b.lean = 0.07; return b; };
P.run = (t, o) => { const b = base(), f = o.freq ?? 2.6, p = TAU * f * t + o.seed;
  b.hip = [0.9 * sin(p), -0.9 * sin(p)]; b.knee = [0.35 + 1.4 * max(0, cos(p)), 0.35 + 1.4 * max(0, -cos(p))];
  b.sh = [-0.95 * sin(p), 0.95 * sin(p)]; b.el = [1.5, 1.5]; b.lean = 0.3; b.lift = 6 * abs(cos(p)); b.expr = b.expr ?? "determined"; return b; };
P.march = (t, o) => { const b = base(), f = o.freq ?? 1.7, p = TAU * f * t + o.seed;
  b.hip = [0.55 * sin(p), -0.55 * sin(p)]; b.knee = [0.06 + 0.25 * max(0, cos(p)), 0.06 + 0.25 * max(0, -cos(p))];
  b.sh = [-0.7 * sin(p), 0.5]; b.el = [0.1, 2.2]; b.lean = 0.0; b.gun = "shoulder"; b.expr = "determined"; return b; };
P.aim = (t, o) => { const b = base(); b.hip = [0.28, -0.22]; b.knee = [0.12, 0.05]; b.lean = 0.1 + 0.01 * sin(t * 2 + o.seed);
  const rk = recoil(t, o); b.lean -= 0.12 * rk; b.gun = "aim"; b.aimRk = rk; b.expr = "angry"; b.hands = [[78 - 14 * rk, -6], [26 - 14 * rk, 2]]; return b; };
P.kneel = (t, o) => { const b = base(); b.hip = [1.45, -0.25]; b.knee = [1.55, 1.95]; b.lean = 0.12;
  const rk = recoil(t, o); b.lean -= 0.1 * rk; b.gun = "aim"; b.aimRk = rk; b.expr = "angry"; b.hands = [[78 - 14 * rk, -6], [26 - 14 * rk, 2]]; return b; };
P.prone = (t, o) => { const b = base(); b.rot = PI / 2 - 0.1; b.hip = [0.06, -0.06]; b.knee = [0, 0]; b.lean = 0; b.tilt = -PI / 2 + 0.25;
  const rk = recoil(t, o); b.gun = "aim"; b.aimRk = rk; b.expr = "angry"; b.hands = [[-12, -64 + 10 * rk], [-6, -24 + 10 * rk]]; b.dx = -60; return b; };
P.crawl = (t, o) => { const b = P.prone(t, o), p = TAU * 1.3 * t + o.seed; b.gun = "sling"; b.hands = null; b.sh = [PI - 0.35 + 0.45 * sin(p), PI - 0.35 - 0.45 * sin(p)]; b.el = [0.5, 0.5];
  b.hip = [0.2 * sin(p), -0.2 * sin(p)]; b.knee = [0.15 + 0.3 * max(0, sin(p)), 0.15 + 0.3 * max(0, -sin(p))]; b.expr = "determined"; return b; };
P.cheer = (t, o) => { const b = base(), p = TAU * 2.2 * t + o.seed; b.sh = [PI - 0.45 + 0.25 * sin(p), PI - 0.6 - 0.25 * sin(p)]; b.el = [0.35, 0.35];
  b.lift = 22 * abs(sin(p * 0.5)); b.knee = [0.25, 0.3]; b.expr = "happy"; b.mouth = 0.7; return b; };
P.jump = P.cheer;
P.shock = (t, o) => { const b = P.idle(t, o); b.sh = [0.9 + 0.05 * sin(t * 20), 0.7]; b.el = [0.9, 0.8]; b.lean = -0.12; b.expr = "shock"; b.dx = 1.2 * sin(t * 40); return b; };
P.wave = (t, o) => { const b = P.idle(t, o); b.sh[0] = 2.55; b.el[0] = 0.5 + 0.45 * sin(t * 9 + o.seed); b.expr = "happy"; return b; };
P.salute = (t, o) => { const b = P.idle(t, o); b.lean = 0; b.hands = [[44, -102], null]; b.expr = "determined"; b.sh[1] = 0.04; return b; };
P.point = (t, o) => { const b = P.idle(t, o); b.sh[0] = 1.62 + 0.05 * sin(t * 3); b.el[0] = 0.06; b.expr = b.expr ?? "shout"; return b; };
P.pointup = (t, o) => { const b = P.idle(t, o); b.sh[0] = 2.75; b.el[0] = 0.05; return b; };
P.talk = (t, o) => { const b = P.idle(t, o), p = t * 2.6 + o.seed; b.sh = [0.55 + 0.35 * sin(p), 0.3 + 0.2 * sin(p * 0.7 + 1)]; b.el = [1.2 + 0.4 * sin(p * 1.3), 0.9]; b.talk = 1; return b; };
P.shout = (t, o) => { const b = P.talk(t, o); b.sh[0] = 1.9 + 0.3 * sin(t * 5); b.el[0] = 0.4; b.expr = "shout"; b.lean = 0.12; return b; };
P.think = (t, o) => { const b = P.idle(t, o); b.hands = [[26, -112], null]; b.sh[1] = 0.5; b.el[1] = 1.6; b.tilt = 0.12; b.expr = "think"; return b; };
P.shrug = (t, o) => { const b = P.idle(t, o), k = 0.5 + 0.5 * sin(t * 3); b.sh = [0.9 + 0.2 * k, 0.9 + 0.2 * k]; b.el = [-1.9, -1.9]; b.expr = "worried"; b.lift = 0; return b; };
P.facepalm = (t, o) => { const b = P.idle(t, o); b.hands = [[34, -118], null]; b.lean = 0.15; b.expr = "sad"; return b; };
P.sit = (t, o) => { const b = base(); b.hip = [PI / 2, PI / 2 - 0.1]; b.knee = [PI / 2, PI / 2 - 0.1]; b.lean = -0.02 + 0.01 * sin(t * 1.5); b.sh = [0.3, 0.2]; b.el = [1.2, 1.1]; return b; };
P.type = (t, o) => { const b = P.sit(t, o), j = sin(t * 23 + o.seed) * 4, k = sin(t * 19 + 2 + o.seed) * 4; b.lean = 0.12; b.hands = [[66, 34 + j], [56, 36 + k]]; b.expr = b.expr ?? "focus"; return b; };
P.radio = (t, o) => { const b = P.sit(t, o); b.lean = 0.08; b.hands = [[22, -88], [60, 40 + 3 * sin(t * 15)]]; b.expr = "focus"; return b; };
P.desk = (t, o) => { const b = P.idle(t, o); b.lean = 0.45; b.hands = [[86, 70 + 3 * sin(t * 2)], [70, 74]]; b.expr = b.expr ?? "focus"; return b; };
P.shiver = (t, o) => { const b = P.idle(t, o); b.hands = [[36, 22], [30, 26]]; b.lean = 0.1; b.dx = 2.2 * sin(t * 61); b.expr = "cold"; b.knee = [0.18, 0.18]; return b; };
P.duck = (t, o) => { const b = base(); b.hip = [1.5, 1.25]; b.knee = [2.35, 2.25]; b.lean = 0.55; b.hands = [[10, -112], [4, -108]]; b.dx = 1.6 * sin(t * 47); b.expr = "scared"; return b; };
P.fall = (t, o) => { const b = P.idle(t, o), u = ss(t / 0.45); b.rot = -u * (PI / 2 - 0.05); b.sh = [lerp(0.1, 2.2, u), lerp(-0.1, 2.6, u)]; b.hip = [lerp(0.07, 0.4, u), lerp(-0.07, 0.15, u)]; b.expr = "ko"; return b; };
P.lie = (t, o) => { const b = base(); b.rot = -(PI / 2 - 0.05); b.sh = [2.2, 2.6]; b.hip = [0.4, 0.15]; b.expr = "ko"; return b; };
P.fly = (t, o) => { const b = P.idle(t, o); b.rot = -t * 9; b.sh = [2.6, 2.2]; b.el = [0.3, 0.3]; b.hip = [0.6, -0.4]; b.expr = "shock"; b.air = 1; return b; };
P.push = (t, o) => { const b = P.walk(t, { ...o, freq: o.freq ?? 0.9, amp: 0.38 }); b.lean = 0.5; b.hands = [[96, -4], [90, 4]]; b.expr = "strain"; return b; };
P.pull = (t, o) => { const b = P.walk(t, { ...o, freq: o.freq ?? 0.8, amp: 0.3 }); b.lean = -0.35; b.hands = [[-50, 30], [-56, 36]]; b.expr = "strain"; return b; };
P.row = (t, o) => { const b = P.sit(t, o), p = TAU * 0.8 * t + o.seed, k = 0.5 + 0.5 * sin(p); b.lean = lerp(-0.25, 0.4, k); b.hands = [[lerp(30, 95, k), 22], [lerp(24, 88, k), 26]]; b.expr = "strain"; return b; };
P.binoc = (t, o) => { const b = P.idle(t, o); b.hands = [[40, -104], [34, -98]]; b.prop = "binoc"; b.expr = "focus"; return b; };
P.handsup = (t, o) => { const b = P.idle(t, o); b.sh = [PI - 0.12 + 0.04 * sin(t * 3), PI - 0.2]; b.el = [0.05, 0.05]; b.expr = "scared"; return b; };
P.handshake = (t, o) => { const b = P.idle(t, o); b.hands = [[78, 8 + 6 * sin(t * 9)], null]; b.expr = "happy"; return b; };
P.read = (t, o) => { const b = P.idle(t, o); b.hands = [[60, -48], [52, -44]]; b.prop = b.prop ?? "paper"; b.expr = b.expr ?? "focus"; b.tilt = 0.15; return b; };
P.hold = (t, o) => { const b = P.idle(t, o); b.hands = [[56, -10 + 3 * sin(t * 2)], [46, -6]]; return b; };
P.holdup = (t, o) => { const b = P.idle(t, o); b.hands = [[44, -150 + 5 * sin(t * 4)], [30, -140]]; b.expr = "happy"; return b; };
P.throw = (t, o) => { const b = P.idle(t, o), p = (t * 1.2 + o.seed) % 1, k = p < 0.6 ? ss(p / 0.6) : 1 - ss((p - 0.6) / 0.4);
  b.sh[0] = lerp(2.8, -2.3 + 4.5, 1 - k); b.sh[0] = lerp(-2.4, 2.2, ss(k)); b.el[0] = 0.4; b.lean = lerp(-0.15, 0.25, k); b.expr = "shout"; return b; };
P.dance = (t, o) => { const b = base(), p = TAU * 1.8 * t + o.seed; b.sh = [PI * 0.75 + 0.5 * sin(p), PI * 0.25 + 0.5 * sin(p + 1)]; b.el = [0.8, 0.8];
  b.hip = [0.35 * sin(p), -0.35 * sin(p)]; b.knee = [0.5 + 0.4 * sin(p), 0.5 - 0.4 * sin(p)]; b.lift = 14 * abs(sin(p)); b.lean = 0.12 * sin(p * 0.5); b.expr = "happy"; b.mouth = 0.6; return b; };
P.hug = (t, o) => { const b = P.idle(t, o); b.hands = [[70, -30], [62, -20]]; b.lean = 0.1; b.expr = "happy"; return b; };
P.sad = (t, o) => { const b = P.idle(t, o); b.lean = 0.18; b.tilt = 0.28; b.sh = [0.05, -0.02]; b.expr = "sad"; return b; };
P.mourn = (t, o) => { const b = P.sad(t, o); b.hands = [[30, 20], [24, 24]]; return b; };
P.carry = (t, o) => { const b = P.walk(t, o); b.hands = [[54, -18], [46, -12]]; return b; };
P.wheel = (t, o) => { const b = P.walk(t, { ...o, freq: 1.0, amp: 0.38 }); b.lean = 0.3; b.hands = [[86, 46], [80, 50]]; b.expr = "strain"; return b; };
P.coldwalk = (t, o) => { const b = P.walk(t, { ...o, freq: 0.9, amp: 0.3 }); b.hands = [[36, 22], [30, 26]]; b.lean = 0.2; b.dx = 1.6 * sin(t * 61); b.expr = "cold"; return b; };
P.runaim = (t, o) => { const b = P.run(t, o); b.gun = "aim"; b.hands = [[78, 4], [30, 10]]; b.lean = 0.25; b.expr = "shout"; b.aimRk = 0; return b; };
P.runcarry = (t, o) => { const b = P.run(t, o); b.gun = "carry"; b.hands = [[52, -10], [22, 24]]; b.lean = 0.25; b.expr = "shout"; return b; };
P.wade = (t, o) => { const b = P.walk(t, { ...o, freq: 0.7, amp: 0.3 }); b.gun = "carry"; b.hands = [[44, -70], [10, -60]]; b.lean = 0.15; b.expr = "strain"; return b; };
function recoil(t, o) { if (!o.fire) return 0; const per = o.fire, ph = ((t + o.seed * 0.37) % per); return ph < 0.18 ? Math.exp(-ph * 22) : 0; }
export const POSES = P;

// ---------------- face ----------------
function face(ctx, expr, mouth, t, seed, kit) {
  const blink = ((t + seed * 1.7) % 3.4) < 0.11;
  const ex1 = 4, ex2 = 19, ey = -4;
  ctx.fillStyle = "#111"; ctx.strokeStyle = "#111"; ctx.lineCap = "round";
  if (expr === "ko") { ctx.lineWidth = 3.2; for (const ex of [ex1, ex2]) { ctx.beginPath(); ctx.moveTo(ex - 4, ey - 4); ctx.lineTo(ex + 4, ey + 4); ctx.moveTo(ex + 4, ey - 4); ctx.lineTo(ex - 4, ey + 4); ctx.stroke(); } }
  else if (blink || expr === "happy" && mouth > 0.5) { ctx.lineWidth = 3; for (const ex of [ex1, ex2]) { ctx.beginPath(); if (blink) { ctx.moveTo(ex - 4, ey); ctx.lineTo(ex + 4, ey); } else ctx.arc(ex, ey + 2, 4.5, PI * 1.1, PI * 1.9); ctx.stroke(); } }
  else { const r = expr === "shock" || expr === "scared" ? 4.6 : 3.8; for (const ex of [ex1, ex2]) { ctx.beginPath(); ctx.arc(ex, ey, r, 0, TAU); ctx.fill(); } }
  // brows
  ctx.lineWidth = 3.4; ctx.beginPath();
  const br = { angry: [3, -3], determined: [2, -1.5], shout: [3, -3], strain: [2.5, -2.5], sad: [-3, 3], worried: [-3, 3], scared: [-3, 3], cold: [-2, 2], shock: [-1, -1], think: [-2, 1] }[expr];
  if (br) { ctx.moveTo(ex1 - 6, ey - 11 + br[1] * -1); ctx.lineTo(ex1 + 5, ey - 11 + br[0] * 1 - 2); ctx.moveTo(ex2 - 5, ey - 11 + br[0] - 2); ctx.lineTo(ex2 + 6, ey - 11 + br[1] * -1); ctx.stroke(); }
  if (kit?.glasses) { ctx.lineWidth = 2.2; ctx.beginPath(); ctx.arc(ex1, ey, 7, 0, TAU); ctx.moveTo(ex2 + 7, ey); ctx.arc(ex2, ey, 7, 0, TAU); ctx.moveTo(ex1 + 7, ey); ctx.lineTo(ex2 - 7, ey); ctx.stroke(); }
  // mouth
  const mx = 12, my = 13; ctx.lineWidth = 3.2;
  const open = mouth ?? 0;
  if (open > 0.15 || expr === "shout" || expr === "shock") { const h = expr === "shock" ? 8 : 3 + 7 * max(open, expr === "shout" ? 0.8 : 0);
    ctx.beginPath(); ctx.ellipse(mx, my, expr === "shock" ? 6 : 7, h, 0, 0, TAU); ctx.fillStyle = "#3a1214"; ctx.fill(); ctx.stroke(); }
  else { ctx.beginPath();
    if (expr === "happy") ctx.arc(mx, my - 5, 8, 0.2 * PI, 0.8 * PI);
    else if (expr === "sad" || expr === "cold" || expr === "worried" || expr === "scared") ctx.arc(mx, my + 7, 7, 1.2 * PI, 1.8 * PI);
    else if (expr === "strain") { ctx.moveTo(mx - 7, my); for (let i = 0; i <= 4; i++) ctx.lineTo(mx - 7 + i * 3.5, my + (i % 2 ? -2 : 2)); }
    else if (expr === "think") { ctx.moveTo(mx - 5, my + 1); ctx.lineTo(mx + 5, my - 1); }
    else { ctx.moveTo(mx - 6, my); ctx.lineTo(mx + 6, my); }
    ctx.stroke(); }
  if (expr === "scared" || expr === "strain") { ctx.fillStyle = "#7ec8ff"; ctx.beginPath(); ctx.ellipse(-20, -14, 3.5, 6, 0.2, 0, TAU); ctx.fill(); }
  if (expr === "cold") { ctx.fillStyle = "rgba(120,170,255,0.45)"; ctx.beginPath(); ctx.arc(-2, 6, 6, 0, TAU); ctx.arc(26, 6, 6, 0, TAU); ctx.fill(); }
}
// ---------------- hats ----------------
function star(ctx, x, y, r, color) { ctx.save(); ctx.fillStyle = color; ctx.beginPath(); for (let i = 0; i < 10; i++) { const a = -PI / 2 + i * PI / 5, rr = i % 2 ? r * 0.45 : r; ctx.lineTo(x + cos(a) * rr, y + sin(a) * rr); } ctx.closePath(); ctx.fill(); ctx.restore(); }
function hat(ctx, kit) {
  const c = kit.hatc, k = kit.hat; if (!k) return;
  ctx.lineWidth = 4; ctx.strokeStyle = "#111"; ctx.fillStyle = c; ctx.lineJoin = "round";
  const P_ = (f) => { ctx.beginPath(); f(); ctx.fill(); ctx.stroke(); };
  if (k === "stahl") { P_(() => { ctx.moveTo(-40, 2); ctx.quadraticCurveTo(-38, -10, -32, -14); ctx.arc(0, -10, 32, PI + 0.15, -0.1); ctx.lineTo(36, -6); ctx.lineTo(30, -4); ctx.lineTo(-30, -4); ctx.quadraticCurveTo(-34, -2, -40, 2); }); }
  else if (k === "brodie") { P_(() => { ctx.ellipse(0, -14, 46, 9, 0, 0, TAU); }); P_(() => { ctx.ellipse(0, -18, 25, 16, 0, PI, TAU); ctx.closePath(); }); }
  else if (k === "m1") { P_(() => { ctx.arc(0, -8, 34, PI + 0.05, -0.05); ctx.lineTo(38, -4); ctx.lineTo(-38, -4); ctx.closePath(); }); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-30, -4); ctx.quadraticCurveTo(-10, 30, 14, 26); ctx.stroke(); }
  else if (k === "ssh") { P_(() => { ctx.arc(0, -8, 33, PI + 0.02, -0.02); ctx.lineTo(38, -6); ctx.lineTo(-36, -4); ctx.closePath(); }); star(ctx, 6, -22, 7, "#d42a2a"); }
  else if (k === "pilotka") { P_(() => { ctx.moveTo(-26, -20); ctx.lineTo(-22, -36); ctx.lineTo(24, -34); ctx.lineTo(28, -20); ctx.closePath(); }); star(ctx, 12, -27, 5, "#d42a2a"); }
  else if (k === "ushanka") { P_(() => { ctx.arc(0, -10, 34, PI, 0); ctx.lineTo(34, 6); ctx.lineTo(24, 8); ctx.lineTo(24, -6); ctx.lineTo(-30, -6); ctx.lineTo(-30, 14); ctx.lineTo(-36, 12); ctx.closePath(); }); star(ctx, 14, -26, 6, "#d42a2a"); }
  else if (k === "jph") { P_(() => { ctx.arc(0, -8, 33, PI, 0); ctx.lineTo(36, -4); ctx.lineTo(-34, -4); ctx.closePath(); }); star(ctx, 8, -24, 7, "#e8c840"); }
  else if (k === "adrian") { P_(() => { ctx.ellipse(0, -8, 42, 8, 0, 0, TAU); }); P_(() => { ctx.arc(0, -10, 29, PI, 0); ctx.closePath(); }); P_(() => { ctx.moveTo(-14, -36); ctx.quadraticCurveTo(0, -48, 14, -36); ctx.closePath(); }); }
  else if (k === "rogat") { P_(() => { ctx.moveTo(-28, -14); ctx.lineTo(-34, -40); ctx.lineTo(30, -42); ctx.lineTo(26, -14); ctx.closePath(); }); ctx.fillStyle = "#2a2a2a"; P_(() => { ctx.moveTo(-6, -14); ctx.lineTo(44, -12); ctx.lineTo(40, -6); ctx.lineTo(-6, -8); ctx.closePath(); }); }
  else if (k === "peak") { P_(() => { ctx.ellipse(-2, -30, 34, 11, -0.05, 0, TAU); }); ctx.fillStyle = kit.top ?? c; P_(() => { ctx.ellipse(-2, -32, 33, 9, -0.05, PI, TAU); ctx.closePath(); });
    ctx.fillStyle = kit.band ?? "#222"; P_(() => { ctx.rect(-24, -26, 46, 8); }); ctx.fillStyle = "#151515"; P_(() => { ctx.moveTo(8, -18); ctx.quadraticCurveTo(34, -20, 44, -10); ctx.lineTo(10, -14); ctx.closePath(); }); }
  else if (k === "aviator") { P_(() => { ctx.arc(0, -4, 34, PI + 0.3, -0.25); ctx.lineTo(30, 4); ctx.lineTo(-30, 14); ctx.closePath(); });
    ctx.fillStyle = "#b8c8d0"; ctx.lineWidth = 3; for (const gx of [2, 22]) { ctx.beginPath(); ctx.arc(gx, -26, 8, 0, TAU); ctx.fill(); ctx.stroke(); }
    if (kit.hachi) { ctx.fillStyle = "#fff"; ctx.fillRect(-30, -20, 60, 6); ctx.fillStyle = "#d42a2a"; ctx.beginPath(); ctx.arc(10, -17, 3, 0, TAU); ctx.fill(); } }
  else if (k === "dixie") { P_(() => { ctx.moveTo(-26, -22); ctx.quadraticCurveTo(0, -30, 26, -22); ctx.lineTo(22, -42); ctx.quadraticCurveTo(0, -48, -22, -42); ctx.closePath(); }); }
  else if (k === "sailorcap") { P_(() => { ctx.ellipse(0, -30, 30, 10, 0, 0, TAU); }); }
  else if (k === "flatcap") { P_(() => { ctx.moveTo(-32, -14); ctx.quadraticCurveTo(-30, -40, 4, -40); ctx.quadraticCurveTo(30, -38, 32, -22); ctx.lineTo(48, -14); ctx.lineTo(-32, -14); ctx.closePath(); }); }
  else if (k === "fedora") { P_(() => { ctx.ellipse(0, -18, 46, 8, 0, 0, TAU); }); P_(() => { ctx.moveTo(-24, -18); ctx.lineTo(-22, -46); ctx.quadraticCurveTo(0, -38, 22, -46); ctx.lineTo(24, -18); ctx.closePath(); }); ctx.fillStyle = "#7a1f1f"; ctx.fillRect(-23, -26, 46, 6); }
  else if (k === "homburg") { P_(() => { ctx.ellipse(0, -18, 40, 8, 0, 0, TAU); }); P_(() => { ctx.moveTo(-22, -18); ctx.lineTo(-20, -48); ctx.quadraticCurveTo(0, -42, 20, -48); ctx.lineTo(22, -18); ctx.closePath(); }); }
  else if (k === "tophat") { P_(() => { ctx.ellipse(0, -20, 40, 7, 0, 0, TAU); }); P_(() => { ctx.rect(-22, -74, 44, 54); }); }
  else if (k === "beret") { P_(() => { ctx.ellipse(-4, -26, 34, 12, -0.15, 0, TAU); }); }
  else if (k === "hair") { ctx.fillStyle = c; P_(() => { ctx.arc(0, -6, 33, PI * 0.95, PI * 2.05); ctx.quadraticCurveTo(10, -22, -32, 0); ctx.closePath(); }); P_(() => { ctx.arc(-30, -18, 12, 0, TAU); }); }
  else if (k === "scarf") { P_(() => { ctx.arc(0, -4, 35, PI * 0.85, PI * 2.15); ctx.quadraticCurveTo(0, -18, -32, 12); ctx.closePath(); }); }
}
// ---------------- props ----------------
export function rifle(ctx, a, b, ext = [44, 74], col = "#6b4a2a") { // a = rear hand, b = front hand
  const dx = b[0] - a[0], dy = b[1] - a[1], L = hypot(dx, dy) || 1, ux = dx / L, uy = dy / L;
  const s = [a[0] - ux * ext[0], a[1] - uy * ext[0]], e = [b[0] + ux * ext[1], b[1] + uy * ext[1]];
  ctx.lineCap = "round"; ctx.strokeStyle = "#111"; ctx.lineWidth = 12; ctx.beginPath(); ctx.moveTo(s[0], s[1]); ctx.lineTo(b[0] + ux * 16, b[1] + uy * 16); ctx.stroke();
  ctx.strokeStyle = col; ctx.lineWidth = 7; ctx.stroke();
  ctx.strokeStyle = "#1c1c1c"; ctx.lineWidth = 4.5; ctx.beginPath(); ctx.moveTo(a[0] + ux * 8, a[1] + uy * 8 - 3); ctx.lineTo(e[0], e[1]); ctx.stroke();
  return e;
}
export function muzzle(ctx, x, y, ang, k) { if (k < 0.15) return; ctx.save(); ctx.translate(x, y); ctx.rotate(ang); ctx.globalAlpha *= k;
  ctx.fillStyle = "#fff6b0"; ctx.beginPath(); ctx.moveTo(0, -9); ctx.lineTo(44, 0); ctx.lineTo(0, 9); ctx.lineTo(14, 0); ctx.closePath(); ctx.fill();
  ctx.fillStyle = "#ffb33a"; ctx.beginPath(); ctx.arc(8, 0, 11, 0, TAU); ctx.fill(); ctx.restore(); }
function flagProp(ctx, x, y, t, colors) { ctx.strokeStyle = "#3a2a1a"; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(x, y + 30); ctx.lineTo(x, y - 150); ctx.stroke();
  drawFlag(ctx, x, y - 150, 110, 70, t, colors); }
export function drawFlag(ctx, x, y, w, h, t, kind) {
  const n = 12; ctx.save(); ctx.beginPath();
  const pt = (u, v) => [x + u * w, y + v * h + sin(t * 6 - u * 5) * 6 * u];
  for (let i = 0; i <= n; i++) { const p = pt(i / n, 0); ctx.lineTo(p[0], p[1]); } for (let i = n; i >= 0; i--) { const p = pt(i / n, 1); ctx.lineTo(p[0], p[1]); }
  ctx.closePath(); ctx.save(); ctx.clip();
  const fillRect = (u0, v0, u1, v1, c) => { ctx.fillStyle = c; ctx.fillRect(x + u0 * w, y + v0 * h - 12, (u1 - u0) * w + 1, (v1 - v0) * h + 24); };
  if (kind === "fr") { fillRect(0, 0, 1 / 3, 1, "#1f4fa8"); fillRect(1 / 3, 0, 2 / 3, 1, "#fff"); fillRect(2 / 3, 0, 1, 1, "#d42a2a"); }
  else if (kind === "pl") { fillRect(0, 0, 1, 0.5, "#fff"); fillRect(0, 0.5, 1, 1, "#d42a3a"); }
  else if (kind === "su") { fillRect(0, 0, 1, 1, "#c8201e"); ctx.save(); ctx.strokeStyle = "#f2d23a"; ctx.fillStyle = "#f2d23a"; ctx.lineWidth = Math.max(2, h * 0.05); const cx = x + w * 0.16, cy = y + h * 0.38, r = h * 0.12;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0.3, Math.PI * 1.25); ctx.stroke(); ctx.beginPath(); ctx.moveTo(cx - r * 0.7, cy + r * 0.9); ctx.lineTo(cx + r * 0.8, cy - r * 0.7); ctx.stroke(); ctx.fillRect(cx + r * 0.5, cy - r, r * 0.6, r * 0.35);
    ctx.lineWidth = Math.max(1, h * 0.025); ctx.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? h * 0.025 : h * 0.06; ctx.lineTo(cx + Math.cos(a) * rr, cy - r * 1.9 + Math.sin(a) * rr); } ctx.closePath(); ctx.stroke(); ctx.restore(); }
  else if (kind === "jp") { fillRect(0, 0, 1, 1, "#fff"); ctx.fillStyle = "#c8201e"; ctx.beginPath(); ctx.arc(x + w / 2, y + h / 2 + sin(t * 6 - 2.5) * 3, h * 0.3, 0, TAU); ctx.fill(); }
  else if (kind === "us") { for (let i = 0; i < 7; i++) fillRect(0, i / 7, 1, (i + 0.5) / 7, i % 2 ? "#fff" : "#c8201e"); for (let i = 0; i < 7; i++) fillRect(0, (i + 0.5) / 7, 1, (i + 1) / 7, i % 2 ? "#c8201e" : "#fff"); fillRect(0, 0, 0.42, 0.54, "#24357a"); }
  else if (kind === "uk") { fillRect(0, 0, 1, 1, "#24357a"); ctx.strokeStyle = "#fff"; ctx.lineWidth = h * 0.22; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w, y + h); ctx.moveTo(x + w, y); ctx.lineTo(x, y + h); ctx.stroke();
    ctx.strokeStyle = "#c8201e"; ctx.lineWidth = h * 0.08; ctx.stroke(); fillRect(0.42, 0, 0.58, 1, "#fff"); fillRect(0, 0.36, 1, 0.64, "#fff"); fillRect(0.45, 0, 0.55, 1, "#c8201e"); fillRect(0, 0.41, 1, 0.59, "#c8201e"); }
  else if (kind === "vn") { fillRect(0, 0, 1, 1, "#d42a1e"); star(ctx, x + w / 2, y + h / 2 + sin(t * 6 - 2.5) * 3, h * 0.3, "#ffd93a"); }
  else if (kind === "un") { fillRect(0, 0, 1, 1, "#4b92db"); ctx.strokeStyle = "#fff"; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x + w / 2, y + h / 2, h * 0.25, 0, TAU); ctx.stroke(); }
  else if (kind === "white") { fillRect(0, 0, 1, 1, "#f2f2f2"); }
  else { fillRect(0, 0, 1, 1, kind || "#c8201e"); }
  ctx.restore(); ctx.lineWidth = 3; ctx.strokeStyle = "rgba(0,0,0,0.6)"; ctx.stroke(); ctx.restore();
}
function heldProp(ctx, kind, hn, hf, t) {
  if (!kind) return;
  if (kind === "paper" || kind === "letter") { ctx.save(); const cx = (hn[0] + hf[0]) / 2, cy = (hn[1] + hf[1]) / 2; ctx.translate(cx, cy); ctx.rotate(-0.12); ctx.fillStyle = "#f4efe0"; ctx.strokeStyle = "#111"; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.rect(-20, -30, 40, 52); ctx.fill(); ctx.stroke(); ctx.strokeStyle = "#999"; ctx.lineWidth = 2; for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.moveTo(-13, -20 + i * 9); ctx.lineTo(13, -20 + i * 9); ctx.stroke(); } ctx.restore(); }
  else if (kind === "money") { ctx.save(); ctx.translate(hn[0], hn[1] - 8); ctx.fillStyle = "#9ab88a"; ctx.strokeStyle = "#2a3a2a"; ctx.lineWidth = 3; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.rect(-26, -i * 7, 52, 26); ctx.fill(); ctx.stroke(); } ctx.restore(); }
  else if (kind === "binoc") { ctx.save(); ctx.translate(hn[0] - 2, hn[1] - 4); ctx.fillStyle = "#222"; ctx.fillRect(-6, -10, 26, 9); ctx.fillRect(-6, 1, 26, 9); ctx.restore(); }
  else if (kind === "flag_su" || kind === "flag_fr" || kind === "flag_us" || kind === "flag_uk" || kind === "flag_vn" || kind === "flag_white" || kind === "flag_pl" || kind === "flag_jp") { flagProp(ctx, hn[0], hn[1], t, kind.slice(5)); }
  else if (kind === "grenade") { ctx.fillStyle = "#3a4a2a"; ctx.strokeStyle = "#111"; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(hn[0], hn[1], 7, 9, 0, 0, TAU); ctx.fill(); ctx.stroke(); }
  else if (kind === "pistol") { ctx.fillStyle = "#222"; ctx.fillRect(hn[0], hn[1] - 6, 26, 8); ctx.fillRect(hn[0], hn[1] - 2, 7, 12); }
  else if (kind === "cup") { ctx.fillStyle = "#eee"; ctx.strokeStyle = "#111"; ctx.lineWidth = 3; ctx.beginPath(); ctx.rect(hn[0] - 7, hn[1] - 14, 15, 18); ctx.fill(); ctx.stroke(); }
  else if (kind === "bread") { ctx.fillStyle = "#c08a4a"; ctx.strokeStyle = "#111"; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(hn[0] + 6, hn[1] - 6, 22, 12, -0.2, 0, TAU); ctx.fill(); ctx.stroke(); }
  else if (kind === "sword") { ctx.strokeStyle = "#ccc"; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(hn[0], hn[1]); ctx.lineTo(hn[0] + 70, hn[1] - 40); ctx.stroke(); }
  else if (kind === "pen") { ctx.strokeStyle = "#111"; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(hn[0], hn[1]); ctx.lineTo(hn[0] + 18, hn[1] + 14); ctx.stroke(); }
  else if (kind === "oar") { ctx.strokeStyle = "#7a5a3a"; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(hn[0] - 20, hn[1] - 10); ctx.lineTo(hn[0] + 70, hn[1] + 70); ctx.stroke(); }
  else if (kind === "mic") { /* drawn by scene */ }
}

// ---------------- main draw ----------------
// o: {x, y(ground), s, dir, pose, t, kit, expr, mouth, talk, seed, alpha, prop, fire, freq, amp, gunCol, noGun}
export function stick(ctx, o, Pin) {
  const s = o.s ?? 1, dir = o.dir ?? 1, seed = o.seed ?? 1, t = o.t ?? 0;
  const kit = typeof o.kit === "string" ? (KITS[o.kit] ?? KITS.civ) : (o.kit ?? KITS.civ);
  const p = Pin ?? (P[o.pose ?? "idle"] ?? P.idle)(t, { ...o, seed });
  // forward kinematics, hip at origin, local facing +x
  const hipP = [0, 0];
  const L = p.lean;
  const legs = [0, 1].map(i => { const k = add(hipP, V(p.hip[i]), T); const f = add(k, V(p.hip[i] - p.knee[i]), SH); return { k, f }; });
  const nk = add(hipP, [sin(L), -cos(L)], LT), shp = add(hipP, [sin(L), -cos(L)], LT - 10);
  const hc = add(nk, [sin(L + p.tilt), -cos(L + p.tilt)], HR + NECK);
  const arms = [0, 1].map(i => { let a = p.sh[i], b = p.el[i];
    if (p.hands && p.hands[i]) { const tgt = [shp[0] + p.hands[i][0], shp[1] + p.hands[i][1]]; [a, b] = ik2(shp, tgt, UA, FA, 1); }
    const e = add(shp, V(a), UA), h = add(e, V(a + b), FA); return { e, h }; });
  // rotation & grounding
  const rot = p.rot ?? 0; const R = (q) => [q[0] * cos(rot) - q[1] * sin(rot), q[0] * sin(rot) + q[1] * cos(rot)];
  const pts = [hipP, legs[0].k, legs[0].f, legs[1].k, legs[1].f, nk, shp, hc, arms[0].e, arms[0].h, arms[1].e, arms[1].h].map(R);
  let maxY = -1e9; for (const q of [pts[1], pts[2], pts[3], pts[4], pts[0], pts[5]]) maxY = max(maxY, q[1]);
  if (rot) maxY = max(maxY, pts[7][1] + HR - 4);
  const gy = p.air ? -150 : maxY + 4; // feet / body on ground
  ctx.save(); ctx.translate(o.x + (p.dx ?? 0) * s * dir, o.y - (p.lift ?? 0) * s); ctx.scale(dir * s * (kit.kid ? 0.66 : 1), s * (kit.kid ? 0.66 : 1));
  ctx.globalAlpha *= o.alpha ?? 1; if (o.filter) ctx.filter = o.filter;
  ctx.translate(0, -gy); ctx.rotate(rot);
  ctx.lineCap = "round"; ctx.lineJoin = "round";
  const limb = (a, b, c, col = "#141414", w = 7) => { ctx.strokeStyle = col; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c[0], c[1]); ctx.stroke(); };
  const foot = (k, f, col) => { ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(f[0] + 7, f[1] + 1, 11, 6, 0, 0, TAU); ctx.fill(); };
  const hand = (h, col) => { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(h[0], h[1], 5.5, 0, TAU); ctx.fill(); };
  // far limbs
  limb(shp, arms[1].e, arms[1].h, "#2a2a2a"); hand(arms[1].h, "#2a2a2a");
  if (!kit.skirt) { limb(hipP, legs[1].k, legs[1].f, "#2a2a2a"); foot(legs[1].k, legs[1].f, "#2a2a2a"); }
  // rifle on back
  const gun = o.noGun ? null : (o.gun ?? p.gun ?? (o.rifle ? "sling" : null));
  if (gun === "sling") { const a0 = add(hipP, [sin(L), -cos(L)], 4), a1 = add(hipP, [sin(L), -cos(L)], 70); rifle(ctx, [a0[0] - 22, a0[1] + 10], [a1[0] - 8, a1[1]], [20, 50], o.gunCol); }
  // torso garment
  const tx = sin(L), ty = -cos(L), nx = -ty, ny = tx; // normal
  const w0 = 17, w1 = 19, top = add(hipP, [tx, ty], LT - 2), bot = add(hipP, [tx, ty], -10);
  ctx.fillStyle = kit.coat; ctx.strokeStyle = "#111"; ctx.lineWidth = 4.5; ctx.beginPath();
  ctx.moveTo(bot[0] + nx * w0, bot[1] + ny * w0); ctx.lineTo(top[0] + nx * w1 * 0.9, top[1] + ny * w1 * 0.9); ctx.quadraticCurveTo(top[0] + tx * 8, top[1] + ty * 8, top[0] - nx * w1 * 0.9, top[1] - ny * w1 * 0.9);
  ctx.lineTo(bot[0] - nx * w0, bot[1] - ny * w0); ctx.closePath(); ctx.fill(); ctx.stroke();
  if (kit.skirt) { ctx.fillStyle = kit.skirt; ctx.beginPath(); ctx.moveTo(bot[0] + nx * w0, bot[1] + ny * w0); ctx.lineTo(bot[0] + nx * 30 - tx * 46, bot[1] + ny * 30 - ty * 46); ctx.lineTo(bot[0] - nx * 30 - tx * 46, bot[1] - ny * 30 - ty * 46); ctx.lineTo(bot[0] - nx * w0, bot[1] - ny * w0); ctx.closePath(); ctx.fill(); ctx.stroke(); }
  if (kit.belt) { const bp = add(hipP, [tx, ty], 6); ctx.strokeStyle = kit.belt; ctx.lineWidth = 7; ctx.lineCap = "butt"; ctx.beginPath(); ctx.moveTo(bp[0] + nx * (w0 - 1), bp[1] + ny * (w0 - 1)); ctx.lineTo(bp[0] - nx * (w0 - 1), bp[1] - ny * (w0 - 1)); ctx.stroke(); ctx.lineCap = "round"; }
  if (kit.collar) { ctx.fillStyle = kit.collar; ctx.beginPath(); ctx.moveTo(top[0] - nx * 18, top[1] - ny * 18); ctx.lineTo(top[0] + nx * 18, top[1] + ny * 18); ctx.lineTo(top[0] - tx * 22, top[1] - ty * 22); ctx.closePath(); ctx.fill(); }
  if (kit.shirt) { ctx.fillStyle = "#f2f2f2"; ctx.beginPath(); ctx.moveTo(top[0] - nx * 7, top[1] - ny * 7); ctx.lineTo(top[0] + nx * 7, top[1] + ny * 7); ctx.lineTo(top[0] - tx * 26, top[1] - ty * 26); ctx.closePath(); ctx.fill();
    if (kit.tie) { ctx.strokeStyle = kit.tie; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(top[0] - tx * 4, top[1] - ty * 4); ctx.lineTo(top[0] - tx * 30, top[1] - ty * 30); ctx.stroke(); } }
  if (kit.scarf) { ctx.strokeStyle = kit.scarf; ctx.lineWidth = 9; ctx.beginPath(); ctx.moveTo(top[0] - nx * 12, top[1] - ny * 12 + 2); ctx.lineTo(top[0] + nx * 12, top[1] + ny * 12 + 2); ctx.lineTo(top[0] - nx * 22 - tx * 18 + sin(t * 7) * 4, top[1] - ny * 22 - ty * 18); ctx.stroke(); }
  // near leg
  if (!kit.skirt) { limb(hipP, legs[0].k, legs[0].f); foot(legs[0].k, legs[0].f, "#141414"); }
  else { for (const lg of legs) { const kk = add(hipP, [-tx, -ty], 40); ctx.strokeStyle = "#141414"; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(kk[0] + (lg === legs[0] ? 6 : -6), kk[1]); ctx.lineTo(lg.f[0], lg.f[1]); ctx.stroke(); foot(lg.k, lg.f, "#141414"); } }
  // held gun
  let tip = null;
  if (gun === "aim" || gun === "carry") { tip = rifle(ctx, arms[1].h[0] < arms[0].h[0] ? arms[1].h : arms[0].h, arms[1].h[0] < arms[0].h[0] ? arms[0].h : arms[1].h, gun === "aim" ? [46, 64] : [36, 54], o.gunCol); }
  if (gun === "shoulder") { const h = arms[1].h; rifle(ctx, [h[0] - 4, h[1] + 4], [h[0] - 22, h[1] - 50], [40, 70], o.gunCol); }
  // near arm
  limb(shp, arms[0].e, arms[0].h); hand(arms[0].h, "#141414");
  heldProp(ctx, o.prop ?? p.prop, arms[0].h, arms[1].h, t);
  // head
  ctx.save(); ctx.translate(hc[0], hc[1]); ctx.rotate(L + p.tilt);
  ctx.fillStyle = "#fff"; ctx.strokeStyle = "#111"; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(0, 0, HR, 0, TAU); ctx.fill(); ctx.stroke();
  const expr = o.expr ?? p.expr ?? "neutral";
  const mouth = o.talk || p.talk ? 0.15 + 0.6 * abs(sin(t * 11 + seed)) * (sin(t * 3.1) > -0.6 ? 1 : 0) : (o.mouth ?? p.mouth ?? 0);
  face(ctx, expr, mouth, t, seed, kit);
  hat(ctx, kit);
  ctx.restore();
  ctx.restore();
  // muzzle flash in world coords
  if (gun === "aim" && tip && (p.aimRk ?? 0) > 0.2) {
    const R2 = (q) => { const r = R(q); return [o.x + (p.dx ?? 0) * s * dir + r[0] * dir * s, o.y - (p.lift ?? 0) * s + (r[1] - gy) * s]; };
    const w = R2(tip); const a0 = R2(arms[0].h), a1 = R2(arms[1].h); const ang = atan2(w[1] - a1[1], w[0] - a1[0]);
    muzzle(ctx, w[0], w[1], ang, p.aimRk); o._flash = w;
  }
  return { head: [o.x + hc[0] * dir * s, o.y + (hc[1] - gy) * s], top: o.y - (gy - min(...pts.map(q => q[1]))) * s };
}

// ---------------- actor timeline ----------------
// keys: [[t, {x,y,s,dir,pose,kit,expr,...,move(sec)}], ...] ; position lerps over 'move' seconds, pose blends over 0.25s
export function actor(ctx, t, keys, extra = {}) {
  const full = []; let acc = { s: 1.45, dir: 1, move: 0.6, pose: "idle", alpha: 1 };
  for (const [kt, k] of keys) { acc = { ...acc, ...k }; full.push([kt, acc]); }
  if (t < full[0][0]) return null;
  let i = 0; while (i + 1 < full.length && t >= full[i + 1][0]) i++;
  const [t0, cur] = full[i]; const prev = i > 0 ? full[i - 1][1] : cur;
  const u = i > 0 ? ss((t - t0) / cur.move) : 1, ul = i > 0 ? clamp((t - t0) / cur.move) : 1;
  const lin = cur.lin ? ul : u;
  const x = lerp(prev.x, cur.x, lin), y = lerp(prev.y, cur.y, lin), sc = lerp(prev.s, cur.s, u), al = lerp(prev.alpha, cur.alpha, u);
  const seed = extra.seed ?? cur.seed ?? 1; const tl = t - (cur.local ? t0 : 0);
  const pc = (P[cur.pose] ?? P.idle)(cur.local ? t - t0 : t, { ...cur, seed });
  let pp = pc;
  const bu = i > 0 && prev.pose !== cur.pose ? ss((t - t0) / 0.25) : 1;
  if (bu < 1) { const pv = (P[prev.pose] ?? P.idle)(t, { ...prev, seed }); pp = blend(pv, pc, bu); }
  const popin = i === 0 && cur.popin ? 0.4 + 0.6 * Math.min(1, (t - t0) / 0.3) : 1;
  return stick(ctx, { ...cur, ...extra, x, y, s: sc * popin, alpha: al * (i === 0 && cur.fade ? clamp((t - t0) / cur.fade) : 1), t, seed }, pp);
}
function blend(a, b, u) {
  const r = { ...b }; for (const k of ["lean", "rot", "lift", "tilt", "dx"]) r[k] = lerp(a[k] ?? 0, b[k] ?? 0, u);
  for (const k of ["hip", "knee", "sh", "el"]) r[k] = [lerp(a[k][0], b[k][0], u), lerp(a[k][1], b[k][1], u)];
  if (a.hands || b.hands) { r.hands = null; // convert to angles by resolving: approximate by switching at mid
    if (u < 0.5) { r.hands = a.hands; r.sh = a.sh; r.el = a.el; } }
  return r;
}
// crowd helper: n figures across [x0,x1]
export function crowd(ctx, t, { n = 8, x0 = 200, x1 = 1700, y = 960, s = 0.8, pose = "cheer", kits = ["civ", "civ2", "civ3", "woman", "woman2", "worker"], dir = 1, seed = 3, depth = 0, expr, prop, filter } = {}) {
  for (let i = 0; i < n; i++) { const u = n === 1 ? 0.5 : i / (n - 1); const r = rnd(seed, i);
    const kit = kits[Math.floor(r * kits.length) % kits.length];
    stick(ctx, { x: lerp(x0, x1, u) + (r - 0.5) * 40, y: y + (i % 2) * depth, s: s * (0.92 + 0.16 * rnd(seed + 1, i)), dir: typeof dir === "function" ? dir(i) : dir, pose: typeof pose === "function" ? pose(i) : pose, t: t + r * 3, kit, seed: seed * 13 + i, expr, filter, prop: typeof prop === "function" ? prop(i) : prop }); }
}
