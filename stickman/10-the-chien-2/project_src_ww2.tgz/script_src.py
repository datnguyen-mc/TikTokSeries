# Source of truth for the WW2 film narration (Vietnamese). Builds chNN/script.json with display|spoken tokens.
import json, os, re

CH = [
 ("00", "mo-dau", "THẾ CHIẾN II", "1939 – 1945", [
  "Sáu năm. Hơn ba mươi quốc gia. Hơn một trăm triệu người cầm súng.",
  "Đây là câu chuyện về cuộc chiến lớn nhất lịch sử loài người, từ những người que.",
 ]),
 ("01", "hat-giong", "HẠT GIỐNG CHIẾN TRANH", "1919 – 1933", [
  "Năm 1919, nước Đức thua Thế chiến thứ nhất và phải ký Hiệp ước Versailles.",
  "Mất đất, mất quân đội, và phải bồi thường một khoản tiền khổng lồ.",
  "Năm 1923, đồng tiền Đức mất giá điên cuồng. Nửa cân bánh mì có giá hơn một trăm tỷ mác.",
  "Người ta chở tiền bằng xe để đi chợ, và dán tiền lên tường thay giấy dán.",
  "Rồi năm 1929, khủng hoảng kinh tế ập đến. Hàng triệu người Đức mất việc.",
  "Trong tuyệt vọng, họ nghe theo một người hứa sẽ làm nước Đức vĩ đại trở lại.",
  "Tháng 1 năm 1933, Adolf Hitler lên nắm quyền. Nước Đức bắt đầu tái vũ trang.",
  "Năm 1938, Đức sáp nhập nước Áo, rồi đòi một phần Tiệp Khắc. Anh và Pháp vẫn gật đầu.",
  "Thủ tướng Anh trở về, vẫy một tờ giấy và tuyên bố: hòa bình cho thời đại chúng ta.",
  "Châu Âu chọn cách nhân nhượng, mong giữ được hòa bình. Họ đã nhầm.",
  "Chưa đầy một năm sau, thế giới bước vào cuộc chiến đẫm máu nhất lịch sử loài người.",
 ]),
 ("02", "chop-nhoang", "CHIẾN TRANH CHỚP NHOÁNG", "1939 – 1940", [
  "Rạng sáng ngày 1/9/1939, quân Đức tràn qua biên giới Ba Lan.",
  "Xe tăng xông lên trước, máy bay ném bom gầm rú trên đầu. Người ta gọi đó là Blitzkrieg, chiến tranh chớp nhoáng.",
  "Hai ngày sau, Anh và Pháp tuyên chiến với Đức. Thế chiến thứ hai chính thức bắt đầu.",
  "Ngày 17/9, Liên Xô cũng tiến vào Ba Lan từ phía đông. Ba Lan chiến đấu dũng cảm, nhưng chỉ hơn một tháng sau, đất nước này sụp đổ.",
  "Nhưng ở phía tây, suốt nhiều tháng gần như không có tiếng súng. Báo chí gọi đó là cuộc chiến tranh kỳ quặc.",
  "Tháng 5 năm 1940, quân Đức vòng qua rừng Ardennes, nơi không ai nghĩ xe tăng có thể đi qua.",
  "Hà Lan, Bỉ lần lượt gục ngã. Ngày 14/6, quân Đức diễu hành qua Paris.",
  "Nước Pháp, cường quốc quân sự hàng đầu châu Âu, gục ngã chỉ sau sáu tuần.",
 ]),
 ("03", "dunkirk", "PHÉP MÀU DUNKIRK", "1940", [
  "Cuối tháng 5 năm 1940, hơn ba trăm nghìn lính Anh và Pháp bị dồn ra bãi biển Dunkirk.",
  "Phía sau là quân Đức. Phía trước là biển. Không còn đường lui.",
  "Rồi một điều khó hiểu xảy ra. Ngày 24/5, Hitler ra lệnh cho xe tăng dừng lại.",
  "Nước Anh chớp lấy thời gian quý giá đó, và kêu gọi mọi con thuyền có thể ra khơi.",
  "Thuyền đánh cá, phà, du thuyền. Khoảng tám trăm đến một nghìn hai trăm con thuyền vượt eo biển.",
  "Lính đứng xếp hàng trong nước ngập đến ngực, dưới bom đạn, chờ đến lượt mình.",
  "Xe tăng, đại bác, xe tải, gần như tất cả phải bỏ lại trên bãi biển.",
  "Sau chín ngày, khoảng ba trăm ba mươi tám nghìn người được cứu.",
  "Churchill nhắc nhở: chiến tranh không thể thắng bằng những cuộc rút lui. Nhưng nước Anh vẫn còn quân để chiến đấu.",
 ]),
 ("04", "bau-troi-anh", "BẦU TRỜI NƯỚC ANH", "1940", [
  "Mùa hè 1940, nước Anh đứng một mình. Muốn đổ bộ, Hitler phải làm chủ bầu trời trước.",
  "Hàng nghìn máy bay Đức bay qua eo biển. Nhưng nước Anh có một vũ khí bí mật: radar.",
  "Một chuỗi trạm radar dọc bờ biển phát hiện máy bay địch từ rất xa. Phi công Anh kịp cất cánh đón đầu.",
  "Hơn hai nghìn chín trăm phi công tham chiến, đến từ Anh, các nước Khối Thịnh vượng chung, và cả những nước đã bị chiếm đóng.",
  "Ngày 15/9, Đức tung ra đợt tấn công lớn nhất. Không quân Anh bắn rơi khoảng sáu mươi máy bay.",
  "Tháng 9, Đức chuyển sang ném bom ban đêm vào London. Người ta gọi đó là trận Blitz.",
  "Nhưng không quân Anh không gục ngã. Đức mất hơn một nghìn bảy trăm máy bay.",
  "Churchill nói: chưa bao giờ có nhiều người mang ơn một số ít người đến vậy.",
  "Kế hoạch đổ bộ bị hoãn vô thời hạn. Lần đầu tiên, cỗ máy chiến tranh của Hitler bị chặn lại.",
 ]),
 ("05", "mua-dong-nga", "MÙA ĐÔNG NƯỚC NGA", "1941", [
  "Ngày 22/6/1941, Hitler phá bỏ hiệp ước và tấn công Liên Xô. Đó là chiến dịch Barbarossa.",
  "Hơn ba triệu quân, trên một mặt trận dài gần ba nghìn cây số.",
  "Chỉ riêng ngày đầu tiên, hơn một nghìn máy bay Liên Xô bị phá hủy.",
  "Quân Đức tiến như vũ bão. Tháng 11, họ chỉ còn cách Moscow khoảng hai mươi cây số.",
  "Mùa thu, mưa biến đường đất thành biển bùn. Xe tăng sa lầy, ngựa kéo không nổi.",
  "Nhưng rồi mùa đông nước Nga ập đến. Lính Đức vẫn mặc quân phục mùa hè. Xe tăng đóng băng, súng không bắn được. Có lúc nhiệt độ xuống dưới âm ba mươi độ.",
  "Đầu tháng 12, Hồng quân phản công. Lần đầu tiên, quân Đức phải rút lui.",
  "Hitler muốn kết thúc trong vài tháng. Cuộc chiến ở phía đông kéo dài gần bốn năm.",
 ]),
 ("06", "tran-chau-cang", "TRÂN CHÂU CẢNG", "1941", [
  "Năm 1940, Nhật đưa quân vào Đông Dương. Họ muốn chiếm cả Đông Nam Á, nơi có dầu mỏ và cao su.",
  "Muốn vậy, phải đánh gục hạm đội Mỹ ở Thái Bình Dương trong một đòn.",
  "Sáng chủ nhật, ngày 7/12/1941. Hawaii yên bình.",
  "Một trạm radar phát hiện một đàn máy bay rất lớn. Họ nghĩ đó là máy bay Mỹ, và bỏ qua.",
  "7 giờ 55 phút, máy bay Nhật lao xuống Trân Châu Cảng.",
  "Hai đợt tấn công, hơn ba trăm năm mươi máy bay. Chiến hạm Arizona nổ tung, hơn một nghìn một trăm thủy thủ thiệt mạng.",
  "Gần hai mươi tàu chiến bị đánh chìm hoặc hư hại, gần hai trăm máy bay bị phá hủy.",
  "Tổng cộng, hai nghìn bốn trăm lẻ ba người Mỹ đã chết.",
  "Nhưng Nhật đã bỏ lỡ một thứ: ba tàu sân bay Mỹ hôm đó không có mặt ở cảng.",
  "Ngày hôm sau, Mỹ tuyên chiến. Người khổng lồ đang ngủ đã thức dậy, và cuộc chiến lan ra khắp thế giới.",
 ]),
 ("07", "midway", "MƯỜI PHÚT Ở MIDWAY", "1942", [
  "Sáu tháng sau Trân Châu Cảng, hải quân Nhật vẫn bất bại.",
  "Tháng 6 năm 1942, Nhật muốn kết liễu hạm đội Mỹ. Mục tiêu có mật danh AF.",
  "Các chuyên gia giải mã Mỹ đã đọc được mật mã Nhật. Họ đoán AF là đảo Midway, nhưng cần chắc chắn.",
  "Họ bày một cái bẫy: cho Midway gửi một tin giả, rằng máy lọc nước bị hỏng.",
  "Ít lâu sau, Nhật báo về: AF đang thiếu nước. Bắt được rồi!",
  "Ngày 4/6, đợt máy bay phóng ngư lôi Mỹ đầu tiên gần như bị tiêu diệt. Nhưng họ đã kéo máy bay tiêm kích Nhật xuống thấp.",
  "Ngay sau đó, máy bay ném bom bổ nhào Mỹ tìm thấy hạm đội Nhật, đúng lúc họ đang nạp nhiên liệu và bom.",
  "Chỉ trong khoảng mười phút, ba tàu sân bay Nhật bốc cháy. Chiếc thứ tư bị đánh trúng ngay chiều hôm đó.",
  "Nhật mất bốn tàu sân bay. Từ đây, thế chủ động ở Thái Bình Dương thuộc về Mỹ.",
 ]),
 ("08", "stalingrad", "STALINGRAD", "1942 – 1943", [
  "Mùa hè 1942, quân Đức tấn công Stalingrad, thành phố mang tên lãnh tụ Liên Xô.",
  "Bom biến thành phố thành đống đổ nát. Nhưng chính đống đổ nát lại trở thành pháo đài.",
  "Lính Liên Xô nhận lệnh: không lùi một bước.",
  "Hai bên giành nhau từng con phố, từng tòa nhà, từng tầng lầu. Lính Đức gọi đó là chiến tranh chuột, vì phải đánh nhau cả trong cống ngầm và tầng hầm.",
  "Có một tòa nhà được một nhóm lính Liên Xô giữ suốt gần hai tháng. Đến nay người ta vẫn gọi nó là Nhà Pavlov.",
  "Tháng 11, Hồng quân mở chiến dịch Sao Thiên Vương, bao vây gần ba trăm nghìn quân Đức và đồng minh.",
  "Mùa đông, đói và rét. Tháng 2 năm 1943, quân Đức đầu hàng. Gần một trăm nghìn người bị bắt.",
  "Gần hai triệu người thương vong. Stalingrad trở thành bước ngoặt của cả cuộc chiến.",
 ]),
 ("09", "enigma", "BẺ KHÓA ENIGMA", "1939 – 1945", [
  "Quân Đức tin rằng không ai đọc được tin nhắn của họ. Họ dùng một chiếc máy tên là Enigma.",
  "Mỗi lần gõ một phím, các bánh xoay chuyển động, và chữ cái biến thành một chữ hoàn toàn khác.",
  "Mã được đổi mỗi ngày. Số cách cài đặt nhiều đến mức thử từng cái thì cả đời cũng không xong.",
  "Các nhà toán học Ba Lan đã phá được Enigma từ trước chiến tranh, và trao lại bí mật cho Anh.",
  "Tại một khu nhà bí mật tên là Bletchley Park, hàng nghìn người làm việc ngày đêm.",
  "Nhà toán học trẻ Alan Turing thiết kế một cỗ máy giải mã tên là Bombe.",
  "Năm 1943, các cỗ máy này giải khoảng tám mươi tư nghìn tin nhắn mỗi tháng. Gần hai tin mỗi phút.",
  "Nhờ đó, các đoàn tàu vận tải biết tàu ngầm Đức nằm ở đâu để tránh.",
  "Có nhà sử học ước tính, công việc ở đây đã rút ngắn chiến tranh từ hai đến bốn năm. Và tất cả được giữ bí mật suốt mấy chục năm.",
 ]),
 ("10", "d-day", "D-DAY & ĐỘI QUÂN MA", "1944", [
  "Năm 1944, Đồng minh chuẩn bị đổ bộ vào Pháp. Câu hỏi lớn nhất là: ở đâu?",
  "Để đánh lừa Đức, họ dựng lên cả một đạo quân không có thật.",
  "Xe tăng bơm hơi, máy bay bằng gỗ và vải, tín hiệu radio giả, gián điệp hai mang. Cả tướng Patton cũng được giao chỉ huy đạo quân ma đó.",
  "Đêm trước ngày đổ bộ, họ còn thả cả những hình nộm nhảy dù, để quân Đức tưởng là lính dù thật.",
  "Hitler tin rằng cuộc đổ bộ chính sẽ diễn ra ở Calais.",
  "Nhưng ngày 6/6/1944, hơn năm nghìn tàu và khoảng một trăm năm mươi sáu nghìn quân đổ bộ lên năm bãi biển ở Normandy.",
  "Bãi Omaha đẫm máu nhất. Nhưng đến tối, Đồng minh đã đặt chân lên đất Pháp.",
  "Còn đơn vị chuyên làm đồ giả, khoảng một nghìn một trăm người, nhiều người là họa sĩ, đã lừa quân Đức hơn hai mươi lần nữa. Người ta gọi họ là Đội quân ma.",
 ]),
 ("11", "berlin", "BERLIN THẤT THỦ", "1944 – 1945", [
  "Tháng 8 năm 1944, Paris được giải phóng. Từ phía đông, Hồng quân tiến dần về Berlin.",
  "Mùa đông năm 1944, Đức tung đòn cuối cùng ở rừng Ardennes, nhưng thất bại.",
  "Khi tiến sâu vào nước Đức, quân Đồng minh tìm thấy các trại tập trung. Những gì họ thấy khiến cả thế giới bàng hoàng.",
  "Khoảng sáu triệu người Do Thái đã bị sát hại, trong cuộc diệt chủng mà ngày nay gọi là Holocaust.",
  "Ngày 25/4/1945, lính Mỹ và lính Liên Xô gặp nhau trên sông Elbe, và bắt tay nhau.",
  "Hồng quân tiến vào Berlin. Ngày 30/4, Hitler tự sát trong hầm ngầm. Lá cờ đỏ được cắm trên nóc tòa nhà Quốc hội Đức.",
  "Ngày 8/5/1945, Đức đầu hàng. Khắp châu Âu, người ta đổ ra đường ăn mừng.",
  "Nhưng ở châu Á, chiến tranh vẫn chưa kết thúc.",
 ]),
 ("12", "ket-thuc", "NGÀY THẾ GIỚI IM LẶNG", "1945", [
  "Mùa hè 1945, Nhật vẫn chưa đầu hàng. Mỹ quyết định dùng một loại vũ khí mới.",
  "8 giờ 15 phút sáng ngày 6/8/1945, một quả bom nguyên tử phát nổ trên Hiroshima.",
  "Ba ngày sau, quả thứ hai rơi xuống Nagasaki. Riêng các vụ nổ đã giết khoảng một trăm mười nghìn người, chưa kể những người chết vì phóng xạ sau đó.",
  "Ngày 15/8, Nhật hoàng tuyên bố đầu hàng qua radio.",
  "Ngày 2/9/1945, trên chiến hạm Missouri ở vịnh Tokyo, Nhật ký văn kiện đầu hàng. Thế chiến thứ hai chính thức kết thúc.",
  "Cũng đúng ngày hôm đó, ở Hà Nội, một đất nước khác tuyên bố độc lập.",
  "Sáu năm. Khoảng bảy mươi đến tám mươi lăm triệu người chết. Phần lớn là dân thường.",
  "Hàng triệu người lính trở về nhà, mang theo những vết thương không ai nhìn thấy.",
  "Liên Hợp Quốc ra đời với một lời hứa: không bao giờ để chuyện này lặp lại.",
 ]),
 ("13", "ket", "HẾT", "", [
  "Cảm ơn bạn đã xem đến cuối. Bạn muốn nghe tiếp câu chuyện nào? Hãy để lại bình luận nhé.",
 ]),
]

NAMES = {
 "Versailles": "véc xai", "Hitler": "hít le", "Adolf": "a đôn", "Blitzkrieg": "blít crích", "Ardennes": "ác đen",
 "Dunkirk": "đăn kơ", "Churchill": "chớc chin", "London": "luân đôn", "Blitz": "blít", "Barbarossa": "bác ba rốt xa",
 "Moscow": "mát xcơ va", "Hawaii": "ha oai", "Arizona": "a ri dô na", "AF": "a ép", "Midway": "mít uây",
 "Stalingrad": "xta lin grát", "Pavlov": "páp lốp", "Enigma": "ê níc ma", "Bletchley": "blét chờ li", "Park": "pác",
 "Alan": "a lan", "Turing": "tiu rinh", "Bombe": "bôm", "D-DAY": "đi đây", "Patton": "pát tơn", "Calais": "ca le",
 "Normandy": "noóc măng đi", "Omaha": "ô ma ha", "Paris": "pa ri", "Berlin": "béc lin", "Elbe": "en bơ",
 "Holocaust": "hô lô cốt", "Hiroshima": "hi rô si ma", "Nagasaki": "na ga xa ki", "Missouri": "mi xu ri", "Tokyo": "tô ky ô",
 "radar": "ra đa", "radio": "ra đi ô",
}
D = "không một hai ba bốn năm sáu bảy tám chín".split()
def n2(n, full=False):
    t, u = divmod(n, 10)
    if t == 0: return ("lẻ " + D[u]) if full and u else D[u]
    s = "mười" if t == 1 else D[t] + " mươi"
    if u == 0: return s
    if u == 1 and t > 1: return s + " mốt"
    if u == 5: return s + " lăm"
    if u == 4 and t > 1: return s + " tư"
    return s + " " + D[u]
def n3(n, full=False):
    h, r = divmod(n, 100)
    if h == 0 and not full: return n2(r)
    s = D[h] + " trăm"
    return s if r == 0 else s + " " + n2(r, True)
def num(n):
    if n < 1000: return n3(n)
    th, r = divmod(n, 1000)
    s = n3(th) + " nghìn"
    return s if r == 0 else s + " " + n3(r, True)
def spoken(tok):
    core = re.sub(r"^[\"“(]+|[.,:;!?\"”)]+$", "", tok)
    m = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{4})", core)
    if m: return f"{num(int(m[1]))} tháng {num(int(m[2]))} năm {num(int(m[3]))}"
    m = re.fullmatch(r"(\d{1,2})/(\d{1,2})", core)
    if m: return f"{num(int(m[1]))} tháng {num(int(m[2]))}"
    if re.fullmatch(r"\d+", core): return num(int(core))
    if core in NAMES: return NAMES[core]
    return None
def tokens(line):
    out = []
    for tok in line.split():
        sp = spoken(tok)
        out.append(tok if sp is None else tok + "|" + sp.replace(" ", "_"))
    return " ".join(out)

if __name__ == "__main__":
    meta = []
    for no, slug, title, years, lines in CH:
        d = f"/home/claude/ww2/ch{no}"; os.makedirs(d, exist_ok=True)
        segs = [{"id": f"s{i+1:02d}", "scene": f"c{no}_{i+1}", "lines": [tokens(l)]} for i, l in enumerate(lines)]
        json.dump(segs, open(f"{d}/script.json", "w"), ensure_ascii=False, indent=1)
        syl = sum(len(spoken(t).split()) if spoken(t) else 1 for l in lines for t in l.split())
        meta.append({"no": no, "slug": slug, "title": title, "years": years, "syl": syl})
        print(no, title, syl, "syl ~", round(syl / 3.7), "s")
    json.dump(meta, open("/home/claude/ww2/chapters.json", "w"), ensure_ascii=False, indent=1)
