"""War SFX (original procedural synthesis) for the WW2 film. Falls back to dope/sfx2 kinds."""
import sys, numpy as np
sys.path.insert(0, "/home/claude/film"); sys.path.insert(0, "/home/claude/dope")
import sfx2
from sfx import SR, t_, env, bp, lp, hp, noise, norm, pink, bell
rng = np.random.default_rng(7)
def _len(x, d): n = int(d * SR); return np.pad(x, (0, max(0, n - len(x))))[:n]
def shot(dist=0.0):
    t = t_(0.6); crack = hp(noise(0.6), 1500) * np.exp(-t * 60); body = lp(noise(0.6), 900) * np.exp(-t * 14); thump = np.sin(2 * np.pi * 70 * t) * np.exp(-t * 25)
    x = crack * (1 - dist) + body * 0.8 + thump * 0.6; tail = lp(pink(0.6), 600) * np.exp(-t * 5) * 0.25
    x = x + tail; return lp(x, 9000 - 7000 * dist) if dist else x
def boom(d=2.8, far=False):
    t = t_(d); low = lp(pink(d), 140) * np.exp(-t * (1.6 if not far else 1.1)); mid = bp(noise(d), 150, 1500) * np.exp(-t * 5)
    crack = hp(noise(d), 1200) * np.exp(-t * 30) * (0 if far else 0.8); sub = np.sin(2 * np.pi * (45 + 30 * np.exp(-t * 8)) * t) * np.exp(-t * 3)
    x = low * 1.6 + mid * 0.7 + crack + sub * 0.9; return lp(x, 900) if far else x
def whistle(d=1.6, f0=1800, f1=500):
    t = t_(d); f = f0 * (f1 / f0) ** (t / d); return np.sin(2 * np.pi * np.cumsum(f) / SR) * (0.3 + 0.7 * t / d) * 0.6 + bp(noise(d), 800, 3000) * 0.05
def engine(d, f=85, rough=0.4, lpf=900):
    t = t_(d); ph = 2 * np.pi * np.cumsum(f * (1 + 0.02 * np.sin(2 * np.pi * 0.7 * t))) / SR
    saw = 2 * ((ph / (2 * np.pi)) % 1) - 1; x = lp(saw, lpf) + lp(noise(d), 400) * rough
    return x * (0.8 + 0.2 * np.sin(2 * np.pi * 9 * t))
def make(kind, dur=None):
    d = dur or 1.0
    if kind.startswith("veo_"):
        import soundfile as _sf
        x, _ = _sf.read(f"/home/claude/ww2/assets/veo/{kind[4:]}.wav", dtype="float32"); n = int(d * SR) if dur else len(x); x = x[:n].copy(); f = int(0.3 * SR); x[-f:] *= np.linspace(1, 0, f); x[:int(0.05*SR)] *= np.linspace(0, 1, int(0.05*SR)); return x
    if kind == "rifle": return norm(shot(), 0.9)
    if kind == "rifle_far": return norm(shot(0.7), 0.5)
    if kind == "mg":
        x = np.zeros(int((d + 0.6) * SR)); s = shot(0.3)
        for st in np.arange(0, d, 1 / 11): p = int(st * SR); x[p:p + len(s)] += s[:len(x) - p] * rng.uniform(0.6, 1)
        return norm(x, 0.85)
    if kind == "volley":
        x = np.zeros(int((d + 0.6) * SR)); s = shot(0.4)
        for i in range(int(d * 4)): p = int(rng.uniform(0, d) * SR); x[p:p + len(s)] += s[:len(x) - p] * rng.uniform(0.3, 1)
        return norm(x, 0.8)
    if kind == "battle": # distant continuous battle ambience
        x = lp(pink(d), 300) * 0.5; s = shot(0.8); b = boom(2.0, True)
        for i in range(int(d * 3)): p = int(rng.uniform(0, d) * SR); x[p:p + len(s)] += s[:len(x) - p] * rng.uniform(0.2, 0.6)
        for i in range(int(d / 1.5)): p = int(rng.uniform(0, d) * SR); x[p:p + len(b)] += b[:len(x) - p] * rng.uniform(0.3, 0.7)
        return norm(x * env(len(x), 0.4, 0.6), 0.6)
    if kind == "boom": return norm(boom(), 1.0)
    if kind == "boom_far": return norm(boom(2.5, True), 0.7)
    if kind == "cannon": return norm(np.concatenate([boom(1.6)]), 0.95)
    if kind == "shell": w = whistle(1.2, 2200, 700); b = boom(); return norm(np.concatenate([w, b]), 0.95)
    if kind == "bombfall": return norm(whistle(d if dur else 1.8, 1600, 400), 0.6)
    if kind == "stuka": t = t_(d); f = 600 + 900 * (t / d) ** 1.5; return norm(np.sign(np.sin(2 * np.pi * np.cumsum(f) / SR)) * 0.25 + engine(d, 120, 0.3, 2000) * 0.6, 0.7) * env(int(d * SR), 0.3, 0.2)
    if kind == "plane": return norm(engine(d, 95, 0.5, 1200) * env(int(d * SR), 0.6, 0.6), 0.6)
    if kind == "bombers": return norm((engine(d, 70, 0.6, 700) + engine(d, 73.5, 0.6, 700)) * env(int(d * SR), 1.0, 1.0), 0.65)
    if kind == "planepass":
        d = dur or 2.6; t = t_(d); c = d / 2; f = 140 * (1 + 0.25 * np.tanh((c - t) * 2.2)); ph = 2 * np.pi * np.cumsum(f) / SR; saw = 2 * ((ph / (2 * np.pi)) % 1) - 1
        a = 1 / (1 + ((t - c) * 2.2) ** 2); return norm(lp(saw + lp(noise(d), 800) * 0.6, 2500) * a, 0.75)
    if kind == "dogfight":
        x = np.zeros(int(d * SR));
        for i in range(int(d / 1.6)): p = int(rng.uniform(0, max(0.1, d - 2.6)) * SR); y = make("planepass", 2.6); x[p:p + len(y)] += y[:len(x) - p] * rng.uniform(0.4, 0.8)
        for i in range(int(d / 2)): p = int(rng.uniform(0, max(0.1, d - 1)) * SR); y = make("mg", 0.6); x[p:p + len(y)] += y[:len(x) - p] * rng.uniform(0.2, 0.5)
        return norm(x, 0.7)
    if kind == "tank":
        t = t_(d); x = engine(d, 42, 0.8, 500) * 1.2; cl = np.zeros(len(t))
        for st in np.arange(0, d, 0.09): p = int(st * SR); k = bp(noise(0.03), 1500, 5000) * np.exp(-t_(0.03) * 200); cl[p:p + len(k)] += k[:len(cl) - p] * rng.uniform(0.2, 0.5)
        return norm((x + cl) * env(len(t), 0.4, 0.5), 0.7)
    if kind == "truck": return norm(engine(d, 55, 0.6, 600) * env(int(d * SR), 0.3, 0.4), 0.55)
    if kind == "march":
        x = np.zeros(int(d * SR))
        for i, st in enumerate(np.arange(0, d - 0.1, 0.32)): p = int(st * SR); k = lp(noise(0.12), 900) * np.exp(-t_(0.12) * 40) + np.sin(2 * np.pi * 90 * t_(0.12)) * np.exp(-t_(0.12) * 50); x[p:p + len(k)] += k[:len(x) - p] * (1 if i % 2 else 0.7)
        return norm(x, 0.6)
    if kind == "shiphorn": t = t_(d or 2.2); f = 92; x = sum(np.sin(2 * np.pi * f * m * t) / m for m in (1, 2, 3, 4)); return norm(lp(x, 900) * env(len(t), 0.15, 0.4), 0.7)
    if kind == "crowd":
        t = t_(d); x = np.zeros(len(t))
        for i in range(14): f = rng.uniform(300, 900); x += bp(noise(d), f, f * 1.8) * (0.5 + 0.5 * np.sin(2 * np.pi * rng.uniform(0.5, 2) * t + rng.uniform(0, 6)))
        return norm(x * env(len(t), 0.4, 0.6), 0.6)
    if kind == "cheer":
        t = t_(d); x = np.zeros(len(t))
        for i in range(20): f = rng.uniform(500, 1600); x += bp(noise(d), f, f * 1.5) * (0.6 + 0.4 * np.sin(2 * np.pi * rng.uniform(1, 4) * t))
        return norm(x * env(len(t), 0.15, 0.8), 0.75)
    if kind == "murmur": t = t_(d); return norm(bp(pink(d), 200, 900) * (0.7 + 0.3 * np.sin(2 * np.pi * 1.3 * t)) * env(len(t), 0.4, 0.4), 0.4)
    if kind == "static": t = t_(d); return norm(bp(noise(d), 1500, 6000) * (0.5 + 0.5 * (np.sin(2 * np.pi * 7 * t) > 0)) * env(len(t), 0.05, 0.1), 0.35)
    if kind == "morse":
        x = np.zeros(int(d * SR)); st = 0.0
        while st < d - 0.2: l = rng.choice([0.06, 0.18]); t = t_(l); k = np.sin(2 * np.pi * 750 * t) * env(len(t), 0.004, 0.004); p = int(st * SR); x[p:p + len(k)] += k[:len(x) - p]; st += l + rng.choice([0.07, 0.07, 0.2])
        return norm(x, 0.35)
    if kind == "ping": t = t_(1.2); return norm(np.sin(2 * np.pi * 1300 * t) * np.exp(-t * 4) + np.sin(2 * np.pi * 2600 * t) * np.exp(-t * 7) * 0.3, 0.45)
    if kind == "bells":
        x = np.zeros(int((d + 2) * SR)); notes = [523, 659, 784, 659, 587, 523, 440, 523]
        for i, st in enumerate(np.arange(0, d, 0.55)): b = bell(notes[i % len(notes)], 2.0); p = int(st * SR); x[p:p + len(b)] += b[:len(x) - p]
        return norm(x[:int(d * SR)], 0.55)
    if kind == "flak":
        x = np.zeros(int(d * SR))
        for i in range(int(d * 2.5)): p = int(rng.uniform(0, d - 0.3) * SR); k = lp(noise(0.5), 700) * np.exp(-t_(0.5) * 12); x[p:p + len(k)] += k[:len(x) - p] * rng.uniform(0.3, 1)
        return norm(x, 0.55)
    if kind == "airraid":
        t = t_(d); f = 420 + 260 * (0.5 - 0.5 * np.cos(2 * np.pi * t / 5.0)); x = np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.3 * np.sin(2 * np.pi * np.cumsum(f * 2) / SR)
        return norm(x * env(len(t), 0.8, 1.0), 0.45)
    if kind == "whistle_blow": t = t_(0.7); f = 2600 * (1 + 0.04 * np.sin(2 * np.pi * 40 * t)); return norm(np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.02, 0.1), 0.45)
    if kind == "ring": t = t_(d); return norm(np.sin(2 * np.pi * 3800 * t) * np.exp(-t * 0.6) * env(len(t), 0.05, 0.5), 0.3)
    if kind == "silence": return np.zeros(int(d * SR))
    if kind == "splash_big": return sfx2.make("splash")
    if kind == "typewriter": return sfx2.make("typing", d)
    if kind == "radio_voice": t = t_(d); x = bp(noise(d), 300, 2500) * (0.5 + 0.5 * np.sin(2 * np.pi * 4 * t) * np.sin(2 * np.pi * 1.1 * t)); return norm(x * env(len(t), 0.1, 0.1), 0.35)
    if kind == "drum_roll": t = t_(d); x = bp(noise(d), 150, 1200) * (0.6 + 0.4 * np.sin(2 * np.pi * 18 * t)); return norm(x * env(len(t), 0.1, 0.3), 0.5)
    if kind == "rotor": return sfx2.make("clock_fast", d)
    return sfx2.make(kind, dur)
