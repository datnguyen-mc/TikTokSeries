// scene helpers shared by chapter scene files
import { W, H, clamp } from "./core.mjs";
export const FOCUS = { x: W / 2, cut: 0 };
export const focus = (x) => { FOCUS.x = x; };
// shots: list of [wordIndex, fn(ctx, lt, d, W2)], cuts happen at word times (wordIndex 0 = segment start).
// wordIndex may also be a number with "s" suffix? use {t: seconds} objects for time-based cuts.
export function shots(ctx, t, s, list) {
  const st = list.map(([wi]) => typeof wi === "object" ? wi.t : (wi === 0 ? 0 : s.w[wi] - 0.08));
  let i = 0; while (i + 1 < list.length && t >= st[i + 1]) i++;
  const t0 = st[i], t1 = i + 1 < list.length ? st[i + 1] : s.d; const lt = t - t0;
  FOCUS.x = W / 2; FOCUS.shot = s.id + ":" + i;
  ctx.save(); list[i][1](ctx, lt, t1 - t0, (k) => s.w[k] - t0); ctx.restore();
  if (lt < 0.08 && i > 0) { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = `rgba(255,255,255,${0.18 * (1 - lt / 0.08)})`; ctx.fillRect(0, 0, W, H); ctx.restore(); }
}
export const GY = 960; // default ground line
export const PENDING = new Set();
