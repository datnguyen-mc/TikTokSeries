import json, os
R = '/home/claude/ww2'; OUT = f'{R}/deliver'
meta = {m['no']: m for m in json.load(open(f'{R}/chapters.json'))}
idx = json.load(open(f'{R}/film_index.json'))
SRC = """- History.com – Dunkirk; Battle of Midway; Operation Barbarossa; D-Day; Battle of Stalingrad; 10 Things about the Battle of Britain
- Smithsonian Magazine – How Hyperinflation Heralded the Fall of German Democracy
- HistoryNet – Ten Minutes at Midway
- Live Science – Pearl Harbor attack
- OUP Blog (Jack Copeland) – Alan Turing: codebreaker
- Mental Floss – V-J Day facts
- WWII Memorial Friends – The Ghost Army of World War II
- HistorySkills – How the Allies won WWII in Europe"""
film = f"""# THẾ CHIẾN II – 6 năm đổi cả thế giới (phim stickman ~{round(idx['total']/60,1)} phút)

## Tiêu đề (chọn 1)
1. THẾ CHIẾN II kể bằng người que – 6 năm đổi cả thế giới
2. Toàn bộ Thế chiến thứ hai trong {round(idx['total']/60)} phút (hoạt hình stickman)
3. Từ Versailles đến Hiroshima: câu chuyện Thế chiến II

## Mô tả
Từ Hiệp ước Versailles 1919 đến ngày Nhật ký văn kiện đầu hàng 2/9/1945 – cũng là ngày Việt Nam tuyên bố độc lập. 12 chương: Blitzkrieg, Dunkirk, Trận chiến nước Anh, Barbarossa, Trân Châu Cảng, Midway, Stalingrad, Enigma, D-Day & Đội quân ma, Berlin, Hiroshima.

Chương:
{chr(10).join(idx['chapters'])}

## Hashtag
#thechien2 #lichsu #ww2 #stickman #kechuyenlichsu #lichsuthegioi #hoathinh

## Tags
thế chiến 2, chiến tranh thế giới thứ hai, lịch sử thế giới, stickman, hoạt hình lịch sử, Dunkirk, Stalingrad, Trân Châu Cảng, Midway, D-Day, Enigma, Alan Turing, Hiroshima, 2/9/1945

## Bình luận ghim
Bạn muốn xem phim tiếp theo về chủ đề nào: Chiến tranh Lạnh, Thế chiến I, hay Điện Biên Phủ?

## Ghi chú
- Không dùng biểu tượng chữ thập ngoặc; lãnh tụ được thể hiện dạng bóng/nhân vật chung.
- Số liệu làm tròn theo các nguồn dưới đây; một số con số (thương vong) là ước tính.

## Nguồn
{SRC}
"""
open(f'{OUT}/phim_16x9/YT_THE_CHIEN_II_phim.md', 'w').write(film)
HOOK = {'01': 'Vì sao nước Đức lại muốn chiến tranh?', '02': '1 tháng để xóa sổ một quốc gia', '03': 'Những chiếc thuyền đánh cá cứu cả một đạo quân', '04': 'Vũ khí bí mật giúp nước Anh sống sót', '05': 'Mùa đông đánh bại cỗ máy chiến tranh', '06': 'Buổi sáng chủ nhật thay đổi lịch sử', '07': '10 phút lật ngược cả Thái Bình Dương', '08': 'Trận chiến đẫm máu nhất lịch sử', '09': 'Những người phá mật mã "không thể phá"', '10': 'Đạo quân bằng bóng bay lừa cả Hitler', '11': 'Những ngày cuối cùng của Đức Quốc xã', '12': '2/9/1945 – ngày thế giới im lặng'}
sh = ["# 12 SHORTS – THẾ CHIẾN II (9:16)\n"]
for c in [f'{i:02d}' for i in range(1, 13)]:
    sh.append(f"## Phần {int(c)}/12 – {meta[c]['title'].title()} ({meta[c]['years']})\n- Tiêu đề: {HOOK[c]} | Thế chiến II #{int(c)}\n- Mô tả: Phần {int(c)}/12 series Thế chiến II kể bằng người que. Xem bản đầy đủ trên kênh.\n- Hashtag: #thechien2 #lichsu #ww2 #stickman #shorts\n")
sh.append("## Nguồn\n" + SRC)
open(f'{OUT}/shorts_9x16/YT_shorts.md', 'w').write('\n'.join(sh))
print('ok')
