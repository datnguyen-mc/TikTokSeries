"""Build a MakeMyClip timeline from a short project and export FCPXML / Premiere XML / mp4.
usage: python3 build.py <projdir> <name>"""
import json, subprocess, sys, os
P, NAME = sys.argv[1], sys.argv[2]; PRO = f'{P}/pro'
env = dict(os.environ, PATH='/opt/node24/bin:' + os.environ['PATH'], MAKEMYCLIP_WORKSPACE=PRO, MAKEMYCLIP_FFMPEG_PATH='/usr/bin/ffmpeg')
CLIP = ['/home/claude/mmc-run/node_modules/.bin/clip', 'timeline']
def clip(*a):
    r = subprocess.run(CLIP + [str(x) for x in a], cwd=PRO, env=env, capture_output=True, text=True)
    if r.returncode: raise SystemExit(f'clip {a[:3]} failed: {r.stderr[-800:]}')
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
TL = json.load(open(f'{P}/timeline.json')); caps = json.load(open(f'{PRO}/captions.json'))
END = TL['duration'] + 0.6
for f in ['composition.json']:
    if os.path.exists(f'{PRO}/{f}'): os.remove(f'{PRO}/{f}')
clip('new', '--width', 720, '--height', 1280, '--fps', 30)
segs = TL['segments']
for i, s in enumerate(segs):
    a = 0 if i == 0 else s['start']; b = END if i == len(segs) - 1 else segs[i + 1]['start']
    clip('add-media', 'video_clean.mp4', round(a, 3), round(b, 3), '--start', round(a, 3), '--track', 'V1')
for k, t in []:
    clip('add-media', f'{k}.wav', 0, round(END, 3), '--start', 0, '--track', t)
for c in caps:
    d = round(max(0.15, c['e'] - c['s']), 3)
    clip('add-text', c['text'], d, '--start', round(c['s'], 3), '--track', 'CAP', '--font', 64, '--color', 'white', '--anchor', 'bottom-center')
show = clip('show')
for fmt, ext in [('fcpxml', 'fcpxml'), ('xmeml', 'xml')]:
    print(fmt, clip('export', f'{NAME}.{ext}', '--format', fmt))
print(json.dumps(show)[:600])
