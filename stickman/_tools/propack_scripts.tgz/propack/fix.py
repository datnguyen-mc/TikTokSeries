"""Point exported projects at the user's Mac folder and style captions like the short.
usage: python3 fix.py <prodir> <name> <device_pro_dir>"""
import sys, re
PRO, NAME, DEV = sys.argv[1:4]
for ext, old, new in [('fcpxml', f'file://{PRO}/', f'file://{DEV}/'), ('xml', f'file://localhost{PRO}/', f'file://localhost{DEV}/')]:
    p = f'{PRO}/{NAME}.{ext}'; s = open(p, encoding='utf-8').read().replace(old, new)
    if ext == 'fcpxml':
        s = s.replace('value="0 -568"', 'value="0 -345"')
        s = s.replace('font="Helvetica" fontSize="64" fontColor="1 1 1 1"', 'font="Arial Black" fontSize="62" fontColor="1 1 1 1" strokeColor="0 0 0 1" strokeWidth="6"')
    open(p, 'w', encoding='utf-8').write(s)
    print(ext, s.count(new))
