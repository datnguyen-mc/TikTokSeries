"""Write voice / music / sfx stems (ducked, common gain) for a short project.
usage: python3 stems.py <projdir> <musicfn: heist|future> <music_gain> <outdir>"""
import json, sys, subprocess, numpy as np, soundfile as sf
P, MF, MG, OUT = sys.argv[1], sys.argv[2], float(sys.argv[3]), sys.argv[4]
sys.path.insert(0, P); sys.path.insert(0, '/home/claude/dope'); sys.path.insert(0, '/home/claude/film')
import music_e, sfx2
from scipy.ndimage import uniform_filter1d, maximum_filter1d
SR = music_e.SR
ev = json.load(open(f'{P}/events.json')); N = int(ev['duration'] * SR)
v, _ = sf.read(f'{P}/narration.wav', dtype='float32'); vv = np.zeros(N, np.float32); vv[:min(N, len(v))] = v[:N]
def buf(): return np.zeros(N, np.float32)
mus, fx = buf(), buf()
def place(B, x, t, g):
    p = int(t * SR)
    if p >= N: return
    n = min(len(x), N - p); B[p:p + n] += x[:n] * g
m = getattr(music_e, MF)(ev['duration']); f = int(1.5 * SR); m[-f:] *= np.linspace(1, 0, f); place(mus, m, 0, MG)
for e in ev['events']:
    try: place(fx, np.asarray(sfx2.make(e['k'], e.get('dur')), np.float32), e['t'], e['gain'] * 0.75)
    except Exception as ex: print('sfx', e['k'], ex)
env = uniform_filter1d(maximum_filter1d(np.abs(vv), int(0.08 * SR)), int(0.3 * SR)); duck = 1 - 0.6 * np.clip(env / 0.07, 0, 1)
mus *= duck; fx *= duck
mix = vv + mus + fx
sf.write('/tmp/_mix.wav', np.stack([mix, mix], 1), SR, subtype='FLOAT')
r = subprocess.run(['ffmpeg', '-hide_banner', '-i', '/tmp/_mix.wav', '-af', 'ebur128', '-f', 'null', '-'], capture_output=True, text=True).stderr
I = float([l for l in r.splitlines() if l.strip().startswith('I:')][-1].split()[1])
g = 10 ** ((-14 - I) / 20); pk = np.abs(mix).max() * g
if pk > 0.95: g *= 0.95 / pk
for name, x in [('voice', vv), ('music', mus), ('sfx', fx), ('mix', mix)]:
    sf.write(f'{OUT}/{name}.wav', np.stack([x * g, x * g], 1), SR, subtype='PCM_24')
print('I', I, 'gain_db', round(20 * np.log10(g), 2))
